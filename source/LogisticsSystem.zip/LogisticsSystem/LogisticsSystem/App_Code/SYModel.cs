﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace LogisticsSystem.App_Code
{
    public class SYModel :IDisposable
    {
        private Dictionary<String, Object> m_Data;
        private SqlCommand m_Cmd = null;
        private List<SqlParameter> m_para;
        public SYModel()
        {
            m_Data = new Dictionary<string, object>();
            m_para = new List<SqlParameter>();
            m_Cmd = new SqlCommand();
            m_Cmd.Connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString);
        }
        public void Dispose()
        {
            m_Data.Clear();
            m_Cmd.Connection.Dispose();
            m_Cmd.Dispose();
        }
        protected Object Get(String key)
        {
            key = key.ToLower();
            if (m_Data.ContainsKey(key))
            {
                return m_Data[key];
            }
            else
            {
                return null;
            }
        }
        protected Object Get(String key,Type pType)
        {
            key = key.ToLower();
            Object pRet = Get(key);
            if(pRet == null || pRet == DBNull.Value)
            {
                if(pType == typeof(String))
                {
                    return "";
                }
                else if(pType == typeof(DateTime))
                {
                    return new DateTime();
                }
                else if(pType == typeof(Int64))
                {
                    return 0L;
                }
                else if(pType == typeof(Decimal))
                {
                    return new Decimal(0);
                }
                else
                {
                    return 0;
                }
            }
            return pRet;
        }
        protected void Set(String key,Object value)
        {
            key = key.ToLower();
            if (m_Data.ContainsKey(key))
            {
                m_Data[key] = value;
            }
            else
            {
                m_Data.Add(key, value);
            }
        }
        public void Add(String key,Object value)
        {
            key = key.ToLower();
            if (m_Data.ContainsKey(key))
            {
                m_Data[key] = value;
            }
            else
            {
                m_Data.Add(key, value);
            }
        }
        public void Remove(String key)
        {
            key = key.ToLower();
            if (m_Data.ContainsKey(key))
            {
                m_Data.Remove(key);
            }
        }
        public void Clear()
        {
            m_Data.Clear();
        }
        protected int Insert(String query, SqlParameter[] para)
        {
            int pRet = -1;
            m_Cmd.CommandText = query;
            m_Cmd.Parameters.Clear();
            m_Cmd.Parameters.AddRange(para);
            try
            {
                m_Cmd.Connection.Open();
                pRet = m_Cmd.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                LogWriter.Instance().LogWrite("Insert Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
                    foreach (SqlParameter pBuffer in para)
                        LogWriter.Instance().LogWrite("PARAMETER - " + pBuffer.ToString() + " : " + pBuffer.Value.ToString());
                pRet = -1;
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected int Insert(String query)
        {
            int pRet = -1;
            m_Cmd.CommandText = query;
            try
            {
                m_Cmd.Connection.Open();
                pRet = m_Cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                LogWriter.Instance().LogWrite("Insert Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected bool Select(CommandType pType,String query,SqlParameter[] para)
        {
            bool pRet = false;
            m_Data.Clear();
            m_Cmd.CommandType = pType;
            m_Cmd.CommandText = query;
            m_Cmd.Parameters.Clear();
            if (para != null) 
            { 
                m_Cmd.Parameters.AddRange(para);
            }
            try
            {
                m_Cmd.Connection.Open();
                using (SqlDataReader dr = m_Cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        for (int i = 0; i < dr.FieldCount; i++)
                        {
                            m_Data.Add(dr.GetName(i).ToLower(), dr.GetValue(i));
                        }
                        pRet = true;
                    }
                }
            }
            catch(Exception e)
            {
                LogWriter.Instance().LogWrite("Select Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
                if (para != null)
                    foreach(SqlParameter pBuffer in para)
                        LogWriter.Instance().LogWrite("PARAMETER - "+ pBuffer.ToString() +" : "+ pBuffer.Value.ToString());
                pRet = false;
            }
            finally {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected bool Select(String query)
        {
            return Select(CommandType.Text, query, null);
        }
        protected bool Select(CommandType pType, String query)
        {
            return Select(pType, query, null);
        }
        protected bool Select(String query, SqlParameter[] para)
        {
            return Select(CommandType.Text, query, para);
        }
        protected void ParameterInit()
        {
            m_para.Clear();
        }
        protected void ParameterAdd(String key,Object value)
        {
            m_para.Add(new SqlParameter(key, value));
        }
        protected SqlParameter[] GetParameter()
        {
            if(m_para.Count > 0)
            {
                SqlParameter[] pRet = new SqlParameter[m_para.Count];
                for (int i = 0; i < m_para.Count ; i++ )
                {
                    pRet[i] = m_para[i];
                }
                return pRet;
            }
            else
            {
                return null;
            }
        }
        protected List<String> GetKey()
        {
            return new List<string>(m_Data.Keys);
        }
        protected int Delete(String query, SqlParameter[] para)
        {
            int pRet = -1;
            m_Cmd.CommandText = query;
            m_Cmd.Parameters.Clear();
            m_Cmd.Parameters.AddRange(para);
            try
            {
                m_Cmd.Connection.Open();
                pRet = m_Cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                LogWriter.Instance().LogWrite("Delete Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
                foreach (SqlParameter pBuffer in para)
                    LogWriter.Instance().LogWrite("PARAMETER - " + pBuffer.ToString() + " : " + pBuffer.Value.ToString());
                pRet = -1;
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected int Update(String query, SqlParameter[] para)
        {
            int pRet = -1;
            m_Cmd.CommandText = query;
            m_Cmd.Parameters.Clear();
            m_Cmd.Parameters.AddRange(para);
            try
            {
                m_Cmd.Connection.Open();
                pRet = m_Cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                LogWriter.Instance().LogWrite("Update Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
                foreach (SqlParameter pBuffer in para)
                    LogWriter.Instance().LogWrite("PARAMETER - " + pBuffer.ToString() + " : " + pBuffer.Value.ToString());
                pRet = -1;
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected Int64 ScopeIndentity(String table)
        {
            Int64 pRet = 0;
            m_Cmd.CommandType = CommandType.Text;
            m_Cmd.CommandText = "SELECT IDENT_CURRENT('"+table+"');";
            m_Cmd.Parameters.Clear();
            try
            {
                m_Cmd.Connection.Open();
                using (SqlDataReader dr = m_Cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        pRet = Convert.ToInt64(dr.GetValue(0));
                    }
                }
            }
            catch (Exception e)
            {
                LogWriter.Instance().LogWrite("Scope Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected bool NullCheck(String obj){
            if (obj == null || obj.Trim().Equals(String.Empty))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}