﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace LogisticsSystem.App_Code
{
    public abstract class SYModelList<T> : List<T>, IDisposable
    {
        private SqlCommand m_Cmd = null;
        private List<SqlParameter> m_para;
        public SYModelList()
        {
            m_para = new List<SqlParameter>();
            m_Cmd = new SqlCommand();
            m_Cmd.Connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString);
        }
        public void Dispose()
        {
            Clear();
            m_Cmd.Connection.Dispose();
            m_Cmd.Dispose();
        }
        protected int SelectList(CommandType pType, String query, SqlParameter[] para,bool pClear = true)
        {
            int pRet = 0;
            if (pClear)
                Clear();
            m_Cmd.CommandType = pType;
            m_Cmd.CommandText = query;
            m_Cmd.Parameters.Clear();
            if (para != null)
            {
                m_Cmd.Parameters.AddRange(para);
            }
            try
            {
                m_Cmd.Connection.Open();
                using (SqlDataReader dr = m_Cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        dynamic pNode = (T)Activator.CreateInstance(typeof(T));
                        for (int i = 0; i < dr.FieldCount; i++)
                        {
                            pNode.Add(dr.GetName(i).ToLower(), dr.GetValue(i));
                            //AddNode(ref pNode, dr.GetName(i).ToLower(), dr.GetValue(i));
                        }
                        Add((T)pNode);
                        pRet++;
                    }
                }
            }
            catch (Exception e)
            {
                LogWriter.Instance().LogWrite("SelectList Excepion");
                LogWriter.Instance().LogWrite("Error Code - " + e.ToString());
                LogWriter.Instance().LogWrite("QUERY - " + query);
                if (para != null)
                    foreach (SqlParameter pBuffer in para)
                        LogWriter.Instance().LogWrite("PARAMETER - " + pBuffer.ToString() + " : " + pBuffer.Value.ToString());
                pRet = 0;
            }
            finally
            {
                m_Cmd.Connection.Close();
            }
            return pRet;
        }
        protected int SelectList(String query)
        {
            return SelectList(CommandType.Text, query, null);
        }
        protected int SelectList(CommandType pType, String query)
        {
            return SelectList(pType, query, null);
        }
        protected int SelectList(String query, SqlParameter[] para)
        {
            return SelectList(CommandType.Text, query, para);
        }
        protected void ParameterInit()
        {
            m_para.Clear();
        }
        protected void ParameterAdd(String key, Object value)
        {
            m_para.Add(new SqlParameter(key, value));
        }
        protected SqlParameter[] GetParameter()
        {
            if (m_para.Count > 0)
            {
                SqlParameter[] pRet = new SqlParameter[m_para.Count];
                for (int i = 0; i < m_para.Count; i++)
                {
                    pRet[i] = m_para[i];
                }
                return pRet;
            }
            else
            {
                return null;
            }
        }
        //protected abstract void AddNode(ref T pNode ,String key,object value);
    }
}