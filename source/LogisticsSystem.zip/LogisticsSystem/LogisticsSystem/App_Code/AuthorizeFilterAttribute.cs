﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace LogisticsSystem.App_Code
{
    public class AuthorizeFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.User.Identity.IsAuthenticated &&
                filterContext.HttpContext.Session["userinfo"] != null &&
                filterContext.HttpContext.Session["compinfo"] != null
                )
            {
                FormsAuthentication.SetAuthCookie(filterContext.HttpContext.User.Identity.Name, false);
                filterContext.HttpContext.Session["userinfo"] = filterContext.HttpContext.Session["userinfo"];
                filterContext.HttpContext.Session["compinfo"] = filterContext.HttpContext.Session["compinfo"];
                filterContext.HttpContext.Session["AuthCheck"] = true;
            }
            else
            {
                FormsAuthentication.SignOut();
                filterContext.HttpContext.Session.Clear();
                filterContext.HttpContext.Session.RemoveAll();
                filterContext.HttpContext.Session["AuthCheck"] = false;
            }
            base.OnActionExecuting(filterContext);
        }
    }
}