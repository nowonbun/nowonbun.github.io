﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace LogisticsSystem.App_Code
{
    public class AjaxFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpSessionStateBase session = filterContext.HttpContext.Session;
            if (filterContext.HttpContext.Request.Cookies["SessionID"] == null)
            {
                session["AjaxCheck"] = false;
            }
            else
            {
                String cookiesSessionID = filterContext.HttpContext.Request.Cookies["SessionID"].Value;
                String sessionID = session["SessionID"].ToString();
                if (sessionID != null && sessionID.Equals(cookiesSessionID))
                {
                    session["AjaxCheck"] = true;
                }
                else
                {
                    session["AjaxCheck"] = false;
                }
            }
        }
    }
}