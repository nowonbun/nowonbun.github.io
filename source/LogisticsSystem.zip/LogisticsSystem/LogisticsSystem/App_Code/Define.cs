﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LogisticsSystem.App_Code
{
    public class Define
    {
        public const String MASTER_VIEW = "~/Views/Master.cshtml";
        public const String POPUP_VIEW = "~/Views/PopupMaster.cshtml";

        public const int STATE_NORMAL = 0;
        public const int STATE_DELETE = 1;
        public const int STATE_APPLY = 2;
    }
}