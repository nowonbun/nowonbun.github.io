﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace LogisticsSystem.App_Code
{
    public class SyController : Controller
    {
        public virtual ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            return Redirect(FormsAuthentication.LoginUrl);
        }
        public ActionResult ErrorPage(String strUrl) 
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            return Redirect(strUrl);
        }
        protected override ViewResult View(string viewName, string masterName, object model)
        {
            String controller = (String)Session["controller"];
            String action = (String)Session["action"];
            Session["viewName"] = viewName;
            
            String pLanguage = Request.Form["Lang"];
            if (pLanguage != null && !"".Equals(pLanguage))
            {
                if("k".Equals(pLanguage))
                {
                    Session["languageType"] = LanguageType.Korea;
                }
                else
                {
                    Session["languageType"] = LanguageType.Japan;
                }
            }
            LanguageType? lType = (LanguageType?)Session["languageType"];

            if (controller != null && action != null)
            {
                ViewBag.Disp = new LanguagePack(Server.MapPath("~/Language"),controller, action, lType);
            }
            if (Define.MASTER_VIEW.Equals(masterName))
            {
                Session["master"] = masterName;
                ViewBag.Master = new LanguagePack(Server.MapPath("~/Language"), "./", "Master", lType);
                ViewBag.Navigate = new NagationPack(Server.MapPath("~/Navigation"), controller, action, lType);
            }
            else
            {
                Session["master"] = null;
            }
            Session["SessionID"] = SessionIDCreate();
            ViewBag.SessionID = Session["SessionID"];
            return base.View(viewName, masterName, model);
        }
        private String SessionIDCreate()
        {
            DateTime pDate = DateTime.Now;
            Random ran = new Random(1000);
            return ran.Next(1000).ToString("0000") + pDate.ToString("yyyyMMddhhmmss");
        }
        protected ContentResult Empty()
        {
            return Content("");
        }
        protected bool SessionCheck(String name)
        {
            if (Session[name] != null && (bool)Session[name])
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        protected ContentResult NoAjax()
        {
            return Content(null);
        }
    }
}