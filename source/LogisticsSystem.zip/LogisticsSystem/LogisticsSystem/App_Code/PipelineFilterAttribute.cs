﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LogisticsSystem.App_Code
{
    public class PipelineFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpSessionStateBase session = filterContext.HttpContext.Session;
            session["controller"] = filterContext.RouteData.Values["controller"];
            session["action"] = filterContext.RouteData.Values["action"];
            String master = (String)session["master"];
            session["SessionCheck"] = true;
            session["BrowserCheck"] = true;
            //Cross Page
            if (Define.MASTER_VIEW.Equals(master))
            {
                String SessionID = (String)session["SessionID"];
                if (SessionID != null)
                {
                    if (false && !SessionID.Equals(filterContext.HttpContext.Request.Form["SessionID"]))
                    {
                        filterContext.HttpContext.Session.Clear();
                        filterContext.HttpContext.Session.RemoveAll();
                        session["SessionCheck"] = false;
                    }
                }
            }
            if (filterContext.HttpContext.Request.Browser.Browser.ToLower().IndexOf("explorer") != -1 ||
                filterContext.HttpContext.Request.Browser.Browser.ToLower().IndexOf("ie") != -1
                )
            {
                if (false && Convert.ToDouble(filterContext.HttpContext.Request.Browser.Version) < 10)
                {
                    filterContext.HttpContext.Session.Clear();
                    filterContext.HttpContext.Session.RemoveAll();
                    session["BrowserCheck"] = false;
                }
            }
            base.OnActionExecuting(filterContext);
        }
    }
}