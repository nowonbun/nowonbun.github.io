﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class ProductInfoList : SYModelList<ProductInfo>
    {
        public ProductInfoList()
        {
        }
        /// <summary>
        /// 상품리스트검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <returns></returns>
        public int ProductNameList(String companycode)
        {
            ParameterInit();
            ParameterAdd("companycode", companycode);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" idx,productname ");
            sb.Append(" FROM tbl_ProductInfo ");
            sb.Append(" WHERE state = @state and companycode = @companycode ");
            sb.Append(" order by idx desc");
            return SelectList(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 상품검색DAO
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int SelectList(int pageLimit, int page, String compcode)
        {
            ParameterInit();
            ParameterAdd("companyCode", compcode);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_ProductInfo ");
            sb.Append(" WHERE state = @state and companyCode=@companyCode");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_ProductInfo WHERE state = @state and companyCode=@companyCode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 상품테이블 전체 갯수 구하는 함수(페이징용)
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int ProductInfoCount(String compcode)
        {
            ParameterInit();
            ParameterAdd("companyCode", compcode);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_ProductInfo ");
            sb.Append(" WHERE state = @state and companyCode=@companyCode ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 상품 이력 리스트 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int ProductInfoHistorySearch(int pageLimit, int page, string code, String compcode)
        {
            ParameterInit();
            ParameterAdd("productcode", code);
            ParameterAdd("companyCode", compcode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_ProductInfo ");
            sb.Append(" WHERE productcode = @productcode and companyCode=@companyCode ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_ProductInfo WHERE productcode = @productcode and companyCode=@companyCode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 상품 이력 리스트 총 개수(페이징용)
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int ProductInfoHistoryCount(String code, String compcode)
        {
            ParameterInit();
            ParameterAdd("code", code);
            ParameterAdd("companyCode", compcode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_ProductInfo ");
            sb.Append(" WHERE productcode = @code and companyCode=@companyCode ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
    }
}