﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class CompanyInfo : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 회사코드
        /// </summary>
        public String companyCode
        {
            get { return (String)Get("companyCode", typeof(String)); }
            set { Set("companyCode", value); }
        }
        /// <summary>
        /// 회사이름
        /// </summary>
        public String companyName
        {
            get { return (String)Get("companyName", typeof(String)); }
            set { Set("companyName", value); }
        }
        /// <summary>
        /// 회사주소
        /// </summary>
        public String companyAddress
        {
            get { return (String)Get("companyAddress", typeof(String)); }
            set { Set("companyAddress", value); }
        }
        /// <summary>
        /// 회사우편번호
        /// </summary>
        public String companyPostnumber
        {
            get { return (String)Get("companyPostnumber", typeof(String)); }
            set { Set("companyPostnumber", value); }
        }
        /// <summary>
        /// 회사우편번호1
        /// </summary>
        public String companyPostnumber1
        {
            get { return (String)Get("companyPostnumber1", typeof(String)); }
            set { Set("companyPostnumber1", value); }
        }
        /// <summary>
        /// 회사우편번호2
        /// </summary>
        public String companyPostnumber2
        {
            get { return (String)Get("companyPostnumber2", typeof(String)); }
            set { Set("companyPostnumber2", value); }
        }
        /// <summary>
        /// 회사사업자번호
        /// </summary>
        public String companySecurityNumber
        {
            get { return (String)Get("companySecurityNumber", typeof(String)); }
            set { Set("companySecurityNumber", value); }
        }
        /// <summary>
        /// 대표자명
        /// </summary>
        public String representative
        {
            get { return (String)Get("representative", typeof(String)); }
            set { Set("representative", value); }
        }
        /// <summary>
        /// 대표자 전화번호
        /// </summary>
        public String representativeNumber
        {
            get { return (String)Get("representativeNumber", typeof(String)); }
            set { Set("representativeNumber", value); }
        }
        /// <summary>
        /// 대표자 전화번호1
        /// </summary>
        public String representativeNumber1
        {
            get { return (String)Get("representativeNumber1", typeof(String)); }
            set { Set("representativeNumber1", value); }
        }
        /// <summary>
        /// 대표자 전화번호2
        /// </summary>
        public String representativeNumber2
        {
            get { return (String)Get("representativeNumber2", typeof(String)); }
            set { Set("representativeNumber2", value); }
        }
        /// <summary>
        /// 대표자 전화번호3
        /// </summary>
        public String representativeNumber3
        {
            get { return (String)Get("representativeNumber3", typeof(String)); }
            set { Set("representativeNumber3", value); }
        }
        /// <summary>
        /// 회사전화번호
        /// </summary>
        public String companyNumber
        {
            get { return (String)Get("companyNumber", typeof(String)); }
            set { Set("companyNumber", value); }
        }
        /// <summary>
        /// 회사전화번호1
        /// </summary>
        public String companyNumber1
        {
            get { return (String)Get("companyNumber1", typeof(String)); }
            set { Set("companyNumber1", value); }
        }
        /// <summary>
        /// 회사전화번호2
        /// </summary>
        public String companyNumber2
        {
            get { return (String)Get("companyNumber2", typeof(String)); }
            set { Set("companyNumber2", value); }
        }
        /// <summary>
        /// 회사전화번호3
        /// </summary>
        public String companyNumber3
        {
            get { return (String)Get("companyNumber3", typeof(String)); }
            set { Set("companyNumber3", value); }
        }
        /// <summary>
        /// 회사팩스번호
        /// </summary>
        public String companyFax
        {
            get { return (String)Get("companyFax", typeof(String)); }
            set { Set("companyFax", value); }
        }
        /// <summary>
        /// 회사팩스번호1
        /// </summary>
        public String companyFax1
        {
            get { return (String)Get("companyFax1", typeof(String)); }
            set { Set("companyFax1", value); }
        }
        /// <summary>
        /// 회사팩스번호2
        /// </summary>
        public String companyFax2
        {
            get { return (String)Get("companyFax2", typeof(String)); }
            set { Set("companyFax2", value); }
        }
        /// <summary>
        /// 회사팩스번호3
        /// </summary>
        public String companyFax3
        {
            get { return (String)Get("companyFax3", typeof(String)); }
            set { Set("companyFax3", value); }
        }
        /// <summary>
        /// 회사이메일
        /// </summary>
        public String companyEmail
        {
            get { return (String)Get("companyEmail", typeof(String)); }
            set { Set("companyEmail", value); }
        }
        /// <summary>
        /// 대표자이메일
        /// </summary>
        public String representativeEmail
        {
            get { return (String)Get("representativeEmail", typeof(String)); }
            set { Set("representativeEmail", value); }
        }
        /// <summary>
        /// 계좌번호
        /// </summary>
        public String companyAccountnumber
        {
            get { return (String)Get("companyAccountnumber", typeof(String)); }
            set { Set("companyAccountnumber", value); }
        }
        /// <summary>
        /// 계좌은행
        /// </summary>
        public String companyAccountBank
        {
            get { return (String)Get("companyAccountBank", typeof(String)); }
            set { Set("companyAccountBank", value); }
        }
        /// <summary>
        /// 계좌지점번호
        /// </summary>
        public String companyAccountBankCode
        {
            get { return (String)Get("companyAccountBankCode", typeof(String)); }
            set { Set("companyAccountBankCode", value); }
        }
        /// <summary>
        /// 계좌지점명
        /// </summary>
        public String companyAccountBankCodeName
        {
            get { return (String)Get("companyAccountBankCodeName", typeof(String)); }
            set { Set("companyAccountBankCodeName", value); }
        }
        /// <summary>
        /// 계좌예금주
        /// </summary>
        public String companyAccountOwnerName
        {
            get { return (String)Get("companyAccountOwnerName", typeof(String)); }
            set { Set("companyAccountOwnerName", value); }
        }
        /// <summary>
        /// 설립일
        /// </summary>
        public DateTime companyEstablishmenidate
        {
            get { return (DateTime)Get("companyEstablishmenidate", typeof(DateTime)); }
            set { Set("companyEstablishmenidate", value); }
        }
        /// <summary>
        /// 설립일(String)
        /// </summary>
        public String companyEstablishmenidateString
        {
            get { return companyEstablishmenidate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일(String)
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 발주 납기 장소
        /// </summary>
        public String orderAddress
        {
            get { return (String)Get("orderAddress",typeof(String));}
            set { Set("orderAddress",value);}
        }
        //****************2014/10/21 추가 영문
        /// <summary>
        /// 회사명 영문
        /// </summary>
        public String companyName_en
        {
            get { return (String)Get("companyName_en", typeof(String)); }
            set { Set("companyName_en", value); }
        }
        /// <summary>
        /// 주소영문
        /// </summary>
        public String companyAddress_en
        {
            get { return (String)Get("companyAddress_en", typeof(String)); }
            set { Set("companyAddress_en", value); }
        }
        /// <summary>
        /// 대표자영문
        /// </summary>
        public String representative_en
        {
            get { return (String)Get("representative_en", typeof(String)); }
            set { Set("representative_en", value); }
        }
        /// <summary>
        /// 납기주소영문
        /// </summary>
        public String orderAddress_en
        {
            get { return (String)Get("orderAddress_en", typeof(String)); }
            set { Set("orderAddress_en", value); }
        }
        /// <summary>
        /// 회사전화번호타입
        /// </summary>
        public String companynumbertype
        {
            get { return (String)Get("companynumbertype", typeof(String)); }
            set { Set("companynumbertype", value); }
        }
        /// <summary>
        /// 회사팩스번호타입
        /// </summary>
        public String companyFaxtype
        {
            get { return (String)Get("companyFaxtype", typeof(String)); }
            set { Set("companyFaxtype", value); }
        }
        /// <summary>
        /// 대표자전화번호타입
        /// </summary>
        public String companyrepresentativenumber
        {
            get { return (String)Get("companyrepresentativenumber", typeof(String)); }
            set { Set("companyrepresentativenumber", value); }
        }
        //********************************************
        /// <summary>
        /// 회사정보취득하기
        /// </summary>
        /// <param name="companycode"></param>
        /// <returns></returns>
        public bool CompanyInfoSelect(string companycode)
        {
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_CompanyInfo where state = '0' and companycode = @companycode");
            ParameterInit();
            ParameterAdd("companycode", companycode);
            bool ret = base.Select(query.ToString(), GetParameter());
            NumberSplit();
            return ret;
        }
        /// <summary>
        /// 번호나누기
        /// </summary>
        public void NumberSplit()
        {
            try
            {
                String[] buffer = companyPostnumber.Split('-');
                companyPostnumber1 = buffer[0];
                companyPostnumber2 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("우편번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
            try
            {
                String[] buffer = companyNumber.Split('-');
                companyNumber1 = buffer[0];
                companyNumber2 = buffer[1];
                companyNumber3 = buffer[2];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("회사전화번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
            try
            {
                String[] buffer = companyFax.Split('-');
                companyFax1 = buffer[0];
                companyFax2 = buffer[1];
                companyFax3 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("팩스번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
            try
            {
                String[] buffer = representativeNumber.Split('-');
                representativeNumber1 = buffer[0];
                representativeNumber2 = buffer[1];
                representativeNumber3 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("대표자전화번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
        }
        /// <summary>
        /// 번호합치기
        /// </summary>
        public void NumberJoin()
        {
            companyPostnumber = companyPostnumber1 + "-" + companyPostnumber2;
            Remove("companyPostnumber1");
            Remove("companyPostnumber2");
            companyNumber = companyNumber1 + "-" + companyNumber2 + "-" + companyNumber3;
            Remove("companyNumber1");
            Remove("companyNumber2");
            Remove("companyNumber3");
            companyFax = companyFax1 + "-" + companyFax2 + "-" + companyFax3;
            Remove("companyFax1");
            Remove("companyFax2");
            Remove("companyFax3");
            representativeNumber = representativeNumber1 + "-" + representativeNumber2 + "-" + representativeNumber3;
            Remove("representativeNumber1");
            Remove("representativeNumber2");
            Remove("representativeNumber3");
        }
        /// <summary>
        /// 회사정보수정
        /// </summary>
        public List<String> CompanyInfoModify(CompanyInfo modifyData, LanguageType? lType)
        {
            List<String> pError = modifyData.validate(lType);
            if (pError.Count < 1)
            {
                             //삭제처리
                ParameterInit();
                ParameterAdd("companycode", companyCode);
                ParameterAdd("idx", idx);
                ParameterAdd("state",Define.STATE_DELETE);
                StringBuilder query = new StringBuilder();
                query.Append(" UPDATE ");
                query.Append(" tbl_CompanyInfo ");
                query.Append(" set state = @state ");
                query.Append(" where companycode = @companycode and idx=@idx");
                base.Delete(query.ToString(), GetParameter());
                //삭제완료
                //Form데이터에 companyCode 넣기
                modifyData.companyCode = this.companyCode;
                this.Clear();
                //메모리데이터 초기화

                List<String> keys = modifyData.GetKey();
                for (int i = 0; i < keys.Count; i++)
                {
                    this.Add(keys[i], modifyData.Get(keys[i]));
                }
                NumberJoin();
                this.state = "0";
                keys = GetKey();
                query.Clear();
                StringBuilder queryValue = new StringBuilder();
                query.Append(" INSERT INTO tbl_CompanyInfo (");
                queryValue.Append(" ( ");
                ParameterInit();
                for (int i = 0; i < keys.Count; i++)
                {
                    object data = Get(keys[i]);
                    if (data != null)
                    {
                        if (i > 0)
                        {
                            query.Append(",");
                            queryValue.Append(",");
                        }
                        query.Append(keys[i]);
                        queryValue.Append("@" + keys[i]);
                        ParameterAdd(keys[i], data);
                    }
                }
                query.Append(")");
                queryValue.Append(" ) ");
                base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());

                            //메모리 재세팅
                CompanyInfoSelect(companyCode);
            }
            return pError;
        }
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (NullCheck(companyName))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("회사이름이 입력되지 않았습니다.");
                else Errmsg.Add("会社名が入力されてありません。");
            }
            if ((NullCheck(companyPostnumber1) || NullCheck(companyPostnumber2)))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("우편번호가 입력되지 않았습니다.");
                else Errmsg.Add("ポスト番号が入力されてありません。");
            }
            if (NullCheck(companyAddress))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("주소가 입력되지 않았습니다.");
                else Errmsg.Add("住所が入力されてありません。");
            }
            if (NullCheck(companySecurityNumber))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("사업자번호가 입력되지 않았습니다.");
                else Errmsg.Add("事業者番号が入力されてありません。");
            }
            if (NullCheck(companySecurityNumber))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("사업자번호가 입력되지 않았습니다.");
                else Errmsg.Add("事業者番号が入力されてありません。");
            }
            if (NullCheck(companyNumber1) || NullCheck(companyNumber2) || NullCheck(companyNumber3))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("회사전화번호가 입력되지 않았습니다.");
                else Errmsg.Add("会社電話番号が入力されてありません。");
            }
            if (NullCheck(companyEmail))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("회사이메일이 입력되지 않았습니다.");
                else Errmsg.Add("会社Eメールが入力されてありません。");
            }
            if (NullCheck(representative))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("대표자명이 입력되지 않았습니다.");
                else Errmsg.Add("代表者名が入力されてありません。");
            }
            if (NullCheck(representativeNumber1) || NullCheck(representativeNumber2) || NullCheck(representativeNumber3))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("대표자전화번호가 입력되지 않았습니다.");
                else Errmsg.Add("代表者電話番号が入力されてありません。");
            }
            if (NullCheck(representativeEmail))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("대표자이메일이 입력되지 않았습니다.");
                else Errmsg.Add("代表者Eメールが入力されてありません。");
            }
            if (NullCheck(companyAccountBank))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("계좌은행명이 입력되지 않았습니다.");
                else Errmsg.Add("通帳銀行名が入力されてありません。");
            }
            if (NullCheck(companyAccountOwnerName))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("예금주가 입력되지 않았습니다.");
                else Errmsg.Add("通帳取付が入力されてありません。");
            }
            if (NullCheck(companyAccountnumber))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("계좌번호가 입력되지 않았습니다.");
                else Errmsg.Add("通帳番号名が入力されてありません。");
            }
            
            return Errmsg;
        }
    }
}