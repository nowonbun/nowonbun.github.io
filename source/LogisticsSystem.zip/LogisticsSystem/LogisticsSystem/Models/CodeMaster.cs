﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class CodeMaster : SYModel
    {
        public String tblname {
            get { return (String)Get("tblname", typeof(String)); }
            set { Set("tblname", value); }  
        }
        public String codekey
        {
            get { return (String)Get("codekey", typeof(String)); }
            set { Set("codekey", value); }
        }
        public String codename
        {
            get { return (String)Get("codename", typeof(String)); }
            set { Set("codename", value); }
        }
        public void trans(LanguageType? ltype)
        {
            if (ltype == LanguageType.Korea)
            {
                Set("codename", Get("codename_k"));
            }
            else
            {
                Set("codename", Get("codename_j"));
            }
        }
    }
}