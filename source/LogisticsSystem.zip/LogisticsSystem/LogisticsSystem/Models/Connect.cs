﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class Connect : SYModel
    {

        /// <summary>
        /// userid
        /// </summary>
        public String userid
        {
            get { return (String)Get("userid", typeof(String)); }
            set { Set("userid", value); }
        }
        /// <summary>
        /// connectdate
        /// </summary>
        public DateTime connectdate
        {
            get { return (DateTime)Get("connectdate", typeof(DateTime)); }
            set { Set("connectdate", value); }
        }
        /// <summary>
        /// ipaddress
        /// </summary>
        public String ipaddress
        {
            get { return (String)Get("ipaddress", typeof(String)); }
            set { Set("ipaddress", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        /// <summary>
        /// 댓글 입력 쿼리
        /// </summary>
        public int ConnectInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_connect (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
    }
}