﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class OrderTableList : SYModelList<OrderTable>
    {
        /// <summary>
        /// 발주서 전체 검색 수
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int OrderCount(int orderType,String companycode,bool state/*전체 또는 STATE = 0 경우*/ )
        {
            StringBuilder sb = new StringBuilder();
            ParameterInit();
            ParameterAdd("orderType", orderType);
            ParameterAdd("companycode",companycode);
            if(state)ParameterAdd("state",Define.STATE_NORMAL);
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Orderlist ");
            sb.Append(" WHERE ");
            if(state)sb.Append(" state = @state and ");
            sb.Append(" orderType = @orderType and companycode=@companycode ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 발주서 전체 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <param name="orderType"></param>
        /// <returns></returns>
        public int OrderSelect(int pageLimit, int page, int orderType, String companycode, bool state/*전체 또는 STATE = 0 경우*/ )
        {
            StringBuilder sb = new StringBuilder();
            ParameterInit();
            ParameterAdd("orderType",orderType);
            ParameterAdd("companycode", companycode);
            if (state) ParameterAdd("state", Define.STATE_NORMAL);

            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Orderlist ");
            sb.Append(" WHERE ");
            if (state) sb.Append(" state = @state and ");
            sb.Append(" orderType = @orderType and companycode=@companycode ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Orderlist WHERE ");
            if(state) sb.Append(" state = @state and ");
            sb.Append(" orderType = @orderType and companycode=@companycode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(),GetParameter());
        }
    }
}