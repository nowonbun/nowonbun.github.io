﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class CommentList : SYModelList<Board>
    {
        /// <summary>
        /// 댓글 검색수
        /// Database - CompanyCode Binding NG!
        /// </summary>
        public int CommentCount(Int64 boardidx)
        {
            ParameterInit();
            ParameterAdd("state", App_Code.Define.STATE_NORMAL);
            ParameterAdd("boardidx", boardidx);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_BoardComment ");
            sb.Append(" WHERE state = @state ");
            sb.Append(" AND boardidx = @boardidx ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 댓글 검색
        /// </summary>
        /// <param name="pageLimit"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public int CommentSelect(Int64 boardidx)
        {
            ParameterInit();
            ParameterAdd("state", App_Code.Define.STATE_NORMAL);
            ParameterAdd("boardidx", boardidx);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT * ");
            sb.Append(" FROM tbl_BoardComment ");
            sb.Append(" WHERE state = @state ");
            sb.Append(" AND boardidx = @boardidx ");
            sb.Append(" order by idx asc");
            return SelectList(sb.ToString(), GetParameter());
        }
    }
}