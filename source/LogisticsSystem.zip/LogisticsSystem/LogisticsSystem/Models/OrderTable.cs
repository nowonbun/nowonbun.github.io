﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    /// <summary>
    /// 발주테이블
    /// </summary>
    public class OrderTable : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 발주번호
        /// </summary>
        public String ordernumber
        {
            get { return (String)Get("ordernumber", typeof(String)); }
            set { Set("ordernumber", value); }
        }
        /// <summary>
        /// 발주사
        /// </summary>
        public String ordername
        {
            get { return (String)Get("ordername", typeof(String)); }
            set { Set("ordername", value); }
        }
        /// <summary>
        /// 발주사_영문
        /// </summary>
        public String ordername_en
        {
            get { return (String)Get("ordername_en", typeof(String)); }
            set { Set("ordername_en", value); }
        }
        /// <summary>
        /// 발주사사업자등록번호
        /// </summary>
        public String ordersecuritynumber 
        {
            get { return (String)Get("ordersecuritynumber", typeof(String)); }
            set { Set("ordersecuritynumber", value); }
        }
        /// <summary>
        /// 발주사우편번호
        /// </summary>
        public String orderPostnumber
        {
            get { return (String)Get("orderPostnumber", typeof(String)); }
            set { Set("orderPostnumber", value); }
        }
        /// <summary>
        /// 발주자주소
        /// </summary>
        public String orderAddress
        {
            get { return (String)Get("orderAddress", typeof(String)); }
            set { Set("orderAddress", value); }
        }
        /// <summary>
        /// 발주자주소_영문(2014/10/22추가)
        /// </summary>
        public String orderAddress_en
        {
            get { return (String)Get("orderAddress_en", typeof(String)); }
            set { Set("orderAddress_en", value); }
        }
        /// <summary>
        /// 발주자전화번호
        /// </summary>
        public String orderPhoneNumber
        {
            get { return (String)Get("orderPhoneNumber", typeof(String)); }
            set { Set("orderPhoneNumber", value); }
        }
        /// <summary>
        /// 발주자전화번호_타입
        /// </summary>
        public String orderPhoneNumbertype
        {
            get { return (String)Get("orderPhoneNumbertype", typeof(String)); }
            set { Set("orderPhoneNumbertype", value); }
        }
        /// <summary>
        /// 발주자팩스번호
        /// </summary>
        public String orderFax
        {
            get { return (String)Get("orderFax", typeof(String)); }
            set { Set("orderFax", value); }
        }
        /// <summary>
        /// 발주자팩스번호_타입
        /// </summary>
        public String orderFaxtype
        {
            get { return (String)Get("orderFaxtype", typeof(String)); }
            set { Set("orderFaxtype", value); }
        }
        /// <summary>
        /// 수주자이름
        /// </summary>
        public String inordername
        {
            get { return (String)Get("inordername", typeof(String)); }
            set { Set("inordername", value); }
        }
        /// <summary>
        /// 총발주금액
        /// </summary>
        public Decimal ordermoney
        {
            get { return (Decimal)Get("ordermoney", typeof(Decimal)); }
            set { Set("ordermoney", value); }
        }
        /// <summary>
        /// 납기일자
        /// </summary>
        public DateTime ordersavedate
        {
            get { return (DateTime)Get("ordersavedate", typeof(DateTime)); }
            set { Set("ordersavedate", value); }
        }
        /// <summary>
        /// 납기일자(String타입)
        /// </summary>
        public String ordersavedateString 
        {
            get { return ordersavedate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 납기장소
        /// </summary>
        public String ordersaveplace 
        {
            get { return (String)Get("ordersaveplace", typeof(String)); }
            set { Set("ordersaveplace", value); }
        }
        /// <summary>
        /// 납기장소_영문 (2014/10/22추가)
        /// </summary>
        public String ordersaveplace_en
        {
            get { return (String)Get("ordersaveplace_en", typeof(String)); }
            set { Set("ordersaveplace_en", value); }
        }
        /// <summary>
        /// 발주일자
        /// </summary>
        public DateTime orderdate 
        {
            get { return (DateTime)Get("orderdate", typeof(DateTime)); }
            set { Set("orderdate", value); }
        }
        /// <summary>
        /// 발주일자(String)
        /// </summary>
        public String orderdateString 
        {
            get { return orderdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 지불예정일
        /// </summary>
        public DateTime paydate
        {
            get { return (DateTime)Get("paydate", typeof(DateTime)); }
            set { Set("paydate", value); }
        }
        /// <summary>
        /// 지불금액
        /// </summary>
        public Decimal paymoney
        {
            get { return (Decimal)Get("paymoney", typeof(Decimal)); }
            set { Set("paymoney", value); }
        }
        /// <summary>
        /// 지불조건
        /// </summary>
        public String paycondition 
        {
            get { return (String)Get("paycondition", typeof(String)); }
            set { Set("paycondition", value); }
        }
        /// <summary>
        /// 비고
        /// </summary>
        public String payother
        {
            get { return (String)Get("payother", typeof(String)); }
            set { Set("payother", value); }
        }
        /// <summary>
        /// 작성일자
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일자(String)
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state 
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 상태명
        /// </summary>
        public String stateDisp
        {
            get { return (String)Get("stateDisp", typeof(String)); }
            set { Set("stateDisp", value); }
        }
        //문서타입 (수주용, 발주용)
        public String ordertype 
        {
            get { return (String)Get("ordertype", typeof(String)); }
            set { Set("ordertype", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        /// <summary>
        /// 수주사 주소
        /// </summary>
        public String inorderaddress
        {
            get { return (String)Get("inorderaddress", typeof(String)); }
            set { Set("inorderaddress", value); }
        }
        /// <summary>
        /// 문서타입
        /// </summary>
        public String printSetting
        {
            get { return (String)Get("printSetting", typeof(String)); }
            set { Set("printSetting", value); }
        }
        /// <summary>
        /// 메모
        /// </summary>
        public String other
        {
            get { return (String)Get("other", typeof(String)); }
            set { Set("other", value); }
        }
        /// <summary>
        /// 총검색건수
        /// </summary>
        /// <returns></returns>
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        /// <summary>
        /// 발주번호 생성
        /// </summary>
        public String CreateCode()
        {
            String query = " insert into codeCreater select Cast(isnull(Max(codebuffer)+1,1) as Decimal) as code,4 from codeCreater where type=4";
            Insert(query);
            query = " select Cast(Max(codebuffer)as Decimal) as code from codeCreater where type=4 ";
            Select(query);
            return "BA-" + ((Decimal)Get("code", typeof(Decimal))).ToString("0000000000");
        }
        public int OrderInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Orderlist (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        /// <summary>
        /// 발주서 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool SelectIdxReflesh(Int64 idx, String companycode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode", companycode);
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_Orderlist where idx = @idx and companycode=@companycode");
            return base.Select(query.ToString(), GetParameter());
        }
        public bool SelectReflesh()
        {
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_Orderlist where ordernumber = @ordernumber");
            ParameterInit();
            ParameterAdd("ordernumber", ordernumber);
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 등록처리
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <returns></returns>
       
        public int Approve(Int64 idx,int nStateType,String companycode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("state",nStateType);
            ParameterAdd("companycode",companycode);

            StringBuilder query = new StringBuilder();
            query.Append(" Update tbl_Orderlist ");
            query.Append(" set state = @state ");
            query.Append(" where idx = @idx ");
            query.Append(" and companycode = @companycode ");
            return base.Update(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 상태처리명
        /// </summary>
        public void stateView(LanguageType? lType)
        {
            //상태
            if (App_Code.Define.STATE_NORMAL.ToString().Equals(state))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인대기";
                else stateDisp = "承認待ち";
            }
            else if (App_Code.Define.STATE_DELETE.ToString().Equals(state))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인취소";
                else stateDisp = "承認取消";
            }
            else if (App_Code.Define.STATE_APPLY.ToString().Equals(state))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인";
                else stateDisp = "承認";
            }
        }
        /// <summary>
        /// validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (NullCheck(ordernumber))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("문서번호가 입력되지 않았습니다..");
                else Errmsg.Add("文書番号が入力されてありません。");
            }
            if (NullCheck(ordername))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주사가 입력되지 않았습니다..");
                else Errmsg.Add("発注社が入力されてありません。");
            }
            //if (NullCheck(ordersecuritynumber))
            //{
            //    if (lType == LanguageType.Korea) Errmsg.Add("사업자등록번호가 입력되지 않았습니다..");
            //    else Errmsg.Add("事業者番号が入力されてありません。");
            //}
            //if (NullCheck(orderPostnumber))
            //{
            //    if (lType == LanguageType.Korea) Errmsg.Add("발주사우편번호가 입력되지 않았습니다..");
            //    else Errmsg.Add("発注社郵便番号が入力されてありません。");
            //}
            if (NullCheck(orderAddress))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주사주소가 입력되지 않았습니다..");
                else Errmsg.Add("発注社住所が入力されてありません。");
            }
            if (NullCheck(orderPhoneNumber))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주사전화번호가 입력되지 않았습니다..");
                else Errmsg.Add("発注社電話番号が入力されてありません。");
            }
            if (NullCheck(orderFax))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주사팩스번호가 입력되지 않았습니다..");
                else Errmsg.Add("発注社ファクス番号が入力されてありません。");
            }
            if (NullCheck(inordername))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("수주자이름가 입력되지 않았습니다..");
                else Errmsg.Add("受注社が入力されてありません。");
            }
            if (ordermoney <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주금액이 없습니다.");
                else Errmsg.Add("発注金額がありません。");
            }
            if (ordersavedate == null || ordersavedate < DateTime.Now.AddDays(-1))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("납기일자가 맞지 않습니다.");
                else Errmsg.Add("納期日付が合わないです。");
                if (ordersavedate < DateTime.Now.AddYears(-1))
                {
                    ordersavedate = DateTime.Now;
                }
            }
            if (NullCheck(ordersaveplace))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("납기장소가 입력되지 않았습니다..");
                else Errmsg.Add("納期場所が入力されてありません。");
            }
            if (orderdate == null || orderdate < DateTime.Now.AddDays(-1))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("발주일자가 맞지 않습니다.");
                else Errmsg.Add("発注日付が合わないです。");
                if (orderdate < DateTime.Now.AddYears(-1))
                {
                    orderdate = DateTime.Now;
                }
            }
            if (paydate == null || paydate < DateTime.Now.AddDays(-1))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("지불일자가 맞지 않습니다.");
                else Errmsg.Add("支払日付が合わないです。");
                if (paydate < DateTime.Now.AddYears(-1))
                {
                    paydate = DateTime.Now;
                }
            }
            if (paymoney <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add("지불금액이 없습니다.");
                else Errmsg.Add("支払金額がありません。");
            }
            if (NullCheck(paycondition))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("지불조건이 선택되지 않았습니다..");
                else Errmsg.Add("支払条件が選択されてありません。");
            }
            return Errmsg;
        }
    }
}