﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class BoardList : SYModelList<Board>
    {
        /// <summary>
        /// 게시판 검색수
        /// Database - CompanyCode Binding NG!
        /// </summary>
        public int BoardCount()
        {
            ParameterInit();
            ParameterAdd("state", App_Code.Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Board ");
            sb.Append(" WHERE state = @state ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 게시판 검색
        /// </summary>
        /// <param name="pageLimit"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public int BoardSelect(int pageLimit, int page)
        {
            ParameterInit();
            ParameterAdd("state", App_Code.Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Board ");
            sb.Append(" WHERE state = @state ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Board WHERE state = @state order by num desc) ");
            sb.Append(" order by num desc");
            return SelectList(sb.ToString(), GetParameter());
        }
    }
}