﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class OrderTable_SubAddList
    {
        private OrderTable_SubList m_pList;
        public OrderTable_SubList List
        {
            get { return m_pList; }
        }
        public OrderTable_SubAddList()
        {
            m_pList = new OrderTable_SubList();
        }
        private void InitList(int count)
        {
            for (int i = m_pList.Count; i < count; i++)
            {
                m_pList.Add(new OrderTable_Sub());
            }
        }
        /// <summary>
        /// 상품키변환
        /// </summary>
        /// 이게 순서대로 넣지 않으면 이상해 지는 버그가 있다.
        public ICollection<Int64> productIndex
        {
            get { return null; }
            set
            {
                List<Int64> pBuffer = (List<Int64>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != 0)
                    {
                        InitList(i + 1);
                        m_pList[i].productIndex = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품타입변환
        /// </summary>
        public ICollection<String> productType
        {
            get { return null; }
            set {
                List<String> pBuffer = (List<String>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != "")
                    {
                        InitList(i+1);
                        m_pList[i].productType = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품규격변환
        /// </summary>
        public ICollection<String> productspec
        {
            get { return null; }
            set
            {
                List<String> pBuffer = (List<String>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != "")
                    {
                        InitList(i + 1);
                        m_pList[i].productSpec = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품양변환
        /// </summary>
        public ICollection<Decimal> productAmount
        {
            get { return null; }
            set
            {
                List<Decimal> pBuffer = (List<Decimal>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != 0)
                    {
                        InitList(i + 1);
                        m_pList[i].productAmount = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품가격변환
        /// </summary>
        public ICollection<Decimal> productprice
        {
            get { return null; }
            set
            {
                List<Decimal> pBuffer = (List<Decimal>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != 0)
                    {
                        InitList(i + 1);
                        m_pList[i].productPrice = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품총값변환
        /// </summary>
        public ICollection<Decimal> producttotal
        {
            get { return null; }
            set
            {
                List<Decimal> pBuffer = (List<Decimal>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != 0)
                    {
                        InitList(i + 1);
                        m_pList[i].productMoney = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// 상품총값변환
        /// </summary>
        public ICollection<String> productspec_disp
        {
            get { return null; }
            set
            {
                List<String> pBuffer = (List<String>)value;
                for (int i = 0; i < value.Count; i++)
                {
                    if (pBuffer[i] != "")
                    {
                        InitList(i + 1);
                        m_pList[i].productspec_disp = pBuffer[i];
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        /// <summary>
        /// validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (this.m_pList.Count <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add("상품명이 입력되지 않았습니다.");
                else Errmsg.Add("商品名が入力されてありません。");
            }
            int i = 1;
            foreach (OrderTable_Sub pdata in this.m_pList)
            {
                List<String> pBuffer = pdata.validate(lType,i);
                foreach (String pBuffer2 in pBuffer)
                {
                    Errmsg.Add(pBuffer2);
                }
                i++;
            }
            return Errmsg;
        }
    }
}