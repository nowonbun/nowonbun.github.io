﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;


namespace LogisticsSystem.Models
{
    public class Bill : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 회사명
        /// </summary>
        public String inordercompany
        {
            get { return (String)Get("inordercompany", typeof(String)); }
            set { Set("inordercompany", value); }
        }
        /// <summary>
        /// 대표자
        /// </summary>
        public String inorderrepresentative
        {
            get { return (String)Get("inorderrepresentative", typeof(String)); }
            set { Set("inorderrepresentative", value); }
        }
        /// <summary>
        /// 우편번호
        /// </summary>
        public String inorderpost
        {
            get { return (String)Get("inorderpost", typeof(String)); }
            set { Set("inorderpost", value); }
        }
        /// <summary>
        /// 주소
        /// </summary>
        public String inorderAddress
        {
            get { return (String)Get("inorderAddress", typeof(String)); }
            set { Set("inorderAddress", value); }
        }
        /// <summary>
        /// 고객
        /// </summary>
        public String ordercompany
        {
            get { return (String)Get("orderCompany", typeof(String)); }
            set { Set("orderCompany", value); }
        }
        /// <summary>
        /// 고객우편번호
        /// </summary>
        public String orderpost
        {
            get { return (String)Get("orderPost", typeof(String)); }
            set { Set("orderPost", value); }
        }
        /// <summary>
        /// 고객주소
        /// </summary>
        public String orderaddress
        {
            get { return (String)Get("orderAddress", typeof(String)); }
            set { Set("orderAddress", value); }
        }
        /// <summary>
        /// 청구일
        /// </summary>
        public DateTime billdate
        {
            get { return (DateTime)Get("billdate", typeof(DateTime)); }
            set { Set("billdate", value); }
        }
        public String billdateString
        {
            get { return billdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 청구금액
        /// </summary>
        public Decimal billmoney
        {
            get { return (Decimal)Get("billmoney", typeof(Decimal)); }
            set { Set("billmoney", value); }
        }
        /// <summary>
        /// 세금
        /// </summary>
        public Decimal billtax
        {
            get { return (Decimal)Get("billtax", typeof(Decimal)); }
            set { Set("billtax", value); }
        }
        /// <summary>
        /// 총금액
        /// </summary>
        public Decimal billtotal
        {
            get { return (Decimal)Get("billtotal", typeof(Decimal)); }
            set { Set("billtotal", value); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일 문자형
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 회사코드
        /// </summary>
        public String companycode
        {
            get { return (String)Get("companycode", typeof(String)); }
            set { Set("companycode", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        public int BillInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_bill (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public void LastIndexReflesh()
        {
            idx = ScopeIndentity("tbl_bill");
        }
        public bool SelectIdx(Int64 idx,String companycode)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode",companycode);
            query.Append("SELECT * FROM tbl_Bill where idx = @idx and companycode=@companycode order by idx desc");
            return base.Select(query.ToString(), GetParameter());
        }
    }
}