﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class ProductFlowList : SYModelList<ProductFlow>
    {
        /// <summary>
        /// 재고 전체 검색 수
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int FlowCount(int state,String companycode)
        {
            StringBuilder sb = new StringBuilder();
            ParameterInit();
            ParameterAdd("state", state);
            ParameterAdd("companycode", companycode);
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_ProductFlow a inner join tbl_ProductInfo b on a.productIndex = b.idx ");
            sb.Append(" WHERE a.companycode = @companycode ");
            sb.Append(" AND a.state = @state ");
            SelectList(System.Data.CommandType.Text, sb.ToString(),GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 재고 전체 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int FlowSelect(int pageLimit, int page, int state, String companycode)
        {
            StringBuilder sb = new StringBuilder();          
            ParameterInit();
            ParameterAdd("state", state);
            ParameterAdd("companycode", companycode);

            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " a.*,b.productname ");
            sb.Append(" FROM tbl_ProductFlow a inner join tbl_ProductInfo b on a.productIndex = b.idx ");
            sb.Append(" WHERE a.state = @state and a.companycode = @companycode ");
            sb.Append(" AND a.idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_ProductFlow WHERE state = @state and companycode = @companycode order by idx desc) ");
            sb.Append(" order by a.idx desc");

            return SelectList(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 전체 검색 수
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int FlowListCount(String companycode,int state1,int state2,int state3)
        {
            ParameterInit();
            ParameterAdd("companycode", companycode);
            ParameterAdd("state1", state1);
            ParameterAdd("state2", state2);
            ParameterAdd("state3", state3);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_ProductFlow ");
            sb.Append(" WHERE state in (@state1,@state2,@state3) and companycode = @companycode ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 전체 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int FlowListSelect(int pageLimit, int page, String companycode, int state1, int state2, int state3)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " a.*,b.productname ");
            sb.Append(" FROM tbl_ProductFlow a inner join tbl_ProductInfo b on a.productIndex = b.idx ");
            sb.Append(" WHERE a.state in (@state1,@state2,@state3) and a.companycode = @companycode ");
            sb.Append(" AND a.idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_ProductFlow ");
            sb.Append(" WHERE a.state in (@state1,@state2,@state3) and a.companycode = @companycode) ");
            sb.Append(" order by a.idx desc");

            return SelectList(sb.ToString(), GetParameter());
        }
    }
}