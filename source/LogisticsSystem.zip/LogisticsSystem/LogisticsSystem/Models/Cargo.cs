﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class Cargo : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 상품Key
        /// </summary>
        public Int64 productindex
        {
            get { return (Int64)Get("productindex", typeof(Int64)); }
            set { Set("productindex", value); }
        }
        public Decimal productInput
        {
            get { return (Decimal)Get("productInput", typeof(Decimal)); }
            set { Set("productInput", value); }
        }
        public Decimal productOutput
        {
            get { return (Decimal)Get("productOutput", typeof(Decimal)); }
            set { Set("productOutput", value); }
        }
        public Decimal productmoney
        {
            get { return (Decimal)Get("productmoney", typeof(Decimal)); }
            set { Set("productmoney", value); }
        }
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        public Decimal ProductAmount
        {
            get { return (Decimal)Get("ProductAmount", typeof(Decimal)); }
        }
        public Decimal ProductAvgPrice
        {
            get { return (Decimal)Get("ProductAvgPrice", typeof(Decimal)); }
        }
        public String productname
        {
            get { return (String)Get("productname", typeof(String)); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        public String producttype
        {
            get { return (String)Get("producttype", typeof(String)); }
            set { Set("producttype", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        
        public int CargoInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_cargo (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public void TypeCheck(LanguageType? lType)
        {
            if (productInput == 0 && productOutput != 0)
            {
                if (lType == LanguageType.Korea) { producttype = "출고"; }
                else { producttype = "出庫"; }
            }
            else if (productInput != 0 && productOutput == 0)
            {
                if (lType == LanguageType.Korea) { producttype = "입고"; }
                else { producttype = "入庫"; }
            }
            else
            {
                if (lType == LanguageType.Korea) { producttype = ""; }
                else { producttype = ""; }
            }
        }
    }
}