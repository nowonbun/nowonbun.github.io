﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class CustomerInfo : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 회사코드
        /// </summary>
        public String customercode
        {
            get { return (String)Get("customercode", typeof(String)); }
            set { Set("customercode", value); }
        }
        /// <summary>
        /// 회사타입(수주사,발주사)
        /// </summary>
        public String customerType
        {
            get { return (String)Get("customerType", typeof(String)); }
            set { Set("customerType", value); }
        }
        /// <summary>
        /// 회사명
        /// </summary>
        public String customerName
        {
            get { return (String)Get("customerName", typeof(String)); }
            set { Set("customerName", value); }
        }
        /// <summary>
        /// 대표자명
        /// </summary>
        public String customerRepresetitive
        {
            get { return (String)Get("customerRepresetitive", typeof(String)); }
            set { Set("customerRepresetitive", value); }
        }
        /// <summary>
        /// 사업자번호
        /// </summary>
        public String customerSecurityNumber
        {
            get { return (String)Get("customerSecurityNumber", typeof(String)); }
            set { Set("customerSecurityNumber", value); }
        }
        /// <summary>
        /// 회사전화번호
        /// </summary>
        public String customerNumber
        {
            get { return (String)Get("customerNumber", typeof(String)); }
            set { Set("customerNumber", value); }
        }
        /// <summary>
        /// 회사팩스번호
        /// </summary>
        public String customerFax
        {
            get { return (String)Get("customerFax", typeof(String)); }
            set { Set("customerFax", value); }
        }
        public String customerPostNumber
        {
            get { return (String)Get("customerPostNumber", typeof(String)); }
            set { Set("customerPostNumber", value); }
        }
        public String customerAddress
        {
            get { return (String)Get("customerAddress", typeof(String)); }
            set { Set("customerAddress", value); }
        }
        /// <summary>
        /// 회사이메일주소
        /// </summary>
        public String customerEmail
        {
            get { return (String)Get("customerEmail", typeof(String)); }
            set { Set("customerEmail", value); }
        }
        public String customerTaxViewRepresentative
        {
            get { return (String)Get("customerTaxViewRepresentative", typeof(String)); }
            set { Set("customerTaxViewRepresentative", value); }
        }
        public String customerTaxViewerAddress
        {
            get { return (String)Get("customerTaxViewerAddress", typeof(String)); }
            set { Set("customerTaxViewerAddress", value); }
        }
        public String customerTaxViewerPostNumber
        {
            get { return (String)Get("customerTaxViewerPostNumber", typeof(String)); }
            set { Set("customerTaxViewerPostNumber", value); }
        }
        public String customerPaymentMethod
        {
            get { return (String)Get("customerPaymentMethod", typeof(String)); }
            set { Set("customerPaymentMethod", value); }
        }
        public String customerAccountbank
        {
            get { return (String)Get("customerAccountbank", typeof(String)); }
            set { Set("customerAccountbank", value); }
        }
        public String customerAccountbankcode
        {
            get { return (String)Get("customerAccountbankcode", typeof(String)); }
            set { Set("customerAccountbankcode", value); }
        }
        public String customerAccountbankcodename
        {
            get { return (String)Get("customerAccountbankcodename", typeof(String)); }
            set { Set("customerAccountbankcodename", value); }
        }
        public String customerAccountOwnerName
        {
            get { return (String)Get("customerAccountOwnerName", typeof(String)); }
            set { Set("customerAccountOwnerName", value); }
        }
        public String customerAccountNumber
        {
            get { return (String)Get("customerAccountNumber", typeof(String)); }
            set { Set("customerAccountNumber", value); }
        }
        public String customerTaxType
        {
            get { return (String)Get("customerTaxType", typeof(String)); }
            set { Set("customerTaxType", value); }
        }
        public int customerTax
        {
            get { return (int)Get("customerTax", typeof(Int32)); }
            set { Set("customerTax", value); }
        }
        public int customerGrade
        {
            get { return (int)Get("customerGrade", typeof(Int32)); }
            set { Set("customerGrade", value); }
        }
        public String customerRepressent
        {
            get { return (String)Get("customerRepressent", typeof(String)); }
            set { Set("customerRepressent", value); }
        }
        public String customerRepressentNumber
        {
            get { return (String)Get("customerRepressentNumber", typeof(String)); }
            set { Set("customerRepressentNumber", value); }
        }
        public String other
        {
            get { return (String)Get("other", typeof(String)); }
            set { Set("other", value); }
        }
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }

        public String customerPostNumber1
        {
            get { return (String)Get("customerPostNumber1", typeof(String)); }
            set { Set("customerPostNumber1", value); }
        }
        public String customerPostNumber2
        {
            get { return (String)Get("customerPostNumber2", typeof(String)); }
            set { Set("customerPostNumber2", value); }
        }
        public String customerTaxViewerPostNumber1
        {
            get { return (String)Get("customerTaxViewerPostNumber1", typeof(String)); }
            set { Set("customerTaxViewerPostNumber1", value); }
        }
        public String customerTaxViewerPostNumber2
        {
            get { return (String)Get("customerTaxViewerPostNumber2", typeof(String)); }
            set { Set("customerTaxViewerPostNumber2", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }

        /// <summary>
        /// 코드생성기
        /// </summary>
        /// <returns></returns>
        public String CreateCode()
        {
            String query = " insert into codeCreater select Cast(isnull(Max(codebuffer)+1,1) as Decimal) as code,2 from codeCreater where type=2";
            Insert(query);
            query = " select Cast(Max(codebuffer)as Decimal) as code from codeCreater where type=2 ";
            Select(query);
            return ((Decimal)Get("code", typeof(Decimal))).ToString("0000");
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        /// <summary>
        /// 고객 입력 쿼리
        /// </summary>
        public int CustmerInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Customer (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public void postNumberProcedure()
        {
            customerPostNumber = customerPostNumber1 + "-" + customerPostNumber2;
            customerTaxViewerPostNumber = customerTaxViewerPostNumber1 + "-" + customerTaxViewerPostNumber2;
            Remove("customerPostNumber1");
            Remove("customerPostNumber2");
            Remove("customerTaxViewerPostNumber1");
            Remove("customerTaxViewerPostNumber2");
        }
        /// <summary>
        /// 고객검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool CustomerSelect(string code,String compcode)
        {
            ParameterInit();
            ParameterAdd("customercode", code);
            ParameterAdd("companycode", compcode);
            ParameterAdd("state",Define.STATE_NORMAL);
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_Customer where state = @state and customercode = @customercode and companycode=@companycode");
            bool ret = base.Select(query.ToString(), GetParameter());

            try
            {
                String[] buffer = customerPostNumber.Split('-');
                customerPostNumber1 = buffer[0];
                customerPostNumber2 = buffer[1];
                buffer = customerTaxViewerPostNumber.Split('-');
                customerTaxViewerPostNumber1 = buffer[0];
                customerTaxViewerPostNumber2 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("우편번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
            return ret;
        }
        /// <summary>
        /// 고객검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool CustomerSelect(int idx, String compcode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode", compcode);
            ParameterAdd("state", Define.STATE_NORMAL);
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_Customer where state = @state and idx = @idx and companycode=@companycode ");
            bool ret = base.Select(query.ToString(), GetParameter());
            try
            {
                String[] buffer = customerPostNumber.Split('-');
                customerPostNumber1 = buffer[0];
                customerPostNumber2 = buffer[1];
                buffer = customerTaxViewerPostNumber.Split('-');
                customerTaxViewerPostNumber1 = buffer[0];
                customerTaxViewerPostNumber2 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("고객 검색시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }

            return ret;
        }
        /// <summary>
        /// 고객검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool CustomerHistorySelect(int idx,String compcode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode",compcode);
            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_Customer where idx = @idx and companycode=@companycode ");
            bool ret = base.Select(query.ToString(), GetParameter());
            try
            {
                String[] buffer = customerPostNumber.Split('-');
                customerPostNumber1 = buffer[0];
                customerPostNumber2 = buffer[1];
                buffer = customerTaxViewerPostNumber.Split('-');
                customerTaxViewerPostNumber1 = buffer[0];
                customerTaxViewerPostNumber2 = buffer[1];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("히스토리 검색시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }

            return ret;
        }
        /// <summary>
        /// 삭제 쿼리
        /// </summary>
        public int CustomerDelete(String compcode)
        {
            ParameterInit();
            ParameterAdd("customercode", customercode);
            ParameterAdd("companycode", compcode);

            StringBuilder query = new StringBuilder();
            query.Append(" UPDATE ");
            query.Append(" tbl_Customer ");
            query.Append(" set state = 1 ");
            query.Append(" where customercode = @customercode and companycode = @companycode");
            return base.Delete(query.ToString(), GetParameter());
        }
        /// <summary>
        /// Validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (lType == LanguageType.Korea)
            {
                if (customercode == null || customercode.Equals(""))
                {
                    Errmsg.Add("상품코드가 입력되지 않았습니다.");
                }
                if (customerName == null || customerName.Equals(""))
                {
                    Errmsg.Add("상품이름이 입력되지 않았습니다.");
                }
                if (customerRepresetitive == null || customerRepresetitive.Equals(""))
                {
                    Errmsg.Add("대표자명이 입력되지 않았습니다.");
                }
                //if (customerSecurityNumber == null || customerSecurityNumber.Equals(""))
                //{
                //    //정규식 체크도 하자
                //    Errmsg.Add("사업자번호가 입력되지 않았습니다.");
                //}
                if (customerNumber == null || customerNumber.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("전화번호가 입력되지 않았습니다.");
                }
                if (customerFax == null || customerFax.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("팩스번호가 입력되지 않았습니다.");
                }
                if (customerPostNumber1 == null || customerPostNumber1.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("우편번호가 입력되지 않았습니다.");
                }
                if (customerPostNumber2 == null || customerPostNumber2.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("우편번호가 입력되지 않았습니다.");
                }
                if (customerAddress == null || customerAddress.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("주소가 입력되지 않았습니다.");
                }
            }
            else
            {
                if (customercode == null || customercode.Equals(""))
                {
                    Errmsg.Add("商品コードが入力されてありません。");
                }
                if (customerName == null || customerName.Equals(""))
                {
                    Errmsg.Add("商品名が入力されてありません。");
                }
                if (customerRepresetitive == null || customerRepresetitive.Equals(""))
                {
                    Errmsg.Add("代表者名が入力されてありません。");
                }
                //if (customerSecurityNumber == null || customerSecurityNumber.Equals(""))
                //{
                //    //정규식 체크도 하자
                //    Errmsg.Add("事業番号が入力されてありません。");
                //}
                if (customerNumber == null || customerNumber.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("電話番号が入力されてありません。");
                }
                if (customerFax == null || customerFax.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("ファクス番号が入力されてありません。");
                }
                if (customerPostNumber1 == null || customerPostNumber1.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("ポスト番号が入力されてありません。");
                }
                if (customerPostNumber2 == null || customerPostNumber2.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("ポスト番号が入力されてありません。");
                }
                if (customerAddress == null || customerAddress.Equals(""))
                {
                    //정규식 체크도 하자
                    Errmsg.Add("住所が入力されてありません。");
                }
            }
            return Errmsg;
        }
    }
}