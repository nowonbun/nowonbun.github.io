﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    /// <summary>
    /// 발주테이블
    /// </summary>
    public class OrderTable_Sub : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 발주테이블키
        /// </summary>
        public Int64 orderKey
        {
            get { return (Int64)Get("orderKey", typeof(Int64)); }
            set { Set("orderKey", value); }
        }
        /// <summary>
        /// 번호
        /// </summary>
        public int number
        {
            get { return (int)Get("number", typeof(int)); }
            set { Set("number", value); }
        }
        /// <summary>
        /// 상품키
        /// </summary>
        public Int64 productIndex
        {
            get { return (Int64)Get("productIndex", typeof(Int64)); }
            set { Set("productIndex", value); }
        }
        /// <summary>
        /// 규격
        /// </summary>
        public String productSpec
        {
            get { return (String)Get("productSpec", typeof(String)); }
            set { Set("productSpec", value); }
        }
        public String productspec_disp
        {
            get { return (String)Get("productspec_disp", typeof(String)); }
            set { Set("productspec_disp", value); }
        }
        /// <summary>
        /// 단위
        /// </summary>
        public String productType 
        {
            get { return (String)Get("productType", typeof(String)); }
            set { Set("productType", value); }
        }
        /// <summary>
        /// 상품양
        /// </summary>
        public Decimal productAmount
        {
            get { return (Decimal)Get("productAmount", typeof(Decimal)); }
            set { Set("productAmount", value); }
        }
        /// <summary>
        /// 단가
        /// </summary>
        public Decimal productPrice
        {
            get { return (Decimal)Get("productPrice", typeof(Decimal)); }
            set { Set("productPrice", value); }
        }
        /// <summary>
        /// 금액
        /// </summary>
        public Decimal productMoney 
        {
            get { return (Decimal)Get("productMoney", typeof(Decimal)); }
            set { Set("productMoney", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater 
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 작성상태
        /// </summary>
        public String state //작성상태
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        //Join용
        public String productName //상품이름
        {
            get { return (String)Get("productName", typeof(String)); }
            set { Set("productName", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        /// <summary>
        /// 입력
        /// </summary>
        public int SubInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Orderlist_sub (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        /// <summary>
        /// 상태변경
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int stateModify(Int64 idx,int state,String companycode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("state", state);
            ParameterAdd("companycode", companycode);

            StringBuilder query = new StringBuilder();
            query.Append(" Update tbl_Orderlist_sub ");
            query.Append(" set state = @state ");
            query.Append(" where idx = @idx ");
            query.Append(" and companycode = @companycode ");
            
            return base.Update(query.ToString(), GetParameter());
        }
        /// <summary>
        /// validate
        /// </summary>
        public List<String> validate(LanguageType? lType,int i)
        {
            List<String> Errmsg = new List<string>();
            //if (orderKey <= 0)
            //{
            //    if (lType == LanguageType.Korea) Errmsg.Add(productIndex.ToString() + "번째 발주테이블키가 입력되지 않았습니다..");
            //    else Errmsg.Add(productIndex.ToString() + "番目、発注データキーが入力されてありません。");
            //}
            //if (number <= 0)
            //{
            //    if (lType == LanguageType.Korea) Errmsg.Add(productIndex.ToString() + "번째 발주번호가 입력되지 않았습니다..");
            //    else Errmsg.Add(productIndex.ToString() + "番目、発注番号が入力されてありません。");
            //}
            if (productIndex <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add(i.ToString() + "번째 상품번호가 입력되지 않았습니다..");
                else Errmsg.Add(i.ToString() + "番目、商品番号が入力されてありません。");
            }
            if (NullCheck(productSpec))
            {
                if (lType == LanguageType.Korea) Errmsg.Add(i.ToString() + "번째 상품규격이 입력되지 않았습니다..");
                else Errmsg.Add(i.ToString() + "番目、商品規格が入力されてありません。");
            }
            if (productAmount <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add(i.ToString() + "번째 상품양이 입력되지 않았습니다..");
                else Errmsg.Add(i.ToString() + "番目、商品量が入力されてありません。");
            }
            if (productPrice <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add(i.ToString() + "번째 상품가격이 입력되지 않았습니다..");
                else Errmsg.Add(i.ToString() + "番目、商品価格が入力されてありません。");
            }
            if (productMoney <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add(i.ToString() + "번째 금액이 입력되지 않았습니다..");
                else Errmsg.Add(i.ToString() + "番目、金額が入力されてありません。");
            }
            return Errmsg;
        }
    }
}