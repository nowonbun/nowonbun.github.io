﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class Document : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 문서번호
        /// </summary>
        public String documentCode
        {
            get { return (String)Get("documentcode", typeof(String)); }
            set { Set("documentcode", value); }
        }
        /// <summary>
        /// 문서타입
        /// </summary>
        public String documentType
        {
            get { return (String)Get("documenttype", typeof(String)); }
            set { Set("documenttype", value); }
        }
        /// <summary>
        /// 문서 Index (각 문서테이블)
        /// </summary>
        public Int64 documentIndex
        {
            get { return (Int64)Get("documentindex", typeof(Int64)); }
            set { Set("documentindex", value); }
        }
        /// <summary>
        /// 작성일자
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일자(출력용)
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 작성자_영문 (2014/10/22추가)
        /// </summary>
        public String creater_en
        {
            get { return (String)Get("creater_en", typeof(String)); }
            set { Set("creater_en", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        /// <summary>
        /// 생성코드
        /// </summary>
        /// <returns></returns>
        public String CreateCode()
        {
            //String query = "select Cast(isnull(Max(substring(documentcode,4,10))+1,0) as Decimal) as code from tbl_Document";
            String query = " insert into codeCreater select Cast(isnull(Max(codebuffer)+1,1) as Decimal) as code,3 from codeCreater where type=3";
            Insert(query);
            query = " select Cast(Max(codebuffer)as Decimal) as code from codeCreater where type=3 ";
            Select(query);
            return "MU-"+((Decimal)Get("code", typeof(Decimal))).ToString("0000000000");
        }
        public int DocumentInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Document (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        /// <summary>
        /// 문서번호 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <returns></returns>
        public bool DocumentSelect(Int64 documentIndex, String documentType, String compcode)
        {
            ParameterInit();
            ParameterAdd("documentType", documentType);
            ParameterAdd("documentIndex", documentIndex);
            ParameterAdd("companycode", compcode);

            StringBuilder query = new StringBuilder();
            query.Append("SELECT * FROM tbl_document where documentType = @documentType and documentIndex = @documentIndex and companycode = @companycode");
            
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (NullCheck(documentCode))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("문서번호가 입력되지 않았습니다..");
                else Errmsg.Add("文書番号が入力されてありません。");
            }
            return Errmsg;
        }
    }
}