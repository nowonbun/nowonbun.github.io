﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class CodeMasterList : SYModelList<CodeMaster>
    {
        public CodeMasterList(String Keyname)
        {
            CodeMasterInit(Keyname);
        }
        public CodeMaster Get(int nIndex)
        {
            return this[nIndex];
        }
        protected int CodeMasterInit(String Keyname)
        {
            
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" * ");
            sb.Append(" FROM TBL_CODEMASTER ");
            sb.Append(" WHERE TBLNAME = @tblname ");

            base.ParameterInit();
            base.ParameterAdd("@tblname", Keyname);
            return SelectList(sb.ToString(),base.GetParameter());
        }
        /// <summary>
        /// 언어 변환
        /// </summary>
        /// <param name="ltype"></param>
        public void Trans(LanguageType? ltype)
        {
            foreach(CodeMaster buffer in this)
            {
                buffer.trans(ltype);
            }
        }
        //protected override void AddNode(ref CodeMaster pNode, string key, object value)
        //{
        //    pNode.Add(key, value);
        //}    
    }
}