﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class Board : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// Index
        /// </summary>
        public Int64 num
        {
            get { return (Int64)Get("num", typeof(Int64)); }
            set { Set("num", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String type
        {
            get { return (String)Get("type", typeof(String)); }
            set { Set("type", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String title
        {
            get { return (String)Get("title", typeof(String)); }
            set { Set("title", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String context
        {
            get { return (String)Get("context", typeof(String)); }
            set { Set("context", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        public Int64 BoardMaxNum()
        {
            Board pBuffer = new Board();
            StringBuilder query = new StringBuilder();
            pBuffer.ParameterInit();
            pBuffer.ParameterAdd("state", Define.STATE_NORMAL);
            query.Append(" SELECT MAX(num) as num FROM tbl_board where state = @state ");
            pBuffer.Select(query.ToString(), pBuffer.GetParameter());
            return pBuffer.num+1;
        }
        /// <summary>
        /// 게시판 입력 쿼리
        /// </summary>
        public int BoardInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Board (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public bool SelectIdx(Int64 idx)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx", idx);
            query.Append("SELECT * FROM tbl_board where idx = @idx order by idx desc");
            return base.Select(query.ToString(), GetParameter());
        }
        public int DeleteIdx(Int64 idx)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("state", Define.STATE_DELETE);
            query.Append("UPDATE tbl_board set state = @state where idx = @idx");
            return base.Delete(query.ToString(), GetParameter());
        }
        public Int64 ModifyIdx()
        {
            Int64 ret = 0;
            Int64 idxbuffer = idx;
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("state", Define.STATE_DELETE);
            query.Append("UPDATE tbl_board set state = @state where idx = @idx");
            this.Remove("idx");
            if (base.Delete(query.ToString(), GetParameter()) > 0)
            {
                BoardInsert();
                Comment comment = new Comment();
                ret = ScopeIndentity("tbl_board");
                comment.ConnectModify(idxbuffer, ret);                
            }
            return ret;
        }
    }
}