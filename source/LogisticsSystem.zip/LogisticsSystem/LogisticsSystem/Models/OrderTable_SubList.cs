﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class OrderTable_SubList : SYModelList<OrderTable_Sub>
    {
        /// <summary>
        /// 리스트저장
        /// </summary>
        public int ListInsert(Int64 orderkey, String creater,String companycode)
        {
            int ret = 0;
            int number = 1;
            foreach (OrderTable_Sub pBuffer in this)
            {
                pBuffer.orderKey = orderkey;
                pBuffer.number = number;
                pBuffer.createdate = DateTime.Now;
                pBuffer.creater = creater;
                pBuffer.state = "0";
                String disp = pBuffer.productspec_disp;
                String productname = pBuffer.productName;
                //DB에 없는 객체 삭제
                pBuffer.productspec_disp = null;
                pBuffer.productName = null;
                //회사코드!
                pBuffer.companycode = companycode;
                ret += pBuffer.SubInsert();
                //Disp객체 재 입력(Spec값임)
                pBuffer.productspec_disp = disp;
                pBuffer.productName = productname;
                number++;
            }
            return ret;
        }
        /// <summary>
        /// 발주서 상품내용 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int SubListSelect(Int64 orderkey,String companycode,LanguageType? ltype)
        {
            ParameterInit();
            ParameterAdd("orderkey", orderkey);
            ParameterAdd("companycode", companycode);
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" a.*,b.productname ");
            sb.Append(" FROM dbo.tbl_Orderlist_sub A INNER JOIN tbl_ProductInfo B ON A.PRODUCTINDEX = B.idx ");
            sb.Append(" WHERE a.orderkey = @orderkey and A.companycode=@companycode and b.companycode=@companycode ");
            sb.Append(" order by a.idx desc");
            
            return SelectList(sb.ToString(),GetParameter());
        }
    }
}