﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class BillList : SYModelList<Bill>
    {
        /// <summary>
        /// 정산서 검색수
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int BillCount(String companycode)
        {
            ParameterInit();
            ParameterAdd("state",App_Code.Define.STATE_NORMAL);
            ParameterAdd("companycode",companycode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_bill ");
            sb.Append(" WHERE state = @state ");
            sb.Append(" AND companycode = @companycode");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 정산서 검색
        /// </summary>
        /// <param name="pageLimit"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public int BillSelect(int pageLimit, int page,String companycode)
        {
            ParameterInit();
            ParameterAdd("state",App_Code.Define.STATE_NORMAL);
            ParameterAdd("companycode",companycode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_bill ");
            sb.Append(" WHERE state = @state and companycode=@companycode ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_bill WHERE state = @state and companycode=@companycode order by idx desc) ");
            sb.Append(" order by idx desc");
            return SelectList(sb.ToString(), GetParameter());
        }
    }
}