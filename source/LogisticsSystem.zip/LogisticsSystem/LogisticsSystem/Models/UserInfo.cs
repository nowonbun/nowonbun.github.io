﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class UserInfo : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 유저아이디
        /// </summary>
        public String userid 
        {
            get { return (String)Get("userid"); }
            set { Set("userid", value); } 
        }
        /// <summary>
        /// 패스워드
        /// </summary>
        public String password 
        {
            get { return (String)Get("password"); }
            set { Set("password", value); } 
        }
        /// <summary>
        /// 패스워드체크
        /// </summary>
        public String passwordCheck
        {
            get { return (String)Get("passwordCheck"); }
            set { Set("passwordCheck", value); }
        }
        /// <summary>
        /// 유저이름
        /// </summary>
        public String username
        {
            get { return (String)Get("username"); }
            set { Set("username", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state"); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 권한
        /// </summary>
        public String permission
        {
            get { return (String)Get("permission"); }
            set { Set("permission", value); }
        }
        /// <summary>
        /// 전화번호
        /// </summary>
        public String usernumber
        {
            get { return (String)Get("usernumber"); }
            set { Set("usernumber", value); }
        }
        /// <summary>
        /// 전화번호1
        /// </summary>
        public String usernumber1
        {
            get { return (String)Get("usernumber1"); }
            set { Set("usernumber1", value); }
        }
        /// <summary>
        /// 전화번호2
        /// </summary>
        public String usernumber2
        {
            get { return (String)Get("usernumber2"); }
            set { Set("usernumber2", value); }
        }
        /// <summary>
        /// 전화번호3
        /// </summary>
        public String usernumber3
        {
            get { return (String)Get("usernumber3"); }
            set { Set("usernumber3", value); }
        }
        /// <summary>
        /// 이메일
        /// </summary>
        public String useremail
        {
            get { return (String)Get("useremail"); }
            set { Set("userEmail", value); }
        }
        /// <summary>
        /// 입사일
        /// </summary>
        public DateTime userIncidentday
        {
            get { return (DateTime)Get("userIncidentday", typeof(DateTime)); }
            set { Set("userIncidentday", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater"); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 회사코드
        /// </summary>
        public String companycode
        {
            get { return (String)Get("companycode"); }
            set { Set("companycode",value); }
        }
        //****************2014/10/21 추가 영문
        /// <summary>
        /// 유저명 영문
        /// </summary>
        public String username_en
        {
            get { return (String)Get("username_en", typeof(String)); }
            set { Set("username_en", value); }
        }
        /// <summary>
        /// 전화번호타입
        /// </summary>
        public String usernumbertype
        {
            get { return (String)Get("usernumbertype", typeof(String)); }
            set { Set("usernumbertype", value); }
        }
        /// <summary>
        /// 인증
        /// </summary>
        /// <returns></returns>
        public bool AuthorizeCheck()
        {
            base.ParameterInit();
            base.ParameterAdd("@id", userid);
            base.ParameterAdd("@pw", password);
            base.ParameterAdd("@state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            /*
            sb.Append(" SELECT ");
            sb.Append(" idx, ");
            sb.Append(" userid, ");
            sb.Append(" password, ");
            sb.Append(" username, ");
            sb.Append(" state, ");
            sb.Append(" permission, ");
            sb.Append(" usernumber, ");
            sb.Append(" userEmail, ");
            sb.Append(" userIncidentday, ");
            sb.Append(" createdate, ");
            sb.Append(" creater, ");
            sb.Append(" companycode ");*/
            sb.Append(" SELECT * ");
            sb.Append(" From tbl_UserInfo WHERE userid=@id and password=@pw and state=@state ");

            
            return Select(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 번호나누기
        /// </summary>
        public void NumberSplit()
        {
            try
            {
                String[] buffer = usernumber.Split('-');
                usernumber1 = buffer[0];
                usernumber2 = buffer[1];
                usernumber3 = buffer[2];
            }
            catch (Exception e)
            {
                LogWriter.Instance().FunctionLog();
                LogWriter.Instance().LineLog();
                LogWriter.Instance().LogWrite("전화번호 분할시 에러가 발생했습니다. ↓");
                LogWriter.Instance().LogWrite(e.ToString());
            }
        }
        /// <summary>
        /// 번호합치기
        /// </summary>
        public void NumberJoin()
        {
            usernumber = usernumber1 + "-" + usernumber2 + "-" + usernumber3;
            Remove("usernumber1");
            Remove("usernumber2");
            Remove("usernumber3");
        }
        /// <summary>
        /// 유저정보 수정
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public List<String> UserInfoModify(UserInfo modifyData, LanguageType? lType, String companyCode)
        {
            List<String> pError = modifyData.validate(lType);
            if (pError.Count < 1)
            {
                             //삭제처리
                ParameterInit();
                ParameterAdd("idx", idx);
                ParameterAdd("companycode", companyCode);
                StringBuilder query = new StringBuilder();
                query.Append(" UPDATE ");
                query.Append(" tbl_UserInfo ");
                query.Append(" set state = 1 ");
                query.Append(" where companycode = @companycode and idx=@idx");

                base.Delete(query.ToString(), GetParameter());

                            //삭제완료
                            //Form데이터에 기존 세팅
                query.Clear();
                ParameterInit();
                ParameterAdd("idx", idx);
                ParameterAdd("companycode", companyCode);
                query.Append(" SELECT ");
                query.Append(" * ");
                query.Append(" FROM tbl_UserInfo where idx=@idx and companycode = @companycode ");
                Select(query.ToString(), GetParameter());
                            
                            //패스워드 때문에 세팅
                modifyData.userid = userid;
                modifyData.companycode = companyCode;
                if (NullCheck(modifyData.password))
                {
                    modifyData.password = password;
                }
                modifyData.permission = permission;
                modifyData.state = "0";
                modifyData.userIncidentday = userIncidentday;
                modifyData.Remove("passwordCheck");
                this.Clear();

                            //메모리데이터 초기화
                List<String> keys = modifyData.GetKey();
                for (int i = 0; i < keys.Count; i++)
                {
                    this.Add(keys[i], modifyData.Get(keys[i]));
                }
                NumberJoin();
                this.state = "0";
                keys = GetKey();
                query.Clear();
                StringBuilder queryValue = new StringBuilder();
                query.Append(" INSERT INTO tbl_UserInfo (");
                queryValue.Append(" ( ");
                ParameterInit();
                for (int i = 0; i < keys.Count; i++)
                {
                    object data = Get(keys[i]);
                    if (data != null)
                    {
                        if (i > 0)
                        {
                            query.Append(",");
                            queryValue.Append(",");
                        }
                        query.Append(keys[i]);
                        queryValue.Append("@" + keys[i]);
                        ParameterAdd(keys[i], data);
                    }
                }
                query.Append(")");
                queryValue.Append(" ) ");
                base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());

                            //메모리 재세팅
                query.Clear();
                ParameterInit();
                ParameterAdd("userid", userid);
                ParameterAdd("companycode", companyCode);
                query.Append(" SELECT ");
                query.Append(" * ");
                query.Append(" FROM tbl_UserInfo where userid=@userid and companycode = @companycode and state = 0");
                Select(query.ToString(), GetParameter());
                Remove("password");
                NumberSplit();
            }
            return pError;
        }
        /// <summary>
        /// validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (NullCheck(username))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("유저명이 입력되지 않았습니다.");
                else Errmsg.Add("名前が入力されてありません。");
            }
            if (NullCheck(usernumber1) || NullCheck(usernumber2) || NullCheck(usernumber3))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("전화번호가 입력되지 않았습니다.");
                else Errmsg.Add("電話番号が入力されてありません。");
            }
            if (NullCheck(useremail))
            {
                if (lType == LanguageType.Korea) Errmsg.Add("이메일이 입력되지 않았습니다.");
                else Errmsg.Add("Eメールが入力されてありません。");
            }
            if (!NullCheck(password))
            {
                if (!password.Equals(passwordCheck))
                {
                    if (lType == LanguageType.Korea) Errmsg.Add("패스워드가 일치하지 않습니다.");
                    else Errmsg.Add("パスワードが一致しません。");
                }
            }
            return Errmsg;
        }
    }
}