﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class ConnectList : SYModelList<Connect>
    {
        public int ConnectCount()
        {
            ParameterInit();

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Connect ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }

        public int ConnectSelect(int pageLimit, int page)
        {
            ParameterInit();

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Connect ");
            sb.Append(" WHERE ");
            sb.Append(" idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Connect order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(), GetParameter());
        }
    }
}