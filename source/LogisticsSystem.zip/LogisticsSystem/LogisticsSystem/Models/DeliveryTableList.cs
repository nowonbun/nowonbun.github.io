﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class DeliveryTableList : SYModelList<DeliveryTable>
    {
        /// <summary>
        /// 납품확인서 카운트 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <returns></returns>
        public int DeliveryCount(String companycode)
        {
            ParameterInit();
            ParameterAdd("state",App_Code.Define.STATE_NORMAL);
            ParameterAdd("companycode",companycode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Delivery ");
            sb.Append(" WHERE state = @state ");
            sb.Append(" AND companycode = @companycode ");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 남품확인서 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int DeliverySelect(int pageLimit, int page,String companycode)
        {
            ParameterInit();
            ParameterAdd("state",App_Code.Define.STATE_NORMAL);
            ParameterAdd("companycode",companycode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Delivery ");
            sb.Append(" WHERE state = @state and companycode = @companycode ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Delivery WHERE state = @state and companycode = @companycode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(), GetParameter());
        }
    }
}