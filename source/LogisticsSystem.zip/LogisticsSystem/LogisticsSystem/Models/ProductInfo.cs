﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class ProductInfo : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 상품코드
        /// </summary>
        public String productcode
        {
            get { return (String)Get("productcode", typeof(String)); }
            set { Set("productcode", value); }
        }
        /// <summary>
        /// 상품이름
        /// </summary>
        public String productname
        {
            get { return (String)Get("productname", typeof(String)); }
            set { Set("productname", value); }
        }
        /// <summary>
        /// 상품타입
        /// </summary>
        public String productType
        {
            get { return (String)Get("productType", typeof(String)); }
            set { Set("productType", value); }
        }
        /// <summary>
        /// 상품규격
        /// </summary>
        public String productspec
        {
            get { return (String)Get("productspec", typeof(String)); }
            set { Set("productspec", value); }
        }
        /// <summary>
        /// 상품세금
        /// </summary>
        public int productTax
        {
            get { return (int)Get("productTax", typeof(int)); }
            set { Set("productTax", value); }
        }
        /// <summary>
        /// 매입사
        /// </summary>
        public String productAcquirer
        {
            get { return (String)Get("productAcquirer", typeof(String)); }
            set { Set("productAcquirer", value); }
        }
        /// <summary>
        /// 재고사
        /// </summary>
        public String productManufacturer
        {
            get { return (String)Get("productManufacturer", typeof(String)); }
            set { Set("productManufacturer", value); }
        }
        /// <summary>
        /// 상품매입가
        /// </summary>
        public Decimal productCost
        {
            get { return (Decimal)Get("productCost", typeof(Decimal)); }
            set { Set("productCost", value); }
        }
        /// <summary>
        /// 상품매입세전
        /// </summary>
        public Decimal productCostNotTax
        {
            get { return (Decimal)Get("productCostNotTax", typeof(Decimal)); }
            set { Set("productCostNotTax", value); }
        }
        /// <summary>
        /// 상품매입 세금
        /// </summary>
        public Decimal productCostTax
        {
            get { return (Decimal)Get("productCostTax", typeof(Decimal)); }
            set { Set("productCostTax", value); }
        }
        /// <summary>
        /// 공장도가격
        /// </summary>
        public Decimal productFactoryPrice
        {
            get { return (Decimal)Get("productFactoryPrice", typeof(Decimal)); }
            set { Set("productFactoryPrice", value); }
        }
        /// <summary>
        /// 공장도가격세전
        /// </summary>
        public Decimal productFactoryPriceNotTax
        {
            get { return (Decimal)Get("productFactoryPriceNotTax", typeof(Decimal)); }
            set { Set("productFactoryPriceNotTax", value); }
        }
        /// <summary>
        /// 공장도가격 세금
        /// </summary>
        public Decimal productFactoryPriceTax
        {
            get { return (Decimal)Get("productFactoryPriceTax", typeof(Decimal)); }
            set { Set("productFactoryPriceTax", value); }
        }
        /// <summary>
        /// 소비자가격
        /// </summary>
        public Decimal productRetailPrice
        {
            get { return (Decimal)Get("productRetailPrice", typeof(Decimal)); }
            set { Set("productRetailPrice", value); }
        }
        /// <summary>
        /// 소비자가격 세전
        /// </summary>
        public Decimal productRetailPriceNotTax
        {
            get { return (Decimal)Get("productRetailPriceNotTax", typeof(Decimal)); }
            set { Set("productRetailPriceNotTax", value); }
        }
        /// <summary>
        /// 소비자가격 세금
        /// </summary>
        public Decimal productRetailPriceTax
        {
            get { return (Decimal)Get("productRetailPriceTax", typeof(Decimal)); }
            set { Set("productRetailPriceTax", value); }
        }
        /// <summary>
        /// 판매가
        /// </summary>
        public Decimal productPrice
        {
            get { return (Decimal)Get("productPrice", typeof(Decimal)); }
            set { Set("productPrice", value); }
        }
        /// <summary>
        /// 판매가세전
        /// </summary>
        public Decimal productPriceNotTax
        {
            get { return (Decimal)Get("productPriceNotTax", typeof(Decimal)); }
            set { Set("productPriceNotTax", value); }
        }
        /// <summary>
        /// 판매가 세금
        /// </summary>
        public Decimal productPriceTax
        {
            get { return (Decimal)Get("productPriceTax", typeof(Decimal)); }
            set { Set("productPriceTax", value); }
        }
        /// <summary>
        /// 바코드
        /// </summary>
        public String barcode
        {
            get { return (String)Get("barcode", typeof(String)); }
            set { Set("barcode", value); }
        }
        /// <summary>
        /// QR코드
        /// </summary>
        public String QRcode
        {
            get { return (String)Get("QRcode", typeof(String)); }
            set { Set("QRcode", value); }
        }
        /// <summary>
        /// 기타
        /// </summary>
        public String other
        {
            get { return (String)Get("other", typeof(String)); }
            set { Set("other", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일 Dispay용
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        public String projectDispSpec
        {
            get { return (String)Get("projectDispSpec", typeof(String)); }
        }
        public String CreateCode()
        {
            String query = " insert into codeCreater select Cast(isnull(Max(codebuffer)+1,1) as Decimal) as code,1 from codeCreater where type=1";
            Insert(query);
            query = " select Cast(Max(codebuffer)as Decimal) as code from codeCreater where type=1 ";
            Select(query);
            return ((Decimal)Get("code", typeof(Decimal))).ToString("0000");
        }
        /// <summary>
        /// 데이터 입력
        /// </summary>
        public int ProductInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_ProductInfo (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        /// <summary>
        /// 상품클릭시 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool ProductSelect(string code,String compcode)
        {
            ParameterInit();
            ParameterAdd("companycode", compcode);
            ParameterAdd("productcode", code);
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT * FROM tbl_ProductInfo where state = '0' and productcode = @productcode and companycode = @companycode ");
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 상품 히스토리 검색(히스토리리스트에서 클릭했을때)
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool ProductHistorySelect(int idx,string compcode)
        {
            ParameterInit();
            ParameterAdd("companycode", compcode);
            ParameterAdd("idx", idx);

            StringBuilder query = new StringBuilder();
            query.Append(" SELECT * FROM tbl_ProductInfo where idx = @idx and companycode=@companycode  ");
            
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 상품 삭제
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int ProductDelete(String productcode,string compcode)
        {
            ParameterInit();
            ParameterAdd("companycode", compcode);
            ParameterAdd("productcode", productcode);
            ParameterAdd("state",Define.STATE_DELETE);

            StringBuilder query = new StringBuilder();
            query.Append(" UPDATE ");
            query.Append(" tbl_ProductInfo ");
            query.Append(" set state = @state ");
            query.Append(" where productcode = @productcode and companycode=@companycode ");
           
            return base.Delete(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 상품 검색
        /// Database - CompanyCode Binding OK!
        /// ltype 부분은 SE가 설정하므로 문제없다.
        /// </summary>
        public bool ProductSelect(int idx, string compcode, LanguageType? lType)
        {
            ParameterInit();
            ParameterAdd("companycode", compcode);
            ParameterAdd("idx", idx);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder query = new StringBuilder();
            query.Append(" SELECT * ");
            query.Append(" FROM tbl_ProductInfo ");
            query.Append(" WHERE state = @state ");
            query.Append(" AND idx = @idx ");
            query.Append(" AND companycode=@companycode ");
            
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// Validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (lType == LanguageType.Korea)
            {
                if (productcode == null || productcode.Equals(""))
                {
                    Errmsg.Add("상품코드가 입력되지 않았습니다.");
                }
                if (productname == null || productname.Equals(""))
                {
                    Errmsg.Add("상품이름이 입력되지 않았습니다.");
                }
            }
            else
            {
                if (productcode == null || productcode.Equals(""))
                {
                    Errmsg.Add("商品コードが入力されてありません。");
                }
                if (productname == null || productname.Equals(""))
                {
                    Errmsg.Add("商品名が入力されてありません。");
                }
            }
            return Errmsg;
        }
    }
}