﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class CustomerInfoList : SYModelList<CustomerInfo>
    {
        /// <summary>
        /// 고객 리스트 총 개수
        /// </summary>
        public int CustomerInfoCount(string compcode)
        {
            ParameterInit();
            ParameterAdd("companycode",compcode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE state = '0' and companycode=@companycode");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 고객 리스트검색 쿼리
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int SelectList(int pageLimit, int page, String compcode)
        {
            ParameterInit();
            ParameterAdd("companycode", compcode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE state = '0' and companycode=@companycode");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Customer WHERE state = '0' and companycode=@companycode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(),GetParameter());
        }
        /// <summary>
        /// 히스토리 리스트에서 검색시
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int CustomerInfoHistorySearch(int pageLimit, int page, string code,String compcode)
        {
            ParameterInit();
            ParameterAdd("customercode", code);
            ParameterAdd("companycode",compcode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" TOP " + pageLimit.ToString() + " * ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE customercode = @customercode and companycode=@companycode ");
            sb.Append(" AND idx not in ");
            sb.Append(" (SELECT TOP " + (pageLimit * (page - 1)).ToString() + " idx FROM tbl_Customer WHERE customercode = @customercode and companycode=@companycode order by idx desc) ");
            sb.Append(" order by idx desc");

            return SelectList(sb.ToString(), GetParameter());
        }
        public int CustomerInfoHistoryCount(String code,String companycode)
        {
            ParameterInit();
            ParameterAdd("code", code);
            ParameterAdd("companycode", companycode);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" count(*) as count ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE customercode = @code and companycode = @companycode");
            SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
            return this[0].GetCount();
        }
        /// <summary>
        /// 발주사 리스트
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <returns></returns>
        public int OrderCompList(String companycode)
        {
            ParameterInit();
            ParameterAdd("customerType", "001");
            ParameterAdd("companycode",companycode);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" * ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE customerType = @customerType and state = @state and companycode=@companycode ");
            return SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
        }
        /// <summary>
        /// 수주사리스트
        /// </summary>
        /// <returns></returns>
        public int InorderCompList(String companycode)
        {
            ParameterInit();
            ParameterAdd("customerType", "002");
            ParameterAdd("companycode", companycode);
            ParameterAdd("state", Define.STATE_NORMAL);

            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT ");
            sb.Append(" * ");
            sb.Append(" FROM tbl_Customer ");
            sb.Append(" WHERE customerType = @customerType and state = @state and companycode=@companycode ");
            return SelectList(System.Data.CommandType.Text, sb.ToString(), GetParameter());
        }
    }
}