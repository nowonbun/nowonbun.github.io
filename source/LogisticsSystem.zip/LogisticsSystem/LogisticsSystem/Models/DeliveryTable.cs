﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    /// <summary>
    /// 납품확인테이블 Model
    /// </summary>
    public class DeliveryTable : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 고객사
        /// </summary>
        public String orderCompany
        {
            get { return (String)Get("orderCompany", typeof(String)); }
            set { Set("orderCompany", value); }
        }
        /// <summary>
        /// 고객사 주소
        /// </summary>
        public String orderAddress
        {
            get { return (String)Get("orderAddress", typeof(String)); }
            set { Set("orderAddress", value); }
        }
        /// <summary>
        /// 납품일
        /// </summary>
        public DateTime orderSavedate
        {
            get { return (DateTime)Get("orderSavedate", typeof(DateTime)); }
            set { Set("orderSavedate", value); }
        }
        /// <summary>
        /// 납품일 String
        /// </summary>
        public String orderSavedateString
        {
            get { return orderSavedate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 납품사(우리회사)
        /// </summary>
        public String inorderCompany
        {
            get { return (String)Get("inorderCompany", typeof(String)); }
            set { Set("inorderCompany", value); }
        }
        /// <summary>
        /// 대표자
        /// </summary>
        public String inorderRepresentative
        {
            get { return (String)Get("inorderRepresentative", typeof(String)); }
            set { Set("inorderRepresentative", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성일 String형으로 변환식
        /// </summary>
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        /// <summary>
        /// 데이터입력
        /// </summary>
        /// <returns></returns>
        public int DeliveryInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Delivery (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public void LastIndexReflesh()
        {
            idx = ScopeIndentity("tbl_Delivery");
        }

        /// <summary>
        /// 납품확인서 취득
        /// Database - CompanyCode Binding OK!
        /// </summary>
        /// <param name="idx"></param>
        /// <param name="companycode"></param>
        /// <returns></returns>
        public bool SelectIdx(Int64 idx,String companycode)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx",idx);
            ParameterAdd("companycode", companycode);
            query.Append("SELECT * FROM tbl_Delivery where idx = @idx order by idx desc");
            return base.Select(query.ToString(),GetParameter());
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
    }
}