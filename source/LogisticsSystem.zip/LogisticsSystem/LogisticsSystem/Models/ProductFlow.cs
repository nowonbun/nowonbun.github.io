﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    public class ProductFlow : SYModel
    {
        public const int INCOMESTANBY = 1;
        public const int INCOMECOMPLATE = 2;
        public const int OUTCOMESTANBY = 3;
        public const int OUTPUTCOMPLATE = 4;
        public const int INCOMECANCEL = 5;
        public const int OUTPUTCANCEL = 6;

        public const Int64 APPLYTYPE_NORMAL = 0;
        /// <summary>
        /// 완료
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 상품Index
        /// </summary>
        public Int64 productIndex
        {
            get { return (Int64)Get("productIndex", typeof(Int64)); }
            set { Set("productIndex", value); }
        }
        /// <summary>
        /// 상품수량
        /// </summary>
        public Decimal productAmount
        {
            get { return (Decimal)Get("productAmount", typeof(Decimal)); }
            set { Set("productAmount", value); }
        }
        /// <summary>
        /// 입고시 가격
        /// </summary>
        public Decimal productbuyPrice
        {
            get { return (Decimal)Get("productbuyPrice", typeof(Decimal)); }
            set { Set("productbuyPrice", value); }
        }
        /// <summary>
        /// 출고시 가격
        /// </summary>
        public Decimal productSellPrice
        {
            get { return (Decimal)Get("productSellPrice", typeof(Decimal)); }
            set { Set("productSellPrice", value); }
        }
        /// <summary>
        /// 생성날자
        /// </summary>
        public DateTime cretedate
        {
            get { return (DateTime)Get("cretedate", typeof(DateTime)); }
            set { Set("cretedate", value); }
        }
        /// <summary>
        /// 생성자
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 상태명
        /// </summary>
        public String stateDisp
        {
            get { return (String)Get("stateDisp", typeof(String)); }
            set { Set("stateDisp", value); }
        }
        public String productname
        {
            get { return (String)Get("productname", typeof(String)); }
            set { Set("productname", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        /// <summary>
        /// 발주서 입력=1, 입고신청서=0 등록 구분
        /// </summary>
        public Int64 applyType
        {
            get { return (Int64)Get("applytype", typeof(Int64)); }
            set { Set("applytype", value); }
        }
        /// <summary>
        /// 그밖에...
        /// </summary>
        public String ETC
        {
            get { return (String)Get("etc", typeof(String)); }
            set { Set("etc", value); }
        }
        /// <summary>
        /// 데이터 입력
        /// </summary>
        public int ProductInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_ProductFlow (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        /// <summary>
        /// 입고등록
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public int ProductApprove(Int64 idx,String companycode,int state)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode",companycode);
            ParameterAdd("state", state);

            StringBuilder query = new StringBuilder();
            query.Append(" Update tbl_ProductFlow ");
            query.Append(" set state = @state ");
            query.Append(" where idx=@idx and companycode=@companycode");
            
            return base.Update(query.ToString(), GetParameter());
        }
        public int ProductReleaseApprove()
        {
            StringBuilder query = new StringBuilder();
            query.Append(" Update tbl_ProductFlow ");
            query.Append(" set state = '4' ");
            query.Append(" where idx = @idx ");
            ParameterInit();
            ParameterAdd("idx", this.idx);
            return base.Update(query.ToString(), GetParameter());
        }
        /// <summary>
        /// 데이터 검색
        /// Database - CompanyCode Binding OK!
        /// </summary>
        public bool ProductSelect(Int64 idx,String companycode)
        {
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("companycode",companycode);

            StringBuilder query = new StringBuilder();
            query.Append(" SELECT A.*,B.productname FROM tbl_ProductFlow A inner join tbl_productInfo B on A.productIndex = B.idx ");
            query.Append(" where A.idx = @idx and A.companycode=@companycode ");
            
            return base.Select(query.ToString(), GetParameter());
        }
        /// <summary>
        /// Validate
        /// </summary>
        public List<String> validate(LanguageType? lType)
        {
            List<String> Errmsg = new List<string>();
            if (productIndex <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add("상품이 선택되지 않았습니다.");
                else Errmsg.Add("商品が選択されてありません。。");
            }
            if (productAmount <= 0)
            {
                if (lType == LanguageType.Korea) Errmsg.Add("상품수량이 입력되지 않았습니다.");
                else Errmsg.Add("商品数量が入力されてありません。");
            }
            return Errmsg;
        }
        /// <summary>
        /// 상태처리명
        /// </summary>
        public void stateView(LanguageType? lType)
        {
            //상태
            if (ProductFlow.INCOMESTANBY.ToString().Equals(state.ToString()))
            {
                if (lType == LanguageType.Korea) stateDisp = "입고대기";
                else stateDisp = "入庫待ち";
            }
                //2014/10/03 여기까지 했다
                //입고 StoreController 까지 했다.
            else if (ProductFlow.INCOMECANCEL.ToString().Equals(state.ToString()))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인취소";
                else stateDisp = "承認取消";
            }
            else if (ProductFlow.INCOMECOMPLATE.ToString().Equals(state))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인";
                else stateDisp = "承認";
            } 
            else if (ProductFlow.OUTCOMESTANBY.ToString().Equals(state.ToString()))
            {
                if (lType == LanguageType.Korea) stateDisp = "출고대기";
                else stateDisp = "出庫待ち";
            }
            else if (ProductFlow.OUTPUTCANCEL.ToString().Equals(state.ToString()))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인취소";
                else stateDisp = "承認取消";
            }
            else if (ProductFlow.OUTPUTCOMPLATE.ToString().Equals(state))
            {
                if (lType == LanguageType.Korea) stateDisp = "승인";
                else stateDisp = "承認";
            }
        }
    }
}