﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Models
{
    public class Comment : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// Index
        /// </summary>
        public Int64 boardidx
        {
            get { return (Int64)Get("boardidx", typeof(Int64)); }
            set { Set("boardidx", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String context
        {
            get { return (String)Get("context", typeof(String)); }
            set { Set("context", value); }
        }
        /// <summary>
        /// String
        /// </summary>
        public String creater
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        public String createdateString
        {
            get { return createdate.ToString("yyyy-MM-dd"); }
        }
        /// <summary>
        /// 상태
        /// </summary>
        public String state
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        public int GetCount()
        {
            return (int)Get("count", typeof(int));
        }
        /// <summary>
        /// 댓글 입력 쿼리
        /// </summary>
        public int CommentInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_BoardComment (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
        public int DeleteIdx(Int64 idx)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("idx", idx);
            ParameterAdd("state", Define.STATE_DELETE);
            query.Append("UPDATE tbl_BoardComment set state = @state where idx = @idx");
            return base.Delete(query.ToString(), GetParameter());
        }
        public int ConnectModify(Int64 preIdx, Int64 afterIdx)
        {
            StringBuilder query = new StringBuilder();
            ParameterInit();
            ParameterAdd("preIdx", preIdx);
            ParameterAdd("afterIdx", afterIdx);
            ParameterAdd("state", Define.STATE_DELETE);
            query.Append("UPDATE tbl_BoardComment set boardidx = @afterIdx where boardidx = @preIdx");
            return base.Delete(query.ToString(), GetParameter());
        }
    }
}