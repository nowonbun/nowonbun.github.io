﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Models
{
    /// <summary>
    /// 납품서브확인테이블
    /// </summary>
    public class DeliveryTable_Sub : SYModel
    {
        /// <summary>
        /// Index
        /// </summary>
        public Int64 idx
        {
            get { return (Int64)Get("idx", typeof(Int64)); }
            set { Set("idx", value); }
        }
        /// <summary>
        /// 납품테이블 키
        /// </summary>
        public Int64 deliverykey 
        {
            get { return (Int64)Get("deliverykey", typeof(Int64)); }
            set { Set("deliverykey", value); }
        }
        /// <summary>
        /// 번호
        /// </summary>
        public int number
        {
            get { return (int)Get("number", typeof(int)); }
            set { Set("number", value); }
        }
        /// <summary>
        /// 상품키
        /// </summary>
        public Int64 productIndex
        {
            get { return (Int64)Get("productIndex", typeof(Int64)); }
            set { Set("productIndex", value); }
        }
        /// <summary>
        /// 규격
        /// </summary>
        public String productSpec
        {
            get { return (String)Get("productSpec", typeof(String)); }
            set { Set("productSpec", value); }
        }
        /// <summary>
        /// 단위
        /// </summary>
        public String productType
        {
            get { return (String)Get("productType", typeof(String)); }
            set { Set("productType", value); }
        }
        /// <summary>
        /// 상품양
        /// </summary>
        public Decimal productAmount
        {
            get { return (Decimal)Get("productAmount", typeof(Decimal)); }
            set { Set("productAmount", value); }
        }
        /// <summary>
        /// 공급가액
        /// </summary>
        public Decimal productPrice
        {
            get { return (Decimal)Get("productPrice", typeof(Decimal)); }
            set { Set("productPrice", value); }
        }
        /// <summary>
        /// 공급가액세금
        /// </summary>
        public Decimal productVat
        {
            get { return (Decimal)Get("productVat", typeof(Decimal)); }
            set { Set("productVat", value); }
        }
        /// <summary>
        /// 비고
        /// </summary>
        public String productOther
        {
            get { return (String)Get("productOther", typeof(String)); }
            set { Set("productOther", value); }
        }
        /// <summary>
        /// 작성일
        /// </summary>
        public DateTime createdate
        {
            get { return (DateTime)Get("createdate", typeof(DateTime)); }
            set { Set("createdate", value); }
        }
        /// <summary>
        /// 작성자
        /// </summary>
        public String creater //작성자
        {
            get { return (String)Get("creater", typeof(String)); }
            set { Set("creater", value); }
        }
        /// <summary>
        /// 작성상태
        /// </summary>
        public String state //작성상태
        {
            get { return (String)Get("state", typeof(String)); }
            set { Set("state", value); }
        }
        /// <summary>
        /// 회사코드(데이터 입력시)
        /// </summary>
        public String companycode
        {
            set { Set("companycode", value); }
        }
        //Join용
        public String productName //상품이름
        {
            get { return (String)Get("productName", typeof(String)); }
            set { Set("productName", value); }
        }
        public String productspec_disp
        {
            get { return (String)Get("productspec_disp", typeof(String)); }
            set { Set("productspec_disp", value); }
        }
        /// <summary>
        /// 데이터입력
        /// </summary>
        /// <returns></returns>
        public int SubInsert()
        {
            List<String> keys = GetKey();
            StringBuilder query = new StringBuilder();
            StringBuilder queryValue = new StringBuilder();
            query.Append(" INSERT INTO tbl_Delivery_Sub (");
            queryValue.Append(" ( ");
            ParameterInit();
            for (int i = 0; i < keys.Count; i++)
            {
                object data = Get(keys[i]);
                if (data != null)
                {
                    if (i > 0)
                    {
                        query.Append(",");
                        queryValue.Append(",");
                    }
                    query.Append(keys[i]);
                    queryValue.Append("@" + keys[i]);
                    ParameterAdd(keys[i], data);
                }
            }
            query.Append(")");
            queryValue.Append(" ) ");
            return base.Insert(query.ToString() + "values" + queryValue.ToString(), GetParameter());
        }
    }
}