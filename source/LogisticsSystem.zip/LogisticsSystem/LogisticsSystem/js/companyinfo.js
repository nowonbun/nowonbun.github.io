﻿$(function () {
    $("#companyEstablishmenidate").datepicker({
        dateFormat: 'yy-mm-dd'
    });
});