﻿function LoginSubmit() {
    document.loginPost.submit();
}