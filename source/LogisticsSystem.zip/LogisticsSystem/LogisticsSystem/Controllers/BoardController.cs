﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;

namespace LogisticsSystem.Controllers
{
    public class BoardController : SyController
    {
        private const int PAGELIMIT = 10000;
        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult List()
        {
            LogWriter.Instance().LogWrite("/Board/List 접속");
            if (!SessionCheck("SessionCheck"))
            {
                LogWriter.Instance().LogWrite("/Board/List 에서 세션 만료로 에러가 발생합니다.");
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                BoardList list = new BoardList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.BoardCount() / (Double)PAGELIMIT)));
                list.BoardSelect(PAGELIMIT, 1);
                ViewBag.listcount = count;
                CommentList comment = new CommentList();
                foreach (Board board in list)
                {
                    board.title += " (" + comment.CommentCount(board.idx).ToString() + ")";
                }
                ViewBag.list = list;

                Session["controller"] = "Board";
                Session["action"] = "List";
                return View("~/Views/Board/Web/List.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/List 인증 에러");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Create()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                ViewBag.user = UserSession.userid;
                Session["controller"] = "Board";
                Session["action"] = "List";
                return View("~/Views/Board/Web/Create.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ModifyView(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                Board board = new Board();
                board.SelectIdx(idx);

                ViewBag.board = board;
                Session["controller"] = "Board";
                Session["action"] = "List";
                ViewBag.user = UserSession.userid;
                CommentList commentlist = new CommentList();
                commentlist.CommentSelect(idx);
                ViewBag.comment = commentlist;
                return View("~/Views/Board/Web/Create.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Insert(Board board)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                board.creater = UserSession.userid;
                board.createdate = DateTime.Now;
                board.state = Define.STATE_NORMAL.ToString();
                if (!String.IsNullOrEmpty(board.title.Trim()))
                {
                    board.num = board.BoardMaxNum();
                    board.BoardInsert();
                }
                return Redirect("/Board/List");
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult View(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                Board board = new Board();
                board.SelectIdx(idx);

                ViewBag.board = board;
                Session["controller"] = "Board";
                Session["action"] = "List";
                ViewBag.user = UserSession.userid;
                CommentList commentlist = new CommentList();
                commentlist.CommentSelect(idx);
                ViewBag.comment = commentlist;
                ViewBag.modifyCheck = board.creater.Equals(UserSession.userid);
                //if (board.creater.Equals(UserSession.userid))
                //{
                //    return View("~/Views/Board/Web/Create.cshtml", Define.MASTER_VIEW);
                //}
                //else
                //{
                    return View("~/Views/Board/Web/View.cshtml", Define.MASTER_VIEW);
                //}
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Delete(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                Board board = new Board();
                board.DeleteIdx(idx);
                return Redirect("/Board/List");
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Modify(Board board)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                board.creater = UserSession.userid;
                board.createdate = DateTime.Now;
                board.state = Define.STATE_NORMAL.ToString();
                Int64 idx = board.ModifyIdx();
                return Redirect("/Board/View?idx=" + idx.ToString());
                //return Redirect("/Board/List");
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/Create - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CommentApply(Comment comment)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                comment.creater = UserSession.userid;
                comment.createdate = DateTime.Now;
                comment.state = Define.STATE_NORMAL.ToString();
                if (!String.IsNullOrEmpty(comment.context.Trim()))
                    comment.CommentInsert();
                return Redirect("/Board/View?idx="+comment.boardidx);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/CommentApply - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CommentDelete(Int64 idx, int boardidx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                Comment comment = new Comment();
                comment.DeleteIdx(idx);
                return Redirect("/Board/View?idx=" + boardidx);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Board/CommentApply - Error");
                return base.Logout();
            }
        }
        //commnetDelete
    }
}
