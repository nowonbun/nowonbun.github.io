﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;

namespace LogisticsSystem.Controllers
{
    public class ProductController : SyController
    {
        private const int PAGELIMIT = 10;
        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"];  }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        /// <summary>
        /// 상품 등록 페이지 초기화
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Main()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Main");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                CodeMasterList pBuffer = new CodeMasterList("productType");
                pBuffer.Trans(lType);
                ViewBag.productType = pBuffer;
                pBuffer = new CodeMasterList("productSpec");
                pBuffer.Trans(lType);
                ViewBag.productSpec = pBuffer;

                //1페이지 검색
                ProductInfoList list = new ProductInfoList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.ProductInfoCount(CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.SelectList(PAGELIMIT, 1, CompanySession.companyCode);
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Product/Web/Main.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Main - Error");
                return Logout();
            }
        }
        /// <summary>
        /// 검색 AJAX
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/ListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                ProductInfoList list = new ProductInfoList();
                int count = list.ProductInfoCount(CompanySession.companyCode);
                list.SelectList(PAGELIMIT, page, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/ListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 코드생성
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CodeCreate()
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/CodeCreate");
                ProductInfo pBuffer = new ProductInfo();
                return Content(pBuffer.CreateCode());
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/CodeCreate - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 상품 등록부분 AJAX
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Insert(ProductInfo data)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Insert");

                List<String> Errmsg = data.validate((LanguageType?)Session["languageType"]);
                if (Errmsg.Count < 1)
                {
                    data.productcode = "GC-" + data.productcode;
                    data.creater = User.Identity.Name;
                    data.createdate = DateTime.Now;
                    data.state = "0";
                    data.companycode = CompanySession.companyCode;
                    data.ProductInsert();
                    return Content(null);
                }
                else
                {
                    String ret = "";
                    foreach (string pBuffer in Errmsg)
                    {
                        ret += pBuffer + "<br>";
                    }
                    return Content(ret);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Insert - Sessionout");
                return Content("SESSIONOUT");
            }
        }
        /// <summary>
        /// 상품검색(리스트 클릭시)
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ProductSearch(String code)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/ProductSearch");

                ProductInfo info = new ProductInfo();
                info.ProductSelect(code,CompanySession.companyCode);
                return Json(info,JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/ProductSearch - Sessionout");
                return NoAjax();
            }
        }
        /// <summary>
        /// 삭제함수
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Delete(String code)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Delete");

                new ProductInfo().ProductDelete(code,CompanySession.companyCode);
                return Content("OK");
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Delete - Sessionout");
                return Content("SESSIONOUT");
            }
        }
        /// <summary>
        /// 수정합수
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Modify(ProductInfo data)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                //버그가 있다.. 수정해야겠다.
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Modify");
                List<String> Errmsg = data.validate((LanguageType?)Session["languageType"]);
                if (Errmsg.Count < 1)
                {
                    Delete("GC-"+data.productcode);
                    return Insert(data);
                }
                else
                {
                    String ret = "";
                    foreach (string pBuffer in Errmsg)
                    {
                        ret += pBuffer + "<br>";
                    }
                    return Content(ret);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/Modify - Sessionout");
                return Content("SESSIONOUT");
            }
        }
        /// <summary>
        /// 상품 이력 리스트 검색 Ajax
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult HistorySearch(String code,int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                int pagelimit = 10;
                if (page < 1)
                {
                    page = 1;
                }
                ProductInfoList list = new ProductInfoList();
                int count = list.ProductInfoHistoryCount(code,CompanySession.companyCode);
                list.ProductInfoHistorySearch(pagelimit, page, code, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", pagelimit);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 히스토리 리스트에서 상품검색을 할 경우
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ProductHistorySearch(int idx = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if(AuthCheck())
            {
                ProductInfo info = new ProductInfo();
                info.ProductHistorySelect(idx,CompanySession.companyCode);
                return Json(info, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
    }
}
