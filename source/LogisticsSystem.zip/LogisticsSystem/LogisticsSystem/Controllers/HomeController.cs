﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using System.Text;

namespace LogisticsSystem.Controllers
{
    public class HomeController : SyController
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Error()
        {
            Session["controller"] = RouteData.Values["controller"];
            Session["action"] = RouteData.Values["action"];
            return View();
        }
        public ContentResult ErrorMsg(string code)
        {
            if (code == null || "".Equals(code))
            {
                return Content("Error");
            }
            return Content(ErrorPack.GetError(Server.MapPath("~/ErrorCode/ErrorCode.xml"), code, (LanguageType?)Session["languageType"]));
        }
        /// <summary>
        /// 익스플로러 8이하 일경우 경고 에러 페이지
        /// </summary>
        /// <returns></returns>
        public ActionResult BrowserError()
        {
            Session["controller"] = RouteData.Values["controller"];
            Session["action"] = RouteData.Values["action"];
            return View();
        }
    }
}
