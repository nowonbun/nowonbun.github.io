﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.Models;
using LogisticsSystem.App_Code;

namespace LogisticsSystem.Controllers
{
    public class DeliveryController : SyController
    {
        private const int PAGELIMIT = 50;
        private const int ORDERCODE = 1;
        private const String DOCUMENTCODE = "1";
        private const String DOCUMENTDELIVERYCODE = "2";
        private const String DOCUMENTBILLCODE = "3";
        private const int COMMIT_KANRYOU = 1;
        private const int COMMIT_KAKUNINN = 2;
        private const int COMMIT_SHOUNINN = 3;
        private const int COMMIT_SHOUNINN_COMPLATE = 4;
        private const int COMMIT_SHOUNINN_CANCLE = 5;

        private const String ORDERSESSIONKEY = "ijdfbfoasbfdka";

        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        /// <summary>
        /// 수주신청서 등록
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryOrder(String key = "")
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryOrder");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                ViewBag.userinfo = UserSession;
                ViewBag.compinfo = CompanySession;
                Document pDoc = new Document();
                OrderTable pOrder = new OrderTable();
                CustomerInfoList pCustomer = new CustomerInfoList();
                ProductInfoList pProduct = new ProductInfoList();

                pCustomer.InorderCompList(CompanySession.companyCode);
                pProduct.ProductNameList(CompanySession.companyCode);
                CodeMasterList pBuffer = new CodeMasterList("MoneySendType"); 
                pBuffer.Trans(lType);
                ViewBag.moneySendType = pBuffer;
                
                ViewBag.productlist = pProduct;
                ViewBag.ordercomplist = pCustomer;

                if ("BACK".Equals(key))
                {
                    pDoc = (Document)Session["orderDOC"];
                    pOrder = (OrderTable)Session["order"];
                    OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                    if (pDoc == null || pOrder == null)
                    {
                        pDoc = new Document();
                        pOrder = new OrderTable();
                        ViewBag.MunCode = pDoc.CreateCode();
                        ViewBag.BalCode = pOrder.CreateCode();
                        ViewBag.totalMoney = 0;
                    }
                    else
                    {
                        ViewBag.MunCode = pDoc.documentCode;
                        ViewBag.BalCode = pOrder.ordernumber;
                        ViewBag.order = pOrder;
                        ViewBag.orderSub = pSubOrder;
                        Decimal totalMoney = 0;
                        foreach (OrderTable_Sub pSub in pSubOrder)
                        {
                            totalMoney += pSub.productMoney;
                        }
                        ViewBag.totalMoney = totalMoney;

                    }
                }
                else
                {
                    pDoc = new Document();
                    pOrder = new OrderTable();
                    ViewBag.MunCode = pDoc.CreateCode();
                    ViewBag.BalCode = pOrder.CreateCode();
                    ViewBag.totalMoney = 0;
                }
                Session["orderDOC"] = null;
                Session["order"] = null;
                Session["orderSub"] = null;
                Session["orderCheck"] = null;


                return View("~/Views/Delivery/Web/DeliveryOrder.cshtml", Define.MASTER_VIEW);
            }
            return base.Logout();
        }
        /// <summary>
        /// 수주신청폼에서 회사 정보 취득 AJAX
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult orderSelect(int idx)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/orderSelect");
                CustomerInfo customer = new CustomerInfo();
                customer.CustomerSelect(idx, CompanySession.companyCode);

                return Json(customer, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/orderSelect - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 입력확인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Inputcheck(Document pDoc, OrderTable pOrder, OrderTable_SubAddList pSubOrder)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Inputcheck");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //잘못된 경로로 들어올 시
                if (pDoc.documentCode == null || "".Equals(pDoc.documentCode))
                {
                    return Redirect("/Delivery/DeliveryOrder");
                }

                List<String> pErrmsg = new List<string>();
                List<String> pBuffer2 = null;
                pBuffer2 = pDoc.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                pBuffer2 = pOrder.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                pBuffer2 = pSubOrder.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                Session["action"] = "DeliveryOrder";
                //에러가 발생시
                if (pErrmsg.Count > 0)
                {
                    //******************************************************
                    //회원정보
                    ViewBag.userinfo = UserSession;
                    //회사정보
                    ViewBag.compinfo = CompanySession;

                    CustomerInfoList pCustomer = new CustomerInfoList();
                    ProductInfoList pProduct = new ProductInfoList();
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                    pCustomer.InorderCompList(CompanySession.companyCode);
                    pProduct.ProductNameList(CompanySession.companyCode);

                    ViewBag.ordercomplist = pCustomer;
                    ViewBag.productlist = pProduct;

                    ViewBag.MunCode = pDoc.documentCode;
                    ViewBag.BalCode = pOrder.ordernumber;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder.List;

                    String err = "";
                    foreach (String pData in pErrmsg)
                    {
                        err += pData + "<br>";
                    }
                    ViewBag.ErrMsg = err;

                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder.List)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;
                    //******************************************************
                    return View("~/Views/Delivery/Web/DeliveryOrder.cshtml", Define.MASTER_VIEW);
                }
                //정상시
                else
                {
                    Document doc = pDoc;
                    OrderTable order = pOrder;
                    OrderTable_SubList orderSub = pSubOrder.List;

                    //세션 저장
                    Session["orderDOC"] = doc;
                    Session["order"] = order;
                    Session["orderSub"] = orderSub;
                    Session["orderCheck"] = ORDERSESSIONKEY;

                    //상품정보 취득
                    ProductInfoList pProduct = new ProductInfoList();
                    pProduct.ProductNameList(CompanySession.companyCode);
                    foreach (OrderTable_Sub data in orderSub)
                    {
                        foreach (ProductInfo info in pProduct)
                        {
                            if (info.idx == data.productIndex)
                            {
                                data.productName = info.productname;
                            }
                        }
                    }
                    //기본ViewBag 설정
                    ViewSetting(doc, order, orderSub);

                    ViewBag.Commit = COMMIT_KAKUNINN;

                    return View("~/Views/Delivery/Web/DeliveryOrderCheck.cshtml", Define.MASTER_VIEW);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Inputcheck - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 수주신청입력 Action
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Input()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/Input");
                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable)Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                String InputSessionkey = (String)Session["orderCheck"];
                //비정상경로
                if (pDoc == null || pOrder == null || pSubOrder == null || InputSessionkey == null)
                {
                    return Redirect("/Obtain/Order");
                }
                else
                {
                    //비정상경로
                    if (!ORDERSESSIONKEY.Equals(InputSessionkey))
                    {
                        return Redirect("/Obtain/Order");
                    }
                    Session["orderDOC"] = null;
                    Session["order"] = null;
                    Session["orderSub"] = null;
                    Session["orderCheck"] = null;
                }
                //************* 발주 테이블
                pOrder.state = App_Code.Define.STATE_NORMAL.ToString();
                pOrder.ordertype = ORDERCODE.ToString();
                pOrder.companycode = CompanySession.companyCode;

                //발주서정보저장
                pOrder.OrderInsert();
                //재갱신
                pOrder.SelectReflesh();

                //*************문서테이블
                pDoc.documentIndex = pOrder.idx;
                pDoc.companycode = CompanySession.companyCode;
                pDoc.documentType = DOCUMENTCODE;
                pDoc.state = App_Code.Define.STATE_NORMAL.ToString();
                //문서정보저장
                pDoc.DocumentInsert();

                //상품테이블
                //서버 상품정보 저장
                pSubOrder.ListInsert(pOrder.idx, pDoc.creater, CompanySession.companyCode);

                ViewBag.Commit = COMMIT_KANRYOU;

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);

                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                foreach (OrderTable_Sub data in pSubOrder)
                {
                    foreach (ProductInfo info in pProduct)
                    {
                        if (info.idx == data.productIndex)
                        {
                            data.productName = info.productname;
                        }
                    }
                }

                Session["action"] = "DeliveryOrder";
                return View("~/Views/Delivery/Web/DeliveryOrderCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/Input - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 기본 Attribute 세팅
        /// </summary>
        protected void ViewSetting(Document pDoc, OrderTable pOrder, OrderTable_SubList pSubOrder)
        {
            String pLanguage = Request.Form["Lang"];
            LanguageType? lType = null;
            if (pLanguage != null && !"".Equals(pLanguage))
            {
                if ("k".Equals(pLanguage))
                {
                    lType = LanguageType.Korea;
                }
                else
                {
                    lType = LanguageType.Japan;
                }
            }

            //기본 데이터 Attribute저장
            ViewBag.doc = pDoc;
            ViewBag.order = pOrder;
            ViewBag.orderSub = pSubOrder;

            //전체 금액 계산
            Decimal totalMoney = 0;
            foreach (OrderTable_Sub pSub in pSubOrder)
            {
                totalMoney += pSub.productMoney;
            }
            ViewBag.totalMoney = totalMoney;

            //코드마스터 취득
            CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
            pBuffer.Trans(lType);
            ViewBag.moneySendType = pBuffer;
        }
        /// <summary>
        /// 수주승인리스트
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryApproveList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryApproveList");

                OrderTableList list = new OrderTableList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.OrderCount(ORDERCODE, CompanySession.companyCode, true) / (Double)PAGELIMIT)));
                //페이지 Default = 1
                list.OrderSelect(PAGELIMIT, 1, ORDERCODE, CompanySession.companyCode, true);

                String idxcollection = "";
                foreach (OrderTable pBuffer in list)
                {
                    idxcollection += pBuffer.idx.ToString() + ",";
                }

                ViewBag.list = list;
                ViewBag.listcount = count;
                ViewBag.idxCollection = idxcollection;

                return View("~/Views/Delivery/Web/DeliveryApproveList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderApproveList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 수주승인 리스트 검색 AJAX
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListApproveSearch(int page = 0)
        {
            //Idx Collection 신경써야한다.
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                OrderTableList list = new OrderTableList();
                int count = list.OrderCount(1, CompanySession.companyCode, true);
                list.OrderSelect(PAGELIMIT, page, ORDERCODE, CompanySession.companyCode, true);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                String idxcollection = "";
                foreach (OrderTable pBuffer in list)
                {
                    idxcollection += pBuffer.idx.ToString() + ",";
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);
                pRet.Add("idxcollection", idxcollection);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ListCheckSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        ///  세부검색 - 항목을 클릭할 시에 나오는 Ajax
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult SubSearch(int idx)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/SubSearch");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                OrderTable_SubList list = new OrderTable_SubList();
                list.SubListSelect(idx, CompanySession.companyCode, lType);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/SubSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 승인페이지
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApprovePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ApprovePage");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //정상경로가 아님
                if (idx < 1)
                {
                    return ErrorPage("/Home/Error");
                }
                OrderTable pOrder = new OrderTable();
                //발주서 검색
                pOrder.SelectIdxReflesh(idx, CompanySession.companyCode);
                //정상경로가 아님
                if (pOrder.idx <= 0)
                {
                    return ErrorPage("/Home/Error");
                }
                //문서정보 취득
                Document pDoc = new Document();
                pDoc.DocumentSelect(pOrder.idx, DOCUMENTCODE, CompanySession.companyCode);

                //서버 상품 검색
                OrderTable_SubList pSubOrder = new OrderTable_SubList();
                pSubOrder.SubListSelect(idx, CompanySession.companyCode, lType);

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);
                //세션 저장
                Session["orderDOC"] = pDoc;
                Session["order"] = pOrder;
                Session["orderSub"] = pSubOrder;
                Session["orderCheck"] = ORDERSESSIONKEY;

                ViewBag.Commit = COMMIT_SHOUNINN;

                Session["action"] = "DeliveryApproveList";
                return View("~/Views/Delivery/Web/DeliveryApproveCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ApprovePage - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 수주승인 폼에서 승인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Approve(string key = "")
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/Approve");
                //정상경로가 아님
                if (!String.IsNullOrEmpty(key) && !"approve".Equals(key) && !"cancel".Equals(key))
                {
                    return ErrorPage("/Home/Error");
                }
                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable)Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                String InputSessionkey = (String)Session["orderCheck"];
                //비정상경로
                if (pDoc == null || pOrder == null || pSubOrder == null || InputSessionkey == null)
                {
                    return Redirect("/Obtain/Order");
                }
                else
                {
                    //비정상경로
                    if (!ORDERSESSIONKEY.Equals(InputSessionkey))
                    {
                        return Redirect("/Obtain/Order");
                    }
                    Session["orderDOC"] = null;
                    Session["order"] = null;
                    Session["orderSub"] = null;
                    Session["orderCheck"] = null;
                }
                //등록처리
                if ("approve".Equals(key))
                {
                    pOrder.Approve(pOrder.idx, App_Code.Define.STATE_APPLY, CompanySession.companyCode);

                    //납품확인서 처리
                    DeliveryTable pDelivery = new DeliveryTable();
                    Document pDoc2 = new Document();

                    pDelivery.orderCompany = pOrder.ordername;
                    pDelivery.orderAddress = pOrder.orderAddress;
                    pDelivery.orderSavedate = pOrder.ordersavedate;
                    pDelivery.inorderCompany = CompanySession.companyName;
                    pDelivery.inorderRepresentative = CompanySession.representative;
                    pDelivery.creater = UserSession.username;
                    pDelivery.createdate = DateTime.Now;
                    pDelivery.state = App_Code.Define.STATE_NORMAL.ToString();
                    pDelivery.companycode = CompanySession.companyCode;
                    pDelivery.DeliveryInsert();
                    pDelivery.LastIndexReflesh();

                    String documentBuffer = pDoc2.CreateCode();
                    pDoc2.Clear();
                    pDoc2.documentCode = documentBuffer;
                    pDoc2.documentType = DOCUMENTDELIVERYCODE;
                    pDoc2.documentIndex = pDelivery.idx;
                    pDoc2.createdate = DateTime.Now;
                    pDoc2.creater = UserSession.username;
                    pDoc2.state = App_Code.Define.STATE_NORMAL.ToString();
                    pDoc2.companycode = CompanySession.companyCode;
                    pDoc2.DocumentInsert();

                    foreach (OrderTable_Sub data in pSubOrder)
                    {
                        //재고처리
                        ProductFlow product = new ProductFlow();
                        DeliveryTable_Sub delivery_sub = new DeliveryTable_Sub();
                        product.productIndex = data.productIndex;
                        product.productAmount = data.productAmount;
                        product.productSellPrice = data.productPrice;
                        product.state = ProductFlow.OUTCOMESTANBY.ToString();
                        product.companycode = CompanySession.companyCode;
                        product.applyType = pOrder.idx;
                        product.creater = UserSession.userid;
                        product.cretedate = DateTime.Now;
                        product.ProductInsert();

                        //납품확인서(서브) 처리
                        delivery_sub.deliverykey = pDelivery.idx;
                        delivery_sub.number = data.number;
                        delivery_sub.productIndex = data.productIndex;
                        delivery_sub.productSpec = data.productSpec;
                        delivery_sub.productType = data.productType;
                        delivery_sub.productAmount = data.productAmount;
                        delivery_sub.productPrice = data.productPrice;
                        //세금처리
                        delivery_sub.productVat = 0;
                        delivery_sub.creater = UserSession.userid;
                        delivery_sub.createdate = DateTime.Now;
                        delivery_sub.state = App_Code.Define.STATE_NORMAL.ToString();
                        delivery_sub.companycode = CompanySession.companyCode;
                        delivery_sub.SubInsert();
                    }
                    //청구서 작성
                    Bill pBill = new Bill();
                    Document pDoc3 = new Document();
                    pBill.inordercompany = CompanySession.companyName;
                    pBill.inorderrepresentative = CompanySession.representative;
                    pBill.inorderpost = CompanySession.companyPostnumber;
                    pBill.inorderAddress = CompanySession.companyAddress;
                    pBill.ordercompany = pOrder.ordername;
                    pBill.orderaddress = pOrder.orderAddress;
                    pBill.billdate = pOrder.paydate;
                    pBill.billmoney = pOrder.ordermoney;
                    //세금처리
                    pBill.billtax = 0;
                    pBill.billtotal = pBill.billmoney + pBill.billtax;
                    pBill.creater = UserSession.username;
                    pBill.createdate = DateTime.Now;
                    pBill.state = App_Code.Define.STATE_NORMAL.ToString();
                    pBill.companycode = CompanySession.companyCode;
                    pBill.BillInsert();
                    pBill.LastIndexReflesh();

                    documentBuffer = pDoc3.CreateCode();
                    pDoc3.Clear();
                    pDoc3.documentCode = documentBuffer;
                    pDoc3.documentType = DOCUMENTBILLCODE;
                    pDoc3.documentIndex = pBill.idx;
                    pDoc3.createdate = DateTime.Now;
                    pDoc3.creater = UserSession.username;
                    pDoc3.state = App_Code.Define.STATE_NORMAL.ToString();
                    pDoc3.companycode = CompanySession.companyCode;
                    pDoc3.DocumentInsert();

                    //기본ViewBag 설정
                    ViewSetting(pDoc, pOrder, pSubOrder);
                    ViewBag.Commit = COMMIT_SHOUNINN_COMPLATE;
                    Session["action"] = "DeliveryApproveList";
                    return View("~/Views/Delivery/Web/DeliveryApproveCheck.cshtml", Define.MASTER_VIEW);
                }
                else if ("cancel".Equals(key))
                {
                    //등록
                    pOrder.Approve(pOrder.idx, App_Code.Define.STATE_DELETE, CompanySession.companyCode);
                    foreach (OrderTable_Sub data in pSubOrder)
                    {
                        //등록
                        data.stateModify(data.idx, App_Code.Define.STATE_DELETE, CompanySession.companyCode);
                    }

                    ViewBag.Commit = COMMIT_SHOUNINN_CANCLE;

                    //기본ViewBag 설정
                    ViewSetting(pDoc, pOrder, pSubOrder);

                    Session["action"] = "DeliveryApproveList";
                    return View("~/Views/Delivery/Web/DeliveryApproveCheck.cshtml", Define.MASTER_VIEW);
                }
                else
                {
                    return ErrorPage("/Home/Error");
                }                
            }
             else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/Approve - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 수주리스트(이력)
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryOrderList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryOrderList");

                OrderTableList list = new OrderTableList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.OrderCount(ORDERCODE, CompanySession.companyCode, false) / (Double)PAGELIMIT)));
                //페이지 Default = 1
                list.OrderSelect(PAGELIMIT, 1, ORDERCODE, CompanySession.companyCode, false);

                String idxcollection = "";
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                foreach (OrderTable pBuffer in list)
                {
                    pBuffer.stateView(lType);
                    idxcollection += pBuffer.idx.ToString() + ",";
                }

                ViewBag.list = list;
                ViewBag.listcount = count;
                ViewBag.idxCollection = idxcollection;

                return View("~/Views/Delivery/Web/DeliveryOrderList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryOrderList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 수주리스트 검색 AJAX
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListSearch(int page = 0)
        {
            //Idx Collection 신경써야한다.
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            { 
                int pagelimit = 50;
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                OrderTableList list = new OrderTableList();
                int count = list.OrderCount(ORDERCODE, CompanySession.companyCode, false);
                list.OrderSelect(pagelimit, page, ORDERCODE, CompanySession.companyCode, false);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                String idxcollection = "";
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                foreach (OrderTable pBuffer in list)
                {
                    //상태
                    pBuffer.stateView(lType);
                    idxcollection += pBuffer.idx.ToString() + ",";
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", pagelimit);
                pRet.Add("idxcollection", idxcollection);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 수주서 열람처리
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult DeliveryOrderView(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/OrderView");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //정상경로가 아님
                if (idx < 1)
                {
                    return ErrorPage("/Home/Error");
                }
                OrderTable pOrder = new OrderTable();
                //발주서 검색
                pOrder.SelectIdxReflesh(idx, CompanySession.companyCode);
                //정상경로가 아님
                if (pOrder.idx <= 0)
                {
                    return ErrorPage("/Home/Error");
                }
                //문서정보 취득
                Document pDoc = new Document();
                pDoc.DocumentSelect(pOrder.idx, DOCUMENTCODE, CompanySession.companyCode);

                //서버 상품 검색
                OrderTable_SubList pSubOrder = new OrderTable_SubList();
                pSubOrder.SubListSelect(idx, CompanySession.companyCode, lType);

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);

                ViewBag.Commit = pOrder.state;
                Session["action"] = "DeliveryOrderList";
                return View("~/Views/Delivery/Web/DeliveryOrderView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/OrderView - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 납품확인서
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryCheckList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryCheckList");

                DeliveryTableList list = new DeliveryTableList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.DeliveryCount(CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.DeliverySelect(PAGELIMIT, 1,CompanySession.companyCode);
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Delivery/Web/DeliveryCheckList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryCheckList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 납품확인서 검색
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult DeliveryCheckSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            { 
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/CheckSearch");
                if (page < 1)
                {
                    page = 1;
                }
                DeliveryTableList list = new DeliveryTableList();
                int count = list.DeliveryCount(CompanySession.companyCode);
                list.DeliverySelect(PAGELIMIT, page,CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 납품확인서 View
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryView(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryView");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                DeliveryTable delivery = new DeliveryTable();
                delivery.SelectIdx(idx,CompanySession.companyCode);
                DeliveryTable_SubList sub = new DeliveryTable_SubList();
                sub.SubListSelect(idx, CompanySession.companyCode, lType);
                Document pDoc = new Document();
                pDoc.DocumentSelect(idx, DOCUMENTDELIVERYCODE, CompanySession.companyCode);
                Decimal total=0;
                Decimal taxtotal = 0;
                foreach (DeliveryTable_Sub pData in sub)
                {
                    total += pData.productPrice;
                    taxtotal += pData.productVat;
                }
                ViewBag.delivery = delivery;
                ViewBag.deliverySub = sub;
                ViewBag.document = pDoc;
                ViewBag.total = total;
                ViewBag.taxtotal = taxtotal;

                Session["action"] = "DeliveryCheckList";
                return View("~/Views/Delivery/Web/DeliveryView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryCheckList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 청구서 리스트
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult DeliveryBillList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryBillList");

                BillList list = new BillList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.BillCount(CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.BillSelect(PAGELIMIT, 1, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Delivery/Web/DeliveryBillList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/DeliveryBillList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 청구서 검색
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult BillSearch(int page = 0)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/BillSearch");
                if (page < 1)
                {
                    page = 1;
                }
                BillList list = new BillList();
                int count = list.BillCount(CompanySession.companyCode);
                list.BillSelect(PAGELIMIT, page, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/ListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        ///청구서 View
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult BillView(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/BillView");

                Bill bill = new Bill();
                bill.SelectIdx(idx,CompanySession.companyCode);

                ViewBag.bill = bill;
                Session["action"] = "DeliveryBillList";
                return View("~/Views/Delivery/Web/BillView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Delivery/BillView - Error");
                return base.Logout();
            }
        }
        
    }
}
