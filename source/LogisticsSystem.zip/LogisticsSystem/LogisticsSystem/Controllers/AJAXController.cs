﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;
using System.IO;

namespace LogisticsSystem.Controllers
{
    public class AJAXController : SyController
    {
        [AuthorizeFilter]
        public ActionResult Imageupload(HttpPostedFileBase file)
        {
            UserInfo pInfo = (UserInfo)Session["userinfo"];
            CompanyInfo pComp = (CompanyInfo)Session["compinfo"];
            if ((bool)Session["AuthCheck"] && pInfo != null && pComp != null)
            {
                if (file != null && file.ContentLength > 0)
                {
                    Stream st = file.InputStream;
                    byte[] pData = new byte[st.Length];
                    st.Read(pData, 0, pData.Length);
                    Session["imageBuffer"] = pData;
                    st.Close();
                    return Content("OK");
                }
            }
            return Content("NG");
        }
        [AuthorizeFilter]
        public ActionResult ImageBuffer()
        {
            UserInfo pInfo = (UserInfo)Session["userinfo"];
            CompanyInfo pComp = (CompanyInfo)Session["compinfo"];
            if ((bool)Session["AuthCheck"] && pInfo != null && pComp != null)
            {
                byte[] buffer = (byte[])Session["imageBuffer"];
                Session.Remove("imageBuffer");
                if (buffer != null)
                {
                    MemoryStream pStream = new MemoryStream(buffer);
                    return File(pStream, "image/jpg");
                }
            }
            return Content("NG");
        }
    }
}
