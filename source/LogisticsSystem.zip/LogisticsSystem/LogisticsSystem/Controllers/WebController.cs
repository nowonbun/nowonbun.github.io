﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.Models;
using LogisticsSystem.App_Code;
using System.Web.Security;

namespace LogisticsSystem.Controllers
{
    public class WebController : SyController
    {
        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        /// <summary>
        /// Index Controller
        /// </summary>
        [PipelineFilter]
        public ActionResult Index()
        {
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            //if (
            //    User.Identity.IsAuthenticated && 
            //    Session["userinfo"] != null &&
            //    Session["compinfo"] != null
            //    )
            //{
            //    return Redirect("Main");
            //}
            //else
            //{
                ViewBag.ErrorMsg = Session["ErrorMsg"];
                ViewBag.IdBuffer = Session["IDbuffer"];
                Session["ErrorMsg"] = "";
                Session["IDbuffer"] = "";
                return View();
            //}
        }
        /// <summary>
        /// 로그인 처리 로직
        /// </summary>
        public ActionResult Login(UserInfo pInfo)
        {
            Session["IDbuffer"] = pInfo.userid;
            if (pInfo.AuthorizeCheck())
            {
                CompanyInfo pComp = new Models.CompanyInfo();
                FormsAuthentication.SetAuthCookie(pInfo.userid, false);
                pInfo.password = "";
                pComp.CompanyInfoSelect(pInfo.companycode);
                pInfo.NumberSplit();
                Session["userinfo"] = pInfo;
                Session["compinfo"] = pComp;
                Connect conn = new Connect();
                conn.userid = pInfo.userid;
                conn.connectdate = DateTime.Now;
                conn.ipaddress = Request.UserHostAddress;
                conn.ConnectInsert();

                LogWriter.Instance().LogWrite(pInfo.userid,"Login Start");
                return Redirect("Main");
            }
            else
            {
                LanguageType? lType = (LanguageType?)Session["languageType"];
                if (lType == LanguageType.Korea) 
                {
                    Session["ErrorMsg"] = "아이디 또는 패스워드를 확인해 주십시오.";
                }
                else
                {
                    Session["ErrorMsg"] = "ユーザIDまたはパスワードを確認してください。";
                }
                return Redirect(FormsAuthentication.LoginUrl);
            }
        }
        /// <summary>
        /// 메인화면 Controller
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Main()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/Main");
                return View("Main", Define.MASTER_VIEW);
            }
            else
            {
                return base.Logout();
            }
        }
        /// <summary>
        /// 회사정보 Controller
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult CompanyInfo()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/CompanyInfo");
                ViewBag.companyInfo = CompanySession;
                return View("~/Views/Web/CompanyInfo.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                return base.Logout();
            }
        }
        /// <summary>
        /// 회사정보 수정 
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult CompanyInsert(CompanyInfo rComp)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/CompanyInsert");
                rComp.creater = UserSession.userid;
                rComp.createdate = DateTime.Now;
                List<String> pError = CompanySession.CompanyInfoModify(rComp, (LanguageType?)Session["languageType"]);
                String ErrMsg = "";
                //에러가 있으면 에러 메시지 작성
                //에러가 없으면 session 재 설정
                if (pError.Count < 1)
                {
                    if ((LanguageType?)Session["languageType"] == LanguageType.Korea) ErrMsg = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" 수정되었습니다.";
                    else ErrMsg = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 修正しました。";
                    rComp = CompanySession;
                    Session["compinfo"] = rComp;
                }
                    
                else
                {
                    foreach (String pBuffer in pError)
                    {
                        ErrMsg += pBuffer + "<br>";
                    }
                }
                ViewBag.ErrMsg = ErrMsg;
                ViewBag.companyInfo = rComp;
                Session["action"] = "CompanyInfo";
                return View("~/Views/Web/CompanyInfo.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                return base.Logout();
            }
        }
       /// <summary>
        /// 유저정보 Controller
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult UserInfo()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/UserInfo");
                ViewBag.UserInfo = UserSession;
                return View("~/Views/Web/UserInfo.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                return base.Logout();
            }
        }
        /// <summary>
        /// 유저정보 수정
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult UserInsert(UserInfo rUser)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/UserInsert");
                rUser.createdate = DateTime.Now;
                rUser.creater = UserSession.userid;

                List<String> pError = UserSession.UserInfoModify(rUser, (LanguageType?)Session["languageType"],CompanySession.companyCode);
                String ErrMsg = "";
                            //에러가 있으면 에러 메시지 작성
                            //에러가 없으면 session 재 설정
                if (pError.Count < 1)
                {
                    if ((LanguageType?)Session["languageType"] == LanguageType.Korea) ErrMsg = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 수정되었습니다.";
                    else ErrMsg = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 修正しました。";
                    rUser = UserSession;
                    Session["userinfo"] = rUser;
                }

                else
                {
                    foreach (String pBuffer in pError)
                    {
                        ErrMsg += pBuffer + "<br>";
                    }
                }
                ViewBag.ErrMsg = ErrMsg;
                ViewBag.UserInfo = rUser;
                Session["action"] = "UserInfo";

                return View("~/Views/Web/UserInfo.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                return base.Logout();
            }
        }

        /// <summary>
        /// 카테고리일람 - 현재 사용X
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult CategoryAdmin()
        {
            UserInfo pInfo = (UserInfo)Session["userinfo"];
            if (pInfo != null)
            {
                LogWriter.Instance().LogWrite(pInfo.userid, "/Web/CategoryAdmin");
                return View("Main", Define.MASTER_VIEW);
            }
            return Empty();
        }
        /// <summary>
        /// 언어선택화면
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult LanguageSelectView()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/LanguageSelectView");

                object returnController = Session["ReturnController"];
                object returnAction = Session["ReturnAction"];
                object returnUrl = Session["ReturnURL"];
                object printUrl = Session["PrintURL"];

                Session["ReturnController"] = null;
                Session["ReturnAction"] = null;
                Session["ReturnURL"] = null;
                Session["PrintURL"] = null;

                //정상경로가 아님
                if (returnAction == null || returnAction == null || returnUrl == null || printUrl == null)
                {
                    return ErrorPage("/Home/Error");
                }
                
                Session["controller"] = returnController;
                Session["action"] = returnAction;

                ViewBag.returnUrl = returnUrl;
                ViewBag.printUrl = printUrl;

                return View("~/Views/Web/LanguageSelectView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/LanguageSelectView - Error");
                return base.Logout();
            }
        }
        private const int PAGELIMIT = 50;
        /// <summary>
        /// 접속로그
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ConnectList()
        {
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/ConnectList");

                ConnectList list = new ConnectList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.ConnectCount() / (Double)PAGELIMIT)));
                list.ConnectSelect(PAGELIMIT, 1);

                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Web/ConnectLog.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Web/ConnectList 인증에러");
                return base.Logout();
            }
        }
    }
}
