﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;

namespace LogisticsSystem.Controllers
{
    public class ObtainController : SyController
    {
        private const int PAGELIMIT = 50;
        private const int ORDERCODE = 0;
        private const String DOCUMENTCODE = "1";
        private const int COMMIT_KANRYOU = 1;
        private const int COMMIT_KAKUNINN = 2;
        private const int COMMIT_SHOUNINN = 3;
        private const int COMMIT_SHOUNINN_COMPLATE = 4;
        private const int COMMIT_SHOUNINN_CANCLE = 5;
        private const String ORDERSESSIONKEY = "asdhfagshd";
        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        /// <summary>
        /// 발주신청 초기
        /// </summary>
        /// <returns></returns>
        /// 확인에서 Cancel을 눌렀을때.
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Order(String key="")
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Order");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //회원정보
                ViewBag.userinfo = UserSession;
                //회사정보
                ViewBag.compinfo = CompanySession;

                CustomerInfoList pCustomer = new CustomerInfoList();
                ProductInfoList pProduct = new ProductInfoList();
                CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                pBuffer.Trans(lType);
                ViewBag.moneySendType = pBuffer;

                Document pDoc = null;
                OrderTable pOrder = null;
                pCustomer.OrderCompList(CompanySession.companyCode);
                pProduct.ProductNameList(CompanySession.companyCode);
                
                ViewBag.ordercomplist = pCustomer;
                ViewBag.productlist = pProduct;
                
                if ("BACK".Equals(key))
                {
                    pDoc = (Document)Session["orderDOC"];
                    pOrder = (OrderTable)Session["order"];
                    OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                    if (pDoc == null || pOrder == null)
                    {
                        pDoc = new Document();
                        pOrder = new OrderTable();
                        ViewBag.MunCode = pDoc.CreateCode();
                        ViewBag.BalCode = pOrder.CreateCode();
                        ViewBag.totalMoney = 0;
                    }
                    else
                    {
                        ViewBag.MunCode = pDoc.documentCode;
                        ViewBag.BalCode = pOrder.ordernumber;
                        ViewBag.order = pOrder;
                        ViewBag.orderSub = pSubOrder;
                        Decimal totalMoney = 0;
                        foreach (OrderTable_Sub pSub in pSubOrder)
                        {
                            totalMoney += pSub.productMoney;
                        }
                        ViewBag.totalMoney = totalMoney;

                    }
                }
                else
                {
                    pDoc = new Document();
                    pOrder = new OrderTable();
                    ViewBag.MunCode = pDoc.CreateCode();
                    ViewBag.BalCode = pOrder.CreateCode();
                    ViewBag.totalMoney = 0;
                }
                Session["orderDOC"] = null;
                Session["order"] = null;
                Session["orderSub"] = null;
                Session["orderCheck"] = null;

                return View("~/Views/Obtain/Web/Order.cshtml", Define.MASTER_VIEW);
            }
            else 
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Order - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 상품 셀렉트시 AJX
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ProductSelect(int idx)
        {
            //버그가 있음
            //에러가 있어서 재입력 할때 Cookie와 Session 값이 안 맞는 현상
            if (false && !SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ProductSelect");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                ProductInfo p = new ProductInfo();
                p.ProductSelect(idx, CompanySession.companyCode, lType);
                return Json(p, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ProductSelect - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 입력확인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Inputcheck(Document pDoc, OrderTable pOrder, OrderTable_SubAddList pSubOrder,int inordernameIdx = 0)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Inputcheck");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //잘못된 경로로 들어올 시
                if (pDoc.documentCode == null || "".Equals(pDoc.documentCode))
                {
                    return Redirect("/Obtain/Order");
                }

                if (inordernameIdx != 0)
                {
                    CustomerInfo custInfo = new CustomerInfo();
                    custInfo.CustomerSelect(inordernameIdx,CompanySession.companyCode);
                    pOrder.inordername = custInfo.customerName;
                }
                List<String> pErrmsg = new List<string>();
                List<String> pBuffer2 = null;
                pBuffer2 = pDoc.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                pBuffer2 = pOrder.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                pBuffer2 = pSubOrder.validate(lType);
                foreach (String pData in pBuffer2)
                {
                    pErrmsg.Add(pData);
                }
                Session["action"] = "Order";
                //에러가 발생시
                if (pErrmsg.Count > 0)
                {
                    //******************************************************
                    //회원정보
                    ViewBag.userinfo = UserSession;
                    //회사정보
                    ViewBag.compinfo = CompanySession;

                    CustomerInfoList pCustomer = new CustomerInfoList();
                    ProductInfoList pProduct = new ProductInfoList();
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                    pCustomer.OrderCompList(CompanySession.companyCode);
                    pProduct.ProductNameList(CompanySession.companyCode);

                    ViewBag.ordercomplist = pCustomer;
                    ViewBag.productlist = pProduct;

                    ViewBag.MunCode = pDoc.documentCode;
                    ViewBag.BalCode = pOrder.ordernumber;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder.List;

                    String err = "";
                    foreach (String pData in pErrmsg)
                    {
                        err += pData + "<br>";
                    }
                    ViewBag.ErrMsg = err;

                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder.List)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;
                    //******************************************************
                    return View("~/Views/Obtain/Web/Order.cshtml", Define.MASTER_VIEW);
                }
                //정상시
                else
                {
                    Document doc = pDoc;
                    OrderTable order = pOrder;
                    OrderTable_SubList orderSub = pSubOrder.List;
                   
                    //세션 저장
                    Session["orderDOC"] = doc;
                    Session["order"] = order;
                    Session["orderSub"] = orderSub;
                    Session["orderCheck"] = ORDERSESSIONKEY;

                    //상품정보 취득
                    ProductInfoList pProduct = new ProductInfoList();
                    pProduct.ProductNameList(CompanySession.companyCode);
                    foreach (OrderTable_Sub data in orderSub)
                    {
                        foreach (ProductInfo info in pProduct)
                        {
                            if (info.idx == data.productIndex)
                            {
                                data.productName = info.productname;
                            }
                        }
                    }
                    //기본ViewBag 설정
                    ViewSetting(doc, order, orderSub);

                    ViewBag.Commit = COMMIT_KAKUNINN;

                    return View("~/Views/Obtain/Web/OrderCheck.cshtml", Define.MASTER_VIEW);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Inputcheck - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 승인시 저장
        /// </summary>
        /// <param name="pDoc"></param>
        /// <param name="pOrder"></param>
        /// <param name="pSubOrder"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Input()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Input");
                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable)Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                String InputSessionkey = (String)Session["orderCheck"];
                //비정상경로
                if (pDoc == null || pOrder == null || pSubOrder == null || InputSessionkey == null)
                {
                    return Redirect("/Obtain/Order");
                }
                else
                {
                    //비정상경로
                    if (!ORDERSESSIONKEY.Equals(InputSessionkey))
                    {
                        return Redirect("/Obtain/Order");
                    }
                    Session["orderDOC"] = null;
                    Session["order"] = null;
                    Session["orderSub"] = null;
                    Session["orderCheck"] = null;
                }
                //************* 발주 테이블
                pOrder.state = App_Code.Define.STATE_NORMAL.ToString();
                pOrder.ordertype = ORDERCODE.ToString();
                pOrder.companycode = CompanySession.companyCode;
                
                //발주서정보저장
                pOrder.OrderInsert();
                //재갱신
                pOrder.SelectReflesh();
                
                //*************문서테이블
                pDoc.documentIndex = pOrder.idx;
                pDoc.companycode = CompanySession.companyCode;
                pDoc.documentType = DOCUMENTCODE;    //발주서 코드
                pDoc.state = App_Code.Define.STATE_NORMAL.ToString();
                //문서정보저장
                pDoc.DocumentInsert();

                //상품테이블
                //서버 상품정보 저장
                pSubOrder.ListInsert(pOrder.idx,pDoc.creater,CompanySession.companyCode);
                ViewBag.Commit = COMMIT_KANRYOU;

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);

                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                foreach (OrderTable_Sub data in pSubOrder)
                {
                    foreach (ProductInfo info in pProduct)
                    {
                        if (info.idx == data.productIndex)
                        {
                            data.productName = info.productname;
                        }
                    }
                }

                Session["action"] = "Order";
                return View("~/Views/Obtain/Web/OrderCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Input - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 발주승인페이지리스트
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult OrderApproveList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderApproveList");

                OrderTableList list = new OrderTableList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.OrderCount(ORDERCODE, CompanySession.companyCode,true) / (Double)PAGELIMIT)));
                //페이지 Default = 1
                list.OrderSelect(PAGELIMIT, 1, ORDERCODE, CompanySession.companyCode,true);

                String idxcollection = "";
                foreach (OrderTable pBuffer in list)
                {
                    idxcollection += pBuffer.idx.ToString() + ",";
                }

                ViewBag.list = list;
                ViewBag.listcount = count;
                ViewBag.idxCollection = idxcollection;

                return View("~/Views/Obtain/Web/OrderApproveList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderApproveList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 발주승인페이지에서 검색(AJAX)
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListCheckSearch(int page = 0)
        {
            //Idx Collection 신경써야한다.
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ListCheckSearch");
                if (page < 1)
                {
                    page = 1;
                }
                OrderTableList list = new OrderTableList();
                int count = list.OrderCount(ORDERCODE, CompanySession.companyCode,true);
                list.OrderSelect(PAGELIMIT, page, ORDERCODE, CompanySession.companyCode,true);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                String idxcollection = "";
                foreach (OrderTable pBuffer in list)
                {
                    idxcollection += pBuffer.idx.ToString() + ",";
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);
                pRet.Add("idxcollection", idxcollection);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ListCheckSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 세부검색 - 항목을 클릭할 시에 나오는 Ajax
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult SubSearch(int idx)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/SubSearch");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                OrderTable_SubList list = new OrderTable_SubList();
                list.SubListSelect(idx, CompanySession.companyCode, lType);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/SubSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 승인페이지
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApprovePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ApprovePage");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //정상경로가 아님
                if (idx < 1)
                {
                    return ErrorPage("/Home/Error");
                }
                OrderTable pOrder = new OrderTable();
                //발주서 검색
                pOrder.SelectIdxReflesh(idx, CompanySession.companyCode);
                //정상경로가 아님
                if (pOrder.idx <= 0)
                {
                    return ErrorPage("/Home/Error");
                }
                //문서정보 취득
                Document pDoc = new Document();
                pDoc.DocumentSelect(pOrder.idx, DOCUMENTCODE, CompanySession.companyCode);

                //서버 상품 검색
                OrderTable_SubList pSubOrder = new OrderTable_SubList();
                pSubOrder.SubListSelect(idx, CompanySession.companyCode, lType);

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);
                //세션 저장
                Session["orderDOC"] = pDoc;
                Session["order"] = pOrder;
                Session["orderSub"] = pSubOrder;
                Session["orderCheck"] = ORDERSESSIONKEY;

                ViewBag.Commit = COMMIT_SHOUNINN;

                Session["action"] = "OrderApproveList";
                return View("~/Views/Obtain/Web/OrderApproveCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ApprovePage - Error");
                return base.Logout();
            }
        }
         /// <summary>
        /// 승인처리
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Approve(string key = "")
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Approve");
                //정상경로가 아님
                if (!String.IsNullOrEmpty(key) && !"approve".Equals(key) && !"cancel".Equals(key))
                {
                    return ErrorPage("/Home/Error");
                }
                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable)Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                String InputSessionkey = (String)Session["orderCheck"];
                //비정상경로
                if (pDoc == null || pOrder == null || pSubOrder == null || InputSessionkey == null)
                {
                    return Redirect("/Obtain/Order");
                }
                else
                {
                    //비정상경로
                    if (!ORDERSESSIONKEY.Equals(InputSessionkey))
                    {
                        return Redirect("/Obtain/Order");
                    }
                    Session["orderDOC"] = null;
                    Session["order"] = null;
                    Session["orderSub"] = null;
                    Session["orderCheck"] = null;
                }
                //등록처리
                if ("approve".Equals(key))
                {
                    //등록
                    pOrder.Approve(pOrder.idx, App_Code.Define.STATE_APPLY,CompanySession.companyCode);
                    foreach (OrderTable_Sub data in pSubOrder)
                    {
                        //재고등록
                        ProductFlow product = new ProductFlow();
                        product.productIndex = data.productIndex;
                        product.productAmount = data.productAmount;
                        product.productbuyPrice = data.productPrice;
                        product.productSellPrice = 0;
                        product.state = ProductFlow.INCOMESTANBY.ToString();
                        product.companycode = CompanySession.companyCode;
                        product.applyType = pOrder.idx;
                        product.creater = UserSession.userid;
                        product.cretedate = DateTime.Now;
                        product.ProductInsert();

                        //등록
                        data.stateModify(data.idx, App_Code.Define.STATE_APPLY, CompanySession.companyCode);
                    }
                    ViewBag.Commit = COMMIT_SHOUNINN_COMPLATE;

                    //기본ViewBag 설정
                    ViewSetting(pDoc, pOrder, pSubOrder);

                    Session["action"] = "OrderApproveList";
                    return View("~/Views/Obtain/Web/OrderApproveCheck.cshtml", Define.MASTER_VIEW);
                }
                //승인취소
                else if ("cancel".Equals(key))
                {
                    //등록
                    pOrder.Approve(pOrder.idx, App_Code.Define.STATE_DELETE, CompanySession.companyCode);
                    foreach (OrderTable_Sub data in pSubOrder)
                    {
                        //등록
                        data.stateModify(data.idx, App_Code.Define.STATE_DELETE, CompanySession.companyCode);
                    }

                    ViewBag.Commit = COMMIT_SHOUNINN_CANCLE;

                    //기본ViewBag 설정
                    ViewSetting(pDoc, pOrder, pSubOrder);

                    Session["action"] = "OrderApproveList";
                    return View("~/Views/Obtain/Web/OrderApproveCheck.cshtml", Define.MASTER_VIEW);
                }
                else
                {
                    return ErrorPage("/Home/Error");
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/Approve - Error");
                return base.Logout();
            }
        }

        /// <summary>
        /// 발주리스트(이력까지 포함)
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult OrderList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ObtainList");
                OrderTableList list = new OrderTableList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.OrderCount(ORDERCODE, CompanySession.companyCode,false) / (Double)PAGELIMIT)));
                //페이지 Default = 1
                list.OrderSelect(PAGELIMIT, 1, ORDERCODE, CompanySession.companyCode,false);

                String idxcollection = "";
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                foreach (OrderTable pBuffer in list)
                {
                    pBuffer.stateView(lType);
                    idxcollection += pBuffer.idx.ToString() + ",";
                }

                ViewBag.list = list;
                ViewBag.listcount = count;
                ViewBag.idxCollection = idxcollection;

                return View("~/Views/Obtain/Web/OrderList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 발주리스트에서 검색 (AJAX 용)
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListSearch(int page = 0)
        {
            //Idx Collection 신경써야한다.
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {             
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                OrderTableList list = new OrderTableList();
                int count = list.OrderCount(ORDERCODE,CompanySession.companyCode,false);
                list.OrderSelect(PAGELIMIT, page, ORDERCODE, CompanySession.companyCode, false);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                String idxcollection = "";
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                foreach (OrderTable pBuffer in list)
                {
                    //상태
                    pBuffer.stateView(lType);
                    idxcollection += pBuffer.idx.ToString() + ",";
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);
                pRet.Add("idxcollection", idxcollection);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Product/ListCheckSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 기본 Attribute 세팅
        /// </summary>
        protected void ViewSetting(Document pDoc,OrderTable pOrder,OrderTable_SubList pSubOrder)
        {
            String pLanguage = Request.Form["Lang"];
            LanguageType? lType = null;
            if (pLanguage != null && !"".Equals(pLanguage))
            {
                if ("k".Equals(pLanguage))
                {
                    lType = LanguageType.Korea;
                }
                else
                {
                    lType = LanguageType.Japan;
                }
            }

            //기본 데이터 Attribute저장
            ViewBag.doc = pDoc;
            ViewBag.order = pOrder;
            ViewBag.orderSub = pSubOrder;

            //전체 금액 계산
            Decimal totalMoney = 0;
            foreach (OrderTable_Sub pSub in pSubOrder)
            {
                totalMoney += pSub.productMoney;
            }
            ViewBag.totalMoney = totalMoney;

            //코드마스터 취득
            CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
            pBuffer.Trans(lType);
            ViewBag.moneySendType = pBuffer;
        }
        /// <summary>
        /// 발주서 열람처리
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult OrderView(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderView");

                Session["action"] = "OrderList";
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                //정상경로가 아님
                if (idx < 1)
                {
                    return ErrorPage("/Home/Error");
                }
                OrderTable pOrder = new OrderTable();
                //발주서 검색
                pOrder.SelectIdxReflesh(idx, CompanySession.companyCode);
                //정상경로가 아님
                if (pOrder.idx <= 0)
                {
                    return ErrorPage("/Home/Error");
                }
                //문서정보 취득
                Document pDoc = new Document();
                pDoc.DocumentSelect(pOrder.idx, DOCUMENTCODE, CompanySession.companyCode);

                //서버 상품 검색
                OrderTable_SubList pSubOrder = new OrderTable_SubList();
                pSubOrder.SubListSelect(idx, CompanySession.companyCode, lType);

                //기본ViewBag 설정
                ViewSetting(pDoc, pOrder, pSubOrder);
                //세션 저장
                Session["orderDOC"] = pDoc;
                Session["order"] = pOrder;
                Session["orderSub"] = pSubOrder;

                ViewBag.Commit = pOrder.state;
                Session["action"] = "OrderList";
                Session["orderIdx"] = idx;
                return View("~/Views/Obtain/Web/OrderView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/OrderView - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// PDF 출력
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult PDFCreate()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                if (Session["orderIdx"] == null)
                {
                    return ErrorPage("/Home/Error");
                }
                //Session["ReturnURL"] = "/Obtain/OrderView?idx=" + Session["orderIdx"].ToString();
                //Session["PrintURL"] = "/Obtain/PDFPrint";
                //Session["ReturnController"] = "Obtain";
                //Session["ReturnAction"] = "OrderList";
                //Session["orderIdx"] = null;
                //return Redirect("/Web/LanguageSelectView");
                Dictionary<String, Object> parameter = new Dictionary<string, object>();
                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable)Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                
                //Session["orderDOC"] = null;
                //Session["order"] = null;
                //Session["orderSub"] = null;

                //비정상 경로
                if (pDoc == null || pOrder == null || pSubOrder == null)
                {
                    return Redirect("/Obtain/Order");
                }

                LanguageType? lType = null;
                if ("1".Equals(pOrder.printSetting))
                {
                    lType = LanguageType.Korea;
                }
                else
                {
                    lType = LanguageType.Japan;
                }
                LanguagePack pLang = new LanguagePack(Server.MapPath("~/Language"), "PDF", "Order", lType);

                

                decimal totalMoney = 0;

                if (lType != LanguageType.Japan)
                {
                    parameter.Add("companytitle", CompanySession.companyName);
                }
                else
                {
                    parameter.Add("companytitle", CompanySession.companyName_en);
                }
                
                parameter.Add("ordernowdate", DateTime.Now.ToString("yyyy-MM-dd"));
                parameter.Add("DocumentNumber_result", pDoc.documentCode);
                parameter.Add("CreateDate_result", pDoc.createdate.ToString("yyyy-MM-dd"));
                if (lType != LanguageType.Japan)
                {
                    String buf = pDoc.creater_en;
                    parameter.Add("Creater_result", buf);
                }
                else
                {
                    parameter.Add("Creater_result", pDoc.creater);
                }
                parameter.Add("OrderNumber_result", pOrder.ordernumber);
                parameter.Add("DeliveryComp_result", pOrder.inordername);
                parameter.Add("DeliveryAddress_result", pOrder.inorderaddress);
                if (lType != LanguageType.Japan)
                {
                    parameter.Add("Totalmoney_result", pOrder.ordermoney.ToString("###,##0") + "엔");
                }
                else
                {
                    parameter.Add("Totalmoney_result", pOrder.ordermoney.ToString("###,##0") + "円");
                }
                
                parameter.Add("PeriodDate_result", pOrder.ordersavedate.ToString("yyyy-MM-dd"));

                if (lType != LanguageType.Japan)
                {
                    String buf = pOrder.ordersaveplace_en;
                    parameter.Add("PeriodPlace_result", buf);
                }
                else
                {
                    parameter.Add("PeriodPlace_result", pOrder.ordersaveplace);
                }
                parameter.Add("ordername_result", pOrder.ordername);
                //parameter.Add("CompsSecuriNum_result", pOrder.ordersecuritynumber);

                if (lType != LanguageType.Japan)
                {
                    String buf = pOrder.orderAddress_en;
                    parameter.Add("CompAddress_result", buf);
                }
                else
                {
                    parameter.Add("CompAddress_result", pOrder.orderAddress);
                }

                if (lType != LanguageType.Japan)
                {
                    String buf = "+81-" + pOrder.orderPhoneNumber.Substring(1);
                    parameter.Add("CompNumber_result", buf);
                }
                else
                {
                    parameter.Add("CompNumber_result", pOrder.orderPhoneNumber);
                }
                if (lType != LanguageType.Japan)
                {
                    String buf = "+81-" + pOrder.orderFax.Substring(1);
                    parameter.Add("CompFax_result", buf);
                }
                else
                {
                    parameter.Add("CompFax_result", pOrder.orderFax);
                }
                parameter.Add("MoneyDate_result", pOrder.paydate.ToString("yyyy-MM-dd"));
                
                if (lType != LanguageType.Japan)
                {
                    parameter.Add("Money_result", pOrder.paymoney.ToString("###,##0") + "엔");
                }
                else
                {
                    parameter.Add("Money_result", pOrder.paymoney.ToString("###,##0") + "円");
                }

                CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                pBuffer.Trans(lType);
                foreach (CodeMaster cm in pBuffer)
                {
                    if (cm.codekey.Equals(pOrder.paycondition))
                    {
                        parameter.Add("Moneycheck_result", cm.codename);
                    }
                }

                parameter.Add("MoneyOrderDate_result", pOrder.orderdate.ToString("yyyy-MM-dd"));

                for (int i = 1; i <= 15; i++)
                {
                    if (pSubOrder.Count >= i)
                    {
                        parameter.Add("ListNumber" + i.ToString(), i.ToString());
                        parameter.Add("ListProductName" + i.ToString(), pSubOrder[i - 1].productName);
                        parameter.Add("ListProductSpec" + i.ToString(), pSubOrder[i - 1].productSpec);
                        parameter.Add("ListMount" + i.ToString(), pSubOrder[i - 1].productAmount.ToString("###,##0"));
                        if (lType != LanguageType.Japan)
                        {
                            parameter.Add("ListMoney" + i.ToString(), pSubOrder[i - 1].productPrice.ToString("###,##0") + "엔");
                            parameter.Add("ListTotalMoney" + i.ToString(), pSubOrder[i - 1].productMoney.ToString("###,##0") + "엔");
                        }
                        else
                        {
                            parameter.Add("ListMoney" + i.ToString(), pSubOrder[i - 1].productPrice.ToString("###,##0") + "円");
                            parameter.Add("ListTotalMoney" + i.ToString(), pSubOrder[i - 1].productMoney.ToString("###,##0") + "円");
                        }
                        totalMoney += pSubOrder[i - 1].productMoney;
                    }
                    else
                    {
                        parameter.Add("ListNumber" + i.ToString(), i.ToString());
                        parameter.Add("ListProductName" + i.ToString(), "");
                        parameter.Add("ListProductSpec" + i.ToString(), "");
                        parameter.Add("ListMount" + i.ToString(), "");
                        parameter.Add("ListMoney" + i.ToString(), "");
                        parameter.Add("ListTotalMoney" + i.ToString(), "");
                    }
                }
                if (lType != LanguageType.Japan)
                {
                    parameter.Add("ListTotalSumMoney_result", totalMoney.ToString("###,##0") + "엔");
                }
                else
                {
                    parameter.Add("ListTotalSumMoney_result", totalMoney.ToString("###,##0") + "円");
                }
                
                parameter.Add("Memo_result",pOrder.other);

                foreach (string key in pLang.Keys)
                {
                    if (!parameter.ContainsKey(key))
                        parameter.Add(key, pLang[key]);
                }
                App_Code.PDFCreate pdf = new PDFCreate();
                pdf.Open();
                System.IO.MemoryStream stm = (System.IO.MemoryStream)pdf.PdfCreater(Server.MapPath("..\\PDF\\OrderForm.html"), parameter);
                pdf.Close();
                String filename = "Order_" + DateTime.Now.ToString("yyyyMMdd") + ".pdf";
                return File(stm.GetBuffer(), "application/octet-stream", filename);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/PDFCreate - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// PDF 출력
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult PDFPrint(String language, String engcheck)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                Dictionary<String, Object> parameter = new Dictionary<string,object>();

                LanguageType? lType = null;
                if ("korean".Equals(language))
                {
                    lType = LanguageType.Korea;
                }
                else
                {
                    lType = LanguageType.Japan;
                }

                Document pDoc = (Document)Session["orderDOC"];
                OrderTable pOrder = (OrderTable) Session["order"];
                OrderTable_SubList pSubOrder = (OrderTable_SubList)Session["orderSub"];
                LanguagePack pLang = new LanguagePack(Server.MapPath("~/Language"), "PDF", "Order", lType);

                decimal totalMoney = 0;
                
                parameter.Add("companytitle", CompanySession.companyName);
                parameter.Add("companytitle_en", CompanySession.companyName_en);
                parameter.Add("ordernowdate", DateTime.Now.ToString("yyyy-MM-dd"));
                parameter.Add("DocumentNumber_result", pDoc.documentCode);
                parameter.Add("CreateDate_result", pDoc.createdate.ToString("yyyy-MM-dd"));
                if (lType != LanguageType.Japan)
                {
                    String buf = pDoc.creater + "<br>"+pDoc.creater_en;
                    parameter.Add("Creater_result", buf);
                }
                else
                {
                    parameter.Add("Creater_result", pDoc.creater);
                }
                parameter.Add("OrderNumber_result", pOrder.ordernumber);
                parameter.Add("DeliveryComp_result", pOrder.inordername);
                parameter.Add("Totalmoney_result", pOrder.ordermoney.ToString("###,##0"));
                parameter.Add("PeriodDate_result", pOrder.ordersavedate.ToString("yyyy-MM-dd"));

                if (lType != LanguageType.Japan)
                {
                    String buf = pOrder.ordersaveplace + "<br>" + pOrder.ordersaveplace_en;
                    parameter.Add("PeriodPlace_result", buf);
                }
                else
                {
                    parameter.Add("PeriodPlace_result", pOrder.ordersaveplace);
                }
                parameter.Add("ordername_result", pOrder.ordername);
                //parameter.Add("CompsSecuriNum_result", pOrder.ordersecuritynumber);

                if (lType != LanguageType.Japan)
                {
                    String buf = pOrder.orderAddress + "<br>" + pOrder.orderAddress_en;
                    parameter.Add("CompAddress_result", buf);
                }
                else
                {
                    parameter.Add("CompAddress_result", pOrder.orderAddress);
                }

                if (lType != LanguageType.Japan)
                {
                    String buf = "+81-" + pOrder.orderPhoneNumber.Substring(1);
                    parameter.Add("CompNumber_result", buf);
                }
                else
                {
                    parameter.Add("CompNumber_result", pOrder.orderPhoneNumber);
                }
                if (lType != LanguageType.Japan)
                {
                    String buf = "+81-" + pOrder.orderFax.Substring(1);
                    parameter.Add("CompFax_result", buf);
                }
                else
                {
                    parameter.Add("CompFax_result", pOrder.orderFax);
                }
                parameter.Add("MoneyDate_result", pOrder.paydate.ToString("yyyy-MM-dd"));
                parameter.Add("Money_result", pOrder.paymoney.ToString("###,##0"));

                CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                pBuffer.Trans(lType);
                foreach (CodeMaster cm in pBuffer)
                {
                    if (cm.codekey.Equals(pOrder.paycondition))
                    {
                        parameter.Add("Moneycheck_result", cm.codename);
                    }
                }
                

                parameter.Add("MoneyOrderDate_result", pOrder.orderdate.ToString("yyyy-MM-dd"));

                for (int i = 1; i <= 15; i++)
                {
                    if(pSubOrder.Count >= i)
                    {
                        parameter.Add("ListNumber" + i.ToString(), i.ToString());
                        parameter.Add("ListProductName" + i.ToString(), pSubOrder[i - 1].productName);
                        parameter.Add("ListProductSpec" + i.ToString(), pSubOrder[i - 1].productspec_disp);
                        parameter.Add("ListMount" + i.ToString(), pSubOrder[i - 1].productAmount.ToString("###,##0"));
                        parameter.Add("ListMoney" + i.ToString(), pSubOrder[i-1].productPrice.ToString("###,##0"));
                        parameter.Add("ListTotalMoney" + i.ToString(), pSubOrder[i - 1].productMoney.ToString("###,##0"));
                        totalMoney += pSubOrder[i - 1].productMoney;
                    }
                    else
                    {
                        parameter.Add("ListNumber" + i.ToString(), i.ToString());
                        parameter.Add("ListProductName" + i.ToString(),"");
                        parameter.Add("ListProductSpec" + i.ToString(), "");
                        parameter.Add("ListMount" + i.ToString(), "");
                        parameter.Add("ListMoney" + i.ToString(), "");
                        parameter.Add("ListTotalMoney" + i.ToString(), "");
                    }
                }

                parameter.Add("ListTotalSumMoney_result", totalMoney.ToString("###,##0"));
                
                foreach (string key in pLang.Keys)
                {
                    if (!parameter.ContainsKey(key))
                        parameter.Add(key, pLang[key]);
                }
                App_Code.PDFCreate pdf = new PDFCreate();
                pdf.Open();
                System.IO.MemoryStream stm = (System.IO.MemoryStream)pdf.PdfCreater(Server.MapPath("..\\PDF\\OrderForm.html"), parameter);
                pdf.Close();
                String filename = "Order_" + DateTime.Now.ToString("yyyyMMdd")+".pdf";
                return File(stm.GetBuffer(), "application/octet-stream", filename);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/PDFCreate - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 업체 셀렉트시 AJX
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CompanySelect(int idx)
        {
            //버그가 있음
            //에러가 있어서 재입력 할때 Cookie와 Session 값이 안 맞는 현상
            if (false && !SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/CompanySelect");

                CustomerInfo custInfo = new CustomerInfo();
                custInfo.CustomerSelect(idx, CompanySession.companyCode);
                return Json(custInfo, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Obtain/ProductSelect - NoAjax");
                return NoAjax();
            }
        }
    }
}
