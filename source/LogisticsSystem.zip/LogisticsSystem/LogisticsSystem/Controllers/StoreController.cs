﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;

namespace LogisticsSystem.Controllers
{
    public class StoreController : SyController
    {
        private const int COMMIT_KANRYOU = 1;
        private const int COMMIT_KAKUNINN = 2;
        private const int PAGELIMIT = 50;

        private const int COMMIT_SHOUNINNPAGE = 1;
        private const int COMMIT_SHOUNINN = 2;
        private const int COMMIT_SHOUNINNCANCEL = 3;

        protected UserInfo UserSession
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanySession
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserSession != null && CompanySession != null;
        }
        /// <summary>
        /// 입고등록
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ApplyAdd(String key)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyAdd");

                if ("BACK".Equals(key))
                {
                    ProductFlow pFlow = (ProductFlow)Session["productFlow"];
                    if (pFlow != null)
                    {
                        ViewBag.Flow = pFlow;
                        ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;
                    }
                }
                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                ViewBag.productlist = pProduct;
                ViewBag.userInfo = UserSession;

                //세션 초기화
                Session["productFlow"] = null;
                return View("~/Views/Store/Web/ApplyAdd.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyAdd - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 상품검색(등록화면에서) AJAX
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ProductSelect(int idx)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ProductSelect");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                ProductInfo p = new ProductInfo();
                p.ProductSelect(idx, CompanySession.companyCode, lType);

                return Json(p, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ProductSelect - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 입고등록입력확인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyAddCheck(ProductFlow pFlow)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyAddCheck");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                Session["action"] = "ApplyAdd";
                List<String> pErrmsg = pFlow.validate(lType);
                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                //에러가 있는 경우
                if (pErrmsg.Count > 0)
                {
                    String err = "";
                    foreach (String pData in pErrmsg)
                    {
                        err += pData + "<br>";
                    }
                    ViewBag.ErrMsg = err;
                    ViewBag.Flow = pFlow;
                    ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;
                    ViewBag.productlist = pProduct;
                    ViewBag.userInfo = UserSession;

                    return View("~/Views/Store/Web/ApplyAdd.cshtml", Define.MASTER_VIEW);
                }
                //정상의 경우
                else
                {
                    foreach (ProductInfo pData in pProduct)
                    {
                        if (pData.idx == pFlow.productIndex)
                        {
                            pFlow.productname = pData.productname;
                        }
                    }
                    ViewBag.Flow = pFlow;
                    ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;
                    Session["productFlow"] = pFlow;

                    ViewBag.Commit = COMMIT_KAKUNINN;
                    return View("~/Views/Store/Web/ApplyAddCheck.cshtml", Define.MASTER_VIEW);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyAddCheck - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 입고등록입력확인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyInsert()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyInsert");

                ProductFlow pFlow = (ProductFlow)Session["productFlow"];
                pFlow.state = ProductFlow.INCOMESTANBY.ToString();
                pFlow.applyType = ProductFlow.APPLYTYPE_NORMAL;
                pFlow.companycode = CompanySession.companyCode;
                String pBuffer = pFlow.productname;
                pFlow.productname = null;
                pFlow.ProductInsert();
                pFlow.productname = pBuffer;
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;

                //세션 초기화
                Session["productFlow"] = null;

                ViewBag.Commit = COMMIT_KANRYOU;
                Session["action"] = "ApplyAdd";
                return View("~/Views/Store/Web/ApplyAddCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyInsert - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 입고승인리스트
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ApplyCheckList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyCheckList");

                ProductFlowList list = new ProductFlowList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.FlowCount(ProductFlow.INCOMESTANBY,CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.FlowSelect(PAGELIMIT, 1, ProductFlow.INCOMESTANBY, CompanySession.companyCode);

                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Store/Web/ApplyCheckList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyCheckList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 승인리스트 검색(AJAX)
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyListSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                ProductFlowList list = new ProductFlowList();
                int count = list.FlowCount(ProductFlow.INCOMESTANBY, CompanySession.companyCode);
                list.FlowSelect(PAGELIMIT, page, ProductFlow.INCOMESTANBY, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 입고승인페이지
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyApprovePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyApprovePage");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                Dictionary<String, Object> sessionBuffer = new Dictionary<string, object>();
                ProductFlow pFlow = new ProductFlow();
                pFlow.ProductSelect(idx, CompanySession.companyCode);
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;

                sessionBuffer.Add("FLOW",pFlow);
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = new OrderTable();
                    //발주서 검색
                    pOrder.SelectIdxReflesh(pFlow.applyType, CompanySession.companyCode);
                    //정상경로가 아님
                    if (pOrder.idx <= 0)
                    {
                        return ErrorPage("/Home/Error");
                    }
                    sessionBuffer.Add("ORDER", pOrder);
                    //문서정보 취득
                    Document pDoc = new Document();
                    pDoc.DocumentSelect(pOrder.idx, "1", CompanySession.companyCode);

                    sessionBuffer.Add("DOCUMENT", pDoc);
                    //서버 상품 검색
                    OrderTable_SubList pSubOrder = new OrderTable_SubList();
                    pSubOrder.SubListSelect(pOrder.idx, CompanySession.companyCode, lType);

                    sessionBuffer.Add("SUBLIST", pSubOrder);
                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;

                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                }

                Session["ApproveData"] = sessionBuffer;
                ViewBag.Commit = COMMIT_SHOUNINNPAGE;
                Session["action"] = "ApplyCheckList";
                return View("~/Views/Store/Web/ApplyCheckPage.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyApprovePage - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 입고승인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyApprove(String key)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyApprove");

                Dictionary<String, Object> sessionBuffer = (Dictionary<String, Object>)Session["ApproveData"];
                if (sessionBuffer == null)
                {
                    return ErrorPage("/Home/Error");
                }
                else
                {
                    Session["ApproveData"] = null;
                }

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                ProductFlow pFlow = (ProductFlow)sessionBuffer["FLOW"];
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = (OrderTable)sessionBuffer["ORDER"];
                    Document pDoc = (Document)sessionBuffer["DOCUMENT"];
                    OrderTable_SubList pSubOrder = (OrderTable_SubList)sessionBuffer["SUBLIST"];
                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;

                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;
                }

                //등록부분
                if ("approve".Equals(key))
                {
                    Cargo cargo = new Cargo();
                    pFlow.ProductApprove(pFlow.idx, CompanySession.companyCode,ProductFlow.INCOMECOMPLATE);
                    cargo.productindex = pFlow.productIndex;
                    cargo.productInput = pFlow.productAmount;
                    cargo.productOutput = 0;
                    cargo.productmoney = pFlow.productAmount * pFlow.productbuyPrice;
                    cargo.creater = UserSession.creater;
                    cargo.createdate = DateTime.Now;
                    cargo.state = Define.STATE_NORMAL.ToString();
                    cargo.companycode = CompanySession.companyCode;
                    cargo.CargoInsert();
                    ViewBag.Commit = COMMIT_SHOUNINN;
                }
                else
                {
                    pFlow.ProductApprove(pFlow.idx, CompanySession.companyCode, ProductFlow.INCOMECANCEL);
                    ViewBag.Commit = COMMIT_SHOUNINNCANCEL;
                }
                Session["action"] = "ApplyCheckList";
                return View("~/Views/Store/Web/ApplyCheckPage.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyApprove - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 입고리스트(히스토리)
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ApplyList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyListearch");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                
                ProductFlowList list = new ProductFlowList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.FlowListCount(CompanySession.companyCode,ProductFlow.INCOMECANCEL,ProductFlow.INCOMECOMPLATE,ProductFlow.INCOMESTANBY) / (Double)PAGELIMIT)));
                list.FlowListSelect(PAGELIMIT, 1, CompanySession.companyCode, ProductFlow.INCOMECANCEL, ProductFlow.INCOMECOMPLATE, ProductFlow.INCOMESTANBY);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                foreach (ProductFlow pFlow in list) 
                {
                    pFlow.stateView(lType);
                }
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Store/Web/ApplyList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyList - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 리스트검색Ajax
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApplyListearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyListearch");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                if (page < 1)
                {
                    page = 1;
                }
                ProductFlowList list = new ProductFlowList();
                int count = list.FlowListCount(CompanySession.companyCode,1,2,5);
                list.FlowListSelect(PAGELIMIT, page, CompanySession.companyCode, 1, 2, 5);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    list[i].stateView(lType);
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApplyListearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 리스트검색페이지
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ApprovePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApprovePage");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                Dictionary<String, Object> sessionBuffer = new Dictionary<string, object>();
                ProductFlow pFlow = new ProductFlow();
                pFlow.ProductSelect(idx, CompanySession.companyCode);
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productbuyPrice * pFlow.productAmount;
                pFlow.stateView(lType);

                sessionBuffer.Add("FLOW", pFlow);
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = new OrderTable();
                    //발주서 검색
                    pOrder.SelectIdxReflesh(pFlow.applyType, CompanySession.companyCode);
                    //정상경로가 아님
                    if (pOrder.idx <= 0)
                    {
                        return ErrorPage("/Home/Error");
                    }
                    sessionBuffer.Add("ORDER", pOrder);
                    //문서정보 취득
                    Document pDoc = new Document();
                    pDoc.DocumentSelect(pOrder.idx, "1", CompanySession.companyCode);

                    sessionBuffer.Add("DOCUMENT", pDoc);
                    //서버 상품 검색
                    OrderTable_SubList pSubOrder = new OrderTable_SubList();
                    pSubOrder.SubListSelect(pOrder.idx, CompanySession.companyCode, lType);

                    sessionBuffer.Add("SUBLIST", pSubOrder);
                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;

                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                }

                //Session["ApproveData"] = sessionBuffer;
                //ViewBag.Commit = COMMIT_SHOUNINNPAGE;
                ViewBag.Commit = pFlow.state;
                Session["action"] = "ApplyList";
                return View("~/Views/Store/Web/ApplyView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ApprovePage - Error");
                return base.Logout();
            }
        }

        /*여기까지가 입고장처리*/

        /// <summary>
        /// 출고등록
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ReleaseAdd(String key)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseAdd");

                if ("BACK".Equals(key))
                {
                    ProductFlow pFlow = (ProductFlow)Session["productFlow"];
                    if (pFlow != null)
                    {
                        ViewBag.Flow = pFlow;
                        ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;
                    }
                }
                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                ViewBag.productlist = pProduct;
                ViewBag.userInfo = UserSession;

                return View("~/Views/Store/Web/ReleaseAdd.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseAdd - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 출고등록입력확인
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseAddCheck(ProductFlow pFlow)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseAddCheck");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                Session["action"] = "ReleaseAdd";
                List<String> pErrmsg = pFlow.validate(lType);
                ProductInfoList pProduct = new ProductInfoList();
                pProduct.ProductNameList(CompanySession.companyCode);
                //에러가 있는 경우
                if (pErrmsg.Count > 0)
                {
                    String err = "";
                    foreach (String pData in pErrmsg)
                    {
                        err += pData + "<br>";
                    }
                    ViewBag.ErrMsg = err;
                    ViewBag.Flow = pFlow;
                    ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;
                    ViewBag.productlist = pProduct;
                    ViewBag.userInfo = UserSession;

                    return View("~/Views/Store/Web/ReleaseAdd.cshtml", Define.MASTER_VIEW);
                }
                //정상의 경우
                else
                {
                    foreach (ProductInfo pData in pProduct)
                    {
                        if (pData.idx == pFlow.productIndex)
                        {
                            pFlow.productname = pData.productname;
                        }
                    }
                    ViewBag.Flow = pFlow;
                    ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;
                    Session["productFlow"] = pFlow;

                    ViewBag.Commit = COMMIT_KAKUNINN;
                    return View("~/Views/Store/Web/ReleaseAddCheck.cshtml", Define.MASTER_VIEW);
                }
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseAddCheck - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 출고등록입력
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseInsert()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseInsert");

                ProductFlow pFlow = (ProductFlow)Session["productFlow"];
                pFlow.state = ProductFlow.OUTCOMESTANBY.ToString();
                pFlow.applyType = ProductFlow.APPLYTYPE_NORMAL;
                pFlow.companycode = CompanySession.companyCode;
                pFlow.productbuyPrice = 0; //입고초기화
                String pBuffer = pFlow.productname;
                pFlow.productname = null;
                pFlow.ProductInsert();
                pFlow.productname = pBuffer;
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;

                //세션 초기화
                Session["productFlow"] = null;

                ViewBag.Commit = COMMIT_KANRYOU;
                Session["action"] = "ReleaseAdd";
                return View("~/Views/Store/Web/ReleaseAddCheck.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseInsert - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 출고승인리스트
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ReleaseCheckList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseCheckList");

                ProductFlowList list = new ProductFlowList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.FlowCount(ProductFlow.OUTCOMESTANBY, CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.FlowSelect(PAGELIMIT, 1, ProductFlow.OUTCOMESTANBY, CompanySession.companyCode);

                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Store/Web/ReleaseCheckList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseCheckList - Error");
                return base.Logout();
            }          
        }
        /// <summary>
        /// 출고승인검색 AJAX
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseApproveSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                int pagelimit = 50;
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApproveSearch");
                if (page < 1)
                {
                    page = 1;
                }
                ProductFlowList list = new ProductFlowList();
                int count = list.FlowCount(ProductFlow.OUTCOMESTANBY, CompanySession.companyCode);
                list.FlowSelect(pagelimit, page, ProductFlow.OUTCOMESTANBY, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", pagelimit);
                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApproveSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 출고승인페이지
        /// </summary>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseApprovePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApprovePage");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                Dictionary<String, Object> sessionBuffer = new Dictionary<string, object>();
                ProductFlow pFlow = new ProductFlow();
                pFlow.ProductSelect(idx, CompanySession.companyCode);
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;

                sessionBuffer.Add("FLOW", pFlow);
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = new OrderTable();
                    //발주서 검색
                    pOrder.SelectIdxReflesh(pFlow.applyType, CompanySession.companyCode);
                    //정상경로가 아님
                    if (pOrder.idx <= 0)
                    {
                        return ErrorPage("/Home/Error");
                    }
                    sessionBuffer.Add("ORDER", pOrder);
                    //문서정보 취득
                    Document pDoc = new Document();
                    pDoc.DocumentSelect(pOrder.idx, "1", CompanySession.companyCode);

                    sessionBuffer.Add("DOCUMENT", pDoc);
                    //서버 상품 검색
                    OrderTable_SubList pSubOrder = new OrderTable_SubList();
                    pSubOrder.SubListSelect(pOrder.idx, CompanySession.companyCode, lType);

                    sessionBuffer.Add("SUBLIST", pSubOrder);
                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;

                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                }

                Session["ApproveData"] = sessionBuffer;
                ViewBag.Commit = COMMIT_SHOUNINNPAGE;
                Session["action"] = "ReleaseCheckList";
                return View("~/Views/Store/Web/ReleaseCheckPage.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApprovePage - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 출고승인
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseApprove(String key)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApprove");

                Dictionary<String, Object> sessionBuffer = (Dictionary<String, Object>)Session["ApproveData"];
                if (sessionBuffer == null)
                {
                    return ErrorPage("/Home/Error");
                }
                else
                {
                    Session["ApproveData"] = null;
                }

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                ProductFlow pFlow = (ProductFlow)sessionBuffer["FLOW"];
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = (OrderTable)sessionBuffer["ORDER"];
                    Document pDoc = (Document)sessionBuffer["DOCUMENT"];
                    OrderTable_SubList pSubOrder = (OrderTable_SubList)sessionBuffer["SUBLIST"];
                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;

                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;
                }

                //등록부분
                if ("approve".Equals(key))
                {
                    Cargo cargo = new Cargo();
                    pFlow.ProductApprove(pFlow.idx, CompanySession.companyCode, ProductFlow.OUTPUTCOMPLATE);
                    cargo.productindex = pFlow.productIndex;
                    cargo.productInput = 0;
                    cargo.productOutput = pFlow.productAmount;
                    cargo.productmoney = pFlow.productAmount * pFlow.productSellPrice;
                    cargo.creater = UserSession.creater;
                    cargo.createdate = DateTime.Now;
                    cargo.state = Define.STATE_NORMAL.ToString();
                    cargo.companycode = CompanySession.companyCode;
                    cargo.CargoInsert();
                    ViewBag.Commit = COMMIT_SHOUNINN;
                }
                else
                {
                    pFlow.ProductApprove(pFlow.idx, CompanySession.companyCode, ProductFlow.OUTPUTCANCEL);
                    ViewBag.Commit = COMMIT_SHOUNINNCANCEL;
                }
                Session["action"] = "ReleaseCheckList";
                return View("~/Views/Store/Web/ReleaseCheckPage.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseApprove - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 출고 리스트(이력)
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult ReleaseList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseList");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                ProductFlowList list = new ProductFlowList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.FlowListCount(CompanySession.companyCode, ProductFlow.OUTCOMESTANBY, ProductFlow.OUTPUTCANCEL, ProductFlow.OUTPUTCOMPLATE) / (Double)PAGELIMIT)));
                list.FlowListSelect(PAGELIMIT, 1, CompanySession.companyCode, ProductFlow.OUTCOMESTANBY, ProductFlow.OUTPUTCANCEL, ProductFlow.OUTPUTCOMPLATE);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                foreach (ProductFlow pFlow in list)
                {
                    pFlow.stateView(lType);
                }
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Store/Web/ReleaseList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseList - Error");
                return base.Logout();
            }
        }
        //여기부터 수정
        /// <summary>
        /// 출고이력검색 AJAX
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleaseListSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseHistoryListSearch");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                if (page < 1)
                {
                    page = 1;
                }
                ProductFlowList list = new ProductFlowList();
                int count = list.FlowListCount(CompanySession.companyCode, ProductFlow.OUTCOMESTANBY, ProductFlow.OUTPUTCANCEL, ProductFlow.OUTPUTCOMPLATE);
                list.FlowListSelect(PAGELIMIT, page, CompanySession.companyCode, ProductFlow.OUTCOMESTANBY, ProductFlow.OUTPUTCANCEL, ProductFlow.OUTPUTCOMPLATE);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    list[i].stateView(lType);
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleaseListSearch - NoAjax");
                return NoAjax();
            }
        }
        /// <summary>
        /// 리스트검색페이지출고
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ReleasePage(Int64 idx)
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleasePage");

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                Dictionary<String, Object> sessionBuffer = new Dictionary<string, object>();
                ProductFlow pFlow = new ProductFlow();
                pFlow.ProductSelect(idx, CompanySession.companyCode);
                ViewBag.Flow = pFlow;
                ViewBag.totalprice = pFlow.productSellPrice * pFlow.productAmount;
                pFlow.stateView(lType);

                sessionBuffer.Add("FLOW", pFlow);
                if (pFlow.applyType != 0)
                {
                    OrderTable pOrder = new OrderTable();
                    //수주서 검색
                    pOrder.SelectIdxReflesh(pFlow.applyType, CompanySession.companyCode);
                    //정상경로가 아님
                    if (pOrder.idx <= 0)
                    {
                        return ErrorPage("/Home/Error");
                    }
                    sessionBuffer.Add("ORDER", pOrder);
                    //문서정보 취득
                    Document pDoc = new Document();
                    pDoc.DocumentSelect(pOrder.idx, "1", CompanySession.companyCode);

                    sessionBuffer.Add("DOCUMENT", pDoc);
                    //서버 상품 검색
                    OrderTable_SubList pSubOrder = new OrderTable_SubList();
                    pSubOrder.SubListSelect(pOrder.idx, CompanySession.companyCode, lType);

                    sessionBuffer.Add("SUBLIST", pSubOrder);
                    //기본 데이터 Attribute저장
                    ViewBag.doc = pDoc;
                    ViewBag.order = pOrder;
                    ViewBag.orderSub = pSubOrder;

                    //전체 금액 계산
                    Decimal totalMoney = 0;
                    foreach (OrderTable_Sub pSub in pSubOrder)
                    {
                        totalMoney += pSub.productMoney;
                    }
                    ViewBag.totalMoney = totalMoney;

                    //코드마스터 취득
                    CodeMasterList pBuffer = new CodeMasterList("MoneySendType");
                    pBuffer.Trans(lType);
                    ViewBag.moneySendType = pBuffer;
                }

                //Session["ApproveData"] = sessionBuffer;
                //ViewBag.Commit = COMMIT_SHOUNINNPAGE;
                ViewBag.Commit = pFlow.state;
                Session["action"] = "ReleaseList";
                return View("~/Views/Store/Web/ReleaseView.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/ReleasePage - Error");
                return base.Logout();
            }
        }
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult StoreList()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreList");

                CargoList list = new CargoList();
                list.CargoSelect(CompanySession.companyCode);

                ViewBag.list = list;
                ViewBag.listcount = list.Count;

                return View("~/Views/Store/Web/StoreList.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreListn - Error");
                return base.Logout();
            }
        }
        //*********************************
        
        /// <summary>
        /// 입출고수불
        /// </summary>
        /// <param name="pDoc"></param>
        /// <param name="pOrder"></param>
        /// <param name="pSubOrder"></param>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult StoreOrder()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreOrder");

                CargoList list = new CargoList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.CargoListSelectCount(CompanySession.companyCode) / (Double)PAGELIMIT)));
                list.CargoListSelect(PAGELIMIT, 1, CompanySession.companyCode);

                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                foreach (Cargo pBuffer in list)
                {
                    pBuffer.TypeCheck(lType);
                }

                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Store/Web/StoreOrder.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreOrder - Error");
                return base.Logout();
            }
        }
        /// <summary>
        /// 입출고수불검색 AJAX
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult StoreListSearch(int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                CargoList list = new CargoList();
                int count = list.CargoListSelectCount(CompanySession.companyCode);
                list.CargoListSelect(PAGELIMIT, page, CompanySession.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }

                for (int i = 0; i < list.Count; i++)
                {
                    list[i].TypeCheck(lType);
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                LogWriter.Instance().LogWrite(UserSession.userid, "/Store/StoreListSearch - NoAjax");
                return NoAjax();
            }
        }
    }
}
