﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LogisticsSystem.App_Code;
using LogisticsSystem.Models;

namespace LogisticsSystem.Controllers
{
    public class CustomerController : SyController
    {
        private const int PAGELIMIT = 10;
        protected UserInfo UserInfo
        {
            get { return (UserInfo)Session["userinfo"]; }
        }
        protected CompanyInfo CompanyInfo
        {
            get { return (CompanyInfo)Session["compinfo"]; }
        }
        protected bool AuthCheck()
        {
            return SessionCheck("AuthCheck") && UserInfo != null && CompanyInfo != null;
        }
        /// <summary>
        /// 고객 등록 페이지 초기화
        /// </summary>
        /// <returns></returns>
        [PipelineFilter]
        [AuthorizeFilter]
        public ActionResult Main()
        {
            if (!SessionCheck("SessionCheck"))
            {
                return ErrorPage("/Home/Error");
            }
            //if (!SessionCheck("BrowserCheck"))
            //{
            //    return ErrorPage("/Home/BrowserError");
            //}
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/Main");
                String pLanguage = Request.Form["Lang"];
                LanguageType? lType = null;
                if (pLanguage != null && !"".Equals(pLanguage))
                {
                    if ("k".Equals(pLanguage))
                    {
                        lType = LanguageType.Korea;
                    }
                    else
                    {
                        lType = LanguageType.Japan;
                    }
                }
                CodeMasterList pBuffer = new CodeMasterList("customerType");
                pBuffer.Trans(lType);
                ViewBag.customerType = pBuffer;

                pBuffer = new CodeMasterList("MoneySendType");
                pBuffer.Trans(lType);
                ViewBag.moneySendType = pBuffer;

                pBuffer = new CodeMasterList("customerTaxType");
                pBuffer.Trans(lType);
                ViewBag.customerTaxType = pBuffer;

                //1페이지 검색
                CustomerInfoList list = new CustomerInfoList();
                int count = Convert.ToInt32(Math.Ceiling((Double)((Double)list.CustomerInfoCount(CompanyInfo.companyCode) / (Double)PAGELIMIT)));
                list.SelectList(PAGELIMIT, 1, CompanyInfo.companyCode);
                ViewBag.list = list;
                ViewBag.listcount = count;

                return View("~/Views/Customer/Web/Main.cshtml", Define.MASTER_VIEW);
            }
            else
            {
                return Logout();
            }
        }
        /// <summary>
        /// 검색Ajax
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult ListSearch(int page = 0)/*Ajax*/
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/ListSearch");
                if (page < 1)
                {
                    page = 1;
                }
                CustomerInfoList list = new CustomerInfoList();
                int count = list.CustomerInfoCount(CompanyInfo.companyCode);
                list.SelectList(PAGELIMIT, page, CompanyInfo.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", PAGELIMIT);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 코드생성
        /// </summary>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CodeCreate()
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/CodeCreate");
                CustomerInfo pBuffer = new CustomerInfo();
                return Content(pBuffer.CreateCode());
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 데이터 입력
        /// </summary>      
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Insert(CustomerInfo data)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/Insert");
                List<String> Errmsg = data.validate((LanguageType?)Session["languageType"]);
                if (Errmsg.Count < 1)
                {
                    data.customercode = "CC-" + data.customercode;
                    data.creater = User.Identity.Name;
                    data.createdate = DateTime.Now;
                    data.state = "0";
                    data.postNumberProcedure();
                    data.companycode = CompanyInfo.companyCode;
                    data.CustmerInsert();
                    return Content(null);
                }
                else
                {
                    String ret = "";
                    foreach (string pBuffer in Errmsg)
                    {
                        ret += pBuffer + "<br>";
                    }
                    return Content(ret);
                }
            }
            else
            {
                return Content("SESSIONOUT");
            }
        }
        /// <summary>
        /// 리스트클릭시 검색
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CustomerSearch(String code)/*Ajax*/
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/CustomerSearch");
                CustomerInfo info = new CustomerInfo();
                info.CustomerSelect(code,CompanyInfo.companyCode);
                return Json(info, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 히스토리 리스트 검색
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult HistorySearch(String code, int page = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/HistorySearch");
                int pagelimit = 10;
                if (page < 1)
                {
                    page = 1;
                }
                CustomerInfoList list = new CustomerInfoList();
                int count = list.CustomerInfoHistoryCount(code,CompanyInfo.companyCode);
                list.CustomerInfoHistorySearch(pagelimit, page, code,CompanyInfo.companyCode);
                Dictionary<String, object> pRet = new Dictionary<String, object>();

                for (int i = 0; i < list.Count; i++)
                {
                    pRet.Add("item" + i.ToString(), list[i]);
                }
                pRet.Add("count", list.Count);
                pRet.Add("totalcount", count);
                pRet.Add("limit", pagelimit);

                return Json(pRet, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 히스토리 리스트에서 선택시 검색
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult CustomerHistorySearch(int idx = 0)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/CustomerHistorySearch");
                CustomerInfo info = new CustomerInfo();
                info.CustomerHistorySelect(idx,CompanyInfo.companyCode);
                return Json(info, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return NoAjax();
            }
        }
        /// <summary>
        /// 삭제쿼리
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Delete(String code)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/CustomerHistorySearch");
                CustomerInfo info = new CustomerInfo();
                info.customercode = code;
                info.CustomerDelete(CompanyInfo.companyCode);
                return Content("OK");
            }
            else
            {
                return Content("SESSIONOUT");
            }
        }
        /// <summary>
        /// 수정처리
        /// </summary>
        [AjaxFilterAttribute]
        [AuthorizeFilter]
        [HttpPost]
        public ActionResult Modify(CustomerInfo data)
        {
            if (!SessionCheck("AjaxCheck"))
            {
                return Content("NG");
            }
            if (AuthCheck())
            {
                LogWriter.Instance().LogWrite(UserInfo.userid, "/Customer/Modify");
                List<String> Errmsg = data.validate((LanguageType?)Session["languageType"]);
                if (Errmsg.Count < 1)
                {
                    Delete("CC-" + data.customercode);
                    return Insert(data);
                }
                else
                {
                    String ret = "";
                    foreach (string pBuffer in Errmsg)
                    {
                        ret += pBuffer + "<br>";
                    }
                    return Content(ret);
                }
            }
            else
            {
                return Content("SESSIONOUT");
            }
        }
    }
}
