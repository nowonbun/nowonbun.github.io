﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pipeline;

namespace Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Pipeline<int?> test = new Pipeline<int?>())
            {
                test.SetPipeLineInserter(() =>
                {
                    for (int i = 0; i < 10000; i++)
                    {
                        test.Push(i);
                    }
                });
                test.SetPipeLineInserter(() =>
                {
                    for (int i = 10000; i < 20000; i++)
                    {
                        test.Push(i);
                    }
                });

                test.SetPipeLineExecutor((item) =>
                {
                    Console.WriteLine("THREAD - 1  - " + item);
                });
                test.SetPipeLineExecutor((item) =>
                {
                    Console.WriteLine("THREAD - 2  - " + item);
                });
                test.SetPipeLineExecutor((item) =>
                {
                    Console.WriteLine("THREAD - 3  - " + item);
                });
                test.SetPipeLineExecutor((item) =>
                {
                    Console.WriteLine("THREAD - 4  - " + item);
                });
            }

            Console.WriteLine("Press Any key...");
            Console.ReadLine();
        }
    }
}
