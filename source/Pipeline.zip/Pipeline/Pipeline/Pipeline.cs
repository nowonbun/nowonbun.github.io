﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Pipeline
{
    public class Pipeline<T> : IDisposable
    {
        enum FLAG
        {
            LIVE,
            FINISH
        }

        private Thread asyncThread = null;
        private LinkedList<T> memory = new LinkedList<T>();
        private Dictionary<Object, FLAG> inserterDic = new Dictionary<object, FLAG>();
        private Dictionary<Object, FLAG> executorDic = new Dictionary<object, FLAG>();
        private int max;
        private int sleeptime;
        private FLAG state = FLAG.LIVE;

        public Pipeline(bool async = true, int max = 10000, int sleeptime = 100)
        {
            this.max = max;
            this.sleeptime = sleeptime;
            if (!async)
            {
                asyncThread = new Thread(() =>
                {
                    Thread.Sleep(-1);
                });
                asyncThread.Start();
            }
        }
        private T Sync(T v)
        {
            lock (memory)
            {
                if (Object.Equals(v, default(T)))
                {
                    if (memory.Count > 0)
                    {
                        T ret = memory.First.Value;
                        memory.RemoveFirst();
                        return ret;
                    }
                }
                else
                {
                    if (memory.Count < max)
                    {
                        memory.AddLast(v);
                        return v;
                    }
                }
                return default(T);
            }
        }

        public void Push(T value)
        {
            T ret;
            while (Object.Equals(ret = Sync(value), default(T)))
            {
                Sleep();
            }
        }

        public T Pop()
        {
            T ret;
            while (Object.Equals(ret = Sync(default(T)), default(T)))
            {
                if (!IsAlive())
                {
                    break;
                }
                Sleep();
            }
            return ret;
        }

        private void Sleep()
        {
            Thread.Sleep(sleeptime);
        }

        public bool IsAlive()
        {
            if (Object.Equals(FLAG.LIVE, state))
            {
                return true;
            }
            return IsSubDic(inserterDic);
        }
        public bool IsFinish()
        {
            if (Object.Equals(FLAG.FINISH, state))
            {
                if (CheckListener(executorDic) && !IsSubDic(executorDic))
                {
                    return true;
                }
            }
            return false;
        }
        private bool CheckListener(Dictionary<Object, FLAG> dic)
        {
            for (int i = 0; i < 3; i++)
            {
                lock (dic)
                {
                    if (dic.Count > 0)
                    {
                        return true;
                    }
                }
                Sleep();
            }
            return false;
        }
        private bool IsSubDic(Dictionary<object, FLAG> obj)
        {
            lock (obj)
            {
                foreach (FLAG flag in obj.Values)
                {
                    if (Object.Equals(FLAG.LIVE, flag))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        private void LockDIc(Dictionary<object, FLAG> target, Action<Dictionary<object, FLAG>> action)
        {
            lock (target)
            {
                action.Invoke(target);
            }
        }

        public void SetPipeLineInserter(Func<T> listener)
        {
            if (Object.Equals(state, FLAG.FINISH))
            {
                throw new Exception("finish");
            }
            ThreadPool.QueueUserWorkItem((callback) =>
            {
                lock (inserterDic)
                {
                    inserterDic.Add(listener, FLAG.LIVE);
                }
                while (true)
                {
                    T obj = listener.Invoke();
                    if (Object.Equals(obj, default(T)))
                    {
                        break;
                    }
                    Push(obj);
                }
                lock (inserterDic)
                {
                    inserterDic[listener] = FLAG.FINISH;
                }
                if (IsSubDic(inserterDic))
                {
                    state = FLAG.FINISH;
                }
            });
        }

        public void SetPipeLineInserter(Action listener)
        {
            if (Object.Equals(state, FLAG.FINISH))
            {
                throw new Exception("finish");
            }
            ThreadPool.QueueUserWorkItem((callback) =>
            {
                lock (inserterDic)
                {
                    inserterDic.Add(listener, FLAG.LIVE);
                }
                listener.Invoke();
                lock (inserterDic)
                {
                    inserterDic[listener] = FLAG.FINISH;
                }
                if (IsSubDic(inserterDic))
                {
                    state = FLAG.FINISH;
                }
            });
        }
        public void SetPipeLineExecutor(Action listener)
        {
            if (!CheckListener(inserterDic))
            {
                throw new Exception("not listener");
            }
            ThreadPool.QueueUserWorkItem((callback) =>
            {
                lock (executorDic)
                {
                    executorDic.Add(listener, FLAG.LIVE);
                }
                listener.Invoke();
                lock (executorDic)
                {
                    executorDic[listener] = FLAG.FINISH;
                }
                if (IsSubDic(executorDic))
                {
                    state = FLAG.FINISH;
                }
            });
        }
        public void SetPipeLineExecutor(Action<T> listener)
        {
            if (!CheckListener(inserterDic))
            {
                throw new Exception("not listener");
            }
            ThreadPool.QueueUserWorkItem((callback) =>
            {
                lock (executorDic)
                {
                    executorDic.Add(listener, FLAG.LIVE);
                }
                while (true)
                {
                    T obj = Pop();
                    if (Object.Equals(obj, default(T)))
                    {
                        break;
                    }
                    listener.Invoke(obj);
                }
                lock (executorDic)
                {
                    executorDic[listener] = FLAG.FINISH;
                }
                if (IsSubDic(executorDic))
                {
                    state = FLAG.FINISH;
                }
            });
        }
        public void Dispose()
        {
            this.state = FLAG.FINISH;
            while (!IsFinish())
            {
                Sleep();
            }
            if (asyncThread != null)
            {
                asyncThread.Abort();
            }
        }
    }
}
