﻿//입력하는 폼으로 이동
function insertForm() {
    location.href = "InsertForm";
}
function mainForm() {
    location.href = "Main";
}
function modify(idx, obj) {
    obj.style.backgroundColor = "#CBECC7";
    location.href = "ModifyForm?idx=" + idx;
}
function Apply() {
    mainform.action = "AddData";
    mainform.submit();
}
function Modify() {
    mainform.action = "ModifyData";
    mainform.submit();
}
function Delete() {
    mainform.action = "DeleteData";
    mainform.submit();
}
function logout() {
    location.href = "Logout";
}
function CategoryForm() {
    location.href = "CategoryList";
}
function categoryadd() {
    location.href = "CategoryForm";
}
function ApplyCategory() {
    categoryform.action = "ApplyCategory";
    categoryform.submit();
}
function categorymodify(idx, obj) {
    obj.style.backgroundColor = "#CBECC7";
    location.href = "ModifyCategoryForm?idx=" + idx;
}
function DeleteCategory() {
    categoryform.action = "DeleteCategory";
    categoryform.submit();
}
function ModifyCategory() {
    categoryform.action = "ModifyCategory";
    categoryform.submit();
}