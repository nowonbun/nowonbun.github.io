﻿$.mobile.ajaxEnabled = false;
var m_bMainLoading = false;
var m_bListLoading = false;
var nType = 0;
function loadingSetting() {
    var docHeight = $(document).height();
    var winHeight = $(window).height();
    var loadingPageSrc = '<div id="loading" align="center" valign="middle" style="display:none;" >' +
                            '<table width="100%" height=' + winHeight + ' border=0>' +
                            '<tr><td align=center valign=middle>' +
                            '<img src="/Contents/Loading.gif" />' +
                            '</td></tr>' +
                            '</table>' +
                            '</div>';
    $(document.body).prepend(loadingPageSrc);
    $("#loading").css({
        opacity: '0.5',
        position: 'absolute',
        top: '0',
        width: '100%',
        height: docHeight,
        background: '#FFF',
        display: '',
        zIndex: '1'
    });
    $("#loading").hide();
}
function loading() {
    m_bMainLoading = false;
    m_bListLoading = false;
    /*$.mobile.loading("show", {
        text: "",
        textVisible: false,
        theme: $.mobile.loader.prototype.options.theme,
        textonly: false,
        html: ""
    });*/
    $("#loading").show();
}
function loadingout2() {
    //$.mobile.loading("hide");
    $("#loading").hide();
}
function loadingout() {
    if (m_bMainLoading && m_bListLoading) {
        //$.mobile.loading("hide");
        $("#loading").hide();
    }
}
function tableadd(idx, date, type, contents, money, other) {
    var dom = $("#template").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##date##/gi, date);
    dom = dom.replace(/##contents##/gi, contents);
    if (type == 1) {
        color = "<label style='color:red;margin-right:3px;'>";
    }
    else {
        color = "<label style='color:blue;margin-right:3px;'>";
    }
    dom = dom.replace(/##money##/gi, color + "￥" + money + "</label>");
    $("#listData").append(dom);
}
function categoryListadd(idx, type, Disp_type, categoryName) {
    var dom = $("#template").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##type##/gi, Disp_type);
    dom = dom.replace(/##contents##/gi, categoryName);
    if (type == 1) {
        dom = dom.replace(/##selectstyle##/gi, "style='color:red;'");
    } else {
        dom = dom.replace(/##selectstyle##/gi, "style='color:blue;'");
    }
    $("#listData").append(dom);
}
function CategoryListSearch() {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/mobile/ajax2/CategoryList",
        dataType: "json",
        success: function (data) {
            count = data.count;
            $("#listData").children().remove();
            for (i = 1; i <= count; i++) {
                categoryListadd(data[i].idx, data[i].type,data[i].Disp_type, data[i].contents);
            }
            if (count == 0) {
                dom = $("#templateNot").html();
                $("#listData").append(dom);
            }
            loadingout2();
        },
        error: function (msg) {
            //logout();
            alert();
            loadingout2();
        }
    });
}
function totalCalcul(year, month) {
    $.ajax({
        type: "GET",
        url: "/mobile/ajax/MonthTotal",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            listSetting(data.income, data.expend, data.total);
            m_bMainLoading = true;
            loadingout();
        },
        error: function (msg) {
            logout();
            m_bMainLoading = true;
            loadingout();
        }
    });
}
function search(year, month) {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/mobile/ajax/ListSearch",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            count = data.count;
            $("#listData").children().remove();
            for (i = 1; i <= count; i++) {
                tableadd(data[i].idx, data[i].date, data[i].type, data[i].contents, data[i].money, data[i].other);
            }
            if (count == 0) {
                dom = $("#templateNot").html();
                $("#listData").append(dom);
            }
            m_bListLoading = true;
            loadingout();
        },
        error: function (msg) {
            logout();
            m_bListLoading = false;
            loadingout();
        }
    });
}
function searchNormal(year, month) {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/mobile/ajax/ListSearch",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            count = data.count;
            $("#listData").children().remove();
            for (i = 1; i <= count; i++) {
                tableadd(data[i].idx, data[i].date, data[i].type, data[i].contents, data[i].money, data[i].other);
            }
            if (count == 0) {
                dom = $("#templateNot").html();
                $("#listData").append(dom);
            }
            loadingout2();
        },
        error: function (msg) {
            logout();
            loadingout2();
        }
    });
}
function searchDaySort(year, month) {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/mobile/ajax/ListSearch",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            pBufferDay = 0;
            pLineNumber = 0;
            pTotalData = 0;
            count = data.count;
            $("#listData").children().remove();
            for (i = 1; i <= count; i++) {
                if (pBufferDay != data[i].date) {
                    if (pTotalData != 0) {
                        tableDaytotaladd(pTotalData, pLineNumber);
                        pTotalData = 0;
                    }
                    pLineNumber++;
                    pBufferDay = data[i].date;
                    tableDayLineAdd(pBufferDay, pLineNumber);
                }
                tableDayadd(data[i].idx, data[i].date, data[i].type, data[i].contents, data[i].money, data[i].other, pLineNumber);
                if (data[i].type == 1) {
                    pTotalData += Number(unNumberFormat(data[i].money));
                } else {
                    pTotalData -= Number(unNumberFormat(data[i].money));
                }
            }
            if (count == 0) {
                dom = $("#templateNot").html();
                $("#listData").append(dom);
            } else {
                if (pTotalData != 0) {
                    tableDaytotaladd(pTotalData, pLineNumber);
                    pTotalData = 0;
                }
            }
            loadingout2();
        },
        error: function (msg) {
            logout();
            loadingout2();
        }
    });
}
function searchCategorySort(year, month) {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/mobile/ajax/ListSearchCategory",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            pBufferCategory = -1;
            pLineNumber = 0;
            pTotalData = 0;
            count = data.count;
            $("#listData").children().remove();
            for (i = 1; i <= count; i++) {
                if (pBufferCategory != data[i].category) {
                    if (pTotalData != 0) {
                        tableDaytotaladd(pTotalData, pLineNumber);
                        pTotalData = 0;
                    }
                    pLineNumber++;
                    pBufferCategory = data[i].category;
                    pCategoryName = data[i].categoryName;
                    if (pCategoryName == "") {
                        pCategoryName = "カテゴリ無し";
                        tableCategoryLineAdd(pCategoryName, 0, pLineNumber);
                    }
                    else {
                        tableCategoryLineAdd(pCategoryName, data[i].type, pLineNumber);
                    }
                }
                tableDayadd(data[i].idx, data[i].date, data[i].type, data[i].contents, data[i].money, data[i].other, pLineNumber);
                if (data[i].type == 1) {
                    pTotalData += Number(unNumberFormat(data[i].money));
                } else {
                    pTotalData -= Number(unNumberFormat(data[i].money));
                }
            }
            if (count == 0) {
                dom = $("#templateNot").html();
                $("#listData").append(dom);
            } else {
                if (pTotalData != 0) {
                    tableDaytotaladd(pTotalData, pLineNumber);
                    pTotalData = 0;
                }
            }
            loadingout2();
        },
        error: function (msg) {
            logout();
            loadingout2();
        }
    });
}
function tableDayLineAdd(date, LineNumber) {
    var dom = $("#templateLabel").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    dom = dom.replace(/##date##/gi, date);
    $("#listData").append(dom);
}
function tableCategoryLineAdd(CategoryName,CategoryType, LineNumber) {
    var dom = $("#templateLabel2").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    if (CategoryType == "1") {
        color = "<font style='color:red;margin-right:3px;'>";
    } else if (CategoryType == "2") {
        color = "<font style='color:blue;margin-right:3px;'>";
    } else {
        color = "<font style='color:black;margin-right:3px;'>";
    }
    dom = dom.replace(/##CategoryName##/gi, color + CategoryName + "</font>");
    $("#listData").append(dom);
}
function tableDayadd(idx, date, type, contents, money, other, LineNumber) {
    var dom = $("#templateHidden").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##date##/gi, date);
    dom = dom.replace(/##contents##/gi, contents);
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    if (type == 1) {
        color = "<label style='color:red;margin-right:3px;'>";
    }
    else {
        color = "<label style='color:blue;margin-right:3px;'>";
    }
    dom = dom.replace(/##money##/gi, color + "￥" + money + "</label>");
    $("#listData").append(dom);
}
function tableDaytotaladd( money, LineNumber) {
    var dom = $("#templateHidden2").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    if (money > 0 ) {
        color = "<label style='color:red;margin-right:3px;'>";
    }    else if (money < 0) {
        color = "<label style='color:blue;margin-right:3px;'>";
    } else {
        color = "<label style='color:black;margin-right:3px;'>";
    }
    dom = dom.replace(/##money##/gi, color + "￥" + numberFormat(money+"") + "</label>");
    $("#listData").append(dom);
}
function ShowDisplay(LineNumber) {
    var dispCheck = $("#disp" + LineNumber).val();
    if (dispCheck == "0") {
        $(".disp" + LineNumber).show();
        $("#plus" + LineNumber).hide();
        $("#minus" + LineNumber).show();
        $("#disp" + LineNumber).val("1");
    } else {
        $(".disp" + LineNumber).hide();
        $("#plus" + LineNumber).show();
        $("#minus" + LineNumber).hide();
        $("#disp" + LineNumber).val("0");
    }
}
function listSetting(income, expend, total) {
    $("#income").html("￥" + numberFormat(income));
    $("#expend").html("￥" + numberFormat(expend));
    $("#total").html("￥" + numberFormat(total));
    if (total > 0) {
        $("#total").css("color", "red");
    } else if (total < 0) {
        $("#total").css("color", "blue");
    } else {
        $("#total").css("color", "black");
    }
}
function selectChange(year, month) {
    loading();
    $("#navbar1").addClass("ui-btn-active");
    $("#navbar2").removeClass("ui-btn-active");
    $("#navbar3").removeClass("ui-btn-active");
    nType = 0;
    totalCalcul(year, month);
    search(year, month);
}
function selectChangeNormal(year, month) {
    loading();
    searchNormal(year, month);
}
function selectChangedaySort(year, month) {
    loading();
    searchDaySort(year, month);
}
function selectChangeCategorySort(year, month) {
    loading();
    searchCategorySort(year, month);
}
function selectEvent() {
    selectChange($("#year").val(), $("#month").val());
}
function selectGroup(type) {
    if (nType != type) {
        if (type == 0) {
            selectChangeNormal($("#year").val(), $("#month").val());
        } else if (type == 1) {
            selectChangedaySort($("#year").val(), $("#month").val());
        } else if (type == 2) {
            selectChangeCategorySort($("#year").val(), $("#month").val());
        }
    }
    nType = type;
}