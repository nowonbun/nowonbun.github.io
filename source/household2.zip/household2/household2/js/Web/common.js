﻿
var newcount = 0;

//콤마찍기
function numberFormat(num) {
    var pattern = /(-?[0-9]+)([0-9]{3})/;
    while (pattern.test(num)) {
        num = num.replace(pattern, "$1,$2");
    }
    return num;
}
//콤마제거
function unNumberFormat(num) {
    return (num.replace(/\,/g, ""));
}

function allCheck(obj) {
    if (obj.checked) {
        $.each($("input[type=checkbox]"), function () {
            if ($(this).attr("id").match(/^item+/gi)) {
                $(this).prop("checked", true);
            }
        });
    }
    else {
        $.each($("input[type=checkbox]"), function () {
            if ($(this).attr("id").match(/^item+/gi)) {
                $(this).prop("checked", false);
            }
        });
    }
}
function cateallCheck(obj) {
    if (obj.checked) {
        $.each($("input[type=checkbox]"), function () {
            if ($(this).attr("id").match(/^cateitem+/gi)) {
                $(this).prop("checked", true);
            }
        });
    }
    else {
        $.each($("input[type=checkbox]"), function () {
            if ($(this).attr("id").match(/^cateitem+/gi)) {
                $(this).prop("checked", false);
            }
        });
    }
}
function numOnly(obj) {
    return !String.fromCharCode(event.keyCode).match(/[^0-9a-i^\`\b\r]/);
}

function keyup(obj) {
    var pBuffer = unNumberFormat(obj.value);
    pBuffer = Number(pBuffer) + "";
    obj.value = numberFormat(pBuffer);
}

function categoryView(idx) {
    if ($("#item" + idx + "_3").val() == "1") {
        $("#item" + idx + "_4").show();
        $("#item" + idx + "_5").hide();
        $("#item" + idx + "_7").css("color", "red");
    }
    else {
        $("#item" + idx + "_4").hide();
        $("#item" + idx + "_5").show();
        $("#item" + idx + "_7").css("color", "blue");
    }
}

function changeValue(idx) {
    $("#item" + idx + "_1").attr("checked", true);
}

function listSetting(income, expend, total) {
    $("#income").html("￥" + numberFormat(income));
    $("#expend").html("￥" + numberFormat(expend));
    $("#total").html("￥" + numberFormat(total));
    if (total > 0) {
        $("#total").css("color", "red");
    } else if (total < 0) {
        $("#total").css("color", "blue");
    } else {
        $("#total").css("color", "black");
    }
}

function tableadd(idx, date, type, contents, money, other, category) {
    var dom = $("#template").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##date##/gi, date);
    dom = dom.replace(/##contents##/gi, contents);
    dom = dom.replace(/##money##/gi, money);
    dom = dom.replace(/##other##/gi, other);
    $("#listData").append(dom);
    $("#item" + idx + "_3").val(type);
    categoryView(idx);
    if (category == 0) {
        category = "";
    }
    if (type == 1) {
        $("#item" + idx + "_4").val(category);
    } else if (type == 2) {
        $("#item" + idx + "_5").val(category);
    }
}

function newline() {
    newcount++;
    tableadd("new" + newcount, "", 2, "", "", "", "");
    $("#itemnew" + newcount + "_2").datepicker({
        dateFormat: 'yy/mm/dd',
        changeMonth: true,
        changeYear: true
    });
}

function DayFormat() {
    $("#year").html($("#yearD").val());
    month = Number($("#monthD").val());
    if (month < 10) {
        $("#month").html("0" + month);
    } else {
        $("#month").html(month);
    }
}

function AddDay(days) {
    year = Number($("#yearD").val());
    month = Number($("#monthD").val());
    month += days;
    if (month < 1) {
        year -= 1;
        month = 12;
    } else if (month > 12) {
        year += 1;
        month = 1;
    }
    $("#yearD").val(year);
    $("#monthD").val(month);
    selectLoading();
}

function checkin(idx) {
    $("#item" + idx + "_1").prop("checked", true);
}

function selectLoading() {
    loading();
    DayFormat();
    year = Number($("#yearD").val());
    month = Number($("#monthD").val());
    searchCategorySort(year, month);
    totalCalcul(year, month);
}
function dialogSetting() {
    $("#dialog-form").dialog({
        autoOpen: false,
        height: '400',
        width: '400',
        modal: true,
        close: function () {
            $("#dialog-form").dialog("close");
        }
    });
}
function categoryDialog() {
    $("#dialog-form").dialog("open");
}
function cateadd(idx, type, contents) {
    var dom = $("#templateCategory").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##contents##/gi, contents);
    $("#listDataCategory").append(dom);
    $("#cateitem" + idx + "_2").val(type);
}