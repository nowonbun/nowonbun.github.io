﻿
var cateCount = 0;
var m_bMainLoading = false;
var m_bListLoading = false;
/*Ajax로딩 화면 생성 $(document).ready() 에 기본 선언 함수*/
function loadingSetting() {
    var docHeight = $(document).height()-100;
    var winHeight = $(window).height()-100;
    var loadingPageSrc = '<div id="loading" align="center" valign="middle" style="display:none;" >' +
                            '<table width="100%" height=' + winHeight + ' border=0>' +
                            '<tr><td align=center valign=middle>' +
                            '<img src="/Contents/Loading.gif" />' +
                            '</td></tr>' +
                            '</table>' +
                            '</div>';
    $(document.body).prepend(loadingPageSrc);
    $("#loading").css({
        opacity: '0.5',
        position: 'absolute',
        top: '0',
        width: '99%',
        height: docHeight,
        background: '#FFF',
        display: '',
        zIndex: '1'
    });
    $("#loading").hide();
}
/*Ajax로딩 화면 띄우기*/
function loading() {
    m_bMainLoading = false;
    m_bListLoading = false;
    $("#loading").show();
}
/*Ajax로딩 화면 감추기*/
function loadingout2() {
    $("#loading").hide();
}
/*Ajax로딩 화면 감추기(메인 화면 검색 전용)*/
function loadingout() {
    if (m_bMainLoading && m_bListLoading) {
        $("#loading").hide();
    }
}
function searchCategorySort(year, month) {
    $("#listData").children().remove();
    var dom = $("#templateIng").html();
    $("#listData").append(dom);
    $.ajax({
        type: "GET",
        url: "/web/ajax/WebListSearch",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            count = data.count;
            for (i = 1; i <= count; i++) {
                if (month < 10) {
                    monthDisp = "0" + month;
                } else {
                    monthDisp = month;
                }
                if (data[i].date < 10) {
                    dayMonth = "0" + data[i].date;
                } else {
                    dayMonth = data[i].date;
                }
                date = year + "/" + monthDisp + "/" + dayMonth;
                tableadd(data[i].idx, date, data[i].type, data[i].contents, data[i].money, data[i].other, data[i].category);
            }
            for (i = 1; i <= 20 - count; i++) {
                newline();
            }
            m_bListLoading = true;
            loadingout();
        },
        error: function (msg) {
            //에러처리 추가
            alert();
        }
    });
}

function totalCalcul(year, month) {
    $.ajax({
        type: "GET",
        url: "/web/ajax/MonthTotal",
        data: "year=" + year + "&month=" + month,
        dataType: "json",
        success: function (data) {
            listSetting(data.income, data.expend, data.total);
            m_bMainLoading = true;
            loadingout();
        },
        error: function (msg) {
            //에러처리 추가
            alert();
        }
    });
}

function Apply() {
    loading();
    var excute = true;
    $.each($("input[type=checkbox]"), function () {
        if ($(this).is(':checked')) {
            var idx = $(this).val();
            if ($(this).attr("id").match(/^item+/gi)) {
                if (idx.match(/##idx##/gi)) {
                    $(this).prop("checked", false);
                } else if (idx == "on") {
                    $(this).prop("checked", false);
                } else if ($("#item" + idx + "_2").val() == "") {
                    excute = false;
                } else if ($("#item" + idx + "_6").val() == "") {
                    excute = false;
                } else if ($("#item" + idx + "_7").val() == "") {
                    excute = false;
                }
            }
        }
    });
    if (excute) {
        $.each($("input[type=checkbox]"), function () {
            if ($(this).is(':checked')) {
                var idx = $(this).val();
                if ($(this).attr("id").match(/^item+/gi)) {
                    if (idx.match(/^new+/gi)) {
                        insert(idx);
                    } else {
                        modify(idx);
                    }
                }
            }
        });
        year = Number($("#yearD").val());
        month = Number($("#monthD").val());
        totalCalcul(year, month);
    } else {
        //에러처리
        alert("チェック間のデータで日付、内容、金額を入力してください。");
    }
    loadingout2();
}
function Delete() {
    loading();
    $.each($("input[type=checkbox]"), function () {
        if ($(this).is(':checked')) {
            var idx = $(this).val();
            if ($(this).attr("id").match(/^item+/gi)) {
                if (idx.match(/##idx##/gi)) {
                    $(this).prop("checked", false);
                } else if (idx == "on") {
                    $(this).prop("checked", false);
                } else if (!idx.match(/^new+/gi)) {
                    del(idx);
                    newline();
                } else {
                    $("#line" + idx).remove();
                    newline();
                }
            }
        }
    });
    loadingout2();
}
function insert(idx) {
    var date = $("#item" + idx + "_2").val();
    date = date.replace(/\//gi, "-");
    var type = $("#item" + idx + "_3").val();
    var incomecategoryList = $("#item" + idx + "_4").val();
    var expendcategoryList = $("#item" + idx + "_5").val();
    var contents = $("#item" + idx + "_6").val();
    var money = unNumberFormat($("#item" + idx + "_7").val());
    var other = $("#item" + idx + "_8").val();
    $.ajax({
        type: "POST",
        url: "/web/Dateprocess/Insert",
        data:   "date=" + date +
                "&selectType=" + type +
                "&incomecategoryList=" + incomecategoryList +
                "&expendcategoryList=" + expendcategoryList +
                "&contents=" + contents +
                "&money=" + money +
                "&other=" + other,
        success: function (msg) {
            if (msg != "NG") {
                $("#item" + idx + "_1").prop("checked", false);
                var newIdx = msg;
                $("#line" + idx).attr("id", "line" + newIdx);
                for (i = 1; i < 9; i++) {
                    if (i == 1) {
                        $("#item" + idx + "_" + i).val(newIdx);
                    }
                    $("#item" + idx + "_" + i).attr("id", "item" + newIdx + "_" + i);
                    $("#item" + newIdx + "_" + i).attr("onchange", "checkin('" + newIdx + "');");
                }
                return true;
            } else {
                return false;
            }
        },
        error: function (msg) {
            return false;
        }
    });
}

function modify(idx) {
    var date = $("#item" + idx + "_2").val();
    date = date.replace(/\//gi, "-");
    var type = $("#item" + idx + "_3").val();
    var incomecategoryList = $("#item" + idx + "_4").val();
    var expendcategoryList = $("#item" + idx + "_5").val();
    var contents = $("#item" + idx + "_6").val();
    var money = unNumberFormat($("#item" + idx + "_7").val());
    var other = $("#item" + idx + "_8").val();
    $.ajax({
        type: "POST",
        url: "/web/Dateprocess/Modify",
        data:   "Index=" + idx +
                "&date=" + date +
                "&selectType=" + type +
                "&incomecategoryList=" + incomecategoryList +
                "&expendcategoryList=" + expendcategoryList +
                "&contents=" + contents +
                "&money=" + money +
                "&other=" + other,
        success: function (msg) {
            if (msg == "OK") {
                $("#item" + idx + "_1").prop("checked", false);
                return true;
            } else {
                return false;
            }
        },
        error: function (msg) {
            return false;
        }
    });
}

function del(idx) {
    $.ajax({
        type: "POST",
        url: "/web/Dateprocess/Delete",
        data: "Index=" + idx,
        success: function (msg) {
            if (msg == "OK") {
                $("#line" + idx).remove();
                return true;
            } else {
                return false;
            }
        },
        error: function (msg) {
            return false;
        }
    });
}

function dialogLoading() {
    CategorySearch();
}
function cateAddline() {
    ++cateCount;
    cateadd("new" + cateCount, 2, "");
}

function CategorySearch(){
    $.ajax({
        type: "GET",
        url: "/mobile/ajax2/CategoryList",
        dataType: "json",
        success: function (data) {
            count = data.count;
            $("#listDataCategory").children().remove();
            for (i = 1; i <= count; i++) {
                cateadd(data[i].idx, data[i].type, data[i].contents);
            }
            for (i = 1; i <= 10 - count; i++) {
                cateAddline();
            }
        },
        error: function (msg) {
            alert();
        }
    });
}
