﻿function logout() {
    location.href = "Logout";
}