﻿USE [household]
GO
/****** 개체:  Table [dbo].[가계부]    스크립트 날짜: 06/03/2014 21:23:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[가계부](
	[idx] [bigint] IDENTITY(1,1) NOT NULL,
	[일시] [datetime] NULL,
	[구분] [char](1) COLLATE Korean_Wansung_CI_AS NULL,
	[내용] [nvarchar](255) COLLATE Korean_Wansung_CI_AS NULL,
	[금액] [decimal](20, 0) NULL,
	[비고] [nvarchar](255) COLLATE Korean_Wansung_CI_AS NULL,
	[작성자] [varchar](100) COLLATE Korean_Wansung_CI_AS NULL,
	[작성일시] [datetime] NULL,
	[상태] [char](1) COLLATE Korean_Wansung_CI_AS NULL,
	[가계부구분] [int] NULL,
	[카테고리] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[idx] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

USE [household]
GO
/****** 개체:  Table [dbo].[접속로그]    스크립트 날짜: 06/03/2014 21:25:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[접속로그](
	[id] [varchar](255) COLLATE Korean_Wansung_CI_AS NULL,
	[ConntectTime] [datetime] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

USE [household]
GO
/****** 개체:  Table [dbo].[카테고리]    스크립트 날짜: 06/03/2014 21:25:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[카테고리](
	[idx] [bigint] IDENTITY(1,1) NOT NULL,
	[가계부구분] [int] NULL,
	[구분] [char](1) COLLATE Korean_Wansung_CI_AS NULL,
	[카테고리명] [nvarchar](255) COLLATE Korean_Wansung_CI_AS NULL,
	[작성자] [varchar](100) COLLATE Korean_Wansung_CI_AS NULL,
	[작성일시] [datetime] NULL,
	[상태] [char](1) COLLATE Korean_Wansung_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[idx] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

USE [household]
GO
/****** 개체:  Table [dbo].[Session]    스크립트 날짜: 06/03/2014 21:26:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Session](
	[userid] [varchar](100) COLLATE Korean_Wansung_CI_AS NOT NULL,
	[sessionKey] [varchar](100) COLLATE Korean_Wansung_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[userid] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

USE [household]
GO
/****** 개체:  Table [dbo].[userTable]    스크립트 날짜: 06/03/2014 21:26:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[userTable](
	[userid] [varchar](100) COLLATE Korean_Wansung_CI_AS NOT NULL,
	[userpw] [varchar](100) COLLATE Korean_Wansung_CI_AS NOT NULL,
	[username] [nvarchar](255) COLLATE Korean_Wansung_CI_AS NOT NULL,
	[holdhousetype] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[userid] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

USE [household]
GO
/****** 개체:  StoredProcedure [dbo].[LoginCheck]    스크립트 날짜: 06/03/2014 21:26:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[LoginCheck]
	@userid varchar(100),
	@userpw varchar(100),
	@rs varchar(10) OUTPUT,
	@username nvarchar(255) output,
	@householdtype int output
as
	declare @resultpw varchar(100);
	select @resultpw = userpw,@username = username,@householdtype=holdhousetype from userTable where userid = @userid
	if @resultpw is null
		set @rs = 'ERROR'
	else if @resultpw <> @userpw
		set @rs = 'ERROR'
	else if @resultpw = @userpw
		set @rs = 'OK'

USE [household]
GO
/****** 개체:  StoredProcedure [dbo].[SessionCheck]    스크립트 날짜: 06/03/2014 21:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[SessionCheck]
	@pId varchar(100),
	@pSession varchar(100)	
as
	delete Session where userid = @pId
	insert into Session(userid,sessionKey)values(@pId,@pSession)