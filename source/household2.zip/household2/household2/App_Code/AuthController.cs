﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace household_Mvc.Core
{
    public class AuthController : DBController
    {
        protected bool CookieCheck()
        {
            bool ret = false;
            if (Request.Cookies["UserID"] != null)
            {
                String BufferID = Request.Cookies["UserID"].Value;
                if (BufferID != null && BufferID != "")
                {
                    if (Request.Cookies["SessionKey"] != null)
                    {
                        String BufferSession = Request.Cookies["SessionKey"].Value;
                        if (BufferSession != null && BufferSession.Equals(GetSession(BufferID)))
                        {
                            String sUserName = "";
                            int nType = 0;
                            if (SetLoginInfo(BufferID, out sUserName, out nType))
                            {
                                Session["UserID"] = BufferID;
                                Session["UserName"] = sUserName;
                                Session["HouseType"] = nType;
                                FormsAuthentication.SetAuthCookie(BufferID, true);
                                MWLogWriter.Instance().MessageLog("CookieCheck - ID : ", BufferID);
                                ret = true;
                            }
                            else
                            {
                                ret = false;
                            }
                        }
                    }
                }
            }
            return ret;
        }
        protected bool AuthCheck(String id, String pw)
        {
            if (id == null || pw == null)
            {
                return false;
            }
            String sUserName = "";
            int nType = 0;
            if (LoginCheck(id, pw, out sUserName,out nType))
            {
                Session["UserID"] = id;
                Session["UserName"] = sUserName;
                Session["HouseType"] = nType;
                SetCookie(id);
                FormsAuthentication.SetAuthCookie(id, true);
                MWLogWriter.Instance().MessageLog("AuthCheck - ID : ", id);
                return true;
            }
            else
            {
                Session["UserID"] = null;
                Session["UserName"] = null;
                Session["HouseType"] = null;
                return false;
            }
        }
        protected void SetCookie(String Uid)
        {
            Response.Cookies["UserID"].Value = null;
            Response.Cookies["SessionKey"].Value = null;
            Response.Cookies["UserID"].Value = Uid;
            Response.Cookies["SessionKey"].Value = SetSession(Uid);
            Response.Cookies["UserID"].Expires = DateTime.Now.AddDays(365);
            Response.Cookies["SessionKey"].Expires = DateTime.Now.AddDays(365);
        }
        protected bool IsAuthenticated()
        {
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                String sUserName = "";
                int nType = 0;
                if (SetLoginInfo(HttpContext.User.Identity.Name, out sUserName, out nType))
                {
                    Session["UserID"] = HttpContext.User.Identity.Name;
                    Session["UserName"] = sUserName;
                    Session["HouseType"] = nType;
                    SetCookie(HttpContext.User.Identity.Name);
                    FormsAuthentication.SetAuthCookie(HttpContext.User.Identity.Name, true);
                    MWLogWriter.Instance().MessageLog("IsAuthenticated - ID : ", HttpContext.User.Identity.Name);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        protected void Logout()
        {
            Session["UserID"] = null;
            Session["UserName"] = null;
            Session["HouseType"] = null;
            Response.Cookies["UserID"].Value = "";
            Response.Cookies["SessionKey"].Value = "";
            FormsAuthentication.SignOut();
        }
        
    }
}