﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using System.Diagnostics;

namespace household_Mvc.Core
{
    /// <summary>
    /// 로그 클래스 입니다.
    /// </summary>
    public class MWLogWriter
    {
        private const String LogDirectoryPath = "C:\\LOG";
        private static MWLogWriter oLogInstance = null;

        /// <summary>
        /// 생성자
        /// </summary>
        /// 

        public MWLogWriter()
        {
            DirectoryInfo DI = new DirectoryInfo(LogDirectoryPath);
            if (!DI.Exists)
            {
                DI.Create();
            }
        }

        /// <summary>
        /// 로그 남기는 메소드
        /// </summary>
        /// <param name="sLogString">로그 메시지</param>
        /// 

        public void LogWrite(String sLogString)
        {
            Debug.WriteLine(sLogString);
            DateTime DT = DateTime.Now;
            String sFileName = String.Format("{0:0000}{1:00}{2:00}.txt", DT.Year, DT.Month, DT.Day);
            sFileName = LogDirectoryPath + "\\" + sFileName;
            FileInfo FI = new FileInfo(sFileName);
            String cTime;
            cTime = String.Format("{0:00}:{1:00}:{2:00}:{3:000}", DT.Hour, DT.Minute, DT.Second, DT.Millisecond);
            try
            {
                FileStream FS = new FileStream(FI.FullName, FileMode.Append);
                StreamWriter SW = new StreamWriter(FS);
                SW.WriteLine(cTime + "\t" + sLogString);
                SW.Close();
                FS.Close();

                SW.Dispose();
                FS.Dispose();

                SW = null;
                FS = null;
            }
            catch (Exception)
            {
                Debug.WriteLine("로그 에러!!");
            }
            FI = null;
        }
        public void FunctionStart()
        {
            string sLog = String.Format("▼▼▼▼▼{0}▼▼▼▼▼", new StackTrace(true).GetFrame(1).GetMethod().Name);
            LogWrite(sLog);
        }
        public void FunctionEnd()
        {
            string sLog = String.Format("▲▲▲▲▲{0}▲▲▲▲▲", new StackTrace(true).GetFrame(1).GetMethod().Name);
            LogWrite(sLog);
        }
        public void LineLog()
        {
            string sLog = String.Format("-------{0}-----", new StackTrace(true).GetFrame(1).GetFileLineNumber());
            LogWrite(sLog);
        }
        public void FileLog()
        {
            string sLog = String.Format("*****{0}*****", new StackTrace(true).GetFrame(1).GetFileName());
            LogWrite(sLog);
        }
        public void MessageLog(String msg, String result)
        {
            string sLog = String.Format("&&&&& MESSAGE : {0} ,DATA : {1}&&&&&", msg, result);
            LogWrite(sLog);
        }
        public void HandleLog(IntPtr data)
        {
            string sLog = String.Format("+++++ HANDLE : {0} +++++", data);
            LogWrite(sLog);
        }
        /// <summary>
        /// 인스턴스화 메소드
        /// </summary>
        /// <returns></returns>
        public static MWLogWriter Instance()
        {
            if (oLogInstance == null)
            {
                oLogInstance = new MWLogWriter();
            }
            return oLogInstance;
        }
    }
}