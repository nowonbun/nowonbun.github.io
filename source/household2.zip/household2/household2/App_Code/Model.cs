﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Text;

namespace household_Mvc.Core
{
    public class Model
    {
        private String m_DBInfo;
        private SqlConnection m_conn;
        private SqlCommand m_cmd;

        public Model()
        {
            m_DBInfo = System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString;
            m_conn = new SqlConnection(m_DBInfo);
            m_cmd = new SqlCommand();
            m_cmd.Connection = m_conn;
        }
        /// <summary>
        /// 카테고리 취득(사용하지 않음)
        /// </summary>
        /// <param name="Index"></param>
        /// <returns></returns>
        public String getCategoryName(int Index)
        {
            MWLogWriter.Instance().FunctionStart();
            StringBuilder query = new StringBuilder();
            String ret = "";
            query.Append(" SELECT ");
            query.Append(" 카테고리명 ");
            query.Append(" FROM 카테고리 ");
            query.Append(" WHERE IDX = '{0}' ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), Index);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    ret = dr.GetString(0);
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
    }
}