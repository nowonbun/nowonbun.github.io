﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Text;
using System.Web.Mvc;
using System.Diagnostics;

namespace household_Mvc.Core
{
    public class DBController : Controller
    {
        private String m_DBInfo;
        private SqlConnection m_conn;
        private SqlCommand m_cmd;

        public DBController()
        {
            Debug.WriteLine("DBContorller 생성자");
            m_DBInfo = System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString;
            m_conn = new SqlConnection(m_DBInfo);
            m_cmd = new SqlCommand();
            m_cmd.Connection = m_conn;
        }
        /// <summary>
        /// 세션체크함수
        /// </summary>
        protected String GetSession(String pID)
        {
            Debug.WriteLine("DBContorller GetSession");
            MWLogWriter.Instance().FunctionStart();
            String SessionKey = "";
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" sessionKey ");
            query.Append(" FROM Session ");
            query.Append(" WHERE userid = '{0}' ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), pID);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    SessionKey = dr.GetString(0);
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("세션 체크 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return SessionKey;
        }
        /// <summary>
        /// 로그인 정보 취득함수
        /// </summary>
        protected bool SetLoginInfo(String Uid,out String sName,out int nType)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            if (Uid == null)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("파라메터에러");
                MWLogWriter.Instance().FunctionEnd();
                sName = "";
                nType = -1;
                return false;
            }
            if (String.Empty == Uid)
            {
                MWLogWriter.Instance().FunctionEnd();
                sName = "";
                nType = -1;
                return false;
            }
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" username, ");
            query.Append(" holdhousetype ");
            query.Append(" FROM userTable ");
            query.Append(" WHERE userid = '{0}' ");
            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), Uid);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    sName = dr.GetString(0);
                    nType = dr.GetInt32(1);
                    ret = true;
                }
                else
                {
                    sName = "";
                    nType = -1;
                    ret = false;
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("로그인정보 취득중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                sName = "";
                nType = -1;
                ret = false;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 로그인
        /// </summary>
        public bool LoginCheck(String pID, String pPW, out String pName, out int pType)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            m_cmd.CommandType = System.Data.CommandType.StoredProcedure;
            m_cmd.CommandText = "LoginCheck";

            m_cmd.Parameters.Add("@userid", System.Data.SqlDbType.VarChar, 100);
            m_cmd.Parameters.Add("@userpw", System.Data.SqlDbType.VarChar, 100);
            m_cmd.Parameters["@userid"].Value = pID;
            m_cmd.Parameters["@userpw"].Value = pPW;
            SqlParameter rs = m_cmd.Parameters.Add("@rs", System.Data.SqlDbType.VarChar, 10);
            rs.Direction = System.Data.ParameterDirection.Output;
            rs = m_cmd.Parameters.Add("@username", System.Data.SqlDbType.NVarChar, 255);
            rs.Direction = System.Data.ParameterDirection.Output;
            rs = m_cmd.Parameters.Add("@householdtype", System.Data.SqlDbType.Int);
            rs.Direction = System.Data.ParameterDirection.Output;
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
                String buffer = m_cmd.Parameters["@rs"].Value.ToString();
                if ("OK".Equals(buffer))
                {
                    ret = true;
                    pName = m_cmd.Parameters["@username"].Value.ToString();
                    pType = (int)m_cmd.Parameters["@householdtype"].Value;
                }
                else
                {
                    ret = false;
                    pName = "";
                    pType = -1;
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("로그인 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                pName = "";
                pType = -1;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 로그인 할떄 세션 생성
        /// </summary>
        public String SetSession(String pID)
        {
            MWLogWriter.Instance().FunctionStart();
            String SessionKey = String.Format("{0}", DateTime.Now.ToString("yyyyMMddHHmmss"));
            m_cmd.CommandType = System.Data.CommandType.StoredProcedure;
            m_cmd.CommandText = "SessionCheck";

            m_cmd.Parameters.Add("@pId", System.Data.SqlDbType.VarChar, 100);
            m_cmd.Parameters.Add("@pSession", System.Data.SqlDbType.VarChar, 100);
            m_cmd.Parameters["@pId"].Value = pID;
            m_cmd.Parameters["@pSession"].Value = SessionKey;
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("세션 체크 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite("pID : "+ pID);
                MWLogWriter.Instance().LogWrite("SessionKey : " + SessionKey);
                MWLogWriter.Instance().LogWrite("세션 체크 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_cmd.Parameters.Clear();
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return SessionKey;
        }
        /// <summary>
        /// 전체 계산 취득
        /// </summary>
        public Dictionary<String, String> MonthTotalCalCul(int nType, int year, int month)
        {
            MWLogWriter.Instance().FunctionStart();
            Dictionary<String, String> ret = new Dictionary<String, String>();
            Decimal income = 0, expend = 0;
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" case 구분 when '1' then '입금' when '2' then '출금' end as 구분, ");
            query.Append(" sum(금액) as 금액 ");
            query.Append(" FROM 가계부 ");
            query.Append(" WHERE convert(varchar(6),일시,112) = '{0}{1}' ");
            query.Append(" AND 상태 = '0' ");
            query.Append(" AND 가계부구분 = '{2}' ");
            query.Append(" GROUP BY 구분 ");
            query.Append(" ORDER BY 구분 ASC ");
            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), year.ToString("0000"), month.ToString("00"), nType);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                while (dr.Read())
                {
                    switch (dr.GetString(0))
                    {
                        case "입금":
                            income = dr.GetDecimal(1);
                            break;
                        case "출금":
                            expend = dr.GetDecimal(1);
                            break;
                    }
                }
                ret.Add("income", income.ToString());
                ret.Add("expend", expend.ToString());
                ret.Add("total", (income - expend).ToString());
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("월별 정보 취득 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 리스트 검색
        /// </summary>
        public Dictionary<String, object> ListSearch(int nType, int nYear, int nMonth,int orderType)
        {
            MWLogWriter.Instance().FunctionStart();
            Dictionary<String, object> ret = new Dictionary<String, object>();
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" A.IDX, ");
            query.Append(" A.일시, ");
            query.Append(" A.구분, ");
            query.Append(" A.내용, ");
            query.Append(" A.금액, ");
            query.Append(" A.비고, ");
            query.Append(" A.작성자, ");
            query.Append(" A.작성일시 ");
            if (orderType == 1 || orderType == 2)
            {
                query.Append(" ,ISNULL(A.카테고리,0), ");
                query.Append(" ISNULL(B.카테고리명,'') ");
            }
            query.Append(" FROM 가계부 A");
            if (orderType == 1 || orderType == 2)
            {
                query.Append(" LEFT OUTER JOIN 카테고리 B ON A.카테고리 = B.idx ");
            }
            query.Append(" WHERE convert(varchar(6),A.일시,112) = '{0:0000}{1:00}' ");
            query.Append(" AND A.상태='0' ");
            query.Append(" AND A.가계부구분='{2}' ");
            if (orderType == 1)
            {
                query.Append(" ORDER BY ISNULL(A.카테고리,0) DESC,A.일시 DESC,A.IDX DESC");
            }
            else if (orderType == 2)
            {
                query.Append(" ORDER BY A.일시 ASC,A.IDX ASC");
            }
            else
            {
                query.Append(" ORDER BY A.일시 DESC,A.IDX DESC");
            }

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), nYear, nMonth, nType);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                int index = 1;
                while (dr.Read())
                {
                    Dictionary<String, String> sub = new Dictionary<String, String>();
                    sub.Add("idx", ((int)dr.GetInt64(0)).ToString());
                    sub.Add("date", (dr.GetDateTime(1).Day).ToString());
                    sub.Add("type", (dr.GetValue(2)).ToString());
                    sub.Add("contents", (dr.GetString(3)).ToString());
                    sub.Add("money", (dr.GetDecimal(4).ToString("###,###,##0")).ToString());
                    sub.Add("other", (dr.GetString(5)).ToString());
                    if (orderType == 1 || orderType == 2)
                    {
                        sub.Add("category", (dr.GetInt64(8)).ToString());
                        sub.Add("categoryName", (dr.GetString(9)).ToString());
                    }
                    ret.Add(index.ToString(), sub);
                    index++;
                }
                ret.Add("count", (index - 1).ToString());
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("리스트 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret.Clear();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 데이터 입력함수
        /// </summary>
        public bool DataInsert(Dictionary<String, object> pNode, String Uid, int nType)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            StringBuilder query = new StringBuilder();
            query.Append(" INSERT INTO 가계부(일시,구분,내용,금액,비고,작성자,작성일시,상태,가계부구분,카테고리) ");
            query.Append(" values('{0}','{1}',N'{2}','{3}',N'{4}','{5}',getdate(),'0','{6}','{7}'); ");

            try
            {
                m_cmd.CommandType = System.Data.CommandType.Text;
                m_cmd.CommandText = String.Format(query.ToString(), pNode["Date"], pNode["Type"], pNode["Contents"], pNode["Money"], pNode["Ohter"], Uid, nType, pNode["CategoryIdx"]);
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("데이터 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ret;
            }
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
                ret = true;
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("데이터 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = false;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 가장 마지막 등록된 IDX번호
        /// (웹에서 등록후에 IDX로 테이블라인INDEX를 부여하기 위해 작성된 함수)
        /// </summary>
        public Int64 lastIDX()
        {
            MWLogWriter.Instance().FunctionStart();
            Int64 ret = 0;
            StringBuilder query = new StringBuilder();
            query.Append(" select isnull(max(idx),0) from 가계부 ");
            try
            {
                m_cmd.CommandType = System.Data.CommandType.Text;
                m_cmd.CommandText = String.Format(query.ToString());
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("인덱스 취득 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ret;
            }
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    ret = dr.GetInt64(0);
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("인덱스 취득 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 데이터 검색
        /// </summary>
        public Dictionary<String,object> DataSelect(int Index)
        {
            MWLogWriter.Instance().FunctionStart();
            Dictionary<String, object> ret = null;
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" IDX, ");
            query.Append(" 일시, ");
            query.Append(" 구분, ");
            query.Append(" 내용, ");
            query.Append(" 금액, ");
            query.Append(" 비고, ");
            query.Append(" 작성자, ");
            query.Append(" 작성일시, ");
            query.Append(" ISNULL(카테고리,0) ");
            query.Append(" FROM 가계부 ");
            query.Append(" WHERE IDX = '{0}' ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), Index);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    ret = new Dictionary<String, object>();
                    ret.Add("Index", dr.GetInt64(0));
                    ret.Add("Date", dr.GetDateTime(1));
                    ret.Add("Type", dr.GetValue(2).ToString());
                    ret.Add("Contents", dr.GetString(3));
                    ret.Add("Money", dr.GetDecimal(4));
                    ret.Add("Ohter", dr.GetString(5));
                    ret.Add("Category", dr.GetInt64(8));
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("데이터 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = null;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 데이터 삭제 함수
        /// </summary>
        public bool DataDelete(Int64 nIndex)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            StringBuilder query = new StringBuilder();
            query.Append(" update 가계부 set 상태 = '1' where idx='{0}'; ");
            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), nIndex);
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
                ret = true;
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("데이터 삭제 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = false;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 데이터 수정
        /// </summary>
        public bool DataModify(Dictionary<String, object> pNode, String Uid, int nType, Int64 nIndex)
        {
            MWLogWriter.Instance().FunctionStart();
            if (!DataDelete(nIndex))
            {
                return false;
            }
            if (!DataInsert(pNode, Uid, nType))
            {
                return false;
            }
            MWLogWriter.Instance().FunctionEnd();
            return true;
        }
        /// <summary>
        /// 카테고리 추가 함수
        /// </summary>
        public bool CategoryInsert(Dictionary<String, object> pNode, String Uid, int nType)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            StringBuilder query = new StringBuilder();
            query.Append(" INSERT INTO 카테고리(가계부구분,구분,카테고리명,작성자,작성일시,상태) ");
            query.Append(" values('{0}','{1}',N'{2}','{3}',getdate(),'0'); ");

            try
            {
                m_cmd.CommandType = System.Data.CommandType.Text;
                m_cmd.CommandText = String.Format(query.ToString(), nType, pNode["Type"], pNode["CategoryName"], Uid);
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ret;
            }
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
                ret = true;
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = false;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        public Dictionary<String, object> CategorySearch(int nType)
        {
            MWLogWriter.Instance().FunctionStart();
            Dictionary<String, object> ret = new Dictionary<String, object>();
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" IDX, ");
            query.Append(" 구분, ");
            query.Append(" 카테고리명 ");
            query.Append(" FROM 카테고리 ");
            query.Append(" WHERE 가계부구분='{0}' ");
            query.Append(" AND 상태='0' ");
            query.Append(" ORDER BY IDX DESC ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), nType);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                int index = 1;
                while (dr.Read())
                {
                    Dictionary<String, String> sub = new Dictionary<String, String>();
                    sub.Add("idx", ((int)dr.GetInt64(0)).ToString());
                    sub.Add("type", (dr.GetValue(1)).ToString());
                    sub.Add("Disp_type", "2".Equals((dr.GetValue(1)).ToString())?"支出":"収入");
                    sub.Add("contents", (dr.GetString(2)).ToString());
                    ret.Add(index.ToString(), sub);
                    index++;
                }
                ret.Add("count", (index - 1).ToString());
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 리스트 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret.Clear();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 카테고리 리스트 검색
        /// </summary>
        public List<Dictionary<String, String>> CategoryListSearch(int nType)
        {
            MWLogWriter.Instance().FunctionStart();
            List<Dictionary<String, String>> ret = new List<Dictionary<String, String>>();
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" IDX, ");
            query.Append(" 구분, ");
            query.Append(" 카테고리명 ");
            query.Append(" FROM 카테고리 ");
            query.Append(" WHERE 가계부구분='{0}' ");
            query.Append(" AND 상태='0' ");
            query.Append(" ORDER BY IDX DESC ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), nType);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                int index = 1;
                while (dr.Read())
                {
                    Dictionary<String, String> sub = new Dictionary<String, String>();
                    sub.Add("idx", ((int)dr.GetInt64(0)).ToString());
                    sub.Add("type", (dr.GetValue(1)).ToString());
                    sub.Add("Disp_type", "2".Equals((dr.GetValue(1)).ToString()) ? "支出" : "収入");
                    sub.Add("contents", (dr.GetString(2)).ToString());
                    ret.Add(sub);
                    index++;
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 리스트 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret.Clear();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 카테고리 폼 검색 함수
        /// </summary>
        public Dictionary<String, object> CategorySelect(int Index)
        {
            MWLogWriter.Instance().FunctionStart();
            Dictionary<String, object> ret = null;
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT ");
            query.Append(" IDX, ");
            query.Append(" 구분, ");
            query.Append(" 카테고리명 ");
            query.Append(" FROM 카테고리 ");
            query.Append(" WHERE IDX = '{0}' ");

            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), Index);
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    ret = new Dictionary<String, object>();
                    ret.Add("Index", dr.GetInt64(0));
                    ret.Add("Type", dr.GetValue(1).ToString());
                    ret.Add("categoryName", dr.GetString(2));
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("카테고리 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = null;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 카테고리 삭제 함수
        /// </summary>
        public bool CategoryDelete(Int64 nIndex)
        {
            MWLogWriter.Instance().FunctionStart();
            bool ret = false;
            StringBuilder query = new StringBuilder();
            query.Append(" update 카테고리 set 상태 = '1' where idx='{0}'; ");
            m_cmd.CommandType = System.Data.CommandType.Text;
            m_cmd.CommandText = String.Format(query.ToString(), nIndex);
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
                ret = true;
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("데이터 삭제 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                ret = false;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
        /// <summary>
        /// 카테고리 수정함수
        /// </summary>
        public bool CategoryModify(Dictionary<String, object> pNode, String Uid, int nType, Int64 nIndex)
        {
            MWLogWriter.Instance().FunctionStart();
            if (!CategoryDelete(nIndex))
            {
                return false;
            }
            if (!CategoryInsert(pNode, Uid, nType))
            {
                return false;
            }
            MWLogWriter.Instance().FunctionEnd();
            return true;
        }
        /// <summary>
        /// 접속 로그 입력함수
        /// </summary>
        protected void WriteLog(String Uid)
        {
            MWLogWriter.Instance().FunctionStart();
            StringBuilder query = new StringBuilder();
            query.Append(" INSERT INTO 접속로그(id,ConntectTime) ");
            query.Append(" values('{0}',getdate()); ");

            try
            {
                m_cmd.CommandType = System.Data.CommandType.Text;
                m_cmd.CommandText = String.Format(query.ToString(), Uid);
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("접속로그 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ;
            }
            try
            {
                m_conn.Open();
                m_cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("접속로그 입력 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
        }
        /// <summary>
        /// 접속로그 취득함수
        /// </summary>
        protected DateTime GetLog(String Uid)
        {
            MWLogWriter.Instance().FunctionStart();
            DateTime ret = new DateTime(0);
            StringBuilder query = new StringBuilder();
            query.Append(" SELECT TOP 2 ConntectTime ");
            query.Append(" FROM 접속로그 ");
            query.Append(" WHERE ID = '{0}' ");
            query.Append(" ORDER BY ConntectTime DESC; ");

            try
            {
                m_cmd.CommandType = System.Data.CommandType.Text;
                m_cmd.CommandText = String.Format(query.ToString(), Uid);
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("접속로그 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ret;
            }
            try
            {
                m_conn.Open();
                SqlDataReader dr = m_cmd.ExecuteReader();
                if (dr.Read())
                {
                    if (dr.Read())
                    {
                        ret = dr.GetDateTime(0);
                    }
                }
            }
            catch (Exception e)
            {
                MWLogWriter.Instance().LineLog();
                MWLogWriter.Instance().LogWrite("접속로그 검색 중 에러가 발생했습니다.");
                MWLogWriter.Instance().LogWrite(e.ToString());
                return ret;
            }
            finally
            {
                m_conn.Close();
            }
            MWLogWriter.Instance().FunctionEnd();
            return ret;
        }
    }
}