﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using household_Mvc.Core;

namespace household_Mvc.Models
{
    public class CategoryModel : Model
    {
        public CategoryModel()
        {
            selectType = "2";
        }

        public Int64 Index { get; set; }
        public String selectType { get; set; }
        public String categoryName { get; set; }

        public Dictionary<String, object> DBList
        {
            get
            {
                Dictionary<String, object> pData = new Dictionary<string, object>();
                pData.Add("Type", selectType);
                pData.Add("CategoryName", categoryName);
                return pData;
            }
            set
            {
                Index = (Int64)value["Index"];
                selectType = (String)value["Type"];
                categoryName = (String)value["categoryName"];
            }
        }
    }
}