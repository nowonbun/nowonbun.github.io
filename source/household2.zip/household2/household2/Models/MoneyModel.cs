﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using household_Mvc.Core;

namespace household_Mvc.Models
{
    /// <summary>
    /// 가계부 데이터 구조체
    /// </summary>
    public class MoneyModel : Model
    {
        public MoneyModel()
        {
            date = DateTime.Now;
            year = date.Year;
            month = date.Month;
            day = date.Day;
            selectType = "2";
        }
        public Int64 Index { get; set; }
        public DateTime date { get; set; }
        public int year { get; set; }
        public int month { get; set; }
        public int day { get; set; }
        public String selectType { get; set; }
        public String contents { get; set; }
        public Decimal money { get; set; }
        public String other { get; set; }
        public int categoryIdx { get; set; }
        public int incomecategoryList { get; set; }
        public int expendcategoryList { get; set; }

        public Dictionary<String, object> DBList
        {
            set
            {
                Index = (Int64)value["Index"];
                date = (DateTime)value["Date"];
                year = date.Year;
                month = date.Month;
                day = date.Day;
                selectType = (String)value["Type"];
                contents = (String)value["Contents"];
                money = (Decimal)value["Money"];
                other = (String)value["Ohter"];
                categoryIdx = Convert.ToInt32((Int64)value["Category"]);
            }
            get
            {
                Dictionary<String, object> pData = new Dictionary<string, object>();
                date = new DateTime(year, month, day);
                pData.Add("Date", date.ToString("yyyyMMdd"));
                pData.Add("Type", selectType);
                pData.Add("Contents", contents);
                pData.Add("Money", money.ToString());
                pData.Add("Ohter", other);
                if ("1".Equals(selectType))
                {
                    categoryIdx = incomecategoryList;
                }
                else
                {
                    categoryIdx = expendcategoryList;
                }
                pData.Add("CategoryIdx", categoryIdx);
                return pData;
            }
        }
    }
}