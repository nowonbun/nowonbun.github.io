﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using household_Mvc.Core;

namespace household_Mvc.Models
{
    /// <summary>
    /// 로그인 구조체
    /// </summary>
    public class LoginModel : Model
    {
        private String m_userID;
        private String m_userName;
        private int m_householdType = -1;
        private bool m_authCheck;
        public String txt_id 
        { 
            get { return m_userID; }
            set { m_userID = value; }
        }
        public String txt_pass { get; set; }
        public String Post { get; set; }

        public String UserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        public String UserName
        {
            get { return m_userName; }
            set { m_userName = value; }
        }
        public int HouseholdType
        {
            get { return m_householdType; }
            set { m_householdType = value; }
        }
    }
}