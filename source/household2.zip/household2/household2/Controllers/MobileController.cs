﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using household_Mvc.Models;
using household_Mvc.Core;

namespace household_Mvc.Controllers
{
    public class MobileController : AuthController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual ActionResult Index()
        {
            MWLogWriter.Instance().FileLog();
            if (CookieCheck())
            {
                String Uid = (String)Session["UserID"];
                WriteLog(Uid);
                return Redirect("Main");
            }
            return View("Index", "Master",new LoginModel());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_Login"></param>
        /// <returns></returns>
        public virtual ActionResult Login(LoginModel _Login)
        {
            MWLogWriter.Instance().FileLog();
            if (AuthCheck(Request.Form["txt_id"], Request.Form["txt_pass"]))
            {
                String Uid = (String)Session["UserID"];
                WriteLog(Uid);
                return Redirect("Main");
            }
            else
            {
                ViewBag.ErrMsg = "IDまたはパスワードを確認してください。";
            }
            return View("Index", "Master", _Login);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual ActionResult Main()
        {
            if (IsAuthenticated())
            {
                return View("Main", "Master");
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual ActionResult Logout()
        {
            MWLogWriter.Instance().FileLog();
            base.Logout();
            return Redirect("Index");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public virtual ActionResult Ajax(String id,int year,int month)
        {
            MWLogWriter.Instance().FileLog();
            if (IsAuthenticated())
            {
                int nType = (int)Session["HouseType"];
                if ("MonthTotal".Equals(id))
                {
                    return Json(MonthTotalCalCul(nType, year, month), JsonRequestBehavior.AllowGet);
                }
                else if("ListSearch".Equals(id))
                {
                    return Json(ListSearch(nType, year, month,0), JsonRequestBehavior.AllowGet);
                }
                else if ("ListSearchCategory".Equals(id))
                {
                    return Json(ListSearch(nType, year, month, 1), JsonRequestBehavior.AllowGet);
                }
            }
            //에러처리가 되지 않는다
            return new EmptyResult();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public ActionResult Ajax2(String id)
        {
            MWLogWriter.Instance().FileLog();
            if (IsAuthenticated())
            {
                int nType = (int)Session["HouseType"];
                if ("CategoryList".Equals(id))
                {
                    return Json(CategorySearch(nType), JsonRequestBehavior.AllowGet);
                }
            }
            //에러처리가 되지 않는다
            return new EmptyResult();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult InsertForm()
        {
            if (IsAuthenticated())
            {
                ViewBag.Type = "ADD";
                return View("Form", "Master", new MoneyModel());
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult AddData(MoneyModel _node)
        {
            if (IsAuthenticated())
            {
                if (_node.contents == null || _node.contents == "")
                {
                    ViewBag.Type = "ADD";
                    ViewBag.ErrMsg = "内容を入力してください。";
                    return View("Form", "Master", _node);
                }
                if (_node.money == 0)
                {
                    ViewBag.Type = "ADD";
                    ViewBag.ErrMsg = "金額を入力してください。";
                    return View("Form", "Master", _node);
                }
                String sUserID = (String)Session["UserID"];
                int nType = (int)Session["HouseType"];
                if (!DataInsert(_node.DBList, sUserID, nType))
                {
                    ViewBag.Type = "ADD";
                    ViewBag.ErrMsg = "入力中で障害が発生しました。";
                    return View("Form", "Master", _node);
                }
                else
                {
                    return Redirect("Main");
                }
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public ActionResult ModifyForm(int idx)
        {
            if (IsAuthenticated())
            {
                ViewBag.Type = "MODIFY";
                Dictionary<String, object> pData = DataSelect(idx);
                MoneyModel pNode = new MoneyModel();
                pNode.DBList = pData;
                return View("Form", "Master", pNode);
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult ModifyData(MoneyModel _node)
        {
            if (IsAuthenticated())
            {
                if (_node.contents == null || _node.contents == "")
                {
                    ViewBag.Type = "MODIFY";
                    ViewBag.ErrMsg = "内容を入力してください。";
                    return View("Form", "Master", _node);
                }
                if (_node.money == 0)
                {
                    ViewBag.Type = "MODIFY";
                    ViewBag.ErrMsg = "金額を入力してください。";
                    return View("Form", "Master", _node);
                }
                String sUserID = (String)Session["UserID"];
                int nType = (int)Session["HouseType"];
                if (!DataModify(_node.DBList, sUserID, nType, _node.Index))
                {
                    ViewBag.Type = "MODIFY";
                    ViewBag.ErrMsg = "修正中で障害が発生しました。";
                    return View("Form", "Master", _node);
                }
                else
                {
                    return Redirect("Main");
                }
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult DeleteData(MoneyModel _node)
        {
            if (IsAuthenticated())
            {
                if (!DataDelete(_node.Index))
                {
                    ViewBag.Type = "DELETE";
                    ViewBag.ErrMsg = "削除中で障害が発生しました。";
                    return View("Form", "Master", _node);
                }
                else
                {
                    return Redirect("Main");
                }
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult CategoryList()
        {
            if (IsAuthenticated())
            {
                return View("CategoryList", "Master");
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult CategoryForm()
        {
            if (IsAuthenticated())
            {
                ViewBag.Type = "ADD";
                return View("CategoryForm", "Master", new CategoryModel());
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult ApplyCategory(CategoryModel _node)
        {
            if (IsAuthenticated())
            {
                String sUserID = (String)Session["UserID"];
                int nType = (int)Session["HouseType"];
                if (!CategoryInsert(_node.DBList, sUserID, nType))
                {
                    ViewBag.Type = "ADD";
                    return View("CategoryForm", "Master", new CategoryModel());
                }
                else
                {
                    return Redirect("CategoryList");
                }
            }
            return Redirect("Index");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public ActionResult ModifyCategoryForm(int idx)
        {
            if (IsAuthenticated())
            {
                ViewBag.Type = "MODIFY";
                Dictionary<String, object> pData = CategorySelect(idx);
                CategoryModel pNode = new CategoryModel();
                pNode.DBList = pData;
                return View("CategoryForm", "Master", pNode);
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult DeleteCategory(CategoryModel _node)
        {
            if (IsAuthenticated())
            {
                if (!CategoryDelete(_node.Index))
                {
                    ViewBag.Type = "DELETE";
                    ViewBag.ErrMsg = "削除中で障害が発生しました。";
                    return View("CategoryForm", "Master", _node);
                }
                else
                {
                    return Redirect("CategoryList");
                }
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_node"></param>
        /// <returns></returns>
        public ActionResult ModifyCategory(CategoryModel _node)
        {
            if (IsAuthenticated())
            {
                String sUserID = (String)Session["UserID"];
                int nType = (int)Session["HouseType"];
                if (!CategoryModify(_node.DBList, sUserID, nType, _node.Index))
                {
                    ViewBag.Type = "MODIFY";
                    ViewBag.ErrMsg = "修正中で障害が発生しました。";
                    return View("CategoryForm", "Master", _node);
                }
                else
                {
                    return Redirect("CategoryList");
                }
            }
            else
            {
                return Redirect("Index");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewName"></param>
        /// <param name="masterName"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override ViewResult View(string viewName, string masterName, object model)
        {
            if ("Form".Equals(viewName))
            {
                int nType = (int)Session["HouseType"];
                List<Dictionary<String, String>> pData = CategoryListSearch(nType);
                List<Dictionary<String, String>> incomeCategory = new List<Dictionary<string, string>>();
                List<Dictionary<String, String>> ExpendCategory = new List<Dictionary<string, string>>();

                foreach (Dictionary<String, String> pBufferData in pData)
                {
                    if ("1".Equals(pBufferData["type"]))
                    {
                        incomeCategory.Add(pBufferData);
                    }
                    else
                    {
                        ExpendCategory.Add(pBufferData);
                    }
                }
                ViewBag.IncomecategoryList = incomeCategory;
                ViewBag.ExpendcategoryList = ExpendCategory;
            }
            return base.View(viewName, masterName, model);
        }
    }
}
