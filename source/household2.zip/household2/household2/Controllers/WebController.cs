﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using household_Mvc.Core;
using household_Mvc.Models;

namespace household_Mvc.Controllers
{
    public class WebController : MobileController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override ActionResult Index()
        {
            MWLogWriter.Instance().FileLog();
            if (IsAuthenticated())
            {
                String Uid = (String)Session["UserID"];
                WriteLog(Uid);
                return Redirect("Main");
            }
            return View("Index", "Master", new LoginModel());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_Login"></param>
        /// <returns></returns>
        public override ActionResult Login(LoginModel _Login)
        {
            return base.Login(_Login);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override ActionResult Main()
        {
            ActionResult pRet = base.Main();
            if(typeof(ViewResult) == pRet.GetType())
            {
                String Uid = (String)Session["UserID"];
                ViewResult pRetBuffer = (ViewResult)pRet;
                DateTime pDateLog = GetLog(Uid);
                ViewBag.DateLog = pDateLog;

                int nType = (int)Session["HouseType"];
                List<Dictionary<String, String>> pData = CategoryListSearch(nType);
                List<Dictionary<String, String>> incomeCategory = new List<Dictionary<string, string>>();
                List<Dictionary<String, String>> ExpendCategory = new List<Dictionary<string, string>>();

                foreach (Dictionary<String, String> pBufferData in pData)
                {
                    if ("1".Equals(pBufferData["type"]))
                    {
                        incomeCategory.Add(pBufferData);
                    }
                    else
                    {
                        ExpendCategory.Add(pBufferData);
                    }
                }
                ViewBag.IncomecategoryList = incomeCategory;
                ViewBag.ExpendcategoryList = ExpendCategory;

            }
            return pRet;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override ActionResult Logout()
        {
            return base.Logout();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public override ActionResult Ajax(string id, int year, int month)
        {
            ActionResult ret = base.Ajax(id, year, month);
            if (typeof(EmptyResult) == ret.GetType())
            {
                MWLogWriter.Instance().FileLog();
                if (IsAuthenticated())
                {
                    int nType = (int)Session["HouseType"];
                    if ("WebListSearch".Equals(id))
                    {
                        return Json(ListSearch(nType, year, month, 2), JsonRequestBehavior.AllowGet);
                    }
                }
            }
            return ret;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public ActionResult Dateprocess(string id, MoneyModel data)
        {
            String sUserID = (String)Session["UserID"];
            int nType = (int)Session["HouseType"];
            data.year = data.date.Year;
            data.month = data.date.Month;
            data.day = data.date.Day;
            if ("Insert".Equals(id))
            {
                if (!DataInsert(data.DBList, sUserID, nType))
                {
                    return Json("NG");
                }
                return Json(lastIDX());
            }
            else if ("Modify".Equals(id))
            {
                if (!DataModify(data.DBList, sUserID, nType, data.Index))
                {
                    return Json("NG");
                }
                else
                {
                    return Json("OK");
                }
            }
            else if ("Delete".Equals(id))
            {
                if (!DataDelete(data.Index))
                {
                    return Json("NG");
                }
                else
                {
                    return Json("OK");
                }
            }
            return new EmptyResult();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewName"></param>
        /// <param name="masterName"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        protected override ViewResult View(string viewName, string masterName, object model)
        {
            return base.View(viewName, masterName, model);
        }
    }
}
