if (typeof YAHOO === "undefined") {
    var YAHOO = {};
}
YAHOO.i13n = YAHOO.i13n || {};
YAHOO.i13n = (function() {
    "use stick";

    var inline = {};
    var util = {
        MAX_VALUE_LENGTH: 300,
        LINK_TAG_LIST: ["a", "button", "input"],
        logWarn: function(msg) {
            if (typeof console.warn === "undefined") {
                console.warn = console.log;
            }
            console.warn(msg);
        },
        logErr: function(msg) {
            if (typeof console.error === "undefined") {
                console.error = console.log;
            }
            console.error(msg);
        },
        isDebug: function() {
            return (typeof util !== "undefined" && typeof util.debug !== "undefined" && util.debug);
        },
        logDebug: function(msg) {
            if (this.isDebug()) {
                console.log("Rapid : [" + (new Date().getTime()) + "]" + msg);
            }
        },
        logTrace: function(clz, obj) {
            if (this.isDebug()) {
                console.log("Rapid : [TRACELOG][" + (new Date().getTime()) + "]" + clz);
                console.log(obj);
            }
        },
        isPlainObject: function(obj) {
            var proto, Ctor;

            if (!obj || toString.call(obj) !== "[object Object]") {
                return false;
            }
            proto = Object.getPrototypeOf(obj);
            if (!proto) {
                return true;
            }
            Ctor = this.hasOwn.call(proto, "constructor") && proto.constructor;
            return typeof Ctor === "function";
        },
        isFunction: function(obj) {
            return util.type(obj) === "[object Function]";
        },
        isDate: function(obj) {
            return util.type(obj) === "[object Date]";
        },
        isArr: function(obj) {
            return util.type(obj) === "[object Array]";
        },
        isStr: function(obj) {
            return util.type(obj) === "string";
        },
        isNum: function(obj) {
            return util.type(obj) === "number" && isFinite(obj);
        },
        isNumeric: function(input) {
            return (input - 0) === input && (input + "").replace(/^\s+|\s+$/g, "").length > 0;
        },
        isObj: function(o) {
            return (o && (typeof o === "object"));
        },
        isIE: (function() {
            return navigator.userAgent.match(/MSIE\s[^;]*/) || navigator.userAgent.match(/Trident\/[^;]*/) ? 1 : 0;
        }()),
        ieV: (function() {
            if (this.isIE) {
                if (document.documentMode) {
                    return document.documentMode;
                }
                if (document.compatMode) {
                    if (document.compatMode === "CSS1Compat") {
                        return 7;
                    }
                }
                return 5;
            }
            return null;
        }()),
        isEdge: (function() {
            return navigator.userAgent.indexOf(" Edge/") > -1;
        }()),
        type: function(obj) {
            if (obj === null) {
                return obj + "";
            }
            return typeof obj === "object" || typeof obj === "function" ? Object.prototype.toString.call(obj) || "object" : typeof obj;
        },
        extend: function() {
            var options, name, src, copy, copyIsArray, clone,
                target = arguments[ 0 ] || {},
                i = 1,
                length = arguments.length,
                deep = false;

            if (typeof target === "boolean") {
                deep = target;
                target = arguments[ i ] || {};
                i++;
            }
            if (typeof target !== "object" && !util.isFunction(target)) {
                target = {};
            }
            if (i === length) {
                target = this;
                i--;
            }
            for (; i < length; i++) {
                if ((options = arguments[ i ]) !== null) {
                    for (name in options) {
                        if (!options.hasOwnProperty(name)) {
                            continue;
                        }
                        src = target[ name ];
                        copy = options[ name ];
                        if (target === copy) {
                            continue;
                        }
                        if (deep && copy && (util.isPlainObject(copy) || (copyIsArray = Array.isArray(copy)))) {
                            if (copyIsArray) {
                                copyIsArray = false;
                                clone = src && Array.isArray(src) ? src : [];
                            } else {
                                clone = src && util.isPlainObject(src) ? src : {};
                            }
                            target[ name ] = util.extend(deep, clone, copy);
                        } else if (typeof copy !== "undefined") {
                            target[ name ] = copy;
                        }
                    }
                }
            }
        },
        trim: function(text) {
            text = text === null ? "" : (text + "").replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
            return text.replace(/[\u007f-\u00a0]|\s{2,}/g, " ").replace(/\ufeff|\uffef|[\u0000-\u001f]|[\ue000-\uf8ff]/g, "");
        },
        getValueWithBounds: function(value, lower, upper) {
            if (value < lower) {
                return lower;
            }
            if (value > upper) {
                return upper;
            }
            return value;
        },
        getScrollbarWidthHeight: function() {
            var div = util.make("div");

            div.style.overflow = "scroll";
            div.style.visibility = "hidden";
            div.style.position = "absolute";
            div.style.width = "100px";
            div.style.height = "100px";
            document.body.appendChild(div);
            var ret = {
                width: div.offsetWidth - div.clientWidth,
                height: div.offsetHeight - div.clientHeight
            };

            util.rmBodyEl(div);
            return ret;
        },
        make: function(name, attrs) {
            var el = document.createElement(name);

            if (attrs && util.isObj(attrs)) {
                for (var k in attrs) {
                    if (!attrs.hasOwnProperty(k)) {
                        continue;
                    }
                    el.setAttribute(k, attrs[k]);
                }
            }
            return el;
        },
        rmBodyEl: function(element) {
            document.body.removeChild(element);
        },
        hasOwn: function(obj, key) {
            return Object.prototype.hasOwnProperty.call(obj, key);
        },
        getAttribute: function(el, attr) {
            var ret = "";

            if (!document.documentElement.hasAttribute && (attr === "class")) {
                attr = "className";
            }
            if (el && el.getAttribute) {
                ret = el.getAttribute(attr, 2);
            }
            return ret;
        },
        clref: function(r) {
            if (r.indexOf("http://") !== 0 && r.indexOf("https://") !== 0) {
                return "";
            }
            var ret = this.strip(r);

            return ret.clean || ret.url;
        },
        toJSON: function(o) {
            return JSON.stringify(o);
        },
        hasCC: function(s) {
            for (var i = 0; i < s.length; i++) {
                var c = s.charCodeAt(i);

                if (c < 0x20 || c === "=") {
                    return true;
                }
            }
            return false;
        },
        isValidPair: function(k, v) {
            if (this.in_value_whitelist(k)) {
                return true;
            }
            if (k.length > 8 || v.length > this.MAX_VALUE_LENGTH) {
                util.logWarn("Invalid key/value pair (" + k + "=" + v + ") Size must be < 8/300 respectively.");
                return false;
            }
            return true;
        },
        ser: function(o, rs) {
            if (!o) {
                return "";
            }
            if (typeof rs === "undefined") {
                rs = true;
            }
            var ret = [],
                encoded = "";

            for (var i in o) {
                if (util.hasOwn(o, i)) {
                    var k = i,
                        v = o[i];

                    if (k === null || v === null) {
                        continue;
                    }
                    k = k + "";
                    v = v + "";
                    if (v && !this.in_value_whitelist(k) && v.length > this.MAX_VALUE_LENGTH) {
                        v = v.substring(0, this.MAX_VALUE_LENGTH);
                    }
                    if (!this.isValidPair(k, v)) {
                        continue;
                    }
                    if (!this.hasCC(k) && !this.hasCC(v)) {
                        encoded = "";
                        v = this.trim(v);
                        if ((v === "" || v === " ") && rs) {
                            v = "_";
                        }
                        try {
                            encoded = encodeURIComponent(k + "\x03" + v);
                            encoded = encoded.replace(/'/g, "%27");
                        } catch (e) {
                            encoded = "_ERR_ENCODE_";
                            util.logErr(e);
                        }
                        ret.push(encoded);
                    }
                }
            }
            return ret.join("%04");
        },
        in_value_whitelist: function(k) {
            if (util.isIE && util.ieV <= 8) {
                return false;
            }
            var list = ["A_res", "A_cmi", "A_cma", "A_utm"];

            return list.indexOf(k) !== -1;
        },
        rmProto: function(u) {
            if (!u) {
                return "";
            }
            if (u.substr(0, 7) === "http://") {
                return u.substr(7, u.length);
            }
            if (u.substr(0, 8) === "https://") {
                return u.substr(8, u.length);
            }
            return u;
        },
        rand: function() {
            var index = 0,
                s = "",
                c = "";

            while (index++ < 16) {
                var n = Math.floor(Math.random() * 62);

                if (n < 10) {
                    c = n;
                } else {
                    c = String.fromCharCode(n < 36 ? n + 55 : n + 61);
                }
                s += c;
            }
            var tm = util.tms();

            return s + tm.toString(36);
        },
        tms: function() {
            return +new Date();
        },
        aug: function(r, s, f) {
            if (!s) {
                return;
            }
            for (var i in s) {
                if (this.hasOwn(s, i)) {
                    if (f && !f.call(null, i, s[i])) {
                        continue;
                    }
                    r[i] = s[i];
                }
            }
        },
        strip: function(u) {
            var delims = {
                "/": "P",
                ";": "1",
                "?": "P",
                "&": "1",
                "#": "P"
            };
            var data = {
                url: u,
                clean: "",
                keys: []
            };
            var idx = 0;

            while (u.indexOf("_yl", idx) !== -1) {
                var start = u.indexOf("_yl", idx);

                if (idx < start) {
                    data.clean += u.slice(idx, start - 1);
                }
                idx = start + 3;
                if (delims[u.charAt(start - 1)] && u.charAt(start + 4) === "=") {
                    data.ult = 1;
                    var key = "_yl" + u.charAt(start + 3);
                    var value = "";

                    for (start = start + 5; start < u.length && !delims[u.charAt(start)]; start++) {
                        value += u.charAt(start);
                    }
                    data.keys.push(key);
                    data[key] = value;
                    if (delims[u.charAt(start)] && delims[u.charAt(start)] === "P") {
                        data.clean += u.charAt(start);
                    }
                    idx = start + 1;
                } else {
                    data.clean += u.slice(start - 1, idx);
                }
            }
            if (data.ult) {
                data.clean += u.substr(idx);
            }
            return data;
        },
        getXHR: function() {
            return new XMLHttpRequest();
        },
        hasCORS: function() {
            if (util.isIE && (util.ieV < 10)) {
                return false;
            }
            if ("withCredentials" in (new XMLHttpRequest())) {
                return true;
            } else if (typeof XDomainRequest !== "undefined") {
                return true;
            }
            return false;
        },
        COMPRESS_TYPE: {
            none: 0,
            gzip: 1,
            lzw: 2,
            deflate: 3
        },
        hasWorkers: function() {
            return !!window.Worker;
        },
        getProtocol: function() {
            if (typeof util !== "undefined" && util.yhlhttp) {
                return "http://";
            }
            return "https://";
        },
        on: function(obj, evt, fn) {
            if (obj.addEventListener) {
                obj.addEventListener(evt, fn, false);
            } else if (obj.attachEvent) {
                obj.attachEvent("on" + evt, fn);
            }
        },
        off: function(obj, evt, fn) {
            if (obj.removeEventListener) {
                obj.removeEventListener(evt, fn, false);
            } else if (obj.detachEvent) {
                obj.detachEvent("on" + evt, fn);
            }
        },
        async: function(obj, time) {
            if (typeof time === "undefined" || time === null) {
                time = 0;
            }
            return setTimeout(obj, time);
        },
        hasClass: function(el, className) {

            /**
             * _hasClass
             * @param {Object} ele .
             * @param {Object} cls .
             * @returns {void}
             */
            function ihasClass(ele, cls) {
                var ret = false,
                    current;

                if (ele && className) {
                    current = util.getAttribute(ele, "class") || "";
                    if (className.exec) {
                        ret = cls.test(current);
                    } else {
                        ret = cls && (" " + current + " ").indexOf(" " + cls + " ") > -1;
                    }
                }
                return ret;
            }
            if (this.isArr(className)) {
                for (var i = 0; i < className.length; i++) {
                    if (ihasClass(el, className[i])) {
                        return true;
                    }
                }
                return false;
            } else if (this.isStr(className)) {
                return ihasClass(el, className);
            }
            return false;
        },
        extDomain: function(url) {
            var matches = url.match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);

            return (matches && matches[1]);
        },
        screenPos: function(delim) {
            return (screen ? screen.width + (delim ? delim : ",") + screen.height : "");
        },
        pos: function(e) {

            /**
             * gs
             * @returns {void}
             */
            function gs() {
                var dd = document.documentElement,
                    db = document.body;

                if (dd && (dd.scrollTop || dd.scrollLeft)) {
                    return [dd.scrollTop, dd.scrollLeft];
                } else if (db) {
                    return [db.scrollTop, db.scrollLeft];
                }
                return [0, 0];
            }
            var ieD = null,
                x = e.pageX,
                y = e.pageY;

            if (this.isIE) {
                ieD = gs();
            }
            if (!x && x !== 0) {
                x = e.clientX || 0;
                if (this.isIE) {
                    x += ieD[1];
                }
            }
            if (!y && y !== 0) {
                y = e.clientY || 0;
                if (this.isIE) {
                    y += ieD[0];
                }
            }
            return x + "," + y;
        },
        getElementsByTagNames: function(obj, filter) {
            if (!obj) {
                obj = document;
            }
            var ret = [];

            for (var i = 0; i < this.LINK_TAG_LIST.length; i++) {
                var tags = obj.getElementsByTagName(this.LINK_TAG_LIST[i]);

                for (var j = 0; j < tags.length; j++) {
                    var curTag = tags[j];

                    if (filter && !filter.call(0, curTag)) {
                        continue;
                    }
                    ret.push(curTag);
                }
            }
            return this.sort(ret);
        },
        getElementsByTagNamesDOMParsing: function(mem, obj, list, filter) {

            /**
             * isTag
             * @param {Object} o .
             * @returns {void}
             */
            function isTag(o) {
                for (var i = 0; i < this.LINK_TAG_LIST.length; i++) {
                    if (o.tagName && o.tagName.toLowerCase() === this.LINK_TAG_LIST[i].toLowerCase()) {
                        return true;
                    }
                }
                return false;
            }
            if (!obj) {
                obj = document;
            }
            var ret = list || [];
            var children = obj.childNodes;

            if (this.getAttribute(obj, mem.conf.skip_attr) !== "true") {
                for (var i = 0; i < children.length; i++) {
                    var curTag = children[i];

                    if (isTag(curTag)) {
                        if (!filter || filter.call(0, curTag)) {
                            ret.push(curTag);
                        }
                    }
                    if (this.getAttribute(curTag, mem.conf.skip_attr) !== "true") {
                        ret = this.getElementsByTagNamesDOMParsing(mem, curTag, ret, filter);
                    } else if (util.getAttribute(curTag, mem.conf.skip_attr) === "true") {
                        ret.push(curTag);
                    }
                }
            }
            return this.sort(ret);
        },
        sort: function(list) {
            var node = list[0];

            if (!node) {
                return [];
            }
            if (node.sourceIndex) {
                list.sort(function(a, b) {
                    return a.sourceIndex - b.sourceIndex;
                });
            } else if (node.compareDocumentPosition) {
                list.sort(function(a, b) {
                    return 3 - (a.compareDocumentPosition(b) & 6);
                });
            }
            return list;
        },
        getLinkContent: function(l) {
            for (var i = 0, s = "", o; ((o = l.childNodes[i]) && o); i++) {
                if (o.nodeType === 1) {
                    if (o.nodeName.toLowerCase() === "img") {
                        s += (this.getAttribute(o, "alt") || "") + " ";
                    }
                    s += this.getLinkContent(o);
                }
            }
            return s;
        },
        getLT: function(l, type) {
            if (!l) {
                return "_";
            }
            var ret = "";

            type = type.toLowerCase();
            if (l.nodeName.toLowerCase() === "input") {
                ret = this.getAttribute(l, "value");
            } else if (type === "text") {
                if ((/KHTML/).test(navigator.userAgent)) {
                    ret = l.textContent;
                } else {
                    ret = (l.innerText ? l.innerText : l.textContent);
                }
            } else if (type === "href") {
                ret = this.rmProto(this.getAttribute(l, "href"));
            } else {
                ret = this.getAttribute(l, type) || "";
            }
            ret = this.trim(ret);
            if (ret === "") {
                ret = this.trim(this.getLinkContent(l));
            }
            if (ret && ret.length > util.MAX_VALUE_LENGTH) {
                ret = ret.substring(0, util.MAX_VALUE_LENGTH);
            }
            return (ret === "" ? "_" : ret);
        },
        getCompStyle: function(el, pseudo) {
            if (typeof window.getComputedStyle !== "undefined") {
                return window.getComputedStyle(el, pseudo);
            }
            this.el = el;
            this.getPropertyValue = function(prop) {
                var re = /(¥-([a-z]){1})/g;

                if (prop === "float") {
                    prop = "styleFloat";
                }
                if (re.test(prop)) {
                    prop = prop.replace(re, function() {
                        return arguments[2].toUpperCase();
                    });
                }
                return el.currentStyle[prop] ? el.currentStyle[prop] : 0;
            };
            return this;
        },
        isAboveFoldArea: function(element, scrollbarSize) {

            /**
             * isScrollHorizontalVisible
             * @returns {void}
             */
            function isScrollHorizontalVisible() {
                return document.documentElement.scrollWidth > document.documentElement.clientWidth;
            }

            /**
             * isScrollVerticalVisible
             * @returns {void}
             */
            function isScrollVerticalVisible() {
                return document.documentElement.scrollHeight > document.documentElement.clientHeight;
            }
            var linkstyle = this.getCompStyle(element);

            if (linkstyle.getPropertyValue("visibility") === "hidden" || linkstyle.getPropertyValue("display") === "none") {
                return false;
            }
            var r = element.getBoundingClientRect();
            var windowInnerHeight = window.innerHeight || document.documentElement.clientHeight;
            var windowInnerWidth = window.innerWidth || document.documentElement.clientWidth;
            var elementHeight;
            var elementWidth;

            if (typeof r.height === "undefined" || typeof r.width === "undefined") {
                elementHeight = Math.abs(r.bottom - r.top);
                elementWidth = Math.abs(r.right - r.left);
            } else {
                elementHeight = r.height;
                elementWidth = r.width;
            }

            if (isScrollHorizontalVisible()) {
                windowInnerHeight -= scrollbarSize.height;
            }
            if (isScrollVerticalVisible()) {
                windowInnerWidth -= scrollbarSize.width;
            }

            if (r.right <= 0 || r.bottom <= 0 || r.left >= windowInnerWidth || r.top >= windowInnerHeight) {
                return false;
            }
            var elementViewableRect = {};

            elementViewableRect.top = r.top < 0 ? 0 : r.top;
            elementViewableRect.left = r.left < 0 ? 0 : r.left;
            elementViewableRect.bottom = r.bottom > windowInnerHeight ? windowInnerHeight : r.bottom;
            elementViewableRect.right = r.right > windowInnerWidth ? windowInnerWidth : r.right;
            elementViewableRect.width = elementViewableRect.right - elementViewableRect.left;
            elementViewableRect.height = elementViewableRect.bottom - elementViewableRect.top;
            if ((elementWidth * elementHeight) / 2 <= (elementViewableRect.width * elementViewableRect.height)) {
                return true;
            }
            return false;
        },
        ltattr: function(mod, defaultVal) {
            if (util.hasClass(mod, "rapid_track_href")) {
                return "href";
            }
            if (util.hasClass(mod, "rapid_track_text")) {
                return "text";
            }
            if (util.hasClass(mod, "rapid_track_title")) {
                return "title";
            }
            if (util.hasClass(mod, "rapid_track_id")) {
                return "id";
            }
            return defaultVal;
        }
    };

    util.extend(inline, {
        Uploader: function(mem) {

            /**
             * send
             * @param {Object} json .
             * @param {Object} callback .
             * @param {Object} sender .
             * @param {Object} option .
             * @returns {void}
             */
            function send(json, callback, sender, option) {

                /**
                 * query
                 * @param {Object} data .
                 * @param {Object} needKey .
                 * @param {Object} doEncode .
                 * @returns {void}
                 */
                function query(data, needKey, doEncode) {
                    var s = "select * from x where a = '" + data + "'";

                    return (needKey ? "q=" : "") + (doEncode ? encodeURIComponent(s) : s);
                }

                /**
                 * getURI
                 * @param {Object} compressed .
                 * @returns {void}
                 */
                function getURI(compressed) {
                    var ret = [
                        util.getProtocol(),
                        mem.conf.yql_host,
                        mem.conf.yql_path,
                        "?yhlVer=2&yhlClient=rapid&yhlS=", mem.conf.spaceid,
                        ((mem.conf.deb === true) ? "&yhlEnv=staging" : ""),
                        ((mem.conf.deb === true || mem.conf.ldbg) ? "&debug=true&diagnostics=true" : ""),
                        ((util.isIE && util.ieV) ? "&yhlUA=ie" + util.ieV : ""),
                        "&format=json",
                        "&yhlCT=2",
                        "&yhlBTMS=", (new Date()).valueOf(),
                        "&yhlClientVer=", mem.conf.version,
                        "&yhlRnd=", util.rand(),
                        "&yhlCompressed=", compressed || 0
                    ].join("");

                    util.logDebug("[Yahoo.i13n.Uploader.getURI] result : " + ret);
                    return ret;
                }

                /**
                 * exec
                 * @param {Object} data .
                 * @param {Object} compression .
                 * @returns {void}
                 */
                function exec(data, compression) {
                    if (compression === 0) {
                        data = data.replace(/'/g, "¥¥¥'");
                    }
                    if (util.isDebug()) {
                        util.logDebug("[Yahoo.i13n.Uploader.send.exec] A_sid : " + mem.conf.keys.get("A_sid"));
                    }
                    if (util.hasCORS()) {
                        util.logDebug("[Yahoo.i13n.Uploader.send.exec] this method is XHR transfer.");
                        var xhr = util.getXHR(),
                            url = getURI(compression);

                        xhr.open("POST", url, true);
                        xhr.withCredentials = true;
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                        xhr.timeout = mem.conf.click_timeout;
                        xhr.onload = xhr.ontimeout = function (e) {
                            if (callback && util.isFunction(callback)) {
                                callback.call(0, sender, option);
                            }
                        };
                        xhr.send(query(data, true, true));
                    } else {
                        util.logDebug("[Yahoo.i13n.Uploader.send.exec] this method is to create Iframe and form submit.");
                        var frameName = "rapid_if_" + util.rand(),
                            formId = "rapid_if_" + util.rand(),
                            frame = document.createElement("iframe"),
                            encType = "application/x-www-form-urlencoded;charset=UTF-8",
                            ifr = null,
                            form = null,
                            input = null,
                            submit = null;

                        frame.name = frameName;

                        var onloadRemove = function() {
                            util.off(frame, "load", onloadRemove);
                            util.async(function() {
                                document.body.removeChild(frame);
                            });
                        };

                        frame.setAttribute("style", "display:none");
                        document.body.appendChild(frame);
                        ifr = frame.contentDocument || frame.contentWindow.document;
                        ifr.open();
                        ifr.close();
                        form = ifr.createElement("form");
                        form.setAttribute("style", "display:none");
                        form.id = formId;
                        form.method = "POST";
                        form.action = getURI(compression);
                        form.target = frameName;
                        form.setAttribute("enctype", encType);
                        form.setAttribute("encoding", encType);

                        input = ifr.createElement("input");
                        input.name = "q";
                        input.value = query(json, 0, 0);
                        input.type = "text";
                        form.appendChild(input);

                        submit = ifr.createElement("input");
                        submit.type = "submit";
                        form.appendChild(submit);

                        ifr.body.appendChild(form);
                        ifr.charset = "UTF-8";
                        util.on(frame, "load", onloadRemove);
                        if (callback && util.isFunction(callback)) {
                            util.on(form, "submit", function() {
                                callback.call(0, sender, option);
                            });
                            util.async(function() {
                                callback.call(0, sender, option);
                            }, mem.conf.click_timeout);
                        }
                        submit.click();
                    }
                } // exec

                /**
                 * isScrollVerticalVisible
                 * @returns {void}
                 */
                function fail() {
                    if (!sent) {
                        sent = true;
                        exec(json, 0);
                        util.logDebug("[Yahoo.i13n.Uploader.send] sent in failSend");
                    }
                }

                var compressionInt = util.COMPRESS_TYPE[mem.conf.compr_type];

                if (mem.conf.compr_on && util.hasWorkers() && compressionInt > 1 && json.length > (2 * 1024)) {
                    util.logDebug("[Yahoo.i13n.Uploader.send] Looking for worker:" + mem.conf.webworker_file + ", compr timeout:" + mem.conf.compr_timeout);
                    try {
                        var w = new Worker(mem.conf.webworker_file),
                            sent = false,
                            tid = null;

                        w.onerror = function(error) {
                            clearTimeout(tid);
                            fail();
                            util.logWarn(error.message);
                            w.terminate();
                        };
                        w.onmessage = function(event) {
                            clearTimeout(tid);
                            if (event.data === "Decompress fail" || event.data === "Compress fail" || event.data.indexOf("error:") === 0) {
                                util.logDebug("[Yahoo.i13n.Uploader.send]" + event.data);
                                fail();
                            }
                            if (!sent) {
                                sent = true;
                                exec(event.data, compressionInt);
                            }
                            w.terminate();
                        };
                        w.postMessage({
                            type: compressionInt,
                            json: json
                        });
                        tid = util.async(function() {
                            fail();
                            w.terminate();
                        }, mem.conf.compr_timeout);
                    } catch (e) {
                        util.logDebug("[Yahoo.i13n.Uploader.send]compression worker exception " + e);
                        exec(json, 0);
                    }
                } else {
                    exec(json, 0);
                }
            }

            /**
             * createBP
             * @param {Object} isReffer .
             * @returns {void}
             */
            function createBP(isReffer) {
                var ret = {
                    _pl: 1,
                    A_v: mem.conf.version,
                    A_jpv: mem.conf.rapidjp_version
                };
                var ref = util.trim(util.clref((mem.conf.referrer !== null) ? mem.conf.referrer : document.referrer));

                if (ref && isReffer !== false) {
                    //ret._R = ref.substring(0, util.MAX_VALUE_LENGTH);
                    ret._R = ref;
                }
                if (mem.conf.ex) {
                    ret._ex = 1;
                }
                if (!ret._bt) {
                    ret._bt = "rapid";
                }
                var protocol = window.location.protocol || "";

                protocol = protocol.replace(/:$/, "");
                ret.A_pr = protocol;
                ret.A_tzoff = new Date().getTimezoneOffset();
                ret.A_tzoff = ret.A_tzoff ? -1 * ret.A_tzoff / 60 : 0;
                util.logDebug("[Yahoo.i13n.Uploader.createBP] result : " + ret);
                return ret;
            }

            /**
             * createClickJson
             * @param {Object} sender .
             * @returns {void}
             */
            function createClickJson(sender) {
                util.logTrace("[Yahoo.i13n.Uploader.createClickJson] sender ", sender);
                return util.toJSON({
                    bp: createBP(),
                    r: [{
                        t: "cl",
                        s: mem.conf.spaceid,
                        pp: inline.PageParams.makeFromPP(mem.conf.keys).getAll(),
                        _ts: Math.floor(new Date().valueOf() / 1000),
                        ci: (function() {
                            var ret = {};

                            if (sender.targetObject && sender.targetObject.moduleNode) {
                                ret = sender.targetObject.moduleNode.getAll();
                            }
                            for (var sec in sender.data) {
                                if (!util.hasOwn(sender.data, sec) || !sender.data[sec]) {
                                    continue;
                                }
                                var temp = sender.data[sec];
                                if (temp.length > util.MAX_VALUE_LENGTH) {
                                    sender.data[sec] = temp.substring(0, util.MAX_VALUE_LENGTH);
                                }
                                if (typeof sender.data[sec] === "function") {
                                    sender.data[sec] = sender.data[sec].toString();
                                }
                                ret[sec] = sender.data[sec];
                            }
                            return ret;
                        }())
                    }],
                    yrid: mem.conf.yrid,
                    optout: mem.conf.oo,
                    nol: mem.conf.nol
                });
            }

            /**
             * createPageJson
             * @param {Object} mods .
             * @param {Object} param .
             * @returns {void}
             */
            function createPageJson(mods, param) {
                util.logTrace("[Yahoo.i13n.Uploader.createPageJson] Modules ", mods);
                util.logTrace("[Yahoo.i13n.Uploader.createPageJson] Parameter ", param);
                return util.toJSON({
                    bp: createBP(),
                    r: [{
                        t: "lv",
                        s: mem.conf.spaceid,
                        pp: (function() {
                            var ret = inline.PageParams.makeFromPP(mem.conf.keys);

                            if (param) {
                                ret.absorb(param);
                            }
                            return ret.getAll();
                        }()),
                        _ts: Math.floor(new Date().valueOf() / 1000),
                        lv: (function() {
                            var ret = [],
                                mod = null;

                            for (var mname in mods) {
                                if (!util.hasOwn(mods, mname)) {
                                    continue;
                                }
                                mod = mods[mname];
                                if (!mod) {
                                    continue;
                                }
                                var modObj = (function() {

                                    /**
                                     * filter
                                     * @param {Object} key .
                                     * @param {Object} value .
                                     * @returns {void}
                                     */
                                    function filter(key, value) {
                                        var isPos = (key === "_p");

                                        if (isPos) {
                                            return true;
                                        }
                                        if (key === "sec" && value !== sub.m && value !== modSec) {
                                            return true;
                                        }
                                        return key !== "sec" && !isPos;
                                    }

                                    /**
                                     * linkToStrippedJSON
                                     * @param {Object} link .
                                     * @param {Object} pfilter .
                                     * @returns {void}
                                     */
                                    function linkToStrippedJSON(link, pfilter) {
                                        var rv = {};

                                        if (!util.isObj(link)) {
                                            return rv;
                                        }
                                        util.aug(rv, link, pfilter);
                                        return rv;
                                    }

                                    var sub = {
                                        m: util.trim(mod.moduleName),
                                        l: []
                                    };

                                    if (mod.moduleNode) {
                                        sub.ylk = mod.moduleNode.getAll();
                                    }
                                    var modSec = (ret.ylk && ret.ylk.sec) ? ret.ylk.sec : "",
                                        links = mod.links;
                                    
                                    if (links) {
                                        for (var i = 0; i < links.length; i++) {
                                            if (!links[i]) {
                                                continue;
                                            }
                                            if (mem.conf.viewability && !links[i].viewable) {
                                                util.logDebug("Skipping not viewable link: " + links[i].data.slk);
                                                continue;
                                            }
                                            var temp = links[i].data;
                                            if (temp.length > util.MAX_VALUE_LENGTH) {
                                                links[i].data = temp.substring(0, util.MAX_VALUE_LENGTH);
                                            }
                                            var lsub = linkToStrippedJSON(links[i].data, filter);

                                            sub.l.push(lsub);
                                        }
                                    }
                                    return sub;
                                }());

                                if (modObj.l.length > 0) {
                                    ret.push(modObj);
                                } else {
                                    util.logDebug("[Yahoo.i13n.Uploader.createPageRowMsg] Not capturing 0 links mod: \"" + mod.moduleName + "\"");
                                }
                            }
                            return ret;
                        }())
                    }],
                    yrid: mem.conf.yrid,
                    optout: mem.conf.oo,
                    nol: mem.conf.nol
                });
            }

            /**
             * createEventJson
             * @param {Object} eventtype .
             * @param {Object} eventname .
             * @param {Object} data .
             * @param {Object} outcome .
             * @returns {void}
             */
            function createEventJson(eventtype, eventname, data, outcome) {
                var pp = inline.PageParams.makeFromPP(mem.conf.keys).getAll();

                data = data || {};
                if (eventtype) {
                    var type = YAHOO.i13n.EventTypes.getEventByName(eventtype);

                    data._E = type.getEventName();
                    eventname = data._E;
                } else {
                    data._E = eventname || "_";
                }
                if (outcome) {
                    data.outcm = outcome;
                }
                for (var nm in data) {
                    if (util.hasOwn(data, nm)) {
                        if (nm.length > 8) {
                            delete data[nm];
                            continue;
                        }
                    }
                    var temp = data[nm];
                    if (temp.length > util.MAX_VALUE_LENGTH) {
                        data[nm] = temp.substring(0, util.MAX_VALUE_LENGTH);
                    }
                }
                util.extend(pp, data);
                return util.toJSON({
                    bp: createBP(),
                    r: [{
                        t: "ev",
                        s: mem.conf.spaceid,
                        pp: pp,
                        _ts: Math.floor(new Date().valueOf() / 1000)
                    }],
                    yrid: mem.conf.yrid,
                    optout: mem.conf.oo,
                    nol: mem.conf.nol
                });
            }

            /**
             * stopClickEvent
             * @param {Object} e .
             * @returns {void}
             */
            function stopClickEvent(e) {
                if (!e) {
                    return;
                }
                if (e.preventDefault) {
                    e.preventDefault();
                } else {
                    e.returnValue = false;
                }
            }

            /**
             * redirect
             * @param {Object} sender .
             * @param {Object} callback .
             * @returns {void}
             */
            function redirect(sender, callback) {
                util.logTrace("[Yahoo.i13n.Uploader.redirect] sender ", sender);
                if (callback && util.isFunction(callback)) {
                    callback.call();
                    return;
                }
                if (!sender.synch) {
                    util.logDebug("[Yahoo.i13n.Uploader.redirect] synch " + sender.synch);
                    return;
                }
                if (!sender.targetElement) {
                    return;
                }
                if (mem.conf.click_postmsg.origin) {
                    var targetWin = mem.conf.click_postmsg.window || top;
                    var data = mem.conf.click_postmsg.payload || {};

                    data.href = sender.targetElement.href;
                    targetWin.postMessage(util.toJSON(data), mem.conf.click_postmsg.origin);
                } else {
                    if ((util.isIE && util.ieV >= 11) || util.isEdge) {
                        if (document.readyState !== "complete") {
                            history.pushState("", document.title);
                        }
                        if (sender.hasTargetTop) {
                            top.document.location = sender.targetElement.href;
                        } else {
                            document.location = sender.targetElement.href;
                        }
                    } else {
                        var element = sender.targetElement.cloneNode(true);

                        if (element.dispatchEvent) {
                            var evt = document.createEvent("MouseEvents");

                            evt.initEvent("click", true, false);
                            element.dispatchEvent(evt);
                        } else {
                            element.click();
                        }
                    }
                }
            }

            /**
             * isendRapidPage
             * @param {Object} mod .
             * @param {Object} param .
             * @returns {void}
             */
            function isendRapidPage(mod, param) {
                util.logDebug("[Yahoo.i13n.Uploader.isendRapidPage]");
                var json = createPageJson(mod, param);

                util.logTrace("[Yahoo.i13n.Uploader.isendRapidPage] Json ", json);
                send(json);
            }

            /**
             * isendRapidClick
             * @param {Object} sender .
             * @param {Object} callback .
             * @returns {void}
             */
            function isendRapidClick(sender, callback) {
                util.logDebug("[Yahoo.i13n.Uploader.isendRapidClick]");
                var json = createClickJson(sender);

                util.logTrace("[Yahoo.i13n.Uploader.isendRapidClick] Json ", json);
                if (!sender.stop) {
                    stopClickEvent(sender.event);
                }
                send(json, redirect, sender, callback);
            }

            /**
             * isendRapidEvent
             * @param {Object} event .
             * @param {Object} data .
             * @param {Object} outcome .
             * @returns {void}
             */
            function isendRapidEvent(event, data, outcome) {
                util.logDebug("[Yahoo.i13n.Uploader.isendRapidEvent]");
                var json = createEventJson(0, event, data, outcome);

                util.logTrace("[Yahoo.i13n.Uploader.isendRapidEvent] Json ", json);
                send(json);
            }
            return {
                sendRapidPage: function(mod, param) {
                    util.logDebug("[Yahoo.i13n.Uploader.sendRapidPage]");
                    isendRapidPage(mod, param);
                },
                sendRapidClick: function(sender, callback) {
                    util.logDebug("[Yahoo.i13n.Uploader.sendRapidClick]");
                    isendRapidClick(sender, callback);
                },
                sendRapidEvent: function(event, data, outcome, callback) {
                    util.logDebug("[Yahoo.i13n.Uploader.sendRapidEvent]");
                    isendRapidEvent(event, data, outcome, callback);
                }
            };
        },
        Module: function(mem, name, id, isView, scrollSize) {
            util.logDebug("[Yahoo.i13n.Module]");

            /**
             * getLinkAtPos
             * @param {Object} o .
             * @param {Object} pos .
             * @returns {void}
             */
            function getLinkAtPos(o, pos) {
                if (pos > o.links.length) {
                    return null;
                }
                return o.links[pos - 1];
            }

            /**
             * link
             * @param {Object} moduleLtattr .
             * @param {Object} moduleName .
             * @param {Object} position .
             * @param {Object} anchorEl .
             * @param {Object} linkSlk .
             * @param {Object} skippedDiv .
             * @param {Object} useViewability .
             * @param {Object} scrollbarSize .
             * @returns {void}
             */
            function link(moduleLtattr, moduleName, position, anchorEl, linkSlk, skippedDiv, useViewability, scrollbarSize) {
                var linkText = "",
                    linkKeyPairs = null,
                    viewable = useViewability ? util.isAboveFoldArea(anchorEl, scrollbarSize) : true,
                    ret = {
                        viewable: viewable,
                        data: {
                            sec: moduleName,
                            _p: position
                        }
                    };

                if (useViewability) {
                    util.aug(ret.data, { A_lv: 1 });
                }
                if (!skippedDiv) {
                    anchorEl.setAttribute(mem.conf.anc_pos_attr, position);
                    if (useViewability) {
                        anchorEl.setAttribute(mem.conf.anc_v9y_attr, viewable ? "1" : "0");
                    }
                    linkText = util.getLT(anchorEl, moduleLtattr);
                    if (linkText && linkText !== "") {
                        linkKeyPairs = mem.fn.getNode(anchorEl);
                    } else {
                        linkText = "_ELINK_";
                    }
                    linkText = "_";
                    ret.data.slk = linkSlk ? linkSlk : linkText;
                } else {
                    ret.data.slk = linkSlk || "section";
                    linkKeyPairs = mem.fn.getNode(anchorEl);
                }
                if (linkKeyPairs !== null) {
                    util.aug(ret.data, linkKeyPairs.getAll());
                }
                return ret;
            }

            /**
             * setLink
             * @param {Object} linklist .
             * @returns {void}
             */
            function setLink(linklist) {
                var ret = [];

                targetObject.linkpos = targetObject.linkpos || 1;
                var l = null;
                var mapSec = targetObject.moduleNode !== null ? targetObject.moduleNode.map.sec : null;
                var mapSlk = targetObject.moduleNode !== null ? targetObject.moduleNode.map.slk : null;
                
                for (var i = 0; i < linklist.length; i++) {
                    if (linklist[i].tagName.toLowerCase() === "div") {
                        var skippedDiv = linklist[i];
                        var localNode = mem.fn.getNode(skippedDiv);

                        l = link(util.ltattr(ele, mem.conf.lt_attr),
                            mapSec || targetObject.moduleName,
                            1,
                            skippedDiv,
                            localNode.map.slk || mapSlk,
                            true,
                            targetObject.useViewability,
                            scrollSize);
                        targetObject.links[0] = l;
                        ret.push(l);
                    } else {
                        var linkElement = linklist[i];
                        l = link(util.ltattr(ele, mem.conf.lt_attr),
                            mapSec || targetObject.moduleName,
                            targetObject.linkpos,
                            linkElement,
                            mapSlk,
                            0,
                            targetObject.useViewability,
                            scrollSize);
                        targetObject.links[targetObject.linkpos - 1] = l;
                        ret.push(l);
                        targetObject.linkpos++;
                    }
                }
                if (util.getAttribute(ele, mem.conf.skip_attr) === "true") {
                    l = link(util.ltattr(ele, mem.conf.lt_attr),
                        mapSec || targetObject.moduleName,
                        1,
                        skippedDiv,
                        mapSlk,
                        true,
                        targetObject.useViewability,
                        scrollSize);
                    targetObject.links[0] = l;
                    ret.push(l);
                }
                return ret;
            }

            /**
             * clickEvent
             * @param {Object} e .
             * @returns {void}
             */
            function clickEvent(e) {

                /**
                 * getTarget
                 * @param {Object} e1 .
                 * @returns {void}
                 */
                function getTarget(e1) {
                    var target = e1.target || e1.srcElement;
                    var name1 = target.nodeName.toLowerCase();

                    // NOTICE : In element type, node type is '3';

                    if (target && target.nodeType === 3) {
                        target = target.parentNode;
                    }
                    while (target && name1 !== "a" && name1 !== "button" && !((name1 === "input") && (util.getAttribute(target, "type") === "submit")) && !util.hasClass(target, mem.conf.nonanchor_track_class)) {
                        target = target.parentNode;
                    }
                    return target;
                }

                /**
                 * hasClickModifier
                 * @param {Object} e2 .
                 * @param {Object} targ .
                 * @param {Object} mdl .
                 * @returns {void}
                 */
                function hasClickModifier(e2, targ, mdl) {
                    var target = targ.target ? targ.target.toLowerCase() : "_self";

                    return (
                        (target !== "_self" && target !== "_top" && target !== "_parent" && window.name !== target) ||
                                e2.which === 2 ||
                                e2.button === 4 ||
                                e2.altKey ||
                                e2.ctrlKey ||
                                e2.shiftKey ||
                                e2.metaKey ||
                                util.getAttribute(targ, "data-nofollow") === "on" ||
                                (util.getAttribute(targ, "href") && util.getAttribute(targ, "href").substr(0, 11).toLowerCase() === "javascript:") ||
                                util.hasClass(targ, mem.conf.nofollow_class) ||
                                util.hasClass(mdl, mem.conf.nofollow_class)
                    );
                }

                e = e || event;
                var target = getTarget(e);

                if (!target || util.hasClass(target, mem.conf.no_click_listen)) {
                    return;
                }
                var targetName = target.nodeName.toLowerCase();
                var pos = util.getAttribute(target, mem.conf.anc_pos_attr);

                if (getLinkAtPos(targetObject, pos) !== null) {
                    var click = {
                        data: (function() {
                            var ret = null;

                            if (util.hasClass(target, mem.conf.nonanchor_track_class)) {
                                ret = {
                                    pos: 0,
                                    sec: targetObject.moduleName,
                                    slk: "_"
                                };
                                var lk = mem.fn.getNode(target, 1);

                                if (lk) {
                                    util.aug(ret, lk.getAll());
                                }
                            } else {
                                ret = getLinkAtPos(targetObject, pos).data;
                            }
                            if (!ret.tar) {
                                var href = util.getAttribute(target, "href");

                                if (href) {
                                    ret.tar = util.extDomain(href);
                                }
                                if (!href || !ret.tar) {
                                    ret.tar = util.extDomain(mem.conf.loc);
                                }
                            }
                            if (!ret.tar_uri) {
                                if (target.pathname) {
                                    ret.tar_uri = target.pathname.substring(0, util.MAX_VALUE_LENGTH);
                                } else {
                                    ret.tar_uri = "";
                                }
                            }

                            ret.A_xy = util.pos(e);
                            ret.A_sr = util.screenPos();
                            if (e.type === "contextmenu") {
                                ret.A_cl = 3;
                            }
                            return ret;
                        }()),
                        event: e,
                        moduleElement: targetObject.moduleElement,
                        targetElement: target,
                        targetObject: targetObject,
                        stop: hasClickModifier(e, target, targetObject.moduleElement),
                        synch: !util.hasClass(target, mem.conf.nonanchor_track_class) && targetName !== "input" && targetName !== "button" && !hasClickModifier(e, target, targetObject.moduleElement) && e.type !== "contextmenu",
                        hasTargetTop: (target && target.target && target.target.toLowerCase() === "_top")
                    };

                    mem.variable.uploader.sendRapidClick(click);
                }

            }
            var ele = document.getElementById(id);
            if (!ele) {
                util.logWarn("Specified module not in DOM: " + id);
                return null;
            }
            var targetObject = {
                useViewability: isView,
                moduleNode: mem.fn.getNode(ele),
                links: [],
                moduleName: name,
                trackType: util.getAttribute(ele, mem.conf.track_type),
                moduleElement: ele,
                clickEvent: clickEvent,
                setLink: setLink,
                link: link,
                linkpos: 1
            };
            util.logTrace("[Yahoo.i13n.Module] targetObject ", targetObject);
            setLink(mem.conf.parse_dom ? util.getElementsByTagNamesDOMParsing(mem, ele) : util.getElementsByTagNames(ele));
            util.on(ele, "click", clickEvent);
            if (mem.conf.track_right_click) {
                util.on(ele, "contextmenu", clickEvent);
            }

            util.logTrace("[Yahoo.i13n.Module] targetObject ", targetObject);
            return targetObject;
        },
        Node: function() {
            this.map = {};
            this.count = 0;
        },
        PageParams: function(initval) {
            this.map = {};
            this.count = 0;
            if (initval) {
                this.absorb(initval);
            }
        },
        MsgHeader: function() { },
        ViewabilityManager: function(mem) {
            util.logDebug("[Yahoo.i13n.ViewabilityManager]");

            /**
             * getScrollY
             * @returns {void}
             */
            function getScrollY() {
                return (typeof window.pageYOffset !== "undefined") ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
            }

            /**
             * getScrollX
             * @returns {void}
             */
            function getScrollX() {
                return (typeof window.pageXOffset !== "undefined") ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft;
            }

            /**
             * handleViewability
             * @returns {void}
             */
            function handleViewability() {
                var curScrollY = getScrollY(),
                    curScrollX = getScrollX(),
                    scrollSizeY = (lastApvScrollY === -1) ? (curScrollY - pageLoadScrollY) : (curScrollY - lastApvScrollY),
                    scrollSizeX = (lastApvScrollX === -1) ? (curScrollX - pageLoadScrollX) : (curScrollX - lastApvScrollX);

                if (Math.abs(scrollSizeY) > mem.conf.viewability_px ||
                            Math.abs(scrollSizeX) > mem.conf.viewability_px ||
                            userDispatchViewable) {
                    mem.variable.moduleList.sendViewability();
                    lastApvScrollY = curScrollY;
                    lastApvScrollX = curScrollX;
                    userDispatchViewable = false;
                }
            }

            /**
             * viewabilityCb
             * @returns {void}
             */
            function viewabilityCb() {
                if (timer !== null) {
                    clearTimeout(timer);
                }
                var curTime = new Date().getTime();

                if ((curTime - pageLoadTime) < mem.conf.viewability_time) {
                    pageLoadScrollY = getScrollY();
                    pageLoadScrollX = getScrollX();
                }
                timer = util.async(handleViewability, mem.conf.viewability_time);
            }

            /**
             * refreshViewabilityFunc
             * @returns {void}
             */
            function refreshViewabilityFunc() {
                userDispatchViewable = true;
                viewabilityCb();
            }
            var timer = null,
                pageLoadTime = new Date().getTime(),
                pageLoadScrollY = getScrollY(),
                pageLoadScrollX = getScrollX(),
                lastApvScrollY = -1,
                lastApvScrollX = -1,
                userDispatchViewable = false;

            mem.variable.moduleList.refreshViewability = refreshViewabilityFunc;
            util.on(window, "scroll", viewabilityCb);
            return {
                reInit: function() {
                    pageLoadScrollY = getScrollY();
                    pageLoadScrollX = getScrollX();
                    lastApvScrollY = -1;
                    lastApvScrollX = -1;
                    pageLoadTime = new Date().getTime();
                },
                destroy: function() {
                    util.off(window, "scroll", viewabilityCb);
                }
            };
        }
    });
    inline.MsgHeader.prototype = {
        ser: function() {
            return util.ser(this.map);
        },
        set: function(k, v) {
            var val = util.trim(v);

            if (util.isStr(val)) {
                val = val.replace(/\\/g, "\\\\");
            }
            if (!util.in_value_whitelist(k) && val.length > util.MAX_VALUE_LENGTH) {
                val = val.substring(0, util.MAX_VALUE_LENGTH);
            }
            if (util.isValidPair(k, val)) {
                this.map[util.trim(k)] = val;
                this.count++;
            }
        },
        get: function(k) {
            return this.map[k];
        },
        getAll: function() {
            return this.map;
        },
        absorb: function(other) {
            if (!other || !util.isObj(other)) {
                return;
            }
            for (var k in other) {
                if (util.hasOwn(other, k)) {
                    this.set(k, other[k]);
                }
            }
        },
        absorb_filter: function(other, f) {
            if (!other || !util.isObj(other)) {
                return;
            }
            for (var k in other) {
                if (f && !f.call(null, k)) {
                    continue;
                }
                if (util.hasOwn(other, k)) {
                    this.set(k, other[k]);
                }
            }
        },
        getSize: function() {
            return this.count;
        }
    };
    inline.PageParams.makeFromPP = function() {
        var ret = new inline.PageParams();
        var length = arguments.length;

        for (var i = 0; i < length; i++) {
            if (typeof arguments[ i ] !== "undefined" && arguments[ i ] !== null) {
                ret.absorb(arguments[ i ].getAll());
            }
        }
        return ret;
    };
    inline.PageParams.prototype = new inline.MsgHeader();
    inline.PageParams.prototype.constructor = inline.MsgHeader;
    inline.Node.prototype = new inline.MsgHeader();
    inline.Node.prototype.constructor = inline.MsgHeader;

    inline.Module.List = function(mem) {
        var map = {};

        return {
            add: function(id, mod) {
                map[util.trim(id)] = mod;
            },
            addRange: function(mods, isView) {
                util.logDebug("[Yahoo.i13n.Module.List]");
                var isArr = util.isArr(mods),
                    scrollSize = isView ? util.getScrollbarWidthHeight() : {},
                    ret = [];

                if (!isArr) {
                    if (util.isStr(mods)) {
                        mods = new Array(mods);
                        isArr = true;
                    }
                }
                for (var i in mods) {
                    if (!util.hasOwn(mods, i)) {
                        continue;
                    }
                    var id = isArr ? mods[i] : i,
                        name = util.trim(mods[i]);

                    if (!this.exists(id)) {
                        var m = inline.Module(mem, name, id, isView, scrollSize);
                        if (m) {
                            this.add(id, m);
                            ret.push(m);
                        }
                    } else {
                        util.logErr("add() called with prev processed id:\"" + id + "\"");
                    }
                }

                return ret;
            },
            get: function() {
                return map;
            },
            sendViewability: function() {

                /**
                 * send
                 * @param {Object} cMod .
                 * @param {Object} scrollbarSize .
                 * @returns {void}
                 */
                function send(cMod, scrollbarSize) {

                    /**
                     * getElementsByTagNamesFunc
                     * @param {Object} element .
                     * @returns {void}
                     */
                    function getElementsByTagNamesFunc(element) {
                        if (!util.getAttribute(element, mem.conf.anc_pos_attr)) {
                            cMod.linkpos++;
                            element.setAttribute(mem.conf.anc_pos_attr, cMod.linkpos);
                            var l = cMod.link(util.ltattr(element, mem.conf.lt_attr),
                                cMod.moduleNode.map.sec || modName,
                                cMod.linkpos,
                                element,
                                cMod.moduleNode.map.slk,
                                0,
                                false,
                                scrollbarSize);

                            cMod.links[cMod.linkpos - 1] = l;
                        }
                        var v9yValue = util.getAttribute(element, mem.conf.anc_v9y_attr);

                        if (v9yValue !== "1" && util.isAboveFoldArea(element, scrollbarSize)) {
                            element.setAttribute(mem.conf.anc_v9y_attr, "1");
                            return true;
                        }
                        return false;
                    }

                    /**
                     * getEle
                     * @param {Object} obj .
                     * @param {Object} filter .
                     * @returns {void}
                     */
                    function getEle(obj, filter) {
                        if (!obj) {
                            obj = document;
                        }
                        var ret = [];
                        var tags = obj.getElementsByTagName("a");

                        for (var j = 0; j < tags.length; j++) {
                            var curTag = tags[j];

                            if (filter && !filter.call(0, curTag)) {
                                continue;
                            }
                            ret.push(curTag);
                        }
                        return util.sort(ret);
                    }

                    /**
                     * getRevisedLinks
                     * @param {Object} linksArr .
                     * @param {Object} scrollSize .
                     * @returns {void}
                     */
                    function getRevisedLinks(linksArr, scrollSize) {
                        var ret = [];

                        for (var i = 0; i < linksArr.length; i++) {
                            var linkElement = linksArr[i];
                            var pos = util.getAttribute(linkElement, mem.conf.anc_pos_attr);
                            var l = cMod.link(util.ltattr(linkElement, mem.conf.lt_attr),
                                cMod.moduleNode.map.sec || modName,
                                pos,
                                linkElement,
                                cMod.moduleNode.map.slk,
                                0,
                                true,
                                scrollSize);

                            ret.push(l);
                        }
                        return ret;
                    }
                    var newLinkEls = getEle(cMod.moduleElement, getElementsByTagNamesFunc);

                    if (newLinkEls.length === 0) {
                        return;
                    }
                    if (mem.conf.USE_RAPID) {
                        var newViewables = getRevisedLinks(newLinkEls, scrollbarSize);
                        var mc = {};

                        util.aug(mc, cMod);
                        mc.links = newViewables;
                        mem.variable.uploader.sendRapidPage([mc]);
                    }
                }

                /**
                 * getModulesWithViewability
                 * @returns {void}
                 */
                function getModulesWithViewability() {
                    var rv = {};

                    for (var m in map) {
                        var cur = map[m];

                        if (cur.useViewability) {
                            rv[m] = cur;
                        }
                    }
                    return rv;
                }
                var vMods = getModulesWithViewability();
                var scrollbarSize = util.getScrollbarWidthHeight();

                for (var modName in vMods) {
                    send(vMods[modName], scrollbarSize);
                }
            },
            refresh: function(id, sendLink, opt) {

                /**
                 * filter_func
                 * @param {Object} element .
                 * @returns {void}
                 */
                function filterFunc(element) {
                    return !util.getAttribute(element, mem.conf.anc_pos_attr);
                }
                var m = map[util.trim(id)];

                if (!m) {
                    util.logErr("refreshModule called on unknown section: " + id);
                    return;
                }
                opt.isRefreshed = true;
                var ele = document.getElementById(id);
                var newLinkEls = mem.conf.parse_dom ? util.getElementsByTagNamesDOMParsing(mem, ele, null, filterFunc) : util.getElementsByTagNames(ele, filterFunc);
                var numViewableLinks = 0;

                if (newLinkEls.length > 0) {
                    var newlinks = m.setLink(newLinkEls);

                    numViewableLinks = newLinkEls.length;
                    if (m.useViewability) {
                        numViewableLinks = 0;
                        for (var i = 0; i < newlinks.length; i++) {
                            if (newlinks[i].viewable) {
                                numViewableLinks++;
                            }
                        }
                    }
                    if (numViewableLinks > 0 && (mem.conf.USE_RAPID || opt.event)) {
                        var mc = {};

                        util.aug(mc, m);
                        if (sendLink) {
                            mc.links = newlinks;
                            mem.variable.uploader.sendRapidPage([mc], opt.pp);
                        }
                    }
                }
            },
            remove: function(id) {
                var m = map[util.trim(id)];

                if (m) {
                    util.off(m.moduleElement, "click", m.clickEvent);
                    delete map[util.trim(id)];
                }
            },
            destroy: function() {
                for (var m in map) {
                    this.remove(m);
                }
            },
            exists: function(id) {
                return typeof map[util.trim(id)] !== "undefined";
            }
        };
    };
    util.extend(inline, {
        initialize: function(conf, mem, isReset) {
            conf = conf || {}; 
            /**
             * executeOnLoad
             * @param {Object} callback .
             * @returns {void}
             */
            function executeOnLoad(callback) {

                /**
                 * completed
                 * @param {Object} event .
                 * @returns {void}
                 */
                function completed(event) {
                    if (document.addEventListener || (event && event.type === "load") || document.readyState === "complete") {
                        isReady = true;
                        detachOnLoad();
                        callback.call(this);
                    }
                }

                /**
                 * detachOnLoad
                 * @returns {void}
                 */
                function detachOnLoad() {
                    if (document.addEventListener) {
                        document.removeEventListener("DOMContentLoaded", completed, false);
                        window.removeEventListener("load", completed, false);
                    } else {
                        document.detachEvent("onreadystatechange", completed);
                        window.detachEvent("onload", completed);
                    }
                }

                /**
                 * doScrollCheck
                 * @returns {void}
                 */
                function doScrollCheck() {
                    if (!isReady) {
                        try {
                            top.doScroll("left");
                        } catch (e) {
                            util.async(doScrollCheck, 50);
                            return;
                        }
                        detachOnLoad();
                        callback.call(this);
                    }
                }

                util.logDebug("[Yahoo.i13n.Rapid.executeOnLoad]");
                var isReady = false;

                if (document.readyState === "complete") {
                    util.async(completed);
                } else if (document.addEventListener) {
                    document.addEventListener("DOMContentLoaded", completed, false);
                    window.addEventListener("load", completed, false);
                } else {
                    document.attachEvent("onreadystatechange", completed);
                    window.attachEvent("onload", completed);
                    var top = false;

                    try {
                        top = window.frameElement === null && document.documentElement;
                    } catch (e) {
                        util.logErr("[Yahoo.i13n.Rapid.executeOnLoad] e : " + e);
                    }
                    if (top && top.doScroll) {
                        doScrollCheck(isReady, top);
                    }
                }
            }

            /**
             * setValue
             * @param {Object} mem .
             * @returns {void}
             */
            function setValue() {
                var length = arguments.length;

                if (length < 2) {
                    util.logErr("[Yahoo.i13n.Rapid.setValue] This parameter length is wrong.");
                    return;
                }
                var target = mem.conf;
                var name = arguments[1];

                for (var i = 2; i < length; i++) {
                    if (typeof arguments[ i ] !== "undefined") {
                        target[name] = arguments[ i ];
                    }
                }
            }

            /**
             * trim
             * @param {Object} name .
             * @returns {void}
             */
            function trim(name) {
                var target = mem.conf;

                target[name] = util.trim(target[name]);
            }

            /**
             * setConfig
             * @returns {void}
             */
            function setConfig() {

                /**
                 * getParameter
                 * @param {Object} name .
                 * @returns {void}
                 */
                function getParameter(name) {
                    var loc = memConf.loc;
                    var pos = loc.indexOf("?") + 1;
                    var param = loc.substring(pos);

                    param = param.split("&");
                    for (var i = 0; i < param.length; i++) {
                        var t = param[i].split("=");

                        if (t.length === 2) {
                            if (util.trim(t[0]) === name) {
                                var ret = util.trim(t[1]);

                                ret = ret.replace(/[!@#$%^&*();:'",./<>?_=¥+¥-]/gi, "");
                                return ret;
                            }
                        }
                    }
                    return null;
                }

                /**
                 * isParameter
                 * @param {Object} name .
                 * @returns {void}
                 */
                function isParameter(name) {
                    var val = getParameter(name);

                    if (val !== null && (val === "true" || val === "1")) {
                        return true;
                    }
                    return false;
                }
                var memConf = mem.conf;

                for (var name in inline.define) {
                    if (name !== null && name !== "") {
                        setValue(mem, name, inline.define[name]);
                    }
                }
                for (name in memConf) {
                    if (name !== null && name !== "") {
                        setValue(mem, name, conf[name]);
                    }
                }
                setValue(mem, "loc", conf.location, document.location.href);
                memConf.keys = (function() {
                    var ret = new inline.PageParams();

                    ret.set("A_sid", YAHOO.i13n.A_SID || util.rand());
                    ret.set("_w", util.rmProto(memConf.loc).substring(0, util.MAX_VALUE_LENGTH));
                    if (conf.keys) {
                        ret.absorb(conf.keys);
                    }
                    return ret;
                }());
                setValue(mem, "spaceid", memConf.override.spaceid, YAHOO.i13n.SPACEID);
                trim(mem, "spaceid");
                trim(mem, "yrid");
                memConf.oo = conf.oo ? "1" : "0";
                memConf.nol = conf.nol ? "1" : "0";
                memConf.yql_enabled = conf.yql_enabled !== false;
                memConf.fing = conf.use_fing === 1;
                memConf.USE_RAPID = conf.use_rapid !== false;
                setValue(mem, "linktrack_attribut", conf.lt_attr);
                memConf.compr_on = conf.compr_on !== false;
                setValue(mem, "webworker_file", YAHOO.i13n.WEBWORKER_FILE);
                setValue(mem, "no_click_listen", conf.rapid_noclick_resp);
                memConf.deb = conf.debug === true;
                memConf.ldbg = conf.ldbg > 0 ? true : isParameter("yhldebug");
                memConf.yhlhttp = isParameter("yhlhttp") || conf.use_http === true;
                setValue(mem, "addmod_timeout", conf.addmodules_timeout);
                memConf.ult_token_capture = typeof conf.ult_token_capture === "boolean" ? conf.ult_token_capture : false;
                memConf.dwell_on = conf.dwell_on === true;
                memConf.async_all_clicks = conf.async_all_clicks === true;
                memConf.apv = conf.apv !== false;
                memConf.apv_always_send = conf.apv_always_send === true;
                memConf.ex = conf.ex === true;
                memConf.persist_asid = conf.persist_asid === true;
                memConf.track_right_click = conf.track_right_click === true;
                memConf.parse_dom = conf.parse_dom === true;
                memConf.pageview_on_init = conf.pageview_on_init !== false;
                memConf.compr_timeout *= 1;
                util.debug = memConf.ldbg;
                util.yhlhttp = memConf.yhlhttp;
                if (!util.isNum(memConf.compr_timeout)) {
                    memConf.compr_timeout = 700;
                } else {
                    memConf.compr_timeout = util.getValueWithBounds(memConf.compr_timeout, 300, 700);
                }
                if (memConf.ldbg && memConf.click_timeout !== 10000) {
                    util.logWarn("[Yahoo.i13n.Rapid.initialize] Click timeout set to " + memConf.click_timeout + "ms (default 10000ms)");
                }
                if (conf.apv_callback && util.isFunction(conf.apv_callback)) {
                    setValue(mem, "apv_callback", conf.apv_callback);
                }
            }

            /**
             * setModule
             * @returns {void}
             */
            function setModule() {

                mem.variable.moduleList.destroy();
                var mod = mem.variable.moduleList.addRange(mem.conf.tracked_mods, false);
                var vMod = mem.variable.moduleList.addRange(mem.conf.tracked_mods_viewability, mem.conf.viewability);

                if (mem.conf.USE_RAPID && mem.conf.pageview_on_init && !isReset) {
                    mem.variable.uploader.sendRapidPage(mod.concat(vMod));
                }
                executeOnLoad(function() {
                    mem.variable.viewabilityManager = new inline.ViewabilityManager(mem);
                });
                if (util.isFunction((mem.conf.init_callbak))) {
                    mem.conf.init_callback();
                }
            }

            /**
             * setEventType
             * @returns {void}
             */
            function setEventType() {
                var RICHVIEW = "richview";
                var CONTENTMODIFICATION = "contentmodification";

                /**
                 * EventType
                 * @param {Object} yqlid .
                 * @param {Object} eventName .
                 * @param {Object} spaceidPrefix .
                 * @returns {void}
                 */
                function EventType(yqlid, eventName, spaceidPrefix) {
                    this.yqlid = yqlid;
                    this.eventName = eventName;
                    this.spaceidPrefix = spaceidPrefix;
                }
                EventType.prototype = {
                    getYQLID: function() {
                        return this.yqlid;
                    },
                    getEventName: function() {
                        return this.eventName;
                    }
                };
                mem.conf.eventMapping = {
                    pageview: new EventType("pv", "pageview", ""),
                    simple: new EventType("lv", "event", "P"),
                    linkview: new EventType("lv", "linkview", "P"),
                    richview: new EventType(RICHVIEW, RICHVIEW, "R"),
                    contentmodification: new EventType(RICHVIEW, CONTENTMODIFICATION, "R"),
                    dwell: new EventType("lv", "dwell", "D")
                };
            }

            /**
             * setVariable
             * @returns {void}
             */
            function setVariable() {
                util.extend(mem, {
                    variable: {
                        moduleList: new inline.Module.List(mem),
                        uploader: new inline.Uploader(mem),
                        viewabilityManager: null
                    },
                    fn: {
                        inlineInit: function() {

                        },
                        inlineBeaconEvent: function(event, data, outcome, callback) {
                            mem.variable.uploader.sendRapidEvent(event, data, outcome, callback);
                        },
                        inlineBeaconClick: function(sec, slk, pos, optKeys, outcomeName, callback) {

                            /**
                             * createElement
                             * @param {Object} isec .
                             * @param {Object} islk .
                             * @param {Object} ipos .
                             * @param {Object} ioptKeys .
                             * @param {Object} ioutcomeName .
                             * @returns {void}
                             */
                            function createElement(isec, islk, ipos, ioptKeys, ioutcomeName) {
                                var ret = {
                                    outcome: ioutcomeName,
                                    event: null,
                                    moduleElement: null,
                                    targetElement: null,
                                    synch: false,
                                    hasTargetTop: false
                                };

                                ret.data = {
                                    sec: isec,
                                    slk: islk,
                                    _p: ipos
                                };
                                util.aug(ret.data, ioptKeys);
                                return ret;
                            }
                            if (!optKeys && outcomeName) {
                                optKeys = {};
                            }
                            if (outcomeName) {
                                optKeys.outcm = outcomeName;
                            }
                            mem.variable.uploader.sendRapidClick(createElement(sec, slk, pos, optKeys, outcomeName), callback);
                        },
                        inlineAddModules: function(mods, isPageview, options) {
                            options = options || {};
                            var amPP = {
                                A_am: 1
                            };

                            if (options.pp) {
                                util.aug(amPP, options.pp);
                            }
                            options.useViewability = options.useViewability || false;
                            var newMods = mem.variable.moduleList.addRange(mods, options.useViewability);

                            if (mem.conf.USE_RAPID && newMods && newMods.length > 0) {
                                mem.variable.uploader.sendRapidPage(newMods, amPP);
                            }
                        },
                        inlineAddModulesWithViewability: function(mods, isPageview, options) {
                            options = options || {};
                            options.useViewability = mem.conf.viewability;
                            this.inlineAddModules(mods, isPageview, options);
                        },
                        inlineRefreshModule: function(module, isPageView, shouldSendLinkviews, options) {
                            options = options || {};
                            var sendLinks = (shouldSendLinkviews !== false);

                            mem.variable.moduleList.refresh(module, sendLinks, options);
                        },
                        inlineRefreshViewability: function() {
                            mem.variable.moduleList.refreshViewability();
                        },
                        inlineRemoveModule: function(id) {
                            mem.variable.moduleList.remove(id);
                        },
                        inlineIsModuleTracked: function(id) {
                            return mem.variable.moduleList.exists(id);
                        },
                        inlineGetModulesInfo: function() {
                            return mem.variable.moduleList.get();
                        },
                        inlineDestroy: function() {
                            mem.variable.moduleList.destroy();
                            if (mem.variable.viewabilityManager) {
                                mem.variable.viewabilityManager.destroy();
                            }
                        },
                        inlineReInit: function(iconf) {
                            inline.initialize(iconf, mem, true);
                        },
                        inlineSetRapidAttribute: function(attr) {
                            if (attr.keys) {
                                mem.conf.keys.absorb(attr.keys);
                            }
                            if (attr.spaceid) {
                                mem.conf.spaceid = attr.spaceid;
                            }
                            if (attr.referrer) {
                                mem.conf.referrer = attr.referrer.substring(0, util.MAX_VALUE_LENGTH);
                            }
                            if (attr.A_sid) {
                                mem.conf.keys.set("A_sid", attr.A_sid);
                                mem.conf.persist_asid = true;
                            }
                            if (attr.location) {
                                mem.conf.loc = attr.location;
                                mem.conf.keys.set("_w", util.rmProto(attr.location).substring(0, util.MAX_VALUE_LENGTH));
                            }
                        },
                        inlineClearRapidAttribute: function(attr) {
                            for (var n in attr) {
                                if (attr[n] === "keys") {
                                    var oldUrl = mem.conf.keys.get("_w");
                                    var oldASid = mem.conf.keys.get("A_sid");

                                    mem.conf.keys = new inline.PageParams();
                                    mem.conf.keys.set("_w", oldUrl);
                                    mem.conf.keys.set("A_sid", oldASid);
                                } else if (attr[n] === "referrer") {
                                    mem.conf.referrer = "";
                                } else if (attr[n] === "A_sid") {
                                    mem.conf.keys.set("A_sid", "");
                                    mem.conf.persist_asid = true;
                                } else if (attr[n] === "location") {
                                    mem.conf.loc = "";
                                    mem.conf.keys.set("_w", "");
                                }
                            }
                        },
                        inlineGetCurrentSID: function() {
                            return mem.conf.keys.get("A_sid");
                        },
                        inlineBeaconLinkViews: function(linkData, eventType, options, callback) {
                            options = options || {};
                            var blvPP = {};

                            if (options.pp) {
                                util.aug(blvPP, options.pp);
                            }
                            if (linkData.length === 0 && !options.event) {
                                return;
                            }
                            var newMods = [];

                            for (var i = 0; i < linkData.length; i++) {
                                var module = linkData[i];
                                var node = new inline.Node();

                                node.absorb_filter(module, function(elem) {
                                    return (elem !== "sec" && elem !== "_links");
                                });
                                var newLinks = [];
                                var pos = 1;

                                for (var j = 0; j < module._links.length; j++) {
                                    var link = module._links[j];
                                    var newLink = {
                                        viewable: true,
                                        data: {
                                            sec: module.sec,
                                            _p: pos++,
                                            A_lv: 2
                                        }
                                    };

                                    util.aug(newLink.data, link);
                                    newLinks.push(newLink);
                                }

                                var newMod = {
                                    moduleName: module.sec,
                                    moduleNode: node,
                                    links: newLinks,
                                    identifier: module.sec
                                };

                                newMods.push(newMod);
                            }
                            if (mem.conf.USE_RAPID && newMods) {
                                mem.variable.uploader.sendRapidPage(newMods, blvPP);
                            }
                            if (callback) {
                                callback.call();
                            }
                        },
                        getNode: function(el, allowpos) {
                            if (!el) {
                                return null;
                            }
                            if (allowpos === null) {
                                allowpos = false;
                            }
                            var ret = new inline.Node();
                            var dataOutcm = util.getAttribute(el, "data-action-outcome");

                            if (dataOutcm) {
                                ret.set("outcm", dataOutcm);
                            }
                            var keyStr = util.getAttribute(el, "data-ylk");

                            if (keyStr === null || keyStr.length === 0) {
                                return ret;
                            }
                            var parts = keyStr.split(mem.conf.ylk_pair_delim);

                            for (var i = 0; i < parts.length; i++) {
                                var p = parts[i].split(mem.conf.ylk_kv_delim);

                                if (p.length !== 2) {
                                    continue;
                                }
                                var key = p[0],
                                    val = p[1];

                                if (key === null || key === "" || val === null) {
                                    continue;
                                }

                                if (val.length > util.MAX_VALUE_LENGTH) {
                                    val = val.substring(0, util.MAX_VALUE_LENGTH);
                                }
                                if (key.length <= 8 && val.length <= util.MAX_VALUE_LENGTH) {
                                    if (key !== "_p" || allowpos) {
                                        ret.set(key, val);
                                    }
                                }
                            }
                            return ret;
                        },
                        getEventMapping: function(name) {
                            return mem.conf.eventMapping[name];
                        }
                    }
                });
            }

            mem.conf = {};
            setConfig();
            setVariable();
            setModule();
            setEventType();

            util.logTrace("[Yahoo.i13n] conf", mem.conf);
        },
        conf: {},
        define: {
            override: {},
            version: "9.2.1",
            rapidjp_version: "1.0.2",
            keys: null,
            referrer: null,
            spaceid: "0",
            yrid: "",
            oo: "0",
            nol: "0",
            yql_enabled: false,
            fing: false,
            USE_RAPID: false,
            linktrack_attribut: "text",
            tracked_mods: [],
            tracked_mods_viewability: [],
            viewability: false,
            viewability_time: 300,
            viewability_px: 50,
            lt_attr: "text",
            client_only: null,
            text_link_len: -1,
            yql_host: "logql.yahoo.co.jp",
            yql_path: "/v1/public/yql",
            click_timeout: 10000,
            compr_timeout: 300,
            compr_on: false,
            compr_type: "deflate",
            webworker_file: "rapidworker-1.2.js",
            nofollow_class: "rapidnofollow",
            no_click_listen: "rapid-noclick-resp",
            nonanchor_track_class: "rapid-nonanchor-lt",
            anc_pos_attr: "data-rapid_p",
            anc_v9y_attr: "data-v9y",
            deb: false,
            ldbg: false,
            addmod_timeout: 300,
            ult_token_capture: false,
            track_type: "data-tracktype",
            dwell_on: false,
            async_all_clicks: false,
            click_postmsg: {},
            apv: false,
            apv_time: 500,
            apv_px: 500,
            apv_always_send: false,
            apv_callback: null,
            ex: false,
            persist_asid: false,
            track_right_click: false,
            skip_attr: "data-rapid-skip",
            parse_dom: false,
            pageview_on_init: false,
            perf_navigationtime: 0,
            perf_commontime: null,
            perf_usertime: null,
            perf_resourcetime: 0,
            sample: {},
            loc: null,
            init_callback: null,
            ylk_kv_delim: ":",
            ylk_pair_delim: ";",
            eventMapping: {},
            yhlhttp: false
        }
    });
    return {
        EventTypes: {
            getEventByName: function(name) {
                "use strict";
                return inline.fn.getEventMapping(name);
            }
        },
        Rapid: function(conf) {
            "use strict";
            var mem = {};
            inline.initialize(conf, mem, false);
            return {
                init: function() {
                    mem.inlineInit();
                },
                beaconEvent: function(event, data, outcome, cb) {
                    mem.fn.inlineBeaconEvent(event, data, outcome, cb);
                },
                beaconClick: function(sec, slk, pos, ok, oc, callback) {
                    mem.fn.inlineBeaconClick(sec, slk, pos, ok, oc, callback);
                },
                addModules: function(mods, isPageview, options) {
                    mem.fn.inlineAddModules(mods, isPageview, options);
                },
                addModulesWithViewability: function(mods, isPageview, options) {
                    mem.fn.inlineAddModulesWithViewability(mods, isPageview, options);
                },
                refreshModule: function(module, isPageView, shouldSendLinkviews, options) {
                    mem.fn.inlineRefreshModule(module, isPageView, shouldSendLinkviews, options);
                },
                refreshViewability: function() {
                    mem.fn.inlineRefreshViewability();
                },
                removeModule: function(id) {
                    mem.fn.inlineRemoveModule(id);
                },
                isModuleTracked: function(id) {
                    return mem.fn.inlineIsModuleTracked(id);
                },
                getModulesInfo: function() {
                    return mem.fn.inlineGetModulesInfo();
                },
                destroy: function() {
                    mem.fn.inlineDestroy();
                },
                reInit: function(iconf) {
                    mem.fn.inlineReInit(iconf);
                },
                setRapidAttribute: function(attr) {
                    mem.fn.inlineSetRapidAttribute(attr);
                },
                clearRapidAttribute: function(attr) {
                    mem.fn.inlineClearRapidAttribute(attr);
                },
                getCurrentSID: function() {
                    return mem.fn.inlineGetCurrentSID();
                },
                beaconLinkViews: function(linkData, eventType, options, callback) {
                    mem.fn.inlineBeaconLinkViews(linkData, eventType, options, callback);
                }
            };
        }
    };
}());
