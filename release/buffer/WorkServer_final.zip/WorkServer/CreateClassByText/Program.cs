﻿using System;
using System.IO;

namespace CreateClassByText
{
    class Program
    {
        String2 buffer = null;
        public Program()
        {

        }
        public void Read(String filepath)
        {
            FileInfo file = new FileInfo(filepath);
            if (!file.Exists)
            {
                return;
            }
            using (FileStream stream = new FileStream(file.FullName, FileMode.Open, FileAccess.Read))
            {
                buffer = new String2((int)file.Length);
                stream.Read(buffer.ToBytes(), 0, (int)file.Length);
            }
        }
        public void Write(String filename, String namespaceName, String className)
        {
            if (buffer == null)
            {
                return;
            }
            buffer = buffer.Replace("\"", "\"\"");
            String2 temp = "using System;" + String2.CRLF;
            temp += String2.CRLF;
            temp += "namespace " + namespaceName + String2.CRLF;
            temp += "{" + String2.CRLF;
            temp += "    static class " + className + String2.CRLF;
            temp += "    {" + String2.CRLF;
            temp += "        private static String2 data = @\"" + buffer + "\";" + String2.CRLF;
            temp += "        public static String2 Data { get { return data; } }" + String2.CRLF;
            temp += "    }" + String2.CRLF;
            temp += "}";
            using (FileStream stream = new FileStream(filename, FileMode.Create, FileAccess.Write))
            {
                stream.Write(temp.ToBytes(), 0, temp.Length);
            }


        }
        static void Main(string[] args)
        {
            var p = new Program();
            p.Read(@"C:\work\study\index.html");
            p.Write(@"C:\work\study\index.cs","test","Test");
        }
    }
}
