using System;
using WebServer;

namespace WorkServer
{
    static class index
    {
        private static String2 data = @"﻿<!DOCTYPE>
<html>
<head>
    <meta name=""iewport""content=""idth=device-width,initial-scale=1,maximum=1,user-scalable=no""/>
    <meta http-equiv=""-UA-Compatible""content=""E=edge""/>
    <title>Work Board</title>
</head>
<body>
    Hello world
</body>
</html>";
        public static String2 Data { get { return data; } }
    }
}