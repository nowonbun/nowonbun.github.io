﻿using System;
using MySql.Data.MySqlClient;

namespace MysqlTesting.Dao.Interface
{
    public interface IDao
    {
        MySqlCommand Commander { get; }
        void SetConnectionString(String connectString);
    }
}
