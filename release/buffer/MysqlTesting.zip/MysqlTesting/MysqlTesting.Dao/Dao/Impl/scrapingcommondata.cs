using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Common;
using MysqlTesting.Dao.Entity;

namespace MysqlTesting.Dao.Dao.Impl
{
    class scrapingcommondataDao : Dao<scrapingcommondata>, IscrapingcommondataDao
    {
        public IList<scrapingcommondata> Select()
        {
            return base.SelectByEntity(null);
        }
        public int Insert(scrapingcommondata entity)
        {
            return base.InsertByEntity(entity);
        }
        public int Update(scrapingcommondata entity)
        {
            return base.UpdateByEntity(entity);
        }
        public int Delete(scrapingcommondata entity)
        {
            return base.DeleteByEntity(entity);
        }
    }
}