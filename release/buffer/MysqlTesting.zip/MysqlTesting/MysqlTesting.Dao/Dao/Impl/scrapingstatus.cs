using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Common;
using MysqlTesting.Dao.Entity;

namespace MysqlTesting.Dao.Dao.Impl
{
    class scrapingstatusDao : Dao<scrapingstatus>, IscrapingstatusDao
    {
        public IList<scrapingstatus> Select()
        {
            return base.SelectByEntity(null);
        }
        public int Insert(scrapingstatus entity)
        {
            return base.InsertByEntity(entity);
        }
        public int Update(scrapingstatus entity)
        {
            return base.UpdateByEntity(entity);
        }
        public int Delete(scrapingstatus entity)
        {
            return base.DeleteByEntity(entity);
        }
    }
}