using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Common;
using MysqlTesting.Dao.Entity;

namespace MysqlTesting.Dao.Dao.Impl
{
    class daotestDao : Dao<daotest>, IdaotestDao
    {
        public IList<daotest> Select()
        {
            return base.SelectByEntity(null);
        }
        public int Insert(daotest entity)
        {
            return base.InsertByEntity(entity);
        }
        public int Update(daotest entity)
        {
            return base.UpdateByEntity(entity);
        }
        public int Delete(daotest entity)
        {
            return base.DeleteByEntity(entity);
        }
    }
}