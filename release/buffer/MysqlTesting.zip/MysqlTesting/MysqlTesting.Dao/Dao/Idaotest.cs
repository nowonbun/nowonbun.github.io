using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Entity;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Dao
{
    [ImplementDao("daotestDao")]
    public interface IdaotestDao
    {
        IList <daotest> Select();

        int Insert(daotest entity);

        int Update(daotest entity);

        int Delete(daotest entity);
    }
}