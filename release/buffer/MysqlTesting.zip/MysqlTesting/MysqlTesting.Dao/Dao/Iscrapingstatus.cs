using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Entity;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Dao
{
    [ImplementDao("scrapingstatusDao")]
    public interface IscrapingstatusDao
    {
        IList <scrapingstatus> Select();

        int Insert(scrapingstatus entity);

        int Update(scrapingstatus entity);

        int Delete(scrapingstatus entity);
    }
}