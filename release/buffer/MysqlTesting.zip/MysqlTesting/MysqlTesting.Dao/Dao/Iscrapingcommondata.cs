using System;
using System.Collections.Generic;
using MysqlTesting.Dao.Entity;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Dao
{
    [ImplementDao("scrapingcommondataDao")]
    public interface IscrapingcommondataDao
    {
        IList <scrapingcommondata> Select();

        int Insert(scrapingcommondata entity);

        int Update(scrapingcommondata entity);

        int Delete(scrapingcommondata entity);
    }
}