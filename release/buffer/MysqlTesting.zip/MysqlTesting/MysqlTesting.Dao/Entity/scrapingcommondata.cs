using System;
using MySql.Data.MySqlClient;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Entity
{
    [Table("scrapingcommondata")]
    public class scrapingcommondata
    {
        [Column("KEYCODE",  MySqlDbType.String, LogicalName = "KEYCODE", Key = true)]
        private string keycode;
        [Column("KEYINDEX",  MySqlDbType.Int32, LogicalName = "KEYINDEX", Key = true)]
        private int keyindex;
        [Column("DATA",  MySqlDbType.VarChar, LogicalName = "DATA")]
        private string data;
        [Column("CREATEDATE",  MySqlDbType.DateTime, LogicalName = "CREATEDATE")]
        private DateTime? createdate;

        public string Keycode
        {
            get { return this.keycode; }
            set { this.keycode = value; }
        }
        public int Keyindex
        {
            get { return this.keyindex; }
            set { this.keyindex = value; }
        }
        public string Data
        {
            get { return this.data; }
            set { this.data = value; }
        }
        public DateTime? Createdate
        {
            get { return this.createdate; }
            set { this.createdate = value; }
        }
    }
}
