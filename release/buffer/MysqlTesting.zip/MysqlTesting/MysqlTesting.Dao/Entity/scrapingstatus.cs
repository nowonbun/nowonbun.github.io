using System;
using MySql.Data.MySqlClient;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Entity
{
    [Table("scrapingstatus")]
    public class scrapingstatus
    {
        [Column("KEYCODE",  MySqlDbType.String, LogicalName = "KEYCODE", Key = true)]
        private string keycode;
        [Column("STARTTIME",  MySqlDbType.DateTime, LogicalName = "STARTTIME")]
        private DateTime? starttime;
        [Column("ENDTIME",  MySqlDbType.DateTime, LogicalName = "ENDTIME")]
        private DateTime? endtime;
        [Column("SCODE",  MySqlDbType.String, LogicalName = "SCODE")]
        private string scode;
        [Column("SID",  MySqlDbType.VarChar, LogicalName = "SID")]
        private string sid;
        [Column("STATUS",  MySqlDbType.String, LogicalName = "STATUS")]
        private string status;

        public string Keycode
        {
            get { return this.keycode; }
            set { this.keycode = value; }
        }
        public DateTime? Starttime
        {
            get { return this.starttime; }
            set { this.starttime = value; }
        }
        public DateTime? Endtime
        {
            get { return this.endtime; }
            set { this.endtime = value; }
        }
        public string Scode
        {
            get { return this.scode; }
            set { this.scode = value; }
        }
        public string Sid
        {
            get { return this.sid; }
            set { this.sid = value; }
        }
        public string Status
        {
            get { return this.status; }
            set { this.status = value; }
        }
    }
}
