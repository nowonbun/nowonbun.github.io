using System;
using MySql.Data.MySqlClient;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Entity
{
    [Table("daotest")]
    public class daotest
    {
        [Column("idx",  MySqlDbType.Int32, LogicalName = "idx", Key = true)]
        private int idx;
        [Column("data",  MySqlDbType.VarChar, LogicalName = "data")]
        private string data;

        public int Idx
        {
            get { return this.idx; }
            set { this.idx = value; }
        }
        public string Data
        {
            get { return this.data; }
            set { this.data = value; }
        }
    }
}
