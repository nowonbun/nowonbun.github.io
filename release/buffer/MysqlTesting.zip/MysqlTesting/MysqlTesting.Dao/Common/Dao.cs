﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Reflection;
using MySql.Data.MySqlClient;
using System.Linq;
using MysqlTesting.Dao.Interface;
using MysqlTesting.Dao.Attribute;

namespace MysqlTesting.Dao.Common
{
    abstract class Dao<T> : IDao
    {
        private MySqlCommand cmd;
        private bool isTransaction = false;
        private Dictionary<Type, Dictionary<String, FieldInfo>> flyweight = new Dictionary<Type, Dictionary<string, FieldInfo>>();

        public Dao()
        {
            cmd = new MySqlCommand();
            cmd.Connection = new MySqlConnection();
        }
        public void SetConnectionString(String connectString)
        {
            cmd.Connection.ConnectionString = connectString;
        }

        public MySqlCommand Commander
        {
            get
            {
                return cmd;
            }
        }

        protected MySqlParameter CreateParameter(String name, Object value, MySqlDbType type)
        {
            MySqlParameter ret = new MySqlParameter();
            ret.ParameterName = name;
            ret.MySqlDbType = type;
            ret.Value = value;
            return ret;
        }

        protected int InsertByEntity(T entity, Boolean scope = false)
        {
            StringBuilder sb = new StringBuilder();
            StringBuilder value = new StringBuilder();
            Type clsTp = typeof(T);
            Table table = clsTp.GetCustomAttribute(typeof(Table)) as Table;

            sb = sb.Append(" insert ").Append(" into ").Append(table.TableName).Append(" (");
            value = value.Append(" values (");
            if (entity == null)
            {
                throw new Exception("Not entity.");
            }
            List<FieldInfo> pis = GetFieldsInfo(entity);
            IList<MySqlParameter> parameter = new List<MySqlParameter>();
            Boolean c = true;
            foreach (FieldInfo pi in pis)
            {
                if (c)
                {
                    c = false;
                }
                else
                {
                    sb = sb.Append(",");
                    value = value.Append(",");
                }
                Column cn = pi.GetCustomAttribute(typeof(Column)) as Column;
                sb = sb.Append(cn.ColumnName);
                String columnName = "@" + cn.ColumnName;
                value = value.Append(columnName);
                parameter.Add(this.CreateParameter(columnName, pi.GetValue(entity), cn.ColumnType));
            }
            sb = sb.Append(")");
            value.Append(")");
            sb.Append(value);
            if (scope)
            {
                sb = sb.Append(";");
                sb = sb.Append("select scope_identity();");
            }
            int ret = -1;
            this.Transaction(() =>
            {
                if (scope)
                {
                    this.ExcuteReader(sb.ToString(), parameter, dr =>
                    {
                        ret = Convert.ToInt32(dr.GetDecimal(0));
                    });
                }
                else
                {
                    ret = this.ExcuteNonReader(sb.ToString(), parameter);
                }
            });
            return ret;
        }

        protected int UpdateByEntity(T entity)
        {
            StringBuilder sb = new StringBuilder();
            Type clsTp = typeof(T);
            Table table = clsTp.GetCustomAttribute(typeof(Table)) as Table;
            IList<FieldInfo> fields = GetFieldsInfo(entity);
            StringBuilder where = new StringBuilder();
            StringBuilder set = new StringBuilder();
            IList<MySqlParameter> parameter = new List<MySqlParameter>();
            foreach (FieldInfo field in fields)
            {
                Column cn = field.GetCustomAttribute(typeof(Column)) as Column;
                String columnName = "@" + cn.ColumnName;
                if (cn.Key)
                {
                    if (where.Length == 0)
                    {
                        where.Append(" WHERE ");
                    }
                    else
                    {
                        where.Append(" AND ");
                    }
                    where = where.Append(" ").Append(cn.ColumnName).Append(" = ").Append(columnName);
                }
                else
                {
                    if (set.Length == 0)
                    {
                        set.Append(" SET ");
                    }
                    else
                    {
                        set.Append(" , ");
                    }
                    set = set.Append(" ").Append(cn.ColumnName).Append(" = ").Append(columnName);
                }
                parameter.Add(CreateParameter(columnName, field.GetValue(entity), cn.ColumnType));
            }
            sb.Append(" UPDATE ").Append(table.TableName).Append(" ");
            sb.Append(set);
            sb.Append(where);
            int ret = -1;
            this.Transaction(() =>
            {
                ret = this.ExcuteNonReader(sb.ToString(), parameter);
            });
            return ret;
        }

        protected int DeleteByEntity(T entity, bool notflag = false)
        {
            Type clsTp = typeof(T);
            Table table = clsTp.GetCustomAttribute(typeof(Table)) as Table;
            StringBuilder sb = new StringBuilder();
            StringBuilder where = new StringBuilder();
            IList<MySqlParameter> parameter = new List<MySqlParameter>();

            sb.Append(" DELETE FROM ");
            sb.Append(table.TableName);
            if (entity != null)
            {
                List<FieldInfo> pis = GetFieldsInfo(entity);

                foreach (FieldInfo pi in pis)
                {
                    if (where.Length == 0)
                    {
                        where.Append(" WHERE ");
                    }
                    else
                    {
                        where.Append(" AND ");
                    }
                    Column cn = pi.GetCustomAttribute(typeof(Column)) as Column;
                    String columnName = "@" + cn.ColumnName;
                    where = where.Append(" ").Append(cn.ColumnName);
                    if (notflag)
                    {
                        where = where.Append(" <> ");
                    }
                    else
                    {
                        where = where.Append(" = ");
                    }
                    where = where.Append(columnName);

                    parameter.Add(this.CreateParameter(columnName, pi.GetValue(entity), cn.ColumnType));
                }
                sb.Append(where);
            }
            int ret = -1;
            Transaction(() =>
            {
                ret = this.ExcuteNonReader(sb.ToString(), parameter);
            });
            return ret;
        }

        protected IList<T> SelectByEntity(T entity, bool notflag = false)
        {
            cmd.Parameters.Clear();
            IList<T> ret = new List<T>();
            Type clsTp = typeof(T);
            Table table = clsTp.GetCustomAttribute(typeof(Table)) as Table;
            StringBuilder sb = new StringBuilder();
            StringBuilder where = new StringBuilder();
            IList<MySqlParameter> parameter = new List<MySqlParameter>();

            sb.Append(" SELECT ");
            sb.Append(" * ");
            sb.Append(" FROM ");
            sb.Append(table.TableName);
            if (entity != null)
            {
                List<FieldInfo> pis = GetFieldsInfo(entity);

                foreach (FieldInfo pi in pis)
                {
                    if (where.Length == 0)
                    {
                        where.Append(" WHERE ");
                    }
                    else
                    {
                        where.Append(" AND ");
                    }
                    Column cn = pi.GetCustomAttribute(typeof(Column)) as Column;
                    String columnName = "@" + cn.ColumnName;
                    where = where.Append(" ").Append(cn.ColumnName);
                    if (notflag)
                    {
                        where = where.Append(" <> ");
                    }
                    else
                    {
                        where = where.Append(" = ");
                    }
                    where = where.Append(columnName);

                    parameter.Add(this.CreateParameter(columnName, pi.GetValue(entity), cn.ColumnType));
                }
                sb.Append(where);
            }
            this.Transaction(() =>
            {
                this.ExcuteReader(sb.ToString(), parameter, (dr) =>
                {
                    T cls = (T)Activator.CreateInstance(clsTp);
                    for (int i = 0; i < dr.FieldCount; i++)
                    {
                        if (dr.IsDBNull(i))
                        {
                            continue;
                        }
                        String columnName = dr.GetName(i);
                        GetFieldInfo(cls, columnName).SetValue(cls, dr.GetValue(i));
                    }
                    ret.Add(cls);
                });
            });
            return ret;
        }

        private List<FieldInfo> GetFieldsInfo(Object cls)
        {
            List<FieldInfo> ret = new List<FieldInfo>();
            Type clsType = cls.GetType();
            FieldInfo[] pis = clsType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (FieldInfo pi in pis)
            {
                Column c = pi.GetCustomAttribute(typeof(Column)) as Column;
                if (c == null)
                {
                    continue;
                }
                if (c.Identity)
                {
                    continue;
                }
                Object data = pi.GetValue(cls);
                if (data != null)
                {
                    ret.Add(pi);
                }
            }
            return ret;
        }

        private FieldInfo GetFieldInfo(Object cls, String columnName)
        {
            if (!flyweight.ContainsKey(cls.GetType()))
            {
                flyweight.Add(cls.GetType(), new Dictionary<string, FieldInfo>());
            }
            Dictionary<string, FieldInfo> subFlyweight = flyweight[cls.GetType()];
            if (!subFlyweight.ContainsKey(columnName))
            {
                FieldInfo pi = cls.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance).AsParallel().First(item =>
                {
                    Column cn = item.GetCustomAttribute(typeof(Column)) as Column;
                    if (Object.Equals(columnName.ToUpper(), cn.ColumnName.ToUpper()))
                    {
                        return true;
                    }
                    return false;
                });
                subFlyweight.Add(columnName, pi);
            }
            return subFlyweight[columnName];
        }

        protected void Transaction(Action action)
        {
            cmd.Parameters.Clear();
            try
            {
                cmd.Connection.Open();
                try
                {
                    cmd.Transaction = cmd.Connection.BeginTransaction();
                    isTransaction = true;
                    action();
                    cmd.Transaction.Commit();
                }
                catch (Exception e)
                {
                    cmd.Transaction.Rollback();
                    throw e;
                }
                finally
                {
                    isTransaction = false;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                cmd.Connection.Close();
            }
        }
        protected int ExcuteReader(String query, IList<MySqlParameter> parameter, Action<MySqlDataReader> dataReader)
        {
            if (!isTransaction)
            {
                throw new Exception("not transaction");
            }
            int count = 0;
            cmd.CommandText = query;
            if (parameter != null)
            {
                cmd.Parameters.AddRange(parameter.ToArray());
            }
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    dataReader(dr);
                    count++;
                }
            }
            return count;
        }
        protected int ExcuteNonReader(String query, IList<MySqlParameter> parameter)
        {
            if (!isTransaction)
            {
                throw new Exception("not transaction");
            }
            cmd.CommandText = query;
            if (parameter != null)
            {
                cmd.Parameters.AddRange(parameter.ToArray());
            }
            return cmd.ExecuteNonQuery();
        }

    }
}
