﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MysqlTesting.Dao.Common;
using MysqlTesting.Dao.Dao;
using MysqlTesting.Dao.Entity;

namespace MysqlTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            IdaotestDao dao = FactoryDao.CreateInstance("Server=localhost;Port=3306; Database=test;Uid=root;Pwd=1234;").GetDao("MysqlTesting.Dao.Dao.Impl.daotestDao") as IdaotestDao;
            daotest entity = new daotest();
            entity.Idx = 2;
            entity.Data = "TEST";

            dao.Insert(entity);

            var a = dao.Select();

            foreach(var b in a)
            {
                Console.WriteLine(b.Idx.ToString() + "    " + b.Data);
            }

            entity.Data = "TESTTEST";
            dao.Update(entity);
            a = dao.Select();

            foreach (var b in a)
            {
                Console.WriteLine(b.Idx.ToString() + "    " + b.Data);
            }

            dao.Delete(entity);

            Console.WriteLine("Press Any Key...");
            Console.ReadKey();
        }
    }
}
