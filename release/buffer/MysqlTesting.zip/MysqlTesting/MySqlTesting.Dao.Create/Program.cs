﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySqlTesting.Dao.Create
{
    class Program
    {
        static void Main(string[] args)
        {
            String str = "Server=localhost;Port=3306; Database=test;Uid=root;Pwd=1234; ";
            AbstractDaoCreate run = new CreateDaoByDatabase(str);

            run.Run("c:\\work\\test\\IDao");

            run = new CreateEntityByDatabase(str);
            run.Run("c:\\work\\test\\Entity");

            Console.WriteLine("Press Any Key...");
            Console.ReadKey();
        }
    }
}
