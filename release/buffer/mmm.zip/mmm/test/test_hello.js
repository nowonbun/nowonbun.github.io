"use strict";
var assert = require('assert');
var dummy = require('../src/libs/dummy');

describe('test hello', function() {
    it('add', function() {
        var ans = dummy.add(1, 1);
        assert.equal(ans, 2);
    });
    it('sub', function() {
        var ans = dummy.sub(1, 1);
        assert.equal(ans, 0);
    });
    it('mul', function() {
        var ans = dummy.mul(1, 1);
        assert.equal(ans, 1);
    });
    it('div', function() {
        var ans = dummy.div(1, 1);
        assert.equal(ans, 1);
    });
    var repair_pattern = /(Repair#[1-9]+|AntiEntropy(Stage|Sessions)\s+[1-9]+)/i;
    it('match? AntiEntropySessions', function() {
        var ans = 'AntiEntropySessions     1';
        var re = repair_pattern;
        var result = ans.match(re);
        console.log(result);
        assert.notEqual(result, null);
    });
    it('match? AntiEntropyStage', function() {
        var ans = 'AntiEntropyStage     1';
        var re = repair_pattern;
        var result = ans.match(re);
        console.log(result);
        assert.notEqual(result, null);
    });
    it('match? Repair', function() {
        var ans = 'Repair#1     1';
        var re = repair_pattern;
        var result = ans.match(re);
        console.log(result);
        assert.notEqual(result, null);
    });
    var ip_pattern = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i;
    it('match? ip', function() {
      var ans = '/127.0.0.1';
      var re = ip_pattern;
      var result = ans.match(re);
      console.log(result);
      assert.notEqual(result, null);
    });
    var host_pattern = /\s([a-z]|-|[0-9]|\.)+yahoo.co.jp/i;
    it('match? host', function() {
      var ans = '235.108.21.172.in-addr.arpa domain name pointer cassandra-03.direct30.kvs.ssk.ynwm.yahoo.co.jp.';
      var re = host_pattern;
      var result = ans.match(re);
      console.log(result);
      assert.notEqual(result, null);
    });
    var pkg_pattern = /\.[0-9]{1,3}$/i;
    it('match? the build version (2 digit)', function() {
        var ans = 'jp_cassandra-1.2.15.75';
        var re = pkg_pattern;
        var result = ans.match(re);
        console.log(result);
        assert.equal(result, '.75');
    });
    it('match? the build version (1 digit)', function() {
        var ans = 'jp_cassandra-3.0.14.1';
        var re = pkg_pattern;
        var result = ans.match(re);
        console.log(result);
        assert.equal(result, '.1');
    });
});
