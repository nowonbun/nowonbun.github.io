'use strict';
var yby = require("yby_jp");
var cookieParser = require('cookie-parser');
var express    = require('express');
var http       = require('http');
var app  = express();
var server = http.Server(app);
var log = require('logger')('YkvsOpstool', 'TRACE');
var io = require('socket.io').listen(server);
var config = require('./libs/config');
var roles = require('./libs/roles');
var ysecure = require('ysecure');
var MESSAGES = require('./libs/messages');
io.set('transports', ['xhr-polling','jsonp-polling','polling']);
module.exports = server;
module.exports.io = io;
var users = module.exports.users = {};
var mysql_password = ysecure.getKey('kvs.opstool.mysql.opstooluser');
var mysql      = require('mysql');
var db_config = {
  host     : config.mysql.host,
  user     : 'opstool',
  database : 'opstool',
  password: mysql_password,
  connectionLimit : 10
};
var connection = mysql.createPool(db_config);
module.exports.con = connection;

var yiv = require('yiv');
var ops = require("./libs/operation.js");
var title = 'YKVS Opstool';
var ybyInstance = yby.createInstance({appid: '3036', logLevel: yby.LOG_ERROR});

app.use(cookieParser());
app.use(express.static(__dirname + '/public'));
app.set('view engine', 'jade');
app.set('views', __dirname + '/views');

/*クッキ取得関数*/
function getYbyCookie(req, res) {
    var remoteAddress = req.headers["y-ra"] || req.headers.yahooremoteip || req.connection.remoteAddress;
    return ybyInstance.parseAndValidate(req.cookies.YBY, remoteAddress);
}

/*権限取得関数*/
function getPermission(req, res) {
    var ybyCookie = getYbyCookie(req, res);
    console.log("status = " + ybyCookie.getStatus());
    // status == 0 権限あり != 0 権限なし
    return ybyCookie.getStatus() == 0;
}

/*スケジュール画面に遷移関数*/
function showSchedules(req, res) {
  connection.query("SELECT * FROM schedules", function(err, rows) {
    var schedules = rows;
    connection.query("SELECT DISTINCT cluster FROM nodes", function(err, rows) {
      res.render('scheduler', { title: title, schedules: schedules ,clusters: rows, schedulerStatus: config.scheduler.isActive, isSchedule: schedules.length!=0, permission: getPermission(req, res)});
    });
  });
}

/*ホストリスト画面に遷移関数*/
function showHostlist(req, res) {
  ops.getNodetoolVersions(
    function(vers) {
      connection.query("SELECT * FROM nodes", function(err, rows) {
        res.render('hostlist', { title: title, versions: vers, nodes: rows, permission: getPermission(req, res) });
      });
    }
  );
}

/*Index(メイン)*/
app.get('/', function(req, res) {
  var user = req.yby.userid;
  connection.query("SELECT DISTINCT cluster FROM nodes ORDER BY cluster", function(err, rows) {
    console.log(err);
    res.render('index', { title: title, nodes: rows, clusters: rows, user: user, permission: getPermission(req, res)});
  });
});

/*スケジュール画面*/
app.get('/scheduler', function(req, res) {
  showSchedules(req, res);
});

/*スケジュール削除要請　削除完了するとリストに遷移*/
app.get('/deleteschedule', function(req, res) {
  if(!getPermission(req, res)){
      console.log(req.yby.userid + " fail to delete schedule:" + req.query.host + " " + req.query.cluster + " :Forbidden - Not permission");
      res.status(403).send("Forbidden - Not permission");
      return;
  }
  var scheduleId = yiv.yiv_get_stripped(req.query.scheduleid, yiv.YIV_FLAG_NONE);
  connection.query("DELETE FROM schedules where id = ?", scheduleId, function(err, rows) {
    showSchedules(req, res);
    log.trace('err=' + err + 'rows=' + rows);
  });
});

/*スケジュール起動　起動完了するとリストに遷移*/
app.get('/runschedule', function(req, res) {
  if(!getPermission(req, res)){
      console.log(req.yby.userid + " fail to run schedule:" + req.query.host + " " + req.query.cluster + " :Forbidden - Not permission");
      res.status(403).send("Forbidden - Not permission");
      return;
  }
  var scheduleId = yiv.yiv_get_stripped(req.query.scheduleid, yiv.YIV_FLAG_NONE);
  connection.query("UPDATE schedules SET nextstarttime=? where id = ?", [new Date(), scheduleId],
    function(err, rows) {
      if (err) {
        console.log("failed to update nextstarttime of schedule " + scheduleId);
      }
      log.trace('rows=' + rows);
      showSchedules(req, res);
    });
});

/*スケジュール活性化　活性するとリストに遷移*/
app.get('/controlscheduler', function(req, res) {
  if(!getPermission(req, res)){
      console.log(req.yby.userid + " fail to control schedule:" + req.query.host + " " + req.query.cluster + " :Forbidden - Not permission");
      res.status(403).send("Forbidden - Not permission");
      return;
  }
  if(req.query.schedulerStatus) {
    console.log(req.yby.userid + " start scheduler.");
    config.scheduler.isActive = true;
  } else {
    console.log(req.yby.userid + " stop scheduler.");
    config.scheduler.isActive = false;
  }
  showSchedules(req, res);
});

/*スケジュール追加　追加完了するとリストに遷移*/
app.get('/addschedule', function(req, res) {
  if(!getPermission(req, res)){
    console.log(req.yby.userid + " fail to add schedule:" + req.query.host + " " + req.query.cluster + " :Forbidden - Not permission");
    res.status(403).send("Forbidden - Not permission");
    return;
  }
  var cluster = yiv.yiv_get_js_string(req.query.cluster, yiv.YIV_FLAG_NONE);
  var nexttime = req.query.nexttime;
  var interval = req.query.interval;
  var doCompaction = req.query.docompaction ? 1 : 0;
  var status = global.SCHEDULE_NOT_RUNNING;

  var sql = ("INSERT INTO schedules (cluster, nextstarttime, scheduleinterval, docompaction, status) VALUES(?, ?, ?, ?, ?)");
  connection.query(sql, [cluster, nexttime, interval, doCompaction, status], function(err) {
    if(err) {
      res.render('addnode', { title: title, result: 'Registration failed: ' + err, permission: getPermission(req, res)});
      console.log(err);
    } else {
      console.log(req.yby.userid + " register repair schedule:" + " " + req.query.cluster);
      showSchedules(req, res);
    }
  });
});

/*repairプロセスに遷移*/
app.get('/repair', function(req, res) {
  connection.query("SELECT * FROM repairs WHERE id IN (SELECT MAX(id) FROM repairs GROUP BY cluster) ORDER BY id DESC LIMIT 100", function(err, rows) {
    res.render('repair', { title: title, repairs: rows, isRepairs: rows.length!=0, permission: getPermission(req, res) });
  });
});

/*コマンド履歴に遷移*/
app.get('/history', function(req, res) {
  connection.query("SELECT * FROM histories ORDER BY id DESC LIMIT 100", function(err, rows) {
    res.render('history', { title: title, hists: rows, permission: getPermission(req, res) });
  });
});

/*ホストリストに遷移*/
app.get('/hostlist', function(req, res) {
  showHostlist(req, res);
});

/*ホスト削除　ホスト削除するとホストリストに遷移*/
app.get('/deletehost', function(req, res) {
  if(!getPermission(req, res)){
    console.log(req.yby.userid + ' fail to delete ' + req.query.host + " :Forbidden - Not permission");
    res.status(403).send("Forbidden - Not permission");
    return;
  }
  connection.query("DELETE FROM nodes WHERE host=?", req.query.host, function(err) {
    if(err){
      console.log(req.yby.userid + ' fail to delete ' + req.query.host);
      console.log(err);
    }
    connection.query("SELECT * FROM nodes", function(err, rows) {
      log.trace('err=' + err + 'rows=' + rows);
      console.log(req.yby.userid + ' delete ' + req.query.host);
      showHostlist(req, res);
    });
  });
});

/*ホスト追加*/
app.get('/addnode', function(req, res) {
  if(!getPermission(req, res)){
    console.log(req.yby.userid + " fail to register:" + req.query.host + " " + req.query.cluster + " :Forbidden - Not permission");
    res.status(403).send("Forbidden - Not permission");
    return;
  }
  var host = yiv.yiv_get_hostport(req.query.host, yiv.YIV_FLAG_NONE);
  var version = yiv.yiv_get_stripped(req.query.version, yiv.YIV_FLAG_NONE);
  var cluster = yiv.yiv_get_js_string(req.query.cluster, yiv.YIV_FLAG_NONE);
  var auth = req.query.auth?1:0;
  var sql = ("INSERT INTO nodes(host, version, cluster, need_auth) VALUES(?, ?, ?, ?)");
  connection.query(sql, [host, version, cluster, auth], function(err) {
    if(err) {
      res.render('addnode', { title: title, result: 'Registration failed: ' + err, permission: getPermission(req, res)});
      console.log(err);
    } else {
      console.log(req.yby.userid + " register:" + req.query.host + " " + req.query.cluster);
      res.render('addnode', { title: title, result: 'Registration done.', permission: getPermission(req, res)});
    }
  });
});

/*ソケット通信*/
io.sockets.on('connection', function(socket){
  /*クッキ取得関数(socket用)*/
  function getYbySocket(sock) {
    function getYBY(){
        var temp = sock.handshake.headers.cookie.split(';');
        for(var idx in temp){
            var buffer = temp[idx].trim();
	        var pos = buffer.indexOf('=');
            if(buffer.substr(0,pos) === 'YBY'){
                return buffer.substr(pos+1, buffer.length);
            }
        }
        return undefined;
    }
    var remoteAddress = sock.request.headers["y-ra"] || sock.request.headers.yahooremoteip || sock.request.connection.remoteAddress;
    return ybyInstance.parseAndValidate(getYBY(), remoteAddress);
  }

  /*権限取得関数(socket用)*/
  function getPermissionSocket(sock) {
    var ybyCookie = getYbySocket(sock);
    console.log("status = " + ybyCookie.getStatus());
    // status == 0 権限あり != 0 権限なし
    return ybyCookie.getStatus() == 0;
  }
  console.log(socket.request.yby.userid + " connected");
  socket.username = socket.request.yby.userid + '_' + Math.random().toString(36).slice(-8);
  users[socket.username] = socket.id;

  socket.on('cluster', function(msg) {
    connection.query("SELECT * FROM nodes WHERE cluster=?", msg.cluster, function(err, rows) {
      if(err) {
        console.log(err);
        return;
      }
      ops.getRingStatus(socket.username, msg.cluster, rows, global.EVENT_STATUS, ops.sendStatusToClient);
    });
  });

  socket.on('nodetooltask' ,function(msg) {
    if(!getPermissionSocket(socket)){
      ops.sendMessage(socket.username, "Not permission", MESSAGES.MESSAGE_CRIT);
      return;
    }
    console.log(socket.username.split('_')[0] + ' executes ' + msg.task + ' to ' + msg.cluster);
    connection.query("SELECT * FROM nodes WHERE cluster=?", msg.cluster, function(err, rows) {
      if(err) {
        console.log(err);
        return;
      }
      if(msg.nodes.length > 0) {
        ops.execTaskNode(socket.username, msg.cluster, msg.nodes,
          rows[0].need_auth === 1, [msg.task]);
      } else {
        ops.getRingStatus(socket.username, msg.cluster,
          rows, global.EVENT_STATUS, ops.execTaskCluster, [msg.task]);
      }
    });
  });
  /*サーバ削除コマンド*/
  
  socket.on('remove', function(msg) {
    if(!getPermissionSocket(socket)){
      ops.sendMessage(socket.username, "Not permission", MESSAGES.MESSAGE_CRIT);
      return;
    }
    var removenode = require("./libs/commands/removenode.js");
    if(msg.id.match(/^[a-f0-9\-]+$/)) {
      removenode.removeNode(socket.username, msg.id, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation remove:' + msg.id);
    }
  });

  /*再起動コマンド*/
  socket.on('restart', function(msg){
    if(!getPermissionSocket(socket)){
      ops.sendMessage(socket.username, "Not permission", MESSAGES.MESSAGE_CRIT);
      return;
    }
    var restart = require("./libs/commands/restartnode.js");
    if(msg.id.match(/^[a-f0-9\-]+$/)) {
      restart.restartNode(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation remove:' + msg.id);
    }
  });

  socket.on('remove_force', function(msg) {
    if(!getPermissionSocket(socket)){
      ops.sendMessage(socket.username, "Not permission", MESSAGES.MESSAGE_CRIT);
      return;
    }
    var removenode = require("./libs/commands/removenode.js");
    removenode.removeNodeForce(
      socket.username,
      msg.execHost,
      msg.cluster
    );
  });

  socket.on('decommission', function(msg) {
    var decom = require("./libs/commands/decommission.js");
    if(!getPermissionSocket(socket)){
      ops.sendMessage(socket.username, "No permission", MESSAGES.MESSAGE_CRIT);
      return;
    }
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      decom.decommissionNode(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation decommission:' + msg.host);
    }
  });

  socket.on('tpstats', function(msg) {
    var tpstats = require("./libs/commands/tpstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      tpstats.tpstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation tpstats:' + msg.host);
    }
  });

  socket.on('tablestats', function(msg) {
    var tablestats = require("./libs/commands/tablestats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      tablestats.tablestats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation tablestats:' + msg.host);
    }
  });

  socket.on('info', function(msg) {
    var info = require("./libs/commands/info.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      info.info(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation info:' + msg.host);
    }
  });

  socket.on('netstats', function(msg) {
    var netstats = require("./libs/commands/netstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      netstats.netstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation netstats:' + msg.host);
    }
  });

  socket.on('compactionstats', function(msg) {
    var compactionstats = require("./libs/commands/compactionstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      compactionstats.compactionstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation compactionstats:' + msg.host);
    }
  });

  socket.on('describecluster', function(msg) {
    var describecluster = require("./libs/commands/describecluster.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      describecluster.describecluster(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation describecluster:' + msg.host);
    }
  });

  socket.on('gossipinfo', function(msg) {
    var gossipinfo = require("./libs/commands/gossipinfo.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      gossipinfo.gossipinfo(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation gossipinfo:' + msg.host);
    }
  });

  socket.on('disconnect', function () {
    delete users[socket.username];
    console.log(socket.username + ' disconenct');
  });
});