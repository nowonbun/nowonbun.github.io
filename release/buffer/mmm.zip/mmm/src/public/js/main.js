var socket = io();
function getAuthority(){
    return $('#permission').val() === 'true';
}
function showLoading() {
  if(document.getElementsByClassName('loading').length == 0){
    location.href = '#top';
    var node = document.createElement('div');
    node.className = 'loading';
    node.innerHTML = '<div class=area><div class=img></div></div>';
    document.body.appendChild(node);
  }
}
function hideLoading() {
  var list = document.getElementsByClassName('loading');
  for(var i in list){
    var element = list[i];
    if(element.parentNode !== undefined){
      element.parentNode.removeChild(element);
    }
  }
}

function disableAllButton() {
  $('button').attr('disabled', true);
  showLoading();
}

function enableAllButton() {
  hideLoading();
  $('button').attr('disabled', false);
}

function setMessage(msg, styleClass) {
  $('#message').attr("class", styleClass + ' lead');
  $('#message').text(msg);
}

function removeNode(id, cluster) {
  if(window.confirm('Remove node?')) {
    socket.emit('remove', {id: id, cluster: cluster});
  }
}

function restartNode(id, host, cluster) {
  if(window.confirm('Restart node?')) {
    socket.emit('restart', {id: id,host: host ,cluster: cluster});
  }
}

function decommissionNode(host, cluster) {
  if(window.confirm('Decommission node?')) {
    socket.emit('decommission', {host: host, cluster: cluster});
  }
}

var isRemovingNode = false;
function removeNodeForce(execHost, cluster) {
  if (isRemovingNode) {
    return;
  }
  isRemovingNode = window.confirm('Remove node forcedly?');
  if(!isRemovingNode) {
    return;
  }
  socket.emit('remove_force', {execHost: execHost, cluster: cluster}, function () {
    enableAllButton();
    $('#remove_force_' + execHost + '_' + cluster).remove();
    isRemovingNode = false;
  });
}

socket.on('disable_button', function(msg) {
  disableAllButton();
});

socket.on('enable_button', function(msg) {
  enableAllButton();
});

socket.on('result', function(msg){
  console.log("result");
  $('#result').text(msg);
});

socket.on('message', function(msg) {
  setMessage(msg.message, msg.styleClass);
});

socket.on('currentTask', function(msg) {
  $('#current_task').find('tr').remove();
  if (msg.tasks.length === 0) {
    $('#current_task').append('<tr><td>Nothing</td></tr>');
    return;
  }
  for (var idx = 0; idx < msg.tasks.length; idx++) {
    var task = msg.tasks[idx];

    // append remove force button
    if (task.hasOwnProperty('task') && task.task === 'removenode' && getAuthority()) {
      var cluster = $('#cluster').val();
      $('#current_task')
        .append($('<tr><td></td></tr>')
          .append($('<button type="button" class="btn btn-danger force-remove">force remove</button></button>').prop('id','remove_node_' + task.execHost + '_' + cluster).prop("task-execHost", task.execHost)));
    } else {
      $('#current_task').append($('<tr><td><pre><code></code></pre></td></tr>').text(task.msg));
    }
  }
});

socket.on('status', function(status){
  clearTable();
  clearStatsTable();
  var subExecHost = firstNode(status);
  for(var dc in status) {
    addDcTable(dc);
    for(var rack in status[dc]) {
      if(!status[dc].hasOwnProperty(rack)) {
          continue;
      }
      var hosts = status[dc][rack];
      console.log(hosts)
      addRackTable(rack);
      var execHost = subExecHost;
      for(var i = 0; i < hosts.length; i++) {
        if(i + 1 in hosts) {
          execHost = hosts[i + 1].host;
        } else if (i -1 in hosts) {
          execHost = hosts[i - 1].host;
        }
        addToTable(hosts[i], execHost, dc);
      }
    }
  }
  $('.nodes').click(function() {
    changeTaskButton();
  });
});

socket.on('disp_tpstats', function(tpstats){
  clearStatsTable();
  $('#stats_table').append(
    $('<tr></tr>')
      .append($('<th></th>').text('Pool Name'))
      .append($('<th></th>').text('Active'))
      .append($('<th></th>').text('Pending'))
      .append($('<th></th>').text('Completed'))
      .append($('<th></th>').text('Blocked'))
      .append($('<th></th>').text('All Time Blocked'))
  );
  var stats = tpstats['stats'];
  if( stats.length == 0) {
    $('#stats_table').append(
      $('<tr></tr>')
        .append($('<td colspan="6" style="text-align:center"></td>').text('No search results'))
    );
  }
  for(var idx in stats) {
    $('#stats_table').append(
      $('<tr></tr>')
        .append($('<td></td>').text(stats[idx]['pool_name']))
        .append($('<td></td>').text(stats[idx]['active']))
        .append($('<td></td>').text(stats[idx]['pending']))
        .append($('<td></td>').text(stats[idx]['completed']))
        .append($('<td></td>').text(stats[idx]['blocked']))
        .append($('<td></td>').text(stats[idx]['all_time_blocked']))
    );
  }
});

socket.on('disp_tablestats', function(tablestats){
  clearStatsTable();

  var stats = tablestats['stats'];
  stats.forEach(function(stat) {
    // Header for Keyspace properties
    var header = $('<tr></tr>');
    var row = $('<tr></tr>');
    stat.keys.forEach(function(key) {
      header.append($('<th></th>').text(key));
      row.append($('<td></td>').text(stat[key]));
    });
    $('#stats_table').append(header).append(row);
    $('#stats_table').append($('<tr class="gap-row"></tr>'));

    // Header for table properties
    header = $('<tr></tr>');
    stat.tableKeys.forEach(function(key) {
      header.append($('<th></th>').text(key));
    });
    $('#stats_table').append(header);

    stat.tables.forEach(function(t) {
      var row = $('<tr></tr>');
      stat.tableKeys.forEach(function(key) {
        row.append($('<td></td>').text(t[key]));
      });
      $('#stats_table').append(row);
    });
    $('#stats_table').append($('<tr class="gap-row"></tr>'));
    $('#stats_table').append($('<tr class="gap-row"></tr>'));
  });
  $('#stats_table tr.gap-row').slice(-2).remove();
});

// Simple colon-separated output
function tableFromSimpleStats(output) {
  clearStatsTable();

  var stats = output['stats'];
  stats.forEach(function(s) {
    var stat = s.split(':');
      $('#stats_table')
        .append($('<tr></tr>')
          .append($('<td></td>').text(stat[0]))
          .append($('<td></td>').text(stat[1])));
  });
}

socket.on('disp_info',  tableFromSimpleStats);

socket.on('disp_netstats', function(netstats){
  clearStatsTable();

  var stats = netstats['stats'];
  for(var idx = 0; idx <  stats.length; idx++) {
    $('#stats_table').append(
      $('<tr></tr>')
        .append($('<td></td>').text(stats[idx]))
    );
  }
});

socket.on('disp_compactionstats', tableFromSimpleStats);

socket.on('disp_describecluster', tableFromSimpleStats);

socket.on('disp_gossipinfo', function(gossipinfo){
  clearStatsTable();
  $('#stats_table').append(
    $('<tr></tr>')
      .append($('<th></th>').text('ip'))
      .append($('<th></th>').text('host'))
      .append($('<th></th>').text('generation'))
      .append($('<th></th>').text('heartbeat'))
      .append($('<th></th>').text('status'))
      .append($('<th></th>').text('load'))
      .append($('<th></th>').text('schema'))
      .append($('<th></th>').text('dc'))
      .append($('<th></th>').text('rack'))
      .append($('<th></th>').text('release_version'))
      .append($('<th></th>').text('internal_ip'))
      .append($('<th></th>').text('rpc_address'))
      .append($('<th></th>').text('severity'))
      .append($('<th></th>').text('net_version'))
      .append($('<th></th>').text('host_id'))
      .append($('<th></th>').text('rpc_ready'))
      .append($('<th></th>').text('tokens'))
  );
  var stats = gossipinfo['stats'];
  if( stats.length == 0) {
    $('#stats_table').append(
      $('<tr></tr>')
        .append($('<td colspan="17" style="text-align:center"></td>').text('No search results'))
    );
  }
  for(var idx in stats) {
    $('#stats_table').append(
      $('<tr></tr>')
        .append($('<td></td>').text(stats[idx]['ip']))
        .append($('<td></td>').text(stats[idx]['host']))
        .append($('<td></td>').text(stats[idx]['generation']))
        .append($('<td></td>').text(stats[idx]['heartbeat']))
        .append($('<td></td>').text(stats[idx]['status']))
        .append($('<td></td>').text(stats[idx]['load']))
        .append($('<td></td>').text(stats[idx]['schema']))
        .append($('<td></td>').text(stats[idx]['dc']))
        .append($('<td></td>').text(stats[idx]['rack']))
        .append($('<td></td>').text(stats[idx]['release_version']))
        .append($('<td></td>').text(stats[idx]['internal_ip']))
        .append($('<td></td>').text(stats[idx]['rpc_address']))
        .append($('<td></td>').text(stats[idx]['severity']))
        .append($('<td></td>').text(stats[idx]['net_version']))
        .append($('<td></td>').text(stats[idx]['host_id']))
        .append($('<td></td>').text(stats[idx]['rpc_ready']))
        .append($('<td></td>').text(stats[idx]['tokens']))
    );
  }
});

socket.on('myerror', function(msg){
  console.log("error");
  console.log(msg);
  window.alert(msg);
  clearTable();
  $('#status_table').append(
    $('<tr></tr>').append($('<td colspan="7" style="text-align:center"></td>').text('No search results'))
  );
});

$('#select_cluster').click(function(){
  socket.emit('cluster', {cluster: $('#cluster').val()});
  return false;
});

$('#repair_cluster').click(function(){
  if(window.confirm('Repair ' + getTargetCluster() + ' ?')) {
    socket.emit('nodetooltask', {task: 'repair', cluster:$('#cluster').val(), nodes: getCheckedNodes()});
    return false;
  }
});

$("#cleanup_cluster").click(function(){
  if(window.confirm('Cleanup ' + getTargetCluster() + ' ?')) {
    socket.emit('nodetooltask', {task: 'cleanup', cluster:$('#cluster').val(), nodes: getCheckedNodes()});
    return false;
  }
});

function firstNode(status) {
  for(var dc in status) {
    if(status[dc].hasOwnProperty(rack)) {
      for(var rack in status[dc]) {
        if(status[dc].hasOwnProperty(rack)) {
          var hosts = status[dc][rack];
          return hosts[0];
        }
      }
    }
  }
  return false;
}

function clearTable() {
  $('#status_table tbody tr').remove();
  $('#status_table').append(
    $('<tr></tr>')
      .append($('<th></th>').text(''))
      .append($('<th></th>').text('Status'))
      .append($('<th></th>').text('Host'))
      .append($('<th></th>').addClass("hidden-xs").text('HostID'))
      .append($('<th></th>').text('Owns'))
      .append($('<th></th>').text('Load'))
      .append($('<th></th>').text('Action'))
  );
}

function clearStatsTable() {
  $('#stats_table tbody tr').remove();
}

function addDcTable(dc) {
  $('#status_table').append(
    $('<tr></tr>').append(
      $('<td></td>').append($('<input type="checkbox" name="' + dc + '_root" onClick=checkDC("' + dc + '")>')))
      .append($('<td colspan=6></td>').html("<b>" + dc + "</b>")));
}

function addRackTable(rack) {
  $("#status_table").append(
    $("<tr></tr>")
      .append($("<td></td>"))
      .append($("<td></td>"))
      .append($("<td colspan=5></td>").html($("<b></b>").text(rack)))
  );
}

function addToTable(row, execHost, dc) {
  var statusStyle = '';
  if(row['status'] != 'UN') {
    statusStyle = "warning";
  }
  if(row['status'] == 'DN') {
    var action = $('<td></td>');
    if(getAuthority()) {
      action.append($('<button type="button" class="btn btn-danger remove-btn">remove</button>').prop('hostID', row['hostID']));
      action.append($('<button type="button" class="btn btn-danger restart-btn">restart</button>').prop('hostID', row['hostID']).prop('host', row['host']));
      action.append($('<button type="button" class="btn btn-danger decommission-btn">decommission</button>').prop('hostID', row['hostID']).prop('host', row['host']));
    }
  } else if(row['status'] == 'UN') {
      var action = $("<td></td>")
        .append($('<select name="action_list" class="action-list"></select>').prop('host', row['host'])
          .append($('<option value="select">select</option>'))
          .append($('<option value="tpstats">tpstats</option>'))
          .append($('<option value="tablestats">tablestats</option>'))
          .append($('<option value="info">info</option>'))
          .append($('<option value="netstats">netstats</option>'))
          .append($('<option value="compactionstats">compactionstats</option>'))
          .append($('<option value="describecluster">describecluster</option>'))
          .append($('<option value="gossipinfo">gossipinfo</option>')));
    if(getAuthority()) {
      action.append($('<button type="button" class="btn btn-danger restart-btn">restart</button>').prop('hostID', row['hostID']).prop('host', row['host']));
      action.append($('<button type="button" class="btn btn-danger decommission-btn">decommission</button>').prop('hostID', row['hostID']).prop('host', row['host']));
    }
  } else {
    var action = $("<td></td>").text('Nothing');
  }
  $('#status_table').append(
    $('<tr></tr>').addClass(statusStyle)
      .append($('<td></td>').append($('<input type="checkbox" name="nodes">').addClass('nodes').addClass(dc).val(row['host'])))
      .append($('<td></td>').text(row['status']))
      .append($('<td></td>').text(row['host'].replace(".yahoo.co.jp", "")))
      .append($('<td></td>').addClass('hidden-xs').text(row['hostID']))
      .append($('<td></td>').text(row['owns']))
      .append($('<td></td>').text(row['load'] + row['loadUnit']))
      .append(action)
  );
}

function checkDC(dc) {
  var rootCheckBox = document.getElementsByName(dc + "_root");
  var nodes = document.getElementsByClassName(dc);
  if(rootCheckBox[0].checked) {
    for(i = 0; i < nodes.length; i++) {
      nodes[i].checked = true;
    }
  } else {
    for(i = 0; i < nodes.length; i++) {
      nodes[i].checked = false;
    }
  }
}
function getCheckedNodes() {
  var nodes = document.getElementsByName('nodes');
  var checkedNodes = [];
  for(i = 0; i < nodes.length; i++) {
    if(nodes[i].checked) {
      checkedNodes.push(nodes[i].value);
    }
  }
  return checkedNodes;
}

function getTargetCluster() {
  var checkedNodes = getCheckedNodes();
  if(checkedNodes.length > 0) {
    return checkedNodes;
  } else {
    return 'all nodes of ' + $('#cluster').val();
  }
}

function changeTaskButton() {
  var checkedNodesCount = $('[type="checkbox"]:checked').length;
  switch (checkedNodesCount) {
    case 0:
      $('#repair_cluster').text('Repair Cluster');
      $('#cleanup_cluster').text('Cleanup Cluster');
      break;
    case 1:
      $('#repair_cluster').text('Repair node');
      $('#cleanup_cluster').text('Cleanup node');
      break;
    default:
      $('#repair_cluster').text('Repair nodes');
      $('#cleanup_cluster').text('Cleanup nodes');
      break;
  }
}

$("#test").click(function(){
  getCheckedNodes();
  return false;
});

$("body").on("click",".force-remove", function(){
    removeNodeForce($(this).prop("task-execHost"), $('#cluster').val());
});

$("body").on("change",".action-list", function(){
    var value = $(this).val();
    var param = {host: $(this).prop('host'), cluster: $('#cluster').val()};
    if (value === 'tpstats') {
      socket.emit('tpstats', param);
    } else if (value === 'tablestats') {
      socket.emit('tablestats', param);
    } else if (value === 'info') {
      socket.emit('info', param);
    } else if (value === 'netstats') {
      socket.emit('netstats', param);
    } else if (value === 'compactionstats') {
      socket.emit('compactionstats', param);
    } else if (value === 'describecluster') {
      socket.emit('describecluster', param);
    } else if (value === 'gossipinfo') {
      socket.emit('gossipinfo', param);
    }
});

$("body").on("click", ".remove-btn", function() {
  removeNode($(this).prop('hostID'), $('#cluster').val());
});

$("body").on("click", ".restart-btn", function() {
  restartNode($(this).prop('hostID'),$(this).prop('host') ,$('#cluster').val());
});

$("body").on("click", ".decommission-btn", function() {
  decommissionNode($(this).prop('host') ,$('#cluster').val());
});
