<?php
require_once $_SERVER ['DOCUMENT_ROOT'] . '/../lib/YahooJapan/Auction/Sales/Campaign/Extract/Common/AutoLoad.php';

/**
 * データアクセスオブジェクト抽象クラス
 *
 * PDOクラスを利用してMysqlに接続する共通クラス。
 */
abstract class AbstractDao extends AbstractObject {
    /**
     * データベース接続情報
     *
     * @var array(host, dbname, dbuser, password)
     */
    private $conInfo;
    /**
     * PDOクラス (adapter pattern)
     *
     * @var PDO
     */
    private $oPDO;
    /**
     * Statement
     *
     * @var Statement
     */
    private $oStmt;
    /**
     * 一括インサート処理の最大個数
     *
     * @var integer
     */
    const SQL_BULK_MAX = 100;
    
    /**
     * トランザクション可否
     *
     * @var boolean
     */
    private $transation;
    
    /**
     * コンストラクタ
     */
    public function __construct() {
        parent::__construct ();
        $this->conInfo = $this->getConInfo ();
        $this->oPDO = $this->connect ();
        $transation = false;
    }
    
    /**
     * デコンストラクタ
     */
    public function __destruct() {
        // parent::__destruct();
        if ($this->oPDO != null) {
            $this->oPDO = null;
        }
    }
    
    /**
     * DBへ接続
     *
     * @return PDO
     */
    private function connect() {
        parent::getLogger ()->start ( "connect" );
        try {
            $dsn = sprintf ( 'mysql:host=%s;dbname=%s;port=3306;', $this->conInfo ['host'], $this->conInfo ['dbname'] );
            $this->oPDO = new PDO ( $dsn, $this->conInfo ['dbuser'], $this->conInfo ['password'], array (
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION 
            ) );
            $this->oPDO->query ( "set names utf8" ); // 文字化け対策
            
            return $this->oPDO;
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "connect" );
        }
    }
    
    /**
     * (prepare) -> bindparam -> excute -> fetch
     *
     * @param string $sql            
     */
    protected function prepare($sql) {
        parent::getLogger ()->start ( "prepare" );
        if ($this->transation) {
            throw ("It's not transation");
        }
        $this->oStmt = null;
        try {
            $this->oStmt = $this->oPDO->prepare ( $sql );
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "prepare" );
        }
    }
    /**
     * prepare -> (bindparam) -> excute -> fetch
     * データバインディング関数
     *
     * @param int $idx            
     * @param object $data            
     * @param PDO::PARAM $type            
     */
    protected function bindParam($idx, $data) {
        parent::getLogger ()->start ( "bindParam" );
        if ($this->transation) {
            throw ("It's not transation");
        }
        if ($this->oStmt == null) {
            throw ("It's not ready that'PDO:prepare' is.");
        }
        try {
            $this->oStmt->bindParam ( $idx, $data );
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "bindParam" );
        }
    }
    /**
     * prepare -> bindparam -> (excute) -> fetch
     * クエリとバインディングしたクエリを実行。
     *
     * @param array $arg            
     * @throws PDOException
     * @return boolean
     */
    protected function execute($arg = null) {
        parent::getLogger ()->start ( "execute" );
        if ($this->transation) {
            throw ("It's not transation");
        }
        if ($this->oStmt == null) {
            throw ("It's not ready that'PDO:prepare' is.");
        }
        try {
            if ($arg != null) {
                return $this->oStmt->execute ( $arg );
            } else {
                return $this->oStmt->execute ();
            }
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "execute" );
        }
    }
    /**
     * prepare -> bindparam -> excute -> (fetch)
     * 結果を呼び出す
     *
     * @throws PDOException
     * @return array
     */
    protected function fetch() {
        parent::getLogger ()->start ( "fetch" );
        if ($this->transation) {
            throw ("It's not transation");
        }
        if ($this->oStmt == null) {
            throw ("It's not ready that'PDO:prepare' is.");
        }
        try {
            return $this->oStmt->fetch ( PDO::FETCH_ASSOC );
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "fetch" );
        }
    }
    /**
     * prepare -> bindparam -> excute -> (fetchAll)
     * 結果を呼び出す
     *
     * @throws PDOException
     * @return array
     */
    protected function fetchAll() {
        parent::getLogger ()->start ( "fetch" );
        if ($this->transation) {
            throw ("It's not transation");
        }
        if ($this->oStmt == null) {
            throw ("It's not ready that'PDO:prepare' is.");
        }
        try {
            return $this->oStmt->fetchAll ( PDO::FETCH_ASSOC );
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "fetch" );
        }
    }
    /**
     * トランザクション
     *
     * @return boolean
     */
    protected function transaction() {
        parent::getLogger ()->start ( "beginTransaction" );
        try {
            return $this->oPDO->beginTransaction ();
            $this->transation = true;
            $this->oStmt = null;
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "beginTransaction" );
        }
    }
    /**
     * コミット
     *
     * @throws PDOException
     * @return boolean
     */
    protected function commit() {
        parent::getLogger ()->start ( "commit" );
        try {
            $this->transation = false;
            $this->oStmt = null;
            return $this->oPDO->commit ();
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "commit" );
        }
    }
    /**
     * ロールバック
     *
     * @throws PDOException
     * @return boolean
     */
    protected function rollback() {
        parent::getLogger ()->start ( "commit" );
        try {
            $this->transation = false;
            $this->oStmt = null;
            return $this->oPDO->rollback ();
        } catch ( PDOException $e ) {
            parent::getLogger ()->error ( $e );
            throw $e;
        } finally {
            parent::getLogger ()->end ( "commit" );
        }
    }
    /**
     * 一括インサート処理
     * #TODO：検証する前
     *
     * @param string $sql            
     * @param array $val            
     * @param array $aData            
     */
    protected function bulkInsert($sql, $val, $aData) {
        parent::getLogger ()->start ( "bulkInsert" );
        try {
            if (count ( $aData ) <= AbstractDao::SQL_BULK_MAX) {
                $cur = array_fill ( 0, count ( $aData ), $val );
                $sql_t = $sql . implode ( ",", $cur );
                $this->prepare ( $sql_t );
                $marge = array ();
                foreach ( $aData as $key1 => $val1 ) {
                    foreach ( $val1 as $key2 => $val2 ) {
                        $marge [] = $val2;
                    }
                }
                $this->execute ( $marge );
                unset ( $marge );
                unset ( $aData );
            } else {
                throw ("bulk process count is limited.");
            }
        } finally {
            parent::getLogger ()->end ( "bulkInsert" );
        }
    }
    /**
     *
     * @return unknown[]|string[]|NULL[]
     */
    private function getConInfo() {
        parent::getLogger ()->start ( "getConInfo" );
        try {
            if (isset ( $_SERVER ['VCAP_SERVICES'] )) {
                // 個人ＰＣＦ環境
                $vcap_services = json_decode ( $_SERVER ['VCAP_SERVICES'] );
                $ups = $vcap_services->{'user-provided'} [0]->credentials;
                $dsn = 'mysql:host=' . $ups->host . ';port=' . $ups->port . ';dbname=' . $ups->schema;
                $conInfo = array (
                        'host' => $ups->host,
                        'dbname' => $ups->schema,
                        'dbuser' => $ups->user,
                        'password' => $ups->pass 
                );
            } else {
                $hostname = gethostname ();
                if (preg_match ( "/ynwp.yahoo.co.jp$/i", $hostname )) {
                    $secure = new Secure ();
                    $data = $secure->get_key ( 'auction.sales.cmpext.db_pass' );
                    $signature = $secure->get_key ( 'auction.sales.cmpext.signature' );
                    $password = openssl_decrypt ( $data, 'AES-128-CBC', $signature );
                    $conInfo = array (
                            'host' => 'auc-cmp-ext1.mdb.vip.ssk.ynwp.yahoo.co.jp',
                            'dbname' => 'auc_cmp_ext',
                            'dbuser' => 'auction-sales',
                            'password' => $password 
                    );
                } elseif (preg_match ( "/ynwm.yahoo.co.jp$/i", $hostname )) {
                    $secure = new Secure ();
                    $data = $secure->get_key ( 'auction.sales.cmpext.db_pass' );
                    $signature = $secure->get_key ( 'auction.sales.cmpext.signature' );
                    $password = openssl_decrypt ( $data, 'AES-128-CBC', $signature );
                    $conInfo = array (
                            'host' => 'auc-cmp-ext-member-1.mdb.ogk.ynwm.yahoo.co.jp',
                            'dbname' => 'auc_cmp_ext',
                            'dbuser' => 'auction-sales',
                            'password' => $password 
                    );
                } else {
                    $_SERVER ['ENV_MODE'] = true;
                    // ローカル環境
                    $conInfo = array (
                            'host' => Configuration::$DATABASE ["LOCALHOST"],
                            'dbname' => Configuration::$DATABASE ["LOCALDBNAME"],
                            'dbuser' => Configuration::$DATABASE ["LOCALDBUSER"],
                            'password' => Configuration::$DATABASE ["LOCALPASS"] 
                    );
                }
            }
            parent::getLogger ()->trace ( $conInfo );
            return $conInfo;
        } finally {
            parent::getLogger ()->end ( "getConInfo" );
        }
    }
}
?>