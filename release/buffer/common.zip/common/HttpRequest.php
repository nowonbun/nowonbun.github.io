<?php
require_once $_SERVER ['DOCUMENT_ROOT'] . '/../lib/YahooJapan/Auction/Sales/Campaign/Extract/Common/AutoLoad.php';
class HttpRequest {
    private $url;
    private $post;
    private $header;
    private $param;
    private $filedata;
    /**
     * コンストラクタ
     *
     * @param string $url            
     * @param boolean $post            
     * @param array $header            
     * @param array $param            
     */
    public function __construct($url, $post = false, $header = null, $param = null) {
        $this->url = $url;
        $this->post = $post;
        $this->header = $header;
        $this->param = $param;
    }
    /**
     * urlを接続
     *
     * @param boolean $kinit            
     * @return HttpResponse
     */
    public function connect($kinit, $customRequst = false, $debug = false) {
        // http://php.net/manual/en/function.curl-setopt.php
        if ($kinit) {
            $this->initKerberos ();
        }
        $handle = curl_init ();
        try {
            curl_setopt ( $handle, CURLOPT_URL, $this->url );
            curl_setopt ( $handle, CURLOPT_FOLLOWLOCATION, TRUE );
            curl_setopt ( $handle, CURLOPT_AUTOREFERER, TRUE );
            curl_setopt ( $handle, CURLOPT_POST, $this->post );
            if ($this->param != null) {
                LogManager::getStaticLogger ()->trace ( $this->param );
                curl_setopt ( $handle, CURLOPT_POSTFIELDS, $this->param );
            }
            curl_setopt ( $handle, CURLOPT_VERBOSE, TRUE );
            curl_setopt ( $handle, CURLOPT_SSL_VERIFYPEER, FALSE );
            curl_setopt ( $handle, CURLOPT_RETURNTRANSFER, TRUE );
            curl_setopt ( $handle, CURLOPT_HEADER, TRUE );
            if ($this->header != null) {
                LogManager::getStaticLogger ()->trace ( $this->header );
                curl_setopt ( $handle, CURLOPT_HTTPHEADER, $this->header );
            }
            
            // curl_setopt ( $handle, CURLOPT_KRBLEVEL, true);
            // curl_setopt ( $handle, CURLOPT_GSSAPI_DELEGATION, CURLGSSAPI_DELEGATION_FLAG );
            if ($customRequst) {
                curl_setopt ( $handle, CURLOPT_CUSTOMREQUEST, "PUT" );
                curl_setopt ( $handle, CURLOPT_SAFE_UPLOAD, FALSE );
            }
            if ($debug) {
                $verbose = fopen ( '/home/vcap/app/logs/http.log', 'w+' );
                curl_setopt ( $handle, CURLOPT_STDERR, $verbose );
                curl_setopt ( $handle, CURLOPT_VERBOSE, 1 );
            }
            curl_setopt ( $handle, CURLOPT_HTTPAUTH, CURLAUTH_GSSNEGOTIATE );
            curl_setopt ( $handle, CURLOPT_USERPWD, ":" );
            
            $response = curl_exec ( $handle );
            $header_size = curl_getinfo ( $handle, CURLINFO_HEADER_SIZE );
            $responseClz = new HttpResponse ( $response, $header_size );
            return $responseClz;
        } finally {
            curl_close ( $handle );
        }
    }
    /**
     * kerberos認証
     */
    private function initKerberos() {
        putenv ( 'KRB5_CONFIG=/home/vcap/app/lib/campaign_point_grant/backend/kinit/krb5.conf' );
        shell_exec ( "bash /home/vcap/app/lib/campaign_point_grant/backend/kinit/kinit.sh" );
    }
}
?>