<?php
require_once $_SERVER ['DOCUMENT_ROOT'] . '/../vendor/apache/log4php/src/main/php/Logger.php';
ini_set ( "display_errors", "1" );
/**
 * ページ作成中の構造エラー(コンパイルエラー)
 *
 * @param unknown $errno            
 * @param unknown $errstr            
 * @param string $errfile            
 * @param number $errline            
 * @param array $errcontext            
 */
function SystemErrorHandler($errno, $errstr, $errfile = '', $errline = 0, $errcontext = array()) {
    $logger = Logger::getLogger ( "System" );
    $logger->error ( "ERROR CODE[" . $errno . "] [" . $errfile . " (" . $errline . ")]   " . $errstr );
}
set_error_handler ( 'SystemErrorHandler' );
/**
 *
 * @author t-sfuan
 *        
 */
class LogManager {
    private $logger;
    private static $instance = null;
    /**
     * builder pattern
     *
     * @param object $clzz            
     * @return LogManager
     */
    public static function getLogger($clzz) {
        // エラー設定
        Logger::configure ( $_SERVER ['DOCUMENT_ROOT'] . '/../lib/YahooJapan/Auction/Sales/Campaign/Extract/Log/config.xml' );
        return new LogManager ( Logger::getLogger ( $clzz ) );
    }
    /**
     * sington static Logger
     *
     * @return LogManager
     */
    public static function getStaticLogger() {
        if (LogManager::$instance == null) {
            LogManager::$instance = new LogManager ( Logger::getLogger ( "Static" ) );
        }
        return LogManager::$instance;
    }
    /**
     * コンストラクタ (継承禁止、割り当て禁止)
     *
     * @param unknown $logger            
     */
    private function __construct($logger) {
        $this->logger = $logger;
    }
    /**
     * トランス
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function trace($message, $throwable = null) {
        $this->logger->trace ( $message, $throwable );
    }
    /**
     * デバック
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function debug($message, $throwable = null) {
        $this->logger->debug ( $message, $throwable );
    }
    /**
     * インフォ
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function info($message, $throwable = null) {
        $this->logger->info ( $message, $throwable );
    }
    /**
     * インフォ
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function warn($message, $throwable = null) {
        $this->logger->warn ( $message, $throwable );
    }
    /**
     * エラー
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function error($message, $throwable = null) {
        $this->logger->error ( $message, $throwable );
    }
    /**
     * クリティカルエラー
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function fatal($message, $throwable = null) {
        $this->logger->fatal ( $message, $throwable );
    }
    /**
     * 関数開始
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function start($fnName) {
        $this->logger->info ( "function start : $fnName" );
    }
    /**
     * 関数終了
     *
     * @param object $message            
     * @param Exception $throwable            
     */
    public function end($fnName) {
        $this->logger->info ( "function end : $fnName" );
    }
}
?>