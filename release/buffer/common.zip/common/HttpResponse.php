<?php
require_once $_SERVER ['DOCUMENT_ROOT'] . '/../lib/YahooJapan/Auction/Sales/Campaign/Extract/Common/AutoLoad.php';
/**
 */
class HttpResponse {
    private $version;
    private $code;
    private $codeMsg;
    private $header;
    private $body;
    /**
     * コントラクタ
     *
     * @param string $response            
     * @param int $header_size            
     */
    public function __construct($response, $header_size) {
        $buffer = substr ( $response, 0, $header_size );
        $temp = explode ( "\r\n", $buffer );
        for($i = 0; $i < count ( $temp ); $i ++) {
            
            if ($this->isHeader ( $temp [$i] )) {
                continue;
            }
            if ($this->isNullLine ( $temp [$i] )) {
                continue;
            }
            $temp1 = $temp [$i];
            $temp2 = explode ( ": ", $temp1 );
            if (strlen ( $temp2 [0] ) < 1) {
                continue;
            }
            $this->header [$temp2 [0]] = str_replace ( $temp2 [0] . ": ", "", $temp1 );
        }
        $this->body = substr ( $response, $header_size );
    }
    /**
     *
     * @param string $str            
     * @return boolean
     */
    private function isNullLine($str) {
        if (strlen ( $str ) < 1) {
            return true;
        }
        if (strrpos ( $str, ":" ) === false) {
            return true;
        }
        return false;
    }
    /**
     * ヘッダチェック
     *
     * @param string $str            
     * @return boolean
     */
    private function isHeader($str) {
        if (strrpos ( $str, "HTTP/1." ) === false) {
            return false;
        }
        $res = explode ( " ", $str );
        $this->version = $res [0];
        $this->code = $res [1];
        $this->codeMsg = $res [2];
        empty ( $this->header );
        return true;
    }
    
    /*
     * version プロパティ
     *
     * @return string
     */
    public function getVersion() {
        return $this->version;
    }
    /**
     * code プロパティ
     *
     * @return string
     */
    public function getCode() {
        return $this->code;
    }
    /**
     * codeMsg プロパティ
     *
     * @return string
     */
    public function getCodeMsg() {
        return $this->codeMsg;
    }
    /**
     * name プロパティ
     *
     * @return string
     */
    public function getHeader($name) {
        return $this->header [$name];
    }
    /**
     * body プロパティ
     *
     * @return string
     */
    public function getBody() {
        return $this->body;
    }
}
?>