<?php
require_once $_SERVER ['DOCUMENT_ROOT'] . '/../lib/YahooJapan/Auction/Sales/Campaign/Extract/Common/AutoLoad.php';
abstract class AbstractObject {
    private $logger;
    public function __construct() {
        $this->logger = \LogManager::getLogger ( get_class ( $this ) );
    }
    /**
     * ログ表示
     *
     * @return unknown
     */
    protected function getLogger() {
        return $this->logger;
    }
    /**
     * 画面に表示
     * #deprecated
     *
     * @param unknown $msg            
     */
    protected function printOut($msg) {
        trigger_error ( "deprecated" );
        echo $msg;
        die ();
    }
    /**
     * ブラウザにコード設定
     *
     * @param string $code            
     * @param string $msg            
     */
    protected function setHeaderCode($code, $codeMsg, $msg) {
        echo $msg;
        http_response_code ( $code );
        header ( "HTTP/1.1 " . $code . " " . $msg );
        die ();
    }
    /**
     * ファイル作成
     *
     * @param string $filepath            
     * @param string $data            
     */
    protected function writeFile($filepath, $data) {
        $dir = dirname ( $filepath );
        if (! is_dir ( $dir )) {
            mkdir ( $dir );
        }
        $file = fopen ( $filepath, "w" );
        try {
            fwrite ( $file, $data );
        } finally {
            fclose ( $file );
        }
    }
    /**
     * ファイル読み込む
     *
     * @param string $filepath            
     * @return string
     */
    protected function readFile($filepath) {
        $file = fopen ( $filepath, "r" );
        try {
            return fread ( $file, filesize ( $filepath ) );
        } finally {
            fclose ( $file );
        }
    }
}
?>