﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Http.Impl;

namespace Http
{
    public class HttpFactory
    {
        private static HttpFactory singleton = null;
        private IWebServer webserver = null;
        private IWebSocketServer websocket = null;
        private HttpFactory(int port, int wsport)
        {
            webserver = new WebServer(port);
            websocket = new WebSocketServer(wsport);
        }
        public static HttpFactory NewInstance(int port, int wsport)
        {
            if (singleton == null)
            {
                singleton = new HttpFactory(port, wsport);
            }
            else
            {
                Console.WriteLine("already allocation!");
            }
            return singleton;
        }
        public IWebServer WebServer
        {
            get { return this.webserver; }
        }
        public IWebSocketServer WebSocketServer
        {
            get { return this.websocket; }
        }

    }
}
