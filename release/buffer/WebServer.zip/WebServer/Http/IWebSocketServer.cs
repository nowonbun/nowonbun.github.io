﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Http
{
    public interface IWebSocketServer : IDisposable
    {
        void Get(Func<byte[], WebSocketNode> method);
        void GetAll(Func<byte[], WebSocketNode> method);
    }
}
