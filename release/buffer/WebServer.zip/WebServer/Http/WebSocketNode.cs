﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Http
{
    public class WebSocketNode
    {
        public Opcode OPCode { get; set; }
        public byte[] Message { get; set; }
        public void SetMessage(String message)
        {
            Message = Encoding.UTF8.GetBytes(message);
        }
        public String GetMessage()
        {
            return Encoding.UTF8.GetString(Message);
        }
    }
}
