﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Http;
using System.Threading;
using System.IO;

namespace WebServer
{
    class Program
    {
        static void Main(string[] args)
        {
            var factory = HttpFactory.NewInstance(8080, 8081);
            factory.WebServer.Get("/", (res, rep, context) =>
            {
                return @"C:\work\webserverEx\index.html";
            });
            factory.WebSocketServer.GetAll(data =>
            {
                Console.WriteLine(Encoding.UTF8.GetString(data));
                String ret = "return ++ "+ Encoding.UTF8.GetString(data);
                return new WebSocketNode() { OPCode = Opcode.MESSAGE, Message = Encoding.UTF8.GetBytes(ret) };
            });

            Console.WriteLine("Press Any Key...");
            Console.ReadKey();
        }
    }
}
