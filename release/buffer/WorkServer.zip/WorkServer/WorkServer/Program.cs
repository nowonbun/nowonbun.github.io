﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServer;

namespace WorkServer
{
    class Program
    {
        static void Main(string[] args)
        {
            var server = ServerFactory.NewInstance(8080);
            server.SetRootPath(@"C:\work\study");
            server.Set("/", (res, req) =>
            {
                req.ReadFile(@"C:\work\study\index.html");
            });
            server.SetWebSocket(mes =>
            {
                Console.WriteLine(mes);
                return new WebSocketNode() { OPCode = Opcode.MESSAGE, Message = "Hello world" };
            });
            Console.ReadKey();
        }
    }
}
