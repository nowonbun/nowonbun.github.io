﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServer
{
    public interface IServer
    {
        void Set(String2 key, Action<Request, Response> method);
        void SetRootPath(String path);
        void SetWebSocket(Func<String2, WebSocketNode> method);
    }
}
