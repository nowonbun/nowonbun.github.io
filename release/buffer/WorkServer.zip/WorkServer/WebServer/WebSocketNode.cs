﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServer
{
    public class WebSocketNode
    {
        public Opcode OPCode { get; set; }
        public String2 Message { get; set; }
    }
}
