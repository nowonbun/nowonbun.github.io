package bean;

public class CategoryBean {
	private String categoryCode;
	private String categoryText;
	private String categoryHref;

	public String getCategoryText() {
		return categoryText;
	}

	public void setCategoryText(String categoryText) {
		this.categoryText = categoryText;
	}

	public String getCategoryHref() {
		return categoryHref;
	}

	public void setCategoryHref(String categoryHref) {
		this.categoryHref = categoryHref;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

}
