#!/bin/sh

CURRENT=$(date -u '+%F')

if [ "x${BUILD_NUMBER}" = "x" ]; then
echo "WARNING: BUILD_NUMBER env var not defined, normally Hudson sets this." >&2
echo "Setting to 0.  export BUILD_NUMBER=n and repeat the build to override." >&2
BUILD_NUMBER=0
fi

cat <<EOF
YKVS web opstool. 

RELEASE NOTE

Version 0.9.4_${BUILD_NUMBER} (${CURRENT})
  * Current.

Version 0.9.3_x
  * Node status view grouped by rack.

Version 0.9.2_x
  * Change CI process.

Version 0.9.1_x
  * requires jdk-1.8.x

Version 0.9.0
  * removenode force button
  * requires jdk-1.8.x

Version 0.8.0_x
  * Add repair scheduler

Version 0.7.0
  * yjava_jdk-1.7.0_80.43
  * Support VIP

Version 0.6.0
  * Support any cassandra versions

Version 0.5.0
  * Update library
  * Change DB.
  * Support multi DC.

Version 0.4.3
  * Security update.

Version 0.4.2
  * Update express.js for security issue.
  * Sort result of nodetool status by token.

Version 0.4.1
  * Show owns in status results.

Version 0.4.0
  * Enable to execute task to selected nodes.
  * Fix authentication process.

Version 0.3.2
  * Fix for opc.

Version 0.3.1
  * Small fix.

Version 0.3.0
  * Add command history.

Version 0.2.1 [2014/08/01]
  * Bug fix.

Version 0.2.0 [2014/08/01]
  * Change design.

Version 0.1.2 [2014/07/31]
  * Add registerd hosts list page.

Version 0.1.1 [2014/07/30]
  * Fix prerequisites.

Version 0.1.0 [2014/07/11]
  * Initial version.
EOF
