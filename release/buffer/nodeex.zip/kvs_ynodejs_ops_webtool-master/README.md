# 障害対応用Webtool

## できること
* クラスタの状態を表示
* クラスタに所属するノードのrepair, cleanup
* クラスタへの操作終了後にメール送信
* Downしているノードのremovenode

## 使い方
* セレクトボックスからクラスタを選択しViewボタンを押すとnodetool statusが実行されクラスタの状態が見えます。
* Repair Clusterボタンを押すと、クラスタに所属する生きているノードに対してrepairを１台ずつ実行します。
* 全台のrepairが完了すると実行者にメールを送信します。
* Downしているノードがある場合、removenodeのためのボタンが表示され、ボタンを押すとremovenodeが実行されます。
* 新しいノードを追加する場合には~~Host listに移動し下部のHostにホスト名、Clusterにクラスタ名、jmxの認証が必要な場合はチェックボックスにチェックを入れてRegisterボタンを押してください。~~ 追加対象ホストを [deployのenvironment設定](https://git.corp.yahoo.co.jp/kvspj/chef_pipeline-opstool/tree/master/environments)に追加すると、Screwdriverジョブ実行時にDBに追加されます。

## 運用管理上の注意事項
* jp_cassandraのバージョンが追加された時は、`bin/activate.sh`に該当バージョンの設定を追加して、デプロイのパイプラインを回してください。
例えば、jp_cassandra-3.0.11.0が追加された場合、上記スクリプトに `/home/y/bin/fetch_util jp_cassandra-3.0.11.0` を追加します。
* Cassandraホストの追加は、デプロイの再現性の観点から、UIからではなく、[deployのenvironment設定](https://git.corp.yahoo.co.jp/kvspj/chef_pipeline-opstool/tree/master/environments)に追加することで行ってください。
* [Opstool構築手順](https://git.corp.yahoo.co.jp/kvspj/doc/blob/master/ops/cicd-manual/manuals/opstool.md)

## 依存システム

### 全社MySQL

このツールは、ノード設定情報と操作履歴を全社MySQLに保存しています。

- [Miniy](https://horizon.ynwm-dbaas-mysql1-li.os.ops.yahoo.co.jp/project/database_clusters/f3edf2a8-8942-4f18-a2d2-940eed1f2975/) -> kvs-opstool クラスタ
- [Prod](https://horizon.ynwp-dbaas-mysql1-li.os.ops.yahoo.co.jp/project/database_clusters/1d6aa18f-e4eb-4372-8cc5-b34d451397ea/) -> kvs-opstool クラスタ
- [全社MySQL DevMan](http://cptl.corp.yahoo.co.jp/x/mg4VQg)

#### 接続情報

| env        | Host           | User  | Keyspace | password |
| ------------- |:-------------|:-----:|:-----:|:-----:|
| miniy      | kvs-opstool.mdb.vip.kks.ynwm.yahoo.co.jp | opstool | opstool | ysecureから下記CKMS項目のkey nameで取得 |
| prod      | kvs-opstool.mdb.vip.ssk.ynwp.yahoo.co.jp |opstool | opstool | ysecureから下記CKMS項目のkey nameで取得 | 


### CKMS

このツールは、CKMSを使って、全社MySQLに接続するためのパスワードを取得しています。

| env        | Key Group           | Key Name  |
| ------------- |:-------------:|:-----:|
| miniy      | [kvs.opstool.mysql](https://alpha.kaps.ckms.yahoo.co.jp/g/index.php?search_field=kg_name&search_type=equals&search_for=kvs.opstool.mysql) | [kvs.opstool.mysql.opstooluser](https://alpha.kaps.ckms.yahoo.co.jp/k/update.php?kd_name=kvs.opstool.mysql.opstooluser) |
| prod      | [kvs.opstool.mysql](https://kaps.ckms.yahoo.co.jp/g/index.php?search_field=kg_name&search_type=equals&search_for=kvs.opstool.mysql)      |   [kvs.opstool.mysql.opstooluser](https://kaps.ckms.yahoo.co.jp/k/update.php?kd_name=kvs.opstool.mysql.opstooluser) |


- パスワード置き場
 - いつもの限定セキュリティフォルダ
- [CKMS DevMan](http://cptl.corp.yahoo.co.jp/x/mpjqFw) 
 
## デプロイジョブ

[![Build Status](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/20134/component/icon)](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/20134/component/target)

[![Build Status](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3900/component/icon)](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3900/component/target)

[![Build Status](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/component/icon)](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/component/target)

[![Build Status](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/miniy-opstool/icon)](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/miniy-opstool/target)

[![Build Status](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/prod-opstool/icon)](https://api.screwdriver.corp.yahoo.co.jp:4443/badge/3912/prod-opstool/target)

- [cookbook](http://screwdriver.corp.yahoo.co.jp/projects/3900)
- [chef_pipeline](http://screwdriver.corp.yahoo.co.jp/projects/3912)

## How to start the development

### 1. create a new ynw instance

http://www.os.ops.yahoo.co.jp/

Create a new ynw instance for this tool.
Please make sure that the OS is YJLinux 6.X.

### 2. register the host in RolesDB

Add the roles below to the host in RolesDB.

- [kvs_jp.acl.mysql](http://rolesdb.corp.yahoo.co.jp:9999/ui/role?action=view&id=142735)
- [kvs_jp.opstool](http://rolesdb.corp.yahoo.co.jp:9999/ui/role?action=view&id=85891)

### 3. knife bootstrap & knife node run_list/environment set

```
$ knife bootstrap --bootstrap-install-command 'if ! [ -x /usr/bin/chef-client ]; then rpm -Uvh http://jp.dist.yahoo.co.jp:8000/artifactory/chef_rpms/rhel/6/x86_64/release/Packages/chef-12.18.31-1.el6.x86_64.rpm; fi' --sudo -x $(whoami) -N <BOOTSTRAP-TARGET-HOST> <BOOTSTRAP-TARGET-HOST>
$ knife node environment set <TARGET_HOST> miniy-opstool
$ knife node run_list set <TARGET_HOST> 'role[opstool]'
```

### 4. sudo chef-client

```
$ ssh <TARGET_HOST>
$ sudo chef-client
```

### 5. clone the code and initial setup

```
$ git clone git@git.corp.yahoo.co.jp:kvspj/kvs_ynodejs_ops_webtool
$ cd kvs_ynodejs_ops_webtool
$ gmake
```

### 6. modify codes

```
$ vim src/...
 (give some changes to codes)
$ ynpm install --dev
$ yhint
 (format the codes)
```

### 7. update the host

```
$ gmake update
```

### 8. access and confirm

`http://<TARGET_HOST>:8080`

## 今後の予定
* 実行予定のタスクを表示
 

## 既知の不具合
* websocketが繋がらない（動作に支障はない）

## その他
   * https://issues.apache.org/jira/browse/CASSANDRA-5203 によりdead nodeがある状態でrepairを行うとnodetoolの終了コードは1になる
   * [構築時のメモ](https://jira.corp.yahoo.co.jp/browse/KVS-1586)
