'use strict';
var express    = require('express');
var http       = require('http');
var app  = express();
var server = http.Server(app);
var log = require('logger')('YkvsOpstool', 'TRACE');
var io = require('socket.io').listen(server);
var config = require('./libs/config');
var roles = require('./libs/roles');
var ysecure = require('ysecure');
io.set('transports', ['xhr-polling',
  'jsonp-polling',
  'polling']);
var MESSAGES = require('./libs/messages');

module.exports = server;
module.exports.io = io;
var users = module.exports.users = {};
var mysql_password = ysecure.getKey('kvs.opstool.mysql.opstooluser');

var mysql      = require('mysql');
var connection;
var db_config = {
  host     : config.mysql.host,
  user     : 'opstool',
  database : 'opstool',
  password: mysql_password,
  connectionLimit : 10
};

connection = mysql.createPool(db_config);

module.exports.con = connection;
var yiv = require('yiv');
var ops = require("./libs/operation.js");

var title = 'YKVS Opstool';

app.set('view engine', 'jade');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
  var user = req.yby.userid;
  connection.query("SELECT DISTINCT cluster FROM nodes ORDER BY cluster", function(err, rows) {
    console.log(err);
    res.render('index', { title: title, nodes: rows, clusters: rows, user:user});
  });
});

app.get('/scheduler', function(req, res) {
  showSchedules(req, res);
});

app.get('/deleteschedule', function(req, res) {
  var scheduleId = yiv.yiv_get_stripped(req.query.scheduleid, yiv.YIV_FLAG_NONE);
  connection.query("DELETE FROM schedules where id = ?", scheduleId, function(err, rows) {
    showSchedules(req, res);
    log.trace('err=' + err + 'rows=' + rows);
  });
});

app.get('/runschedule', function(req, res) {
  var scheduleId = yiv.yiv_get_stripped(req.query.scheduleid, yiv.YIV_FLAG_NONE);
  connection.query("UPDATE schedules SET nextstarttime=? where id = ?", [new Date(), scheduleId],
    function(err, rows) {
      if (err) {
        console.log("failed to update nextstarttime of schedule " + scheduleId);
      }
      log.trace('rows=' + rows);
      showSchedules(req, res);
    });
});

app.get('/controlscheduler', function(req, res) {
  if(req.query.schedulerStatus) {
    console.log(req.yby.userid + " start scheduler.");
    config.scheduler.isActive = true;
  } else {
    console.log(req.yby.userid + " stop scheduler.");
    config.scheduler.isActive = false;
  }
  showSchedules(req, res);
});

function showSchedules(req, res) {
  connection.query("SELECT * FROM schedules", function(err, rows) {
    var schedules = rows;
    connection.query("SELECT DISTINCT cluster FROM nodes", function(err, rows) {
      res.render('scheduler', { title: title, schedules: schedules ,clusters: rows,
        schedulerStatus: config.scheduler.isActive});
    });
  });
}

app.get('/addschedule', function(req, res) {
  var cluster = yiv.yiv_get_js_string(req.query.cluster, yiv.YIV_FLAG_NONE);
  var nexttime = req.query.nexttime;
  var interval = req.query.interval;
  var doCompaction = req.query.docompaction ? 1 : 0;
  var status = global.SCHEDULE_NOT_RUNNING;

  var sql = ("INSERT INTO schedules (cluster, nextstarttime, scheduleinterval, docompaction, status) VALUES(?, ?, ?, ?, ?)");
  connection.query(sql, [cluster, nexttime, interval, doCompaction, status], function(err) {
    if(err) {
      res.render('addnode', { title: title, result: 'Registration failed: ' + err});
      console.log(err);
    } else {
      console.log(req.yby.userid + " register repair schedule:" + " " + req.query.cluster);
      showSchedules(req, res);
    }
  });
});

app.get('/repair', function(req, res) {
  connection.query("SELECT * FROM repairs WHERE id IN (SELECT MAX(id) FROM repairs GROUP BY cluster) ORDER BY id DESC LIMIT 100", function(err, rows) {
    res.render('repair', { title: title, repairs: rows });
  });
});

app.get('/hostlist', function(req, res) {
  ops.getNodetoolVersions(
    function(vers) {
      connection.query("SELECT * FROM nodes", function(err, rows) {
        res.render('hostlist', { title: title, versions: vers, nodes: rows });
      });
    }
  );
});

app.get('/history', function(req, res) {
  connection.query("SELECT * FROM histories ORDER BY id DESC LIMIT 100", function(err, rows) {
    res.render('history', { title: title, hists: rows });
  });
});

app.get('/deletehost', function(req, res) {
  var sql = "DELETE FROM nodes WHERE host=?";
  if(roles.hasAdminSymbol(req.yby.roles)) {
    connection.query(sql, req.query.host, function(err) {
      if(err){
        console.log(req.yby.userid + ' fail to delete ' + req.query.host);
        console.log(err);
      }
      connection.query("SELECT * FROM nodes", function(err, rows) {
        log.trace('err=' + err + 'rows=' + rows);
        console.log(req.yby.userid + ' delete ' + req.query.host);
        ops.getNodetoolVersions(
          function(vers) {
            connection.query("SELECT * FROM nodes", function(err, rows) {
              res.render('hostlist', { title: title, versions: vers, nodes: rows });
            });
          }
        );
      });
    });
  } else {
    console.log(req.yby.userid + ' fail to delete ' + req.query.host + " :Forbidden");
    res.status(403).send("Forbidden");
  }
});


app.get('/addnode', function(req, res) {
  var host = yiv.yiv_get_hostport(req.query.host, yiv.YIV_FLAG_NONE);
  var version = yiv.yiv_get_stripped(req.query.version, yiv.YIV_FLAG_NONE);
  var cluster = yiv.yiv_get_js_string(req.query.cluster, yiv.YIV_FLAG_NONE);
  var auth;
  if(req.query.auth) {
    auth = 1;
  } else {
    auth = 0;
  }
  if(roles.hasAdminSymbol(req.yby.roles)) {
    var sql = ("INSERT INTO nodes(host, version, cluster, need_auth) VALUES(?, ?, ?, ?)");
    connection.query(sql, [host, version, cluster, auth], function(err) {
      if(err) {
        res.render('addnode', { title: title, result: 'Registration failed: ' + err});
        console.log(err);
      } else {
        console.log(req.yby.userid + " register:" + req.query.host + " " + req.query.cluster);
        res.render('addnode', { title: title, result: 'Registration done.'});
      }
    });
  } else {
    console.log(req.yby.userid + " fail to register:" + req.query.host + " " + req.query.cluster + " :Forbidden");
    res.status(403).send("Forbidden");
  }
});


io.sockets.on('connection', function(socket){
  console.log(socket.request.yby.userid + " connected");
  socket.username = socket.request.yby.userid + '_' + Math.random().toString(36).slice(-8);
  users[socket.username] = socket.id;

  socket.on('cluster', function(msg) {
    var sql = "SELECT * FROM nodes WHERE cluster=?";
    connection.query(sql, msg.cluster, function(err, rows) {
      if(err) {
        console.log(err);
        return;
      }
      ops.getRingStatus(socket.username, msg.cluster, rows, global.EVENT_STATUS, ops.sendStatusToClient);
    });
  });

  socket.on('nodetooltask' ,function(msg) {
    console.log(socket.username.split('_')[0] + ' executes ' + msg.task + ' to ' + msg.cluster);
    var sql = "SELECT * FROM nodes WHERE cluster=?";
    connection.query(sql, msg.cluster, function(err, rows) {
      if(err) {
        console.log(err);
        return;
      }
      if(msg.nodes.length > 0) {
        ops.execTaskNode(socket.username, msg.cluster, msg.nodes,
          rows[0].need_auth === 1, [msg.task]);
      } else {
        ops.getRingStatus(socket.username, msg.cluster,
          rows, global.EVENT_STATUS, ops.execTaskCluster, [msg.task]);
      }
    });
  });

  var removenode = require("./libs/commands/removenode.js");
  socket.on('remove', function(msg) {
    if(msg.id.match(/^[a-f0-9\-]+$/)) {
      removenode.removeNode(socket.username, msg.id, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation remove:' + msg.id);
    }
  });

  socket.on('remove_force', function(msg) {
    removenode.removeNodeForce(
      socket.username,
      msg.execHost,
      msg.cluster
    );
  });

  socket.on('decommission', function(msg) {
    var decom = require("./libs/commands/decommission.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      decom.decommissionNode(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation decommission:' + msg.host);
    }
  });

  socket.on('tpstats', function(msg) {
    var tpstats = require("./libs/commands/tpstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      tpstats.tpstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation tpstats:' + msg.host);
    }
  });

  socket.on('tablestats', function(msg) {
    var tablestats = require("./libs/commands/tablestats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      tablestats.tablestats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation tablestats:' + msg.host);
    }
  });

  socket.on('info', function(msg) {
    var info = require("./libs/commands/info.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      info.info(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation info:' + msg.host);
    }
  });

  socket.on('netstats', function(msg) {
    var netstats = require("./libs/commands/netstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      netstats.netstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation netstats:' + msg.host);
    }
  });

  socket.on('compactionstats', function(msg) {
    var compactionstats = require("./libs/commands/compactionstats.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      compactionstats.compactionstats(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation compactionstats:' + msg.host);
    }
  });

  socket.on('describecluster', function(msg) {
    var describecluster = require("./libs/commands/describecluster.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      describecluster.describecluster(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation describecluster:' + msg.host);
    }
  });

  socket.on('gossipinfo', function(msg) {
    var gossipinfo = require("./libs/commands/gossipinfo.js");
    if(msg.host.match(/^[a-z0-9\-\.]+$/)) {
      gossipinfo.gossipinfo(socket.username, msg.host, msg.cluster);
    } else {
      ops.sendMessage(socket.username, "Not allowed operation", MESSAGES.MESSAGE_CRIT);
      console.log(socket.username + 'try to execute unknown operation gossipinfo:' + msg.host);
    }
  });

  socket.on('disconnect', function () {
    delete users[socket.username];
    console.log(socket.username + ' disconenct');
  });
});
