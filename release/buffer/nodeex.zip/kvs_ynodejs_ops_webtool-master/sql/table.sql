CREATE TABLE IF NOT EXISTS nodes(id INTEGER PRIMARY KEY AUTO_INCREMENT,host varchar(64) unique,version varchar(16), cluster varchar(32), need_auth tinyint);
CREATE TABLE IF NOT EXISTS histories(id INTEGER PRIMARY KEY AUTO_INCREMENT,time DATETIME,command text,result text, user text);
CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY AUTO_INCREMENT,cluster text NOT NULL ,nextstarttime DATETIME NOT NULL, laststarttime DATETIME, scheduleinterval INTEGER NOT NULL, docompaction TINYINT NOT NULL, status INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS repairs(id INTEGER PRIMARY KEY AUTO_INCREMENT,cluster text NOT NULL, starttime DATETIME, endtime DATETIME, totalnode INTEGER, repairednode INTEGER NOT NULL, failednode INTEGER NOT NULL, status INTEGER NOT NULL);
