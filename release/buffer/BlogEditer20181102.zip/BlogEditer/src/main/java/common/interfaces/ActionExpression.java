package common.interfaces;

public interface ActionExpression<T> {
	void run(T node);
}
