�폜
https://mdbootstrap.com/wp-content/themes/mdbootstrap4/inc/get_social_counts.php?thisurl=
https://sfmonitor.herokuapp.com/f?h=
https://mdbootstrap.com/registration-completed/
"mdbootstrap.com"!==e
