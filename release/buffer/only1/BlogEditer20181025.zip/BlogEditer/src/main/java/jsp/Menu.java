package jsp;

import bean.SideMenuBean;
import common.JspServlet;
import common.annotations.JspName;

@JspName("menu.jsp")
public class Menu extends JspServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected Object doJspMain() throws Exception {
		SideMenuBean bean = new SideMenuBean();
		/*List<CategoryBean> mainList = new ArrayList<>();
		for (Category m : FactoryDao.getDao(CategoryDao.class).selectAll()) {
			CategoryBean sublist = new CategoryBean();
			mainList.add(sublist);
			sublist.setCategoryIdx(m.getIdx());
			sublist.setCategoryName(m.getCategoryName());
			sublist.setChild(new ArrayList<>());
			for (Category s : list.stream().filter(y -> y.getParentCategory() != null && y.getParentCategory().getIdx() == m.getIdx()).collect(Collectors.toList())) {
				CategoryBean subbean = new CategoryBean();
				subbean.setCategoryIdx(s.getIdx());
				subbean.setCategoryName(s.getCategoryName());
				sublist.getChild().add(subbean);
			}
		}
		bean.setSidemenu(mainList);*/
		return bean;
	}

	@Override
	protected void error(Throwable e) {

	}

}
