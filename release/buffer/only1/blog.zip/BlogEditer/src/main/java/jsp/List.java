package jsp;

import common.JspServlet;
import common.annotations.JspName;

@JspName("list.jsp")
public class List extends JspServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected Object doJspMain() throws Exception {
		return null;
	}

	@Override
	protected void error(Throwable e) {

	}
}
