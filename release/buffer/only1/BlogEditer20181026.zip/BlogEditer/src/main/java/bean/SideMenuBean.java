package bean;

import java.util.List;

public class SideMenuBean {
	private List<CategoryBean> sidemenu;

	public List<CategoryBean> getSidemenu() {
		return sidemenu;
	}

	public void setSidemenu(List<CategoryBean> sidemenu) {
		this.sidemenu = sidemenu;
	}

}
