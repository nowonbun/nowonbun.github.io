package login;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.JsonArray;
import bean.ApplyBean;
import bean.MallBean;
import bean.LoginBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.CheckingTemporaryDao;
import dao.CmcodeDao;
import dao.MallDao;
import dao.MemberDao;
import dao.TermDao;
import model.master.Cmcode;
import model.master.Term;
import model.transaction.CheckingTemporary;
import model.transaction.Member;
import model.transaction.MemberMall;
import model.transaction.MemberTerm;
import model.transaction.User;

public class ApplyUser extends IServlet {

	private static final long serialVersionUID = 1L;
	public static String TemporaryMailCheckCode = "MAIL";
	private static Login loginServlet = null;
	private ApplyBean apply = null;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return false;
		}
		apply = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			ApplyBean bean = new ApplyBean();
			bean.setId(JsonConverter.JsonString(obj, "id"));
			bean.setIdCheck("true".equals(JsonConverter.JsonString(obj, "idCheck")));
			bean.setAuth(JsonConverter.JsonString(obj, "auth"));
			bean.setPwd(JsonConverter.JsonString(obj, "pwd"));
			bean.setComp(JsonConverter.JsonString(obj, "comp"));
			bean.setBizno(JsonConverter.JsonString(obj, "bizno"));
			bean.setBiznoCheck("true".equals(JsonConverter.JsonString(obj, "biznoCheck")));
			bean.setOwner(JsonConverter.JsonString(obj, "owner"));
			bean.setOwnerp(JsonConverter.JsonString(obj, "ownerp"));
			bean.setOwnerpCheck("true".equals(JsonConverter.JsonString(obj, "ownerpCheck")));
			bean.setMallcount(JsonConverter.JsonInteger(obj, "mallcount"));
			bean.setMall(new ArrayList<>());
			JsonArray array = obj.getJsonArray("mall");
			for (int i = 0; i < bean.getMallcount(); i++) {
				bean.getMall().add(JsonConverter.parseObject(array.get(i).toString(), (subobj) -> {
					MallBean sub = new MallBean();
					sub.setCode(JsonConverter.JsonString(subobj, "code"));
					sub.setId1(JsonConverter.JsonString(subobj, "id1"));
					sub.setId2(JsonConverter.JsonString(subobj, "id2"));
					sub.setId3(JsonConverter.JsonString(subobj, "id3"));
					sub.setPw1(JsonConverter.JsonString(subobj, "pw1"));
					sub.setPw2(JsonConverter.JsonString(subobj, "pw2"));
					sub.setOp1(JsonConverter.JsonString(subobj, "op1"));
					sub.setOp2(JsonConverter.JsonString(subobj, "op2"));
					return sub;
				}));
			}
			return bean;
		});
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		resParam.setCode(ResponseCodeMap.CODE201);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (!apply.isIdCheck()) {
			resParam.setCode(ResponseCodeMap.CODE501);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE501));
			return;
		}
		CheckingTemporary temp = FactoryDao.getDao(CheckingTemporaryDao.class).getCheckingTemporary(CheckMailAddress.TemporaryMailCheckCode, apply.getId());
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(CheckMailAddress.TemporaryMailCheckCode, apply.getId());
		if (temp == null || !Util.StringEquals(temp.getValue(), apply.getAuth())) {
			resParam.setCode(ResponseCodeMap.CODE504);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE504));
			return;
		}
		if (!apply.isOwnerpCheck()) {
			resParam.setCode(ResponseCodeMap.CODE502);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE502));
			return;
		}
		if (!apply.isBiznoCheck()) {
			resParam.setCode(ResponseCodeMap.CODE503);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE503));
			return;
		}
		temp = FactoryDao.getDao(CheckingTemporaryDao.class).getCheckingTemporary(CheckBizNo.TemporaryBIZNOCheckCode, apply.getId());
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(CheckBizNo.TemporaryBIZNOCheckCode, apply.getId());
		if (temp == null || !Util.StringEquals(temp.getValue(), apply.getBizno())) {
			resParam.setCode(ResponseCodeMap.CODE504);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE504));
			return;
		}
		try {
			Member member = new Member();
			member.setCompanyNm(apply.getComp());
			member.setCmcode(FactoryDao.getDao(CmcodeDao.class).getCmcode("A011", "10"));
			member.setStateDt(new Date());
			member.setBizNo(apply.getBizno());
			member.setCeoNm(apply.getOwner());
			member.setCeoPhone(apply.getOwnerp());
			member.setSignupDt(new Date());
			member.setSignupRoute("");
			member.setInsertDt(new Date());
			member.setInsertMethod(getClass().getName());
			member.setUpdateDt(new Date());
			member.setUpdateMethod(getClass().getName());

			member.setUsers(new User());
			member.getUser().setEmail(apply.getId());
			member.getUser().setPassword(Util.convertMD5(apply.getPwd()));
			member.getUser().setCmcode(FactoryDao.getDao(CmcodeDao.class).getCmcode("A011", "10"));
			member.getUser().setStateDt(new Date());
			member.getUser().setInsertDt(new Date());
			member.getUser().setInsertMethod(getClass().getName());
			member.getUser().setUpdateDt(new Date());
			member.getUser().setUpdateMethod(getClass().getName());
			member.getUser().setPwChangeDt(new Date());
			member.getUser().setMember(member);

			member.setMemberMalls(new ArrayList<>());
			for (MallBean bean : apply.getMall()) {
				MemberMall mall = new MemberMall();
				mall.setMall(FactoryDao.getDao(MallDao.class).getTerm(bean.getCode()));
				mall.setId1Value(bean.getId1());
				mall.setId2Value(bean.getId2());
				mall.setId3Value(bean.getId3());
				mall.setPw1Value(bean.getPw1());
				mall.setPw2Value(bean.getPw2());
				mall.setOption1Value(bean.getOp1());
				mall.setOption2Value(bean.getOp2());
				mall.setInsertDt(new Date());
				mall.setInsertMethod(getClass().getName());
				mall.setUpdateDt(new Date());
				mall.setUpdateMethod(getClass().getName());
				member.addMemberMall(mall);
			}

			/*member.setMemberServices(new ArrayList<>());
			MemberService service = new MemberService();
			service.setService(FactoryDao.getDao(ServiceDao.class).getService(reqParam.getServiceid()));
			service.setInsertDt(new Date());
			service.setInsertMethod(getClass().getName());
			service.setUpdateDt(new Date());
			service.setUpdateMethod(getClass().getName());
			member.addMemberService(service);*/

			member.setMemberTerms(new ArrayList<>());
			List<Cmcode> list = FactoryDao.getDao(CmcodeDao.class).getTermCodeList();
			for(Cmcode l : list) {
				Term term = getTerm(l.getId().getCode());
				if(term != null) {
					MemberTerm memberTerm = new MemberTerm();
					memberTerm.setMember(member);
					memberTerm.setTerm(term);
					memberTerm.setInsertDt(new Date());
					memberTerm.setInsertMethod(getClass().getName());
					memberTerm.setUpdateDt(new Date());
					memberTerm.setUpdateMethod(getClass().getName());
					member.addMemberTerm(memberTerm);
				}
			}
			
			FactoryDao.getDao(MemberDao.class).create(member);
			LoginBean login = new LoginBean();
			login.setId(member.getUser().getEmail());
			login.setMd5(member.getUser().getPassword());
			reqParam.setParams(JsonConverter.create(login));
			if (loginServlet == null) {
				loginServlet = new Login();
			}
			loginServlet.doWork(getRequest(), getResponse(), reqParam, resParam);

			resParam.setCode(ResponseCodeMap.CODE500);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE500));
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
	}

	private Term getTerm(String idx) {
		List<Term> terms = FactoryDao.getDao(TermDao.class)
									 .getTermAll()
									 .stream()
									 .filter(x -> x.getIsUse() && x.getId().getTermsType().equals(idx))
									 .collect(Collectors.toList());
		Term term = null;
		for (Term t : terms) {
			if (term == null) {
				term = t;
			}
			if (t.getId().getVersion() > term.getId().getVersion()) {
				term = t;
			}
		}
		return term;
	}

}
