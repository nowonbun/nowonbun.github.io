package login;

import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.MemberDao;
import model.transaction.Member;

public class SearchUserId extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return false;
		}
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		resParam.setCode(ResponseCodeMap.CODE201);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		
		String bizNo = null;
		try {
			bizNo = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "bizNo");
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		Member member = FactoryDao.getDao(MemberDao.class).getMemberByBizNo(bizNo);
		if (member == null) {
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return;
		}
		String email = member.getUser().getEmail();
		String prefix = email.substring(0, email.indexOf("@"));
		String suffix = email.substring(email.indexOf("@"), email.length());
		if (prefix.length() > 3) {
			prefix = prefix.substring(0, 3) + "*******";
		}
		resParam.setCode(ResponseCodeMap.CODE101);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE101));
		resParam.setData(prefix + suffix);
	}

}
