package model.master.key;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class TermPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "terms_type")
	private String termsType;

	private int version;

	public TermPK() {
	}

	public String getTermsType() {
		return this.termsType;
	}

	public void setTermsType(String termsType) {
		this.termsType = termsType;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TermPK)) {
			return false;
		}
		TermPK castOther = (TermPK) other;
		return this.termsType.equals(castOther.termsType) && (this.version == castOther.version);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.termsType.hashCode();
		hash = hash * prime + this.version;

		return hash;
	}
}