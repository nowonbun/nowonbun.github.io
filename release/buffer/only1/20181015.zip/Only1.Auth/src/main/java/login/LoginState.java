package login;

import java.util.Date;

import javax.servlet.http.Cookie;

import bean.DataBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import model.transaction.AccessLog;
import model.transaction.User;
import model.transaction.UserAuth;

/**
 * writer - Soonyub Hwang
 * 
 * Finally updated data - 2018/10/09
 * 
 * Finally Code review - 2018/10/09 Soonyub Hwang
 * 
 * This is that check login. The first check is session checking.If failed it,
 * the second is cookie checking. If also failed it, finally is parameter
 * checking. If all checking failed it, this class will return the failed
 * message. Unless, the success message will be sent.
 */
public class LoginState extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		getLogger().error("[error] error message - " + e);
		// TODO: error log data insert?
		resParam.setCode(ResponseCodeMap.CODE001);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		String authId = (String) getSession().getAttribute(SESSION_KEY);
		User userBean = (User) getSession().getAttribute(USER_SESSION_KEY);
		if (authId != null && userBean != null) {
			getLogger().info("[doMain] The authentication id was exists in session. - " + authId);
			UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
			if (userAuth != null && userAuth.getUser().getIdx() == userBean.getIdx()) {
				getLogger().info("[doMain] The session value was completed that check with database.");
				setLoginOk(authId, userAuth.getUser(), reqParam, resParam);
				return;
			}
			getLogger().info("[doMain] The session value was failed that check with database.");
		}
		Cookie cookie = getCookie(getCookieKey());
		if (cookie != null) {
			authId = cookie.getValue();
			getLogger().info("[doMain] The authentication id was exists in cookie. - " + authId);
			UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
			if (userAuth != null) {
				getLogger().info("[doMain] The cookie value was completed that check with database.");
				setLoginOk(authId, userAuth.getUser(), reqParam, resParam);
				return;
			}
			getLogger().info("[doMain] The cookie value was failed that check with database.");
		}

		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			getLogger().info("[doMain] The parameter was not setted.");
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}
		try {
			authId = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "authid");
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		if (authId == null) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
		if (userAuth == null) {
			getLogger().info("[doMain] The parameter value was failed that check with database.");
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}
		getLogger().info("[doMain] The parameter value was complated that check with database.");
		userBean = userAuth.getUser();
		setLoginOk(authId, userBean, reqParam, resParam);
	}

	private void setLoginOk(String authId, User userBean, RequestParameter reqParam, ResponseParameter resParam) {
		resParam.setCode(ResponseCodeMap.CODE000);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE000));
		DataBean data = new DataBean();
		data.setAuthId(authId);
		resParam.setData(JsonConverter.create(data));
		updateAccessLog(authId, reqParam.getServiceid(), userBean, resParam.getMessage());
		super.setCookie(getCookieKey(), authId);
		getSession().setAttribute(SESSION_KEY, authId);
		getSession().setAttribute(USER_SESSION_KEY, userBean);

		getLogger().info("[setLoginOk] The key was updated to session and cookie");
	}

	private void updateAccessLog(String authId, String serviceId, User userBean, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setUser(userBean.getIdx());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName());
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
		getLogger().info("[updateAccessLog] The data was updated to table of AccessLog.");
	}
}