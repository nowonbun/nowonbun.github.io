package login;

import java.util.ArrayList;
import bean.MallBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import bean.UserBean;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.UserAuthDao;
import model.transaction.MemberMall;
import model.transaction.User;
import model.transaction.UserAuth;

/**
 * writer - Soonyub Hwang
 * 
 * Finally updated data - 2018/10/09
 * 
 * Finally Code review - 2018/10/09 Soonyub Hwang
 * 
 */
public class GetUserInfo extends IServlet {

	private static final long serialVersionUID = 1L;

	private UserAuth auth;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			getLogger().error("[validate] The parameter was not setted.");
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return false;
		}
		String authId = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			return JsonConverter.JsonString(obj, "authid");
		});
		if (authId == null) {
			getLogger().error("[validate] The parameter of authid was not setted.");
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return false;
		}
		auth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
		if (auth == null) {
			getLogger().error("[validate] The parameter of authid was not exists in database.");
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return false;
		}
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		getLogger().error("[error] error message - " + e);
		// TODO: error log data insert?
		resParam.setCode(ResponseCodeMap.CODE201);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		UserBean bean = new UserBean();
		User user = auth.getUser();
		bean.setId(user.getEmail());
		bean.setBizno(user.getMember().getBizNo());
		bean.setComp(user.getMember().getCompanyNm());
		bean.setOwner(user.getMember().getCeoNm());
		bean.setOwnerp(user.getMember().getCeoPhone());
		bean.setMallcount(user.getMember().getMemberMalls().size());
		bean.setMall(new ArrayList<>());
		for (MemberMall mall : user.getMember().getMemberMalls()) {
			MallBean mallbean = new MallBean();
			mallbean.setCode(mall.getMall().getMallId());
			mallbean.setId1(mall.getId1Value());
			mallbean.setId2(mall.getId2Value());
			mallbean.setId3(mall.getId3Value());
			mallbean.setPw1(mall.getPw1Value());
			mallbean.setPw2(mall.getPw2Value());
			mallbean.setOp1(mall.getOption1Value());
			mallbean.setOp2(mall.getOption2Value());
			bean.getMall().add(mallbean);
		}
		resParam.setCode(ResponseCodeMap.CODE101);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE101));
		resParam.setData(JsonConverter.create(bean));
		getLogger().info("[doMain] The lookup was updated.");
	}
}