package info;

import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.annotation.WebServlet;
import bean.RequestParameter;
import bean.ResponseParameter;
import bean.TermBean;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import dao.CmcodeDao;
import dao.TermDao;
import model.master.Cmcode;
import model.master.Term;

@WebServlet("/GetTermContents")
public class GetTermContents extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		String idx = getRequest().getParameter("idx");
		Cmcode code = FactoryDao.getDao(CmcodeDao.class).getCmcode("A013", idx);
		if (code == null) {
			super.setStatus(403);
			return;
		}
		 ;
		List<Term> terms = FactoryDao.getDao(TermDao.class)
								    .getTermAll()
								    .stream()
								    .filter(x -> x.getIsUse() && x.getId().getTermsType().equals(idx))
								    .collect(Collectors.toList());
		Term term = null;
		for (Term t : terms) {
			if(term == null) {
				term = t;
			}
			if (t.getId().getVersion() > term.getId().getVersion()) {
				term = t;
			}
		}
		TermBean bean = new TermBean();
		bean.setTitle(code.getValue());
		bean.setContens(term.getContent());
		getResponse().setContentType("text/html;charset=UTF-8");
		getPrinter().println(JsonConverter.create(bean));
	}

	@Override
	protected void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

}
