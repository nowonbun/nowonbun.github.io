package login;

import java.util.Date;
import javax.servlet.http.Cookie;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import model.transaction.AccessLog;

/**
 * writer - Soonyub Hwang
 * 
 * Finally updated data - 2018/10/09
 * 
 * Finally Code review - 2018/10/09 Soonyub Hwang
 * 
 * This is logout class. This class default return data is OK.That means is if
 * the data does not exists, it will be returned for OK. The logout procedure is
 * session, cookie and parameter.
 */
public class Logout extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		getLogger().error("[error] error message - " + e);
		// TODO: error log data insert?
		resParam.setCode(ResponseCodeMap.CODE001);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		resParam.setCode(ResponseCodeMap.CODE002);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE002));
		String redirect = "";
		try {
			redirect = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "redirect");
			});
		} catch (Throwable e) {
			getLogger().warn("[doMain] redirect paramter parsing error.");
		}
		String authId = (String) getSession().getAttribute(SESSION_KEY);
		if (authId != null) {
			getSession().removeAttribute(SESSION_KEY);
			getSession().removeAttribute(USER_SESSION_KEY);
			getLogger().info("[doMain] The session was removed. " + authId);
			if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
				getLogger().info("[doMain] The authentication id was removed in database. " + authId);
				updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
			}
		}
		Cookie cookie = getCookie(getCookieKey());
		if (cookie != null) {
			authId = cookie.getValue();
			deleteCookie(getCookieKey());
			getLogger().info("[doMain] The cookie was removed. " + authId);
			if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
				getLogger().info("[doMain] The authentication id was removed in database. " + authId);
				updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
			}
		}
		if (reqParam.getParams() != null && !Util.StringIsEmptyOrNull(reqParam.getParams())) {
			try {
				authId = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
					return JsonConverter.JsonString(obj, "authid");
				});
				if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
					getLogger().info("[doMain] The authentication id was removed in database. " + authId);
					updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
				}
			} catch (Throwable e) {
				getLogger().warn("[doMain] authId paramter parsing error.");
			}
		}
		String url = "./?service=" + reqParam.getServiceid() + "&redirect=" + redirect;
		getLogger().info("[doMain] Redirect url - " + url);
		redirect(url);
	}

	private void updateAccessLog(String authId, String serviceId, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName() + ".doMain");
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
		getLogger().info("[updateAccessLog] The data was updated to table of AccessLog.");
	}

}
