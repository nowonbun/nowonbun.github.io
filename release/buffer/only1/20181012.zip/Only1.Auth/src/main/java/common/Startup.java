package common;

import javax.servlet.annotation.WebServlet;

import bean.RequestParameter;
import bean.ResponseParameter;

@WebServlet("/Startup")
public class Startup extends IServlet {

	private static final long serialVersionUID = 1L;
	
	public void init() {
		getLogger().info("OneId system is starting.");
		FactoryDao.initializeMaster();
	}

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		FactoryDao.resetMaster();
	}

}
