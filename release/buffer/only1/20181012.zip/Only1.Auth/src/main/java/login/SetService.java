package login;

import java.util.Date;
import java.util.List;
import bean.RequestParameter;
import bean.ResponseParameter;
import bean.ServiceBean;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.MemberDao;
import dao.ServiceDao;
import dao.UserAuthDao;
import model.transaction.Member;
import model.transaction.MemberService;
import model.transaction.User;
import model.transaction.UserAuth;

public class SetService extends IServlet {
	private static final long serialVersionUID = 1L;
	private ServiceBean bean = null;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return false;
		}
		bean = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			ServiceBean bean = new ServiceBean();
			bean.setAuthid(JsonConverter.JsonString(obj, "authid"));
			bean.setServiceid(JsonConverter.JsonString(obj, "serviceid"));
			return bean;
		});
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		resParam.setCode(ResponseCodeMap.CODE201);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		UserAuth auth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(bean.getAuthid());
		if (auth == null) {
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return;
		}
		User user = auth.getUser();
		Member member = user.getMember();
		List<MemberService> services = member.getMemberServices();
		if (services.stream().filter(x -> x.getService().getServiceId().equals(bean.getServiceid()) && x.getIx() == null).count() < 1) {
			MemberService service = new MemberService();
			service.setService(FactoryDao.getDao(ServiceDao.class).getService(bean.getServiceid()));
			service.setInsertDt(new Date());
			service.setInsertMethod(this.getClass().getName());
			service.setUpdateDt(new Date());
			service.setUpdateMethod(this.getClass().getName());
			services.add(service);
		}

		FactoryDao.getDao(MemberDao.class).update(member);
		resParam.setCode(ResponseCodeMap.CODE507);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE507));
	}
}
