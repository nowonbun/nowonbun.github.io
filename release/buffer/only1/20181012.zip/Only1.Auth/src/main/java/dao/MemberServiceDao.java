package dao;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.TransactionDao;
import model.transaction.MemberService;

public class MemberServiceDao extends TransactionDao<MemberService> {

	protected MemberServiceDao() {
		super(MemberService.class);
	}

	public boolean hasService(int idx, String serviceid) {
		return transaction((em) -> {
			try {
				String qy = "SELECT m FROM MemberService m WHERE m.member.idx = :idx AND m.service.serviceId = :serviceid AND m.ix is null";
				Query query = em.createQuery(qy);
				query.setParameter("idx", idx);
				query.setParameter("serviceid", serviceid);
				MemberService m = (MemberService) query.getSingleResult();
				if (m != null) {
					return true;
				}
				return false;
			} catch (NoResultException e) {
				return false;
			}
		});
	}
}
