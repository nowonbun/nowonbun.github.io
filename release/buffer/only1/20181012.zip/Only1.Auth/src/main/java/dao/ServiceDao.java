package dao;

import java.util.List;
import java.util.NoSuchElementException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.MasterDao;
import model.master.Service;

public class ServiceDao extends MasterDao<Service> {

	protected ServiceDao() {
		super(Service.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<Service> getDataList() {
		return transaction((em) -> {
			try {
				Query query = em.createNamedQuery("Service.findAll", Service.class);
				return (List<Service>) query.getResultList();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public Service getService(String serviceId) {
		try {
			return getData().stream().filter(x -> x.getServiceId().equals(serviceId)).findFirst().get();
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	public List<Service> getServiceAll() {
		return getData();
	}
}
