package model.transaction;

import java.io.Serializable;
import javax.persistence.*;

import model.master.Cmcode;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "tsn_member")
@NamedQuery(name = "Member.findAll", query = "SELECT m FROM Member m")
public class Member implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;

	@Column(name = "biz_no")
	private String bizNo;

	@Column(name = "ceo_nm")
	private String ceoNm;

	@Column(name = "ceo_phone")
	private String ceoPhone;

	@Column(name = "company_nm")
	private String companyNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	private String ix;

	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "signup_dt")
	private Date signupDt;

	@Column(name = "signup_route")
	private String signupRoute;

	@ManyToOne
	@JoinColumns({ @JoinColumn(name = "group_cd", referencedColumnName = "group_cd"), @JoinColumn(name = "code", referencedColumnName = "code") })
	private Cmcode cmcode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "state_dt")
	private Date stateDt;

	@Column(name = "state_reason")
	private String stateReason;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	@OneToMany(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<MemberMall> memberMalls;

	@OneToMany(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<MemberService> memberServices;

	@OneToMany(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<MemberTerm> memberTerms;

	@OneToOne(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;

	public Member() {
	}

	public int getIdx() {
		return this.idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getBizNo() {
		return this.bizNo;
	}

	public void setBizNo(String bizNo) {
		this.bizNo = bizNo;
	}

	public String getCeoNm() {
		return this.ceoNm;
	}

	public void setCeoNm(String ceoNm) {
		this.ceoNm = ceoNm;
	}

	public String getCeoPhone() {
		return this.ceoPhone;
	}

	public void setCeoPhone(String ceoPhone) {
		this.ceoPhone = ceoPhone;
	}

	public String getCompanyNm() {
		return this.companyNm;
	}

	public void setCompanyNm(String companyNm) {
		this.companyNm = companyNm;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getSignupDt() {
		return this.signupDt;
	}

	public void setSignupDt(Date signupDt) {
		this.signupDt = signupDt;
	}

	public String getSignupRoute() {
		return this.signupRoute;
	}

	public void setSignupRoute(String signupRoute) {
		this.signupRoute = signupRoute;
	}

	public Cmcode getCmcode() {
		return this.cmcode;
	}

	public void setCmcode(Cmcode cmcode) {
		this.cmcode = cmcode;
	}

	public Date getStateDt() {
		return this.stateDt;
	}

	public void setStateDt(Date stateDt) {
		this.stateDt = stateDt;
	}

	public String getStateReason() {
		return this.stateReason;
	}

	public void setStateReason(String stateReason) {
		this.stateReason = stateReason;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public List<MemberMall> getMemberMalls() {
		return this.memberMalls;
	}

	public void setMemberMalls(List<MemberMall> memberMalls) {
		this.memberMalls = memberMalls;
	}

	public MemberMall addMemberMall(MemberMall memberMall) {
		getMemberMalls().add(memberMall);
		memberMall.setMember(this);

		return memberMall;
	}

	public MemberMall removeMemberMall(MemberMall memberMall) {
		getMemberMalls().remove(memberMall);
		memberMall.setMember(null);

		return memberMall;
	}

	public List<MemberService> getMemberServices() {
		return this.memberServices;
	}

	public void setMemberServices(List<MemberService> memberServices) {
		this.memberServices = memberServices;
	}

	public MemberService addMemberService(MemberService memberService) {
		getMemberServices().add(memberService);
		memberService.setMember(this);

		return memberService;
	}

	public MemberService removeMemberService(MemberService memberService) {
		getMemberServices().remove(memberService);
		memberService.setMember(null);

		return memberService;
	}

	public List<MemberTerm> getMemberTerms() {
		return this.memberTerms;
	}

	public void setMemberTerms(List<MemberTerm> memberTerms) {
		this.memberTerms = memberTerms;
	}

	public MemberTerm addMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().add(memberTerm);
		memberTerm.setMember(this);

		return memberTerm;
	}

	public MemberTerm removeMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().remove(memberTerm);
		memberTerm.setMember(null);

		return memberTerm;
	}

	public User getUser() {
		return this.user;
	}

	public void setUsers(User user) {
		this.user = user;
	}

}