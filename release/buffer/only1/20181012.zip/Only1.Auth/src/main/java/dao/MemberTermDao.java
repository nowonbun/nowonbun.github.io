package dao;

import common.TransactionDao;
import model.transaction.MemberTerm;

public class MemberTermDao extends TransactionDao<MemberTerm> {

	protected MemberTermDao() {
		super(MemberTerm.class);
	}
}
