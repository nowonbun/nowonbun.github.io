/**
 * 
 */
function logout(){
	location.href="logout.html";
}
function numOnly(event) {
    return !String.fromCharCode(event.keyCode).match(/[^0-9a-i^\`\b\r]/);
}
function keyup(obj) {
    pBuffer = unNumberFormat(obj.value);
    pBuffer = Number(pBuffer) + "";
    if(pBuffer === "NaN"){
    	pBuffer = "0";
    }
    obj.value = numberFormat(pBuffer);
}
function numberFormat(num) {
    pattern = /(-?[0-9]+)([0-9]{3})/;
    while (pattern.test(num)) {
        num = num.replace(pattern, "$1,$2");
    }
    return num;
}
function unNumberFormat(num) {
    return (num.replace(/\,/g, ""));
}
function loddingShow(){
	$(".lodding").show();
}
function loddingHide(){
	$(".lodding").hide();
}
function send(ws,func, data) {
	msg = JSON.stringify({
		"func" : func,
		"data" : data
	});
	ws.send(msg);
}
function getEndpointUri(location, name) {
	var wsProtocol = (("https:" == location.protocol) ? "wss:" : "ws:");
	var wsHost = location.host;
	var wsContextPath = location.pathname.split("/")[1];
	return wsProtocol + "//" + wsHost + "/" + wsContextPath + "/ws/" + name;
}
function getDateTicks(ticks) {
  var date = new Date(ticks);
  var mm = date.getMonth()+1;
  var dd = date.getDate();
  var yy = date.getFullYear();
  if (mm < 10) mm = "0"+mm;
  if (dd < 10) dd = "0"+dd;
  return yy+"-"+mm+"-"+dd;
}
function setNullCheck(value){
	if(value == null)
		return "";
	else
		return value;
}
function setNull(value){
	if(value == ""){
		return null;
	}else{
		return value;
	}
}
function setMessage(value){
	$("div.buttonDiv > table > tbody > tr > td > span").html(value);
	$("div.buttonDiv > table > tbody > tr > td > span").show();
	setTimeout("setMessageHide()",2000);
}
function setMessageHide(){
	$("div.buttonDiv > table > tbody > tr > td > span").hide();
}