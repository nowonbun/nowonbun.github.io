package kr.pe.nowonbun.household2.browser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.UsertableDao;
import kr.pe.nowonbun.household2.entity.Usertable;

public class HBPostLogin extends HController {
	@RequestMapping(value = "/browser/login.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		//TODO` パラメータにUsertableクラスがあった
		return initialize(modelmap, session, req, res); 
	}
	public String run(){
		Usertable usertable = new Usertable();
		usertable.setUserid(getParameter("userid"));
		usertable.setUsername(getParameter("username"));
		getLogger().info("Web browser's login authentication is starting.");
		
		UsertableDao dao = FactoryDao.getDao(UsertableDao.class);
		String userid = usertable.getUserid();
		//TODO パスワード？
		getLogger().info("Web browser's login ID - " + userid);
		usertable = dao.checkPassword(usertable);
		if (usertable != null) {
			getLogger().info("Web browser's login OK.");
			setUserInfoSession(usertable);
			createConnectLog(userid);
			return "redirect:main.html";
		} else {
			getLogger().info("Web browser's login NG.");
			getModelmap().addAttribute("userid", userid);
			getModelmap().addAttribute("errorMsg", "IDまたはパスワードをご確認してください。");
			return "/browser/login";
		}
	}
}
