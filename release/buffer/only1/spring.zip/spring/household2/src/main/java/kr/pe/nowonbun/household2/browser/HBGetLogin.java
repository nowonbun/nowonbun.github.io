package kr.pe.nowonbun.household2.browser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.UsertableDao;
import kr.pe.nowonbun.household2.entity.Usertable;

@Controller
public class HBGetLogin extends HController {
	@RequestMapping(value = "/browser/login.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return super.initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("Web browser's login page is opening.");
		
		if (getUerInfoSession() != null) {
			getLogger().info("session is lived. id - " + getUerInfoSession().getUserid());
			createConnectLog(getUerInfoSession().getUserid());
			return "redirect:main.html";
		}
		getLogger().info("Loggin Page open");
		return "/browser/login";
	}

}
