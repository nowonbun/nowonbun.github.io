package kr.pe.nowonbun.household2.common;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;

public class HWebFilter implements Filter{

	private static Logger logger = LoggerFactory.getLogger(HWebFilter.class);
	private ArrayList<String> passUrl = null;
	private String contextPath;
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	public void doFilter(ServletRequest sreq, ServletResponse sres, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)sreq;
		HttpServletResponse res = (HttpServletResponse)sres;
		HttpSession session = req.getSession();
		String url = req.getRequestURI();
		for(String buf : passUrl){
			if(buf.equals(url)){
				chain.doFilter(req, res);
				logger.info("This page is inapplicable. url - " + url);
				return;
			}
		}
		Object buffer = null;
		if((buffer = session.getAttribute(HController.USERINFO)) != null){
			session.setAttribute(HController.USERINFO,buffer);
			chain.doFilter(req, res);
			return;
		}
		logger.info("login Authentication is failed");
		res.sendRedirect(contextPath);
	}
	public void init(FilterConfig config) throws ServletException {
		contextPath = config.getServletContext().getContextPath();
		passUrl = new ArrayList<String>();
		String[] ignoredPaths = config.getInitParameter("passPage").split(",");
		for (String ignoredPath : ignoredPaths) {
			passUrl.add(contextPath + ignoredPath);
		}
	}

}
