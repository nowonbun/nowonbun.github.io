$.mobile.ajaxEnabled = false;
function supportsTouch() {
    var android = navigator.userAgent.indexOf('Android') != -1;
    if(navigator.userAgent.indexOf('Chrome/42') != -1){
    	return false;	//Chrome 42.0にバグがありそう。
    }else{
    	return android || !!('createTouch' in document)
     }
}
function NoClickDelay(el) {
    this.element = el;
    if (supportsTouch()) this.element.addEventListener('touchstart', this, false);
}
function mainForm(){
	location.href = "main.html";
}
function logout(){
	location.href="logout.html";
}
function loddingShow(){
	$(".lodding").show();
}
function loddingHide(){
	$(".lodding").hide();
}
function numberFormat(num) {
    pattern = /(-?[0-9]+)([0-9]{3})/;
    while (pattern.test(num)) {
        num = num.replace(pattern, "$1,$2");
    }
    return num;
}
function getEndpointUri(location, name) {
	var wsProtocol = (("https:" == location.protocol) ? "wss:" : "ws:");
	var wsHost = location.host;
	var wsContextPath = location.pathname.split("/")[1];
	return wsProtocol + "//" + wsHost + "/" + wsContextPath + "/ws/" + name;
}
function send(ws,func, data) {
	msg = JSON.stringify({
		"func" : func,
		"data" : data
	});
	ws.send(msg);
}
function setCookie(cName, cValue, cDay){
    var expire = new Date();
    expire.setDate(expire.getDate() + cDay);
    cookies = cName + '=' + escape(cValue) + '; path=/ ';
    if(typeof cDay != 'undefined') cookies += ';expires=' + expire.toGMTString() + ';';
    document.cookie = cookies;
}
function getCookie(cName) {
    cName = cName + '=';
    var cookieData = document.cookie;
    var start = cookieData.indexOf(cName);
    var cValue = '';
    if(start != -1){
        start += cName.length;
        var end = cookieData.indexOf(';', start);
        if(end == -1)end = cookieData.length;
        cValue = cookieData.substring(start, end);
    }
    return unescape(cValue);
}
function getDateTicks(ticks) {
  var date = new Date(ticks);
  var mm = date.getMonth()+1;
  var dd = date.getDate();
  var yy = date.getFullYear();
  if (mm < 10) mm = "0"+mm;
  if (dd < 10) dd = "0"+dd;
  return yy+"-"+mm+"-"+dd;
}
NoClickDelay.prototype = {
    handleEvent: function (e) {
        switch (e.type) {
            case 'touchstart': this.onTouchStart(e); break;
            case 'touchmove': this.onTouchMove(e); break;
            case 'touchend': this.onTouchEnd(e); break;
        }
    },

    onTouchStart: function (e) {
        e.preventDefault();
        this.moved = false;
        this.element.addEventListener('touchmove', this, false);
        this.element.addEventListener('touchend', this, false);
    },

    onTouchMove: function (e) {
        this.moved = true;
    },

    onTouchEnd: function (e) {
        this.element.removeEventListener('touchmove', this, false);
        this.element.removeEventListener('touchend', this, false);

        if (!this.moved) {
            var theTarget = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
            if (theTarget.nodeType == 3) theTarget = theTarget.parentNode;

            var theEvent = document.createEvent('MouseEvents');
            theEvent.initEvent('click', true, true);
            theTarget.dispatchEvent(theEvent);
        }
    }
};