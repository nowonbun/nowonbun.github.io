$(document).ready(function () {
   $("div#header > h2").html("カテゴリ設定");
});
function categoryadd(){
	location.href = "categoryinsert.html";
}
function categorymodify(idx,obj){
	obj.style.backgroundColor = "#CBECC7";
	location.href = "categorymodify.html?idx="+idx;
}