package kr.pe.nowonbun.household2.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.entity.Connectlog;

public class ConnectlogDao extends HDao<Connectlog>{

//	public final static String LASTCONNECTIONTIME = "LastConnectionTime";

	public void connectUser(String userid){
		Connectlog entity = getTemplate();
		entity.setUserid(userid);
		entity.setConntecttime(new Timestamp(new Date().getTime()));
		super.create(entity);
	}
	
	public Connectlog getLastConnectionTime(String userid){
		Connectlog where = getTemplate();
		where.setUserid(userid);
		List<Connectlog> list = super.selectToList(where, "conntecttime desc");
		if(list.size() < 2){
			return null;
		}
		//0の場合は現在接続ログ
		return list.get(1);
		//TODO:データがない場合は？
		//return super.selectToList(where, "conntecttime desc").stream().findFirst().get();
	}
}
