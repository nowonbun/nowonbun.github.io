package kr.pe.nowonbun.household2.common.abstractCommon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class HProcess {
	private Logger logger = null;
	public HProcess(){
		logger = LoggerFactory.getLogger(this.getClass());
	}
	protected Logger getLogger(){
		if(logger == null){
			logger = LoggerFactory.getLogger(this.getClass());
		}
		return this.logger;
	}
}
