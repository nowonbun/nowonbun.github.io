package kr.pe.nowonbun.household2.entity;

import java.io.Serializable;
import javax.persistence.*;

import kr.pe.nowonbun.household2.common.abstractCommon.HObject;


/**
 * The persistent class for the session database table.
 * 
 */
@Entity
@Table(name="session",schema="household")
@NamedQueries({
	@NamedQuery(name="Session.findAll", query="SELECT s FROM Session s"),
	@NamedQuery(name="Session.findActive", query="SELECT s FROM Session s where s.userid=:pk")
})

public class Session extends HObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String userid;

	private String sessionkey;

	public Session() {
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getSessionkey() {
		return this.sessionkey;
	}

	public void setSessionkey(String sessionkey) {
		this.sessionkey = sessionkey;
	}

}