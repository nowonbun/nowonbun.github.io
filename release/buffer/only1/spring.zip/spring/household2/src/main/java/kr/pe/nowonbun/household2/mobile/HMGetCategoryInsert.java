package kr.pe.nowonbun.household2.mobile;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

@Controller
public class HMGetCategoryInsert extends HController {
	@RequestMapping(value = "/mobile/categoryinsert.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}

	public String run() {
		getLogger().info("カテゴリ登録画面開始");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
		return "/mobile/categoryinsert";
	}
}
