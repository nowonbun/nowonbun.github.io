package kr.pe.nowonbun.household2.common;

import java.io.Serializable;

public class HWSParams implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String func;
	private Object data;
	public String getFunc() {
		return func;
	}
	public void setFunc(String func) {
		this.func = func;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
}
