package kr.pe.nowonbun.household2.mobile;

import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.SessionDao;
import kr.pe.nowonbun.household2.dao.UsertableDao;
import kr.pe.nowonbun.household2.entity.Session;
import kr.pe.nowonbun.household2.entity.Usertable;

public class HMPostLogin extends HController{
	@RequestMapping(value = "/mobile/login.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		try {
			//TODO Usertable from parameter
			Usertable usertable = new Usertable();
			getLogger().info("Mobile browser's login authentication is starting.");
			
			UsertableDao usertableDao = FactoryDao.getDao(UsertableDao.class);
			String userid = usertable.getUserid();
			getLogger().info("Mobile browser's login ID - " + userid);
			usertable = usertableDao.checkPassword(usertable);
			if (usertable == null) {
				getLogger().info("Mobile browser's login NG.");
				getModelmap().addAttribute("userid", userid);
				getModelmap().addAttribute("errorMsg", "IDまたはパスワードをご確認してください。");
				return "/mobile/login";
			}
			String checked = getParameter("logincookiecheck");
			if ("1".equals(checked)) {
				SessionDao sessionDao = new SessionDao();
				Session sessionEntity = sessionDao.getSession(userid);
				if (sessionEntity == null) {
					sessionEntity = new Session();
					sessionEntity.setUserid(userid);
				}
				//TODO??
				sessionEntity.setSessionkey(getRequest(). getSession().getId());
				sessionDao.updateData(sessionEntity);
				HashMap<String, String> logininfo = new HashMap<String, String>();
				logininfo.put("userid", userid);
				//TODO??
				logininfo.put("passSession", getRequest().getSession().getId());
				ObjectMapper mapper = new ObjectMapper();
				setCookie("cookieLoginInfo", mapper.writeValueAsString(logininfo), 365 * 24 * 60 * 60);
			}
			getLogger().info("Web browser's login OK.");
			setUserInfoSession(usertable);
			createConnectLog(userid);
			Calendar c = Calendar.getInstance();
			setCookie("date", String.format("%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1), 365 * 24 * 60 * 60);
			return "redirect:main.html";
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
}
