package kr.pe.nowonbun.household2.mobile;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

@Controller
public class HMCategoryList extends HController {

	@RequestMapping(value = "/mobile/categorylist.html")
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("カテゴリデータ検索");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		CategoryDao dao = FactoryDao.getDao(CategoryDao.class);
		List<Category> list = dao.getDefaultList(getUerInfoSession().getHouseholdtype());

		getLogger().info("カテゴリ検索件数 - " + list.size());
		getModelmap().addAttribute("categorylist", list);

		return "/mobile/categorylist";
	}
}
