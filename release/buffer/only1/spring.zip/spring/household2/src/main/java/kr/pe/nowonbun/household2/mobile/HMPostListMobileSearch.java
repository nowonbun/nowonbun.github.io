package kr.pe.nowonbun.household2.mobile;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import javax.websocket.EncodeException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.pe.nowonbun.household2.bean.Household_Category;
import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.HWSParams;
import kr.pe.nowonbun.household2.common.abstractCommon.HAjaxController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Category;
import kr.pe.nowonbun.household2.entity.Household;

@Controller
public class HMPostListMobileSearch extends HAjaxController {
	
	@RequestMapping(value = "/mobile/listMobileSearch.html", method = RequestMethod.POST)
	@ResponseBody
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		String message = getParameter("message");
		HWSParams param = decode(message);

		if ("search".equals(param.getFunc())) {
			return processSearch(param);
		} else if ("searchDay".equals(param.getFunc())) {
			return processSearchDay(param);
		} else if ("searchCategory".equals(param.getFunc())) {
			return processSearchCategory(param);
		}
		throw new RuntimeException("message funcname wrong!");
	}

	private String processSearch(HWSParams param) {
		try {
			HouseholdDao householdDao = new HouseholdDao();
			Calendar c = Calendar.getInstance();
			c.setTime(HDefine.MONTH_FORMAT.parse(param.getData().toString()));
			Calendar c1 = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();

			c1.clear();
			c2.clear();

			c1.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c1.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c1.set(Calendar.DATE, 1);

			c2.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c2.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c2.set(Calendar.DATE, 1);
			c2.add(Calendar.MONTH, 1);
			c2.add(Calendar.DATE, -1);

			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
			getLogger().info("startDate - " + c1.getTime());
			getLogger().info("endDate - " + c2.getTime());
			List<Household> householdList = householdDao.getDefaultList(getUerInfoSession().getHouseholdtype(), c1.getTime(), c2.getTime());

			setReturnFunc(param.getFunc());
			setReturnData(householdList);
			return encode(getReturnParams());
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	private String processSearchDay(HWSParams param) {
		try {
			HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
			Calendar c = Calendar.getInstance();
			c.setTime(HDefine.MONTH_FORMAT.parse(param.getData().toString()));
			Calendar c1 = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();

			c1.clear();
			c2.clear();

			c1.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c1.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c1.set(Calendar.DATE, 1);

			c2.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c2.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c2.set(Calendar.DATE, 1);
			c2.add(Calendar.MONTH, 1);
			c2.add(Calendar.DATE, -1);

			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
			getLogger().info("startDate - " + c1.getTime());
			getLogger().info("endDate - " + c2.getTime());
			List<Household> householdList = householdDao.getDayOrderList(getUerInfoSession().getHouseholdtype(), c1.getTime(), c2.getTime());
			setReturnFunc(param.getFunc());
			setReturnData(householdList);
			return encode(getReturnParams());
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	private String processSearchCategory(HWSParams param) {
		try {
			HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
			CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
			Calendar c = Calendar.getInstance();
			c.setTime(HDefine.MONTH_FORMAT.parse(param.getData().toString()));
			Calendar c1 = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();

			c1.clear();
			c2.clear();

			c1.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c1.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c1.set(Calendar.DATE, 1);

			c2.set(Calendar.YEAR, c.get(Calendar.YEAR));
			c2.set(Calendar.MONTH, c.get(Calendar.MONTH));
			c2.set(Calendar.DATE, 1);
			c2.add(Calendar.MONTH, 1);
			c2.add(Calendar.DATE, -1);

			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
			getLogger().info("startDate - " + c1.getTime());
			getLogger().info("endDate - " + c2.getTime());
			List<Household> list = householdDao.getCategoryList(getUerInfoSession().getHouseholdtype(), c1.getTime(), c2.getTime());
			List<Category> categorylist = categoryDao.getAllList(getUerInfoSession().getHouseholdtype());
			List<Household_Category> householdResultList = new ArrayList<Household_Category>();
			for (Household item : list) {
				Household_Category data = new Household_Category();
				data.setData(item);
				if (data.getCategory() == null) {
					continue;
				}
				for (Category item2 : categorylist) {
					if (item2.getIdx().equals(data.getCategory().intValue())) {
						data.setCategoryname(item2.getCategoryname());
						data.setCategorystate(item2.getState());
						break;
					}
				}
				householdResultList.add(data);
			}
			setReturnFunc(param.getFunc());
			setReturnData(householdResultList);
			return encode(getReturnParams());
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	
}
