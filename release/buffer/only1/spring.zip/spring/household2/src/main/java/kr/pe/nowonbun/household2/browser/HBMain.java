package kr.pe.nowonbun.household2.browser;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.ConnectlogDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;
import kr.pe.nowonbun.household2.entity.Connectlog;

@Controller
public class HBMain extends HController {

	@RequestMapping(value = "/browser/main.html")
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
		ConnectlogDao connectLogDao = FactoryDao.getDao(ConnectlogDao.class);

		Map<String, List<Category>> categoryMap = new ConcurrentHashMap<>();
		categoryMap.put("INCOME", new ArrayList<>());
		categoryMap.put("EXPORT", new ArrayList<>());

		try {
			categoryDao.getDefaultList(getUerInfoSession().getHouseholdtype()).forEach(category -> {
				if ("1".equals(category.getMoneytype())) {
					categoryMap.get("INCOME").add(category);
				} else if ("2".equals(category.getMoneytype())) {
					categoryMap.get("EXPORT").add(category);
				}
			});

			Connectlog connectLog = connectLogDao.getLastConnectionTime(getUerInfoSession().getUserid());
			if (connectLog != null) {
				getModelmap().addAttribute("connectlog", HDefine.LOG_DATE_FORMAT.format(connectLog.getConntecttime().getTime()));
			} else {
				getModelmap().addAttribute("connectlog", "-");
			}

			Calendar nowMonth = Calendar.getInstance();
			if (getParameter("year") != null && getParameter("month") != null) {
				try {
					int year = Integer.parseInt(getParameter("year"));
					int month = Integer.parseInt(getParameter("month"));
					nowMonth.setTime(HDefine.DEFAULT_DATE_FORMAT.parse(String.format("%04d%02d01", year, month)));
				} catch (Throwable e) {
					getLogger().error("parameter error");
					getLogger().error("year : " + getParameter("year"));
					getLogger().error("month : " + getParameter("month"));
					nowMonth.setTime(new Date());
				}
			} else {
				nowMonth.setTime(new Date());
			}
			getModelmap().addAttribute("year", String.format("%04d", nowMonth.get(Calendar.YEAR)));
			getModelmap().addAttribute("month", String.format("%02d", nowMonth.get(Calendar.MONTH) + 1));
			getModelmap().addAttribute("incomeCategory", categoryMap.get("INCOME"));
			getModelmap().addAttribute("exportCategory", categoryMap.get("EXPORT"));

		} catch (Throwable e) {
			getLogger().error("search Error - " + e);
			throw new RuntimeException(e);
		}

		return "/browser/main";
	}
}
