package kr.pe.nowonbun.household2.dao;

import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.entity.Session;

public class SessionDao extends HDao<Session>{
	public Session getSession(String userId){
		Session where = getTemplate();
		where.setUserid(userId);
		return selectToList(where).get(0);
	}
	public void updateData(Session entity){
		super.update(entity);
	}
}
