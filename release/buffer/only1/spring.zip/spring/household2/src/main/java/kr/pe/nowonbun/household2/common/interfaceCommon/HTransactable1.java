package kr.pe.nowonbun.household2.common.interfaceCommon;

import javax.persistence.EntityManager;

@FunctionalInterface
public interface HTransactable1<T> {
	T transaction(EntityManager em);
}
