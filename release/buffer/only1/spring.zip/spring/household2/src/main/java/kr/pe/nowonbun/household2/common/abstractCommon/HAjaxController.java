package kr.pe.nowonbun.household2.common.abstractCommon;

import java.io.IOException;

//import javax.websocket.DecodeException;
//import javax.websocket.EncodeException;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kr.pe.nowonbun.household2.common.HWSParams;

public abstract class HAjaxController extends HController{
	private static ObjectMapper mapper = new ObjectMapper();
	private HWSParams returnMassage = new HWSParams();
	protected HWSParams decode(String str){// throws DecodeException {
		try {
			return mapper.readValue(str, HWSParams.class);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	protected String encode(HWSParams params){// throws EncodeException {
		try {
			return mapper.writeValueAsString(params);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}
	protected void setReturnFunc(String func) {
		returnMassage.setFunc(func);
	}
	protected void setReturnData(Object data){
		returnMassage.setData(data);
	}
	protected HWSParams getReturnParams(){
		return returnMassage;
	}
	protected Object processMessage(String param,Class<?> type){
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.readValue(param, type);
		} catch (JsonParseException e) {
			getLogger().error("mapping error e -" + e);
			return null;
		} catch (JsonMappingException e) {
			getLogger().error("mapping error e -" + e);
			return null;
		} catch (IOException e) {
			getLogger().error("mapping error e -" + e);
			return null;
		}
	}
}
