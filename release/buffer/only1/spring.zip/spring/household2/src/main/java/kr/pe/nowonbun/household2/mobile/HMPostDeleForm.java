package kr.pe.nowonbun.household2.mobile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Household;

public class HMPostDeleForm extends HController{
	@RequestMapping(value = "/mobile/deleteform.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		//TODO Household form parameter
		Household household = new Household();
		getLogger().info("Mobile Delete Page Submit!");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
		Household entity = householdDao.getHouseHold(household.getIdx());
		if (!getUerInfoSession().getHouseholdtype().equals(entity.getHouseholdtype())) {
			throw new RuntimeException("household type 間違い");
		}
		entity.setState("1");
		householdDao.insertData(entity);
		return "redirect:main.html";
	}
}
