package kr.pe.nowonbun.household2.bean;

import java.lang.reflect.Method;

import kr.pe.nowonbun.household2.entity.Household;

/***
 * 
 * @author 黄
 * @since 2015/05/16
 */
public class Household_Category extends Household {

	private static final long serialVersionUID = 1L;
	private String categoryname;
	private String categorystate;

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getCategorystate() {
		return categorystate;
	}

	public void setCategorystate(String categorystate) {
		this.categorystate = categorystate;
	}

	public void setData(Household data) {
		try {
			Method[] methods = Household.class.getDeclaredMethods();
			for (Method method : methods) {
				if (method.getName().indexOf("get") < 0) {
					continue;
				}
				Object value = method.invoke(data);
				String funcName = "set"+method.getName().substring(3);
				Method setMethod = this.getClass().getDeclaredMethod(funcName,value.getClass());
				setMethod.invoke(this, value);
			}
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
		// setIdx(data.getIdx());
		// setCategory(data.getCategory());
		// setContents(data.getContents());
		// setCreatedate(data.getCreatedate());
		// setCreater(data.getCreater());
		// setHouseholddate(data.getHouseholddate());
		// setHouseholdtype(data.getHouseholdtype());
		// setMoney(data.getMoney());
		// setMoneytype(data.getMoneytype());
		// setOther(data.getOther());
		// setState(data.getState());
	}
}
