package kr.pe.nowonbun.household2.mobile;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

@Controller
public class HMGetInsertForm extends HController {

	@RequestMapping(value = "/mobile/insertform.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("Mobile Inset Page Open!");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
		List<Category> categoryList = null;
		Map<String, List<Category>> categoryListMap = new ConcurrentHashMap<>();
		categoryListMap.put(HDefine.INCOME_CATEGORY, new ArrayList<>());
		categoryListMap.put(HDefine.EXPORT_CATEGORY, new ArrayList<>());

		categoryList = categoryDao.getAllList(getUerInfoSession().getHouseholdtype());
		categoryList.parallelStream().forEach((category) -> {
			if ("1".equals(category.getMoneytype())) {
				categoryListMap.get(HDefine.INCOME_CATEGORY).add(category);
			} else if ("2".equals(category.getMoneytype())) {
				categoryListMap.get(HDefine.EXPORT_CATEGORY).add(category);
			}
		});

		Calendar now = Calendar.getInstance();

		getModelmap().addAttribute("year", now.get(Calendar.YEAR));
		getModelmap().addAttribute("month", now.get(Calendar.MONTH) + 1);
		getModelmap().addAttribute("day", now.get(Calendar.DATE));
		getModelmap().addAttribute("incomeCategory", categoryListMap.get(HDefine.INCOME_CATEGORY));
		getModelmap().addAttribute("exportCategory", categoryListMap.get(HDefine.EXPORT_CATEGORY));

		return "/mobile/insertform";
	}
}
