package kr.pe.nowonbun.household2.common.interfaceCommon;

public interface HControllerRunable{
	public String run();
}
