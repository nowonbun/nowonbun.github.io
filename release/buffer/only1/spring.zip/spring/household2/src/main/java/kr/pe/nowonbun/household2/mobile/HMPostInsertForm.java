package kr.pe.nowonbun.household2.mobile;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Household;

public class HMPostInsertForm extends HController {
	
	@RequestMapping(value = "/mobile/insertform.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		 Household household = new Household();
		try {
			
			getLogger().info("Mobile Insert Page Submit!");
			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

			if ("1".equals(household.getMoneytype())) {
				household.setCategory(Long.parseLong(getParameter("incomecategoryList")));
			} else if ("2".equals(household.getMoneytype())) {
				household.setCategory(Long.parseLong(getParameter("expendcategoryList")));
			} else {
				getLogger().error("money typeが合わないです。");
				throw new RuntimeException("money typeが合わないです。");
			}

			int year = Integer.parseInt(getParameter("year"));
			int month = Integer.parseInt(getParameter("month"));
			int day = Integer.parseInt(getParameter("day"));

			Date householdDate = HDefine.DATE_FORMAT.parse(String.format("%04d-%02d-%02d", year, month, day));
			household.setHouseholddate(householdDate);
			setCookie("date", String.format("%04d-%02d", year, month), 365 * 24 * 60 * 60);

			if (household.getContents() == null || "".equals(household.getContents()) || household.getMoney() == null) {
				throw new RuntimeException("データ異常");
			}
			if (household.getCategory() == null) {
				household.setCategory(0L);
			}
			household.setState("0");
			household.setHouseholdtype(getUerInfoSession().getHouseholdtype());
			household.setCreater(getUerInfoSession().getUserid());
			household.setCreatedate(new Date());

			HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
			householdDao.insertData(household);

			return "redirect:main.html";

		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
}
