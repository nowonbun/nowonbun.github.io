package kr.pe.nowonbun.household2.dao;

import java.util.List;

import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.entity.Category;

public class CategoryDao extends HDao<Category> {

	public List<Category> getDefaultList(Integer type) {
		Category where = getTemplate();
		where.setState("0");
		where.setHouseholdtype(type);
		return super.selectToList(where, "idx");
	}

	public List<Category> getAllList(Integer type) {
		Category where = getTemplate();
		where.setHouseholdtype(type);
		return super.selectToList(where, "idx");
	}

	public Category getCategory(Integer idx) {
		Category where = getTemplate();
		where.setIdx(idx);
		return super.selectToList().stream().findFirst().get();
	}

	public void updateBackupData(Category entity) {
		deleteData(entity);
	}

	public void deleteData(Category entity) {
		entity.setState("1");
		super.update(entity);
	}
	public void insertData(Category entity){
		super.create(entity);
	}
	public void updateData(Category entity){
		super.update(entity);
	}

}
