package kr.pe.nowonbun.household2.mobile;

import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.SessionDao;
import kr.pe.nowonbun.household2.dao.UsertableDao;
import kr.pe.nowonbun.household2.entity.Session;
import kr.pe.nowonbun.household2.entity.Usertable;

@Controller
public class HMGetLogin extends HController {

	@RequestMapping(value = "/mobile/login.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	public String run(){
		try {
			getLogger().info("Mobile browser's login page is opening.");
			
			if (getUerInfoSession() != null) {
				getLogger().info("session is lived. id - " + getUerInfoSession().getUserid());
				createConnectLog(getUerInfoSession().getUserid());
				Calendar c = Calendar.getInstance();
				setCookie("date", String.format("%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1), 365 * 24 * 60 * 60);
				return "redirect:main.html";
			}
			Cookie[] cookies = getRequest().getCookies();
			if (cookies == null) {
				return "/mobile/login";
			}
			for (Cookie cookie : cookies) {
				if (!"cookieLoginInfo".equals(cookie.getName())) {
					continue;
				}
				ObjectMapper mapper = new ObjectMapper();
				HashMap<String, String> logininfo = mapper.readValue(cookie.getValue(), HashMap.class);
				SessionDao sessionDao = FactoryDao.getDao(SessionDao.class);
				Session sessionEntity = sessionDao.getSession(logininfo.get("userid"));
				if (sessionEntity == null) {
					continue;
				}
				if (sessionEntity.getSessionkey() != null && sessionEntity.getSessionkey().equals(logininfo.get("passSession"))) {
					UsertableDao usertableDao = FactoryDao.getDao(Usertable.class);
					Usertable usertableEntity = usertableDao.getUsertable(logininfo.get("userid"));
					setUserInfoSession(usertableEntity);
					getLogger().info("session is lived. id - " + getUerInfoSession().getUserid());
					createConnectLog(getUerInfoSession().getUserid());
					Calendar c = Calendar.getInstance();
					setCookie("date", String.format("%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1), 365 * 24 * 60 * 60);
					return "redirect:main.html";
				}
			}
			return "/mobile/login";
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

}
