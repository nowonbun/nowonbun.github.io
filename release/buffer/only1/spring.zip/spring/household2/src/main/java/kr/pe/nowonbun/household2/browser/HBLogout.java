package kr.pe.nowonbun.household2.browser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;

public class HBLogout extends HController{
	@RequestMapping(value = "/browser/logout.html")
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("Web browser's logout. ID - " + getUerInfoSession().getUserid());
		getSession().invalidate();
		return "redirect:login.html";
	}
}
