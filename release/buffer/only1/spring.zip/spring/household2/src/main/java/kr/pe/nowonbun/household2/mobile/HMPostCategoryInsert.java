package kr.pe.nowonbun.household2.mobile;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

public class HMPostCategoryInsert extends HController {
	@RequestMapping(value = "/mobile/categoryinsert.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}

	public String run() {
		// TODO `カテゴリパラメータから取得
		Category data = new Category();

		getLogger().info("カテゴリ挿入開始");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		if (data.getIdx().equals(0)) {
			// 生成
			data.setHouseholdtype(getUerInfoSession().getHouseholdtype());
			data.setCreater(getUerInfoSession().getUserid());
			data.setCreatedate(new Date());
			data.setState("0");
			CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
			categoryDao.insertData(data);
		} else {
			getLogger().error("インデクスがエラーになりました。- idx : " + data.getIdx());
		}
		return "redirect:categorylist.html";
	}
}
