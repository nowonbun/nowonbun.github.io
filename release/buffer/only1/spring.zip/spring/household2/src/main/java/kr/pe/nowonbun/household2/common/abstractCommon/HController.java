package kr.pe.nowonbun.household2.common.abstractCommon;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;

import kr.pe.nowonbun.household2.common.interfaceCommon.HControllerRunable;
import kr.pe.nowonbun.household2.dao.ConnectlogDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Usertable;

public abstract class HController extends HProcess implements HControllerRunable{
	public final static String USERINFO = "userInfo";
	private HttpSession session;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private ModelMap modelmap;
	public HController(){
		super();
	}
	protected abstract String index(ModelMap modelmap,HttpSession session,HttpServletRequest request,HttpServletResponse response);
	protected String initialize(ModelMap modelmap,HttpSession session,HttpServletRequest request,HttpServletResponse response){
		setModelmap(modelmap);
		setSession(session);
		setRequest(request);
		setResponse(response);
		return run();
	}
	protected ModelMap getModelmap() {
		return modelmap;
	}
	private void setModelmap(ModelMap modelmap) {
		this.modelmap = modelmap;
	}
	protected HttpServletRequest getRequest() {
		return request;
	}
	private void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	protected HttpServletResponse getResponse() {
		return response;
	}
	private void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	protected HttpSession getSession() {
		return session;
	}
	private void setSession(HttpSession session) {
		this.session = session;
	}
	protected String getParameter(String parameterName){
		return this.request.getParameter(parameterName);
	}
	
	protected void setUserInfoSession(Usertable userinfo){
		session.setAttribute(USERINFO, userinfo);
	}
	protected Usertable getUerInfoSession(){
		return (Usertable)session.getAttribute(USERINFO);
	}
	protected void createConnectLog(String userid){
		ConnectlogDao dao = FactoryDao.getDao(ConnectlogDao.class);
		dao.connectUser(userid);
	}
	protected void setCookie(String name,String value,int time){
		Cookie cookie = new Cookie(name,value);
		cookie.setMaxAge(time);
		cookie.setPath("/");
		response.addCookie(cookie);
	}
}
