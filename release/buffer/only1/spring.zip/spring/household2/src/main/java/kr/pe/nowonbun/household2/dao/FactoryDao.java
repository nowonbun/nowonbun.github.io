package kr.pe.nowonbun.household2.dao;

import java.util.HashMap;
import java.util.Map;

public class FactoryDao {

	private static FactoryDao instance = null;
	private final Map<Class<?>, Object> flyweight = new HashMap<>();

	private FactoryDao() {

	}

	@SuppressWarnings("unchecked")
	public static <T> T getDao(Class<?> cls) {
		if (instance == null) {
			instance = new FactoryDao();
		}
		return (T)instance.get(cls);
	}

	@SuppressWarnings("unchecked")
	private <T> T get(Class<?> cls) {
		try {
			T ret = (T) flyweight.get(cls);
			if (ret == null) {
				ret = (T) cls.newInstance();
				flyweight.put(cls, ret);
			}
			return ret;
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
}
