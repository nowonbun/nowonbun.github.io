package kr.pe.nowonbun.household2.common;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class HUtils {
	public static Object getGenericInstance(Class<?> cls) throws InstantiationException, IllegalAccessException {
		return getGenericType(cls).newInstance();
	}

	public static Class<?> getGenericType(Class<?> cls) {
		ParameterizedType type = (ParameterizedType) cls.getGenericSuperclass();
		Type[] genericType = type.getActualTypeArguments();
		return (Class<?>) genericType[0];
	}

	public static boolean isStringEmpty(String obj) {
		return obj == null || obj.isEmpty();
	}

	public static boolean isObjectEmpty(Object obj) {
		return obj == null;
	}

	public static String getClassName(Class<?> cls) {
		String name = cls.getName();
		return name.substring(name.lastIndexOf(".") + 1);
	}
}
