package kr.pe.nowonbun.household2.mobile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

public class HMPostCategoryDelete extends HController{
	@RequestMapping(value = "/mobile/categorydelete.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		//TODO `カテゴリパラメータから取得
		Category data = new Category();
		getLogger().info("カテゴリ削除開始");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		if (data != null) {
			getLogger().info("カテゴリ Index - " + data.getIdx());
			CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
			data = categoryDao.getCategory(data.getIdx());
			if (data.getHouseholdtype().equals(getUerInfoSession().getHouseholdtype())) {
				categoryDao.deleteData(data);
			}
		}
		return "redirect:categorylist.html";
	}
}
