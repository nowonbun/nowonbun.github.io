package kr.pe.nowonbun.household2.mobile;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Category;
import kr.pe.nowonbun.household2.entity.Household;

public class HMGetModifyForm extends HController{
	
	@RequestMapping(value = "/mobile/modifyform.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res){
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		//TODO パラメータIDX
		Integer idx = Integer.valueOf(getParameter("idx"));
		
		getLogger().info("Mobile Modify Page Submit!");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
		Map<String, List<Category>> categoryListMap = new ConcurrentHashMap<>();
		List<Category> categoryList = categoryDao.getAllList(getUerInfoSession().getHouseholdtype());
		categoryList.parallelStream().forEach((category) -> {
			if ("1".equals(category.getMoneytype())) {
				categoryListMap.get(HDefine.INCOME_CATEGORY).add(category);
			} else if ("2".equals(category.getMoneytype())) {
				categoryListMap.get(HDefine.EXPORT_CATEGORY).add(category);
			}
		});

		getModelmap().addAttribute("incomeCategory", categoryListMap.get(HDefine.INCOME_CATEGORY));
		getModelmap().addAttribute("exportCategory", categoryListMap.get(HDefine.EXPORT_CATEGORY));

		HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
		Household household = householdDao.getHouseHold(idx);
		if (!getUerInfoSession().getHouseholdtype().equals(household.getHouseholdtype())) {
			throw new RuntimeException("家計簿タイプが合わない。");
		}

		getModelmap().addAttribute("household", household);
		Calendar c = Calendar.getInstance();
		c.setTime(household.getHouseholddate());
		getModelmap().addAttribute("year", c.get(Calendar.YEAR));
		getModelmap().addAttribute("month", c.get(Calendar.MONTH) + 1);
		getModelmap().addAttribute("day", c.get(Calendar.DATE));

		return "/mobile/insertform";
	}
}
