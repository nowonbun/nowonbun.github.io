package kr.pe.nowonbun.household2.mobile;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Household;

public class HMPostModifyForm extends HController {
	@RequestMapping(value = "/mobile/modifyform.html", method = RequestMethod.POST)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		try {
			//TODO
			Household household = new Household();
			getLogger().info("Mobile Modify Page Submit!");
			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

			HouseholdDao householdDao = FactoryDao.getDao(HouseholdDao.class);
			Household entity = householdDao.getHouseHold(household.getIdx());
			if (!getUerInfoSession().getHouseholdtype().equals(entity.getHouseholdtype())) {
				throw new RuntimeException("household type 間違い");
			}
			householdDao.insertBackupData(entity);

			if ("1".equals(household.getMoneytype())) {
				household.setCategory(Long.parseLong(getParameter("incomecategoryList")));
			} else if ("2".equals(household.getMoneytype())) {
				household.setCategory(Long.parseLong(getParameter("expendcategoryList")));
			} else {
				getLogger().error("money typeが合わないです。");
				throw new RuntimeException("money typeが合わないです。");
			}
			int year = Integer.parseInt(getParameter("year"));
			int month = Integer.parseInt(getParameter("month"));
			int day = Integer.parseInt(getParameter("day"));
			Date householdDate = HDefine.DATE_FORMAT.parse(String.format("%04d-%02d-%02d", year, month, day));
			entity.setHouseholddate(householdDate);
			setCookie("date", String.format("%04d-%02d", year, month), 365 * 24 * 60 * 60);

			if (entity.getCategory() == null) {
				entity.setCategory(0L);
			}
			entity.setMoneytype(household.getMoneytype());
			entity.setCategory(household.getCategory());
			entity.setContents(household.getContents());
			entity.setMoney(household.getMoney());
			entity.setOther(household.getOther());
			entity.setCreater(getUerInfoSession().getUserid());
			entity.setCreatedate(new Date());
			householdDao.updateData(entity);

			return "redirect:main.html";
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
}
