package kr.pe.nowonbun.household2.common.interfaceCommon;

import javax.persistence.EntityManager;

@FunctionalInterface
public interface HTransactable2{
	void transaction(EntityManager em);
}
