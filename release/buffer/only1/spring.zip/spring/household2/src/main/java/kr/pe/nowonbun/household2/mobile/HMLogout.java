package kr.pe.nowonbun.household2.mobile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;

public class HMLogout extends HController{
	@RequestMapping(value = "/mobile/logout.html")
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("Mobile mobile's logout. ID - " + getUerInfoSession().getUserid());
		getSession().invalidate();
		setCookie("cookieLoginInfo", null, 0);
		return "redirect:login.html";
	}
}
