package kr.pe.nowonbun.household2.entity;

import java.io.Serializable;

import javax.persistence.*;

import kr.pe.nowonbun.household2.common.abstractCommon.HObject;

import java.util.Date;


/**
 * The persistent class for the category database table.
 * 
 */
@Entity
@Table(name="category",schema="household")
@NamedQueries({
	@NamedQuery(name="Category.findAll", query="SELECT c FROM Category c"),
	@NamedQuery(name="Category.findActive", query="SELECT c FROM Category c where c.idx=:pk")
})

public class Category extends HObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idx;

	private String categoryname;

	@Temporal(TemporalType.DATE)
	private Date createdate;

	private String creater;

	private Integer householdtype;

	private String moneytype;

	private String state;

	public Category() {
	}

	public Integer getIdx() {
		return this.idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	public String getCategoryname() {
		return this.categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getCreater() {
		return this.creater;
	}

	public void setCreater(String creater) {
		this.creater = creater;
	}

	public Integer getHouseholdtype() {
		return this.householdtype;
	}

	public void setHouseholdtype(Integer householdtype) {
		this.householdtype = householdtype;
	}

	public String getMoneytype() {
		return this.moneytype;
	}

	public void setMoneytype(String moneytype) {
		this.moneytype = moneytype;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

}