
package kr.pe.nowonbun.household2.common.abstractCommon;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.Table;

import kr.pe.nowonbun.household2.common.HService;
import kr.pe.nowonbun.household2.common.HUtils;

public abstract class HDao<T> extends HProcess {

	private T whereTemplate = null;

	protected HDao() {
		super();
	}

	protected void create(T entity) {
		HService.getInstance().transaction(em -> {
			em.persist(entity);
			em.flush();
		});
	}

	protected void update(T entity) {
		HService.getInstance().transaction(em -> {
			em.merge(entity);
			em.flush();
		});
	}

	protected void delete(T entity) {
		HService.getInstance().transaction(em -> {
			em.remove(entity);
			em.flush();
		});
	}

	protected List<T> selectToList() {
		return selectToList(null);
	}

	@SuppressWarnings("unchecked")
	protected List<T> selectToList(T where, String... order) {
		return HService.getInstance().transaction(em -> {
			List<Object> parameter = new ArrayList<>();
			String qry = createSelectQuery(parameter, where, order);
			Query query = em.createNativeQuery(qry);
			for (int i = 1; i <= parameter.size(); i++) {
				query.setParameter(i, parameter.get(i - 1));
			}
			return (List<T>) query.getResultList();
		});
	}

	private String createSelectQuery(List<Object> parameter, T where, String... order) {
		try {
			Class<?> cls = HUtils.getGenericType(this.getClass());
			Table annoTable = cls.getDeclaredAnnotation(Table.class);
			StringBuffer sb = new StringBuffer();
			sb.append(" SELECT * FROM ");
			sb.append(" ");
			sb.append(annoTable.schema());
			sb.append(".");
			sb.append(annoTable.name());
			sb.append(" ");
			if (where != null) {
				StringBuffer whereBuffer = new StringBuffer();
				Method[] method = where.getClass().getDeclaredMethods();
				for (Method m : method) {
					if (m.getName().indexOf("get") < 0) {
						continue;
					}
					Object v = m.invoke(where);
					if (HUtils.isObjectEmpty(v)) {
						continue;
					}
					if (HUtils.isStringEmpty(v.toString())) {
						continue;
					}
					String columnName = m.getName().replace("get", "");
					if (whereBuffer.length() > 0) {
						whereBuffer.append(" AND ");
					}
					whereBuffer.append(" ");
					whereBuffer.append(columnName);
					whereBuffer.append(" = ");
					whereBuffer.append(" ? ");
					parameter.add(v);
				}
				if (whereBuffer.length() > 0) {
					sb.append(" WHERE ");
					sb.append(whereBuffer.toString());
				}
			}
			if (order != null && order.length > 0) {
				sb.append(" ORDER BY ");
				for (int i = 0; i < order.length; i++) {
					if (i != 0) {
						sb.append(" , ");
					}
					sb.append(order[i]);
				}

			}
			return sb.toString();
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings("unchecked")
	protected List<T> selectToListByNative(String qry, List<Object> parameter) {
		return HService.getInstance().transaction(em -> {
			Query query = em.createNativeQuery(qry);
			for (int i = 1; i <= parameter.size(); i++) {
				query.setParameter(i, parameter.get(i - 1));
			}
			return (List<T>) query.getResultList();
		});
	}

	@SuppressWarnings("unchecked")
	protected List<T> selectToListNamedQuery(String name, Map<String, Object> parameter) {
		return HService.getInstance().transaction(em -> {
			Query query = em.createNamedQuery(name);
			parameter.keySet().forEach(key -> {
				query.setParameter(key, parameter.get(key));
			});
			return (List<T>) query.getResultList();
		});
	}

	@SuppressWarnings("unchecked")
	protected <E> List<E> selectJoinToListByNative(String qry, List<Object> parameter) {
		return HService.getInstance().transaction(em -> {
			Query query = em.createNativeQuery(qry);
			for (int i = 1; i <= parameter.size(); i++) {
				query.setParameter(i, parameter.get(i - 1));
			}
			return (List<E>) query.getResultList();
		});
	}

	@SuppressWarnings("unchecked")
	protected T getTemplate() {
		try {
			if (whereTemplate == null) {
				whereTemplate = (T) HUtils.getGenericInstance(this.getClass());
			}
			return (T) ((HObject) whereTemplate).clone();
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
}
