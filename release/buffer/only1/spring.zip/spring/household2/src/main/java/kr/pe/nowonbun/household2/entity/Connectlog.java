package kr.pe.nowonbun.household2.entity;

import java.io.Serializable;

import javax.persistence.*;

import kr.pe.nowonbun.household2.common.abstractCommon.HObject;

import java.sql.Timestamp;


/**
 * The persistent class for the connectlog database table.
 * 
 */
@Entity
@Table(name="connectlog",schema="household")
@NamedQueries({
	@NamedQuery(name="Connectlog.findAll", query="SELECT c FROM Connectlog c"),
	@NamedQuery(name="Connectlog.findActive", query="SELECT c FROM Connectlog c where c.idx=:pk")
})
public class Connectlog extends HObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idx;

	private Timestamp conntecttime;

	private String userid;

	public Connectlog() {
	}

	public Integer getIdx() {
		return this.idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	public Timestamp getConntecttime() {
		return this.conntecttime;
	}

	public void setConntecttime(Timestamp conntecttime) {
		this.conntecttime = conntecttime;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}