var viewValue = 0;  //Label 컨트롤에 표시되어 있는 값 저장
var tempValue = 0;  //연산을 위해 임시 저장해둔 변수
var type = 0;       //연산의 종류를 저장 - 1:더하기, 2:빼기, 3:곱하기, 4:나누기
var clearCheck = true;
function btnNumber(num) {
    viewValue *= 10;
    viewValue += num;
    $("#message").text(viewValue);
}
function btnClear() {
    tempValue = 0;
    viewValue = 0;
    clearCheck = true;
    $("#message").text("0");
}
function btnClose() {
    btnClear();
    $("#popupCalcul").popup('close');
}
function btnPlus() {
    if (!clearCheck) {
        tempValue += viewValue;
    } else {
        tempValue = viewValue;
    }
    viewValue = 0;
    type = 1;
    clearCheck = false;
    $("#message").text(tempValue);
}
function btnMinus() {
    if (!clearCheck) {
        tempValue -= viewValue;
    } else {
        tempValue = viewValue;
    }
    viewValue = 0;
    type = 2;
    clearCheck = false;
    $("#message").text(tempValue);
}
function btnMulti() {
    if (!clearCheck) {
        tempValue *= viewValue;
    } else {
        tempValue = viewValue;
    }
    viewValue = 0;
    type = 3;
    clearCheck = false;
    $("#message").text(tempValue);
}
function btnDivide() {
    if (!clearCheck) {
        if (viewValue != 0) {
            tempValue /= viewValue;
        } else {
            tempValue = 0;
            clearCheck = true;
        }
    } else {
        tempValue = viewValue;
    }
    viewValue = 0;
    type = 4;
    clearCheck = false;
    $("#message").text(tempValue);
}
function btnEqual() {
    if (type == 1) {
        viewValue = tempValue + viewValue;
    } else if (type == 2) {
        viewValue = tempValue - viewValue;
    } else if (type == 3) {
        viewValue = tempValue * viewValue;
    } else if (type == 4) {
        if (viewValue > 0) {
            viewValue = tempValue / viewValue;
        } else {
            viewValue = 0;
        }
    }
    tempValue = 0;
    type = 0;
    clearCheck = true;
    $("#message").text(viewValue);
}
function btnInput() {
    if (type != 0) {
        btnEqual();
    }
    $("#money").val($("#message").text());
    btnClear();
    $("#popupCalcul").popup('close');
}
function moneyClear() {
    $("#money").val("0");
}
