package kr.pe.nowonbun.household2.common;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import kr.pe.nowonbun.household2.common.interfaceCommon.HTransactable1;
import kr.pe.nowonbun.household2.common.interfaceCommon.HTransactable2;

public class HService {

	private static HService instance = null;
	private EntityManager entityManager = null;

	public static HService getInstance() {
		if (instance == null) {
			instance = new HService();
		}
		return instance;
	}

	private HService() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("household2");
		entityManager = emf.createEntityManager();
	}

	public <T> T transaction(HTransactable1<T> transactable) {
		try {
			entityManager.getTransaction().begin();
			T ret = transactable.transaction(entityManager);
			entityManager.getTransaction().commit();
			return ret;
		} catch (Throwable e) {
			entityManager.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	public void transaction(HTransactable2 transactable) {
		try {
			entityManager.getTransaction().begin();
			transactable.transaction(entityManager);
			entityManager.getTransaction().commit();
		} catch (Throwable e) {
			entityManager.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	public void transactionBegin() {
		entityManager.getTransaction().begin();
	}

	public void transactionCommit() {
		entityManager.getTransaction().commit();
	}

	public void transactionRollback() {
		entityManager.getTransaction().rollback();
	}
}
