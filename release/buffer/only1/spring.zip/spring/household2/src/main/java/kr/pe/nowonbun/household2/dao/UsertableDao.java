package kr.pe.nowonbun.household2.dao;

import java.util.NoSuchElementException;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import kr.pe.nowonbun.household2.common.HUtils;
import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.entity.Usertable;

public class UsertableDao extends HDao<Usertable> {

	public Usertable checkPassword(Usertable bean) {
		String temp = bean.getUserid();
		if (!HUtils.isStringEmpty(temp) && !"".equals(temp.trim())) {
			Usertable where = getTemplate();
			where.setUserid(temp);
			try {
				return super.selectToList(where).stream().findFirst().get();
			} catch (NoSuchElementException e) {
				getLogger().error(e.toString());
				getLogger().info("Not UserId - " + temp);
			}
		}
		return null;
	}
	public Usertable getUsertable(String userid){
		Usertable where = getTemplate();
		where.setUserid(userid);
		return selectToList(where).get(0);
	}
}
