package kr.pe.nowonbun.household2.entity;

import java.io.Serializable;
import javax.persistence.*;

import kr.pe.nowonbun.household2.common.abstractCommon.HObject;


/**
 * The persistent class for the usertable database table.
 * 
 */
@Entity
@Table(name="usertable",schema="household")
@NamedQueries({
	@NamedQuery(name="Usertable.findAll", query="SELECT u FROM Usertable u"),
	@NamedQuery(name="Usertable.findActive", query="SELECT u FROM Usertable u where u.userid=:pk")
})

public class Usertable extends HObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String userid;

	private Integer householdtype;

	private String username;

	private String userpw;

	public Usertable() {
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public Integer getHouseholdtype() {
		return this.householdtype;
	}

	public void setHouseholdtype(Integer householdtype) {
		this.householdtype = householdtype;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpw() {
		return this.userpw;
	}

	public void setUserpw(String userpw) {
		this.userpw = userpw;
	}

}