package kr.pe.nowonbun.household2.common.abstractCommon;

public abstract class HObject implements Cloneable{
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
}
