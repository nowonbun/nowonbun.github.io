package kr.pe.nowonbun.household2.mobile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

public class HMGetCategoryModify extends HController {
	@RequestMapping(value = "/mobile/categorymodify.html", method = RequestMethod.GET)
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		//TODO パラメータIDX
		Integer idx = Integer.valueOf(getParameter("idx"));
		getLogger().info("カテゴリ修正画面開始");
		getLogger().info("カテゴリ　Index - " + idx);
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
		CategoryDao categoryDao = FactoryDao.getDao(CategoryDao.class);
		Category data = categoryDao.getCategory(idx);

		if (getUerInfoSession().getHouseholdtype().equals(data.getHouseholdtype())) {
			getLogger().info("category Index - " + data.getIdx());
			getModelmap().addAttribute("categoryitem", data);
		} else {
			getLogger().error("家計簿タイプが一致しません。");
		}
		return "/mobile/categoryinsert";
	}
}
