package kr.pe.nowonbun.household2.entity;

import java.io.Serializable;

import javax.persistence.*;

import kr.pe.nowonbun.household2.common.abstractCommon.HObject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the household database table.
 * 
 */
@Entity
@Table(name = "household", schema = "household")
@NamedQueries({ @NamedQuery(name = "Household.findAll", query = "SELECT h FROM Household h"),
		@NamedQuery(name = "Household.findActive", query = "SELECT h FROM Household h where h.idx=:pk")})

public class Household extends HObject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idx;

	private Long category;

	private String contents;

	@Temporal(TemporalType.DATE)
	private Date createdate;

	private String creater;

	@Temporal(TemporalType.DATE)
	private Date householddate;

	private Integer householdtype;

	private BigDecimal money;

	private String moneytype;

	private String other;

	private String state;

	public Household() {
	}

	public Integer getIdx() {
		return this.idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	public Long getCategory() {
		return this.category;
	}

	public void setCategory(Long category) {
		this.category = category;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getCreater() {
		return this.creater;
	}

	public void setCreater(String creater) {
		this.creater = creater;
	}

	public Date getHouseholddate() {
		return this.householddate;
	}

	public void setHouseholddate(Date householddate) {
		this.householddate = householddate;
	}

	public Integer getHouseholdtype() {
		return this.householdtype;
	}

	public void setHouseholdtype(Integer householdtype) {
		this.householdtype = householdtype;
	}

	public BigDecimal getMoney() {
		return this.money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getMoneytype() {
		return this.moneytype;
	}

	public void setMoneytype(String moneytype) {
		this.moneytype = moneytype;
	}

	public String getOther() {
		return this.other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

}