$(document).ready(function () {
   $("div#header > h2").html("カテゴリ設定");
});
function categoryForm(){
	location.href = "categorylist.html";
}
function applyCategory(){
	if($("div#main > form > table > tbody > tr > td > div > input[name=categoryname]").val() === ""){
		$("div#errorMsg > span").html("カテゴリ名(内容)を入力してください。");
		$("div#errorMsg > span").show();
		setTimeout("errorMsgHide()",2000);
	}else{
		$("div#main > form").prop("action","categoryinsert.html");
		$("div#main > form").submit();
	}
}
function errorMsgHide(){
	$("div#errorMsg > span").hide();
}
function modifyCategory(){
	if($("div#main > form > table > tbody > tr > td > div > input[name=categoryname]").val() === ""){
		$("div#errorMsg > span").html("カテゴリ名(内容)を入力してください。");
		$("div#errorMsg > span").show();
		setTimeout("errorMsgHide()",2000);
	}else{
		$("div#main > form").prop("action","categorymodify.html");
		$("div#main > form").submit();
	}
}
function deleteCategory(){
	if($("div#main > form > table > tbody > tr > td > div > input[name=categoryname]").val() === ""){
		$("div#errorMsg > span").html("カテゴリ名(内容)を入力してください。");
		$("div#errorMsg > span").show();
		setTimeout("errorMsgHide()",2000);
	}else{
		$("div#main > form").prop("action","categorydelete.html");
		$("div#main > form").submit();
	}
}