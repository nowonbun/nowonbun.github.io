package kr.pe.nowonbun.household2.common;

import java.text.SimpleDateFormat;

public class HDefine {
	public static final SimpleDateFormat LOG_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final SimpleDateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
	public static final SimpleDateFormat MONTH_FORMAT = new SimpleDateFormat("yyyy-MM");
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	
	public static final String INCOME_CATEGORY = "INCOME_CATEGORY";
	public static final String EXPORT_CATEGORY = "EXPORT_CATEGORY";
}
