package kr.pe.nowonbun.household2.mobile;

import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.pe.nowonbun.household2.common.abstractCommon.HController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.entity.Category;

@Controller
public class HMMain extends HController {

	@RequestMapping(value = "/mobile/main.html")
	public String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		getLogger().info("Mobile Main Page Open!");
		getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());

		String year = getParameter("year");
		String month = getParameter("month");
		if (year != null && month != null) {
			try {
				int nYear = Integer.parseInt(year);
				int nMonth = Integer.parseInt(month);

				if (!(nYear >= 2014 && nYear <= 2020)) {
					throw new Exception("year data Error Year Result - " + year);
				}
				if (!(nMonth >= 1 && nMonth <= 12)) {
					throw new Exception("month data Error Year Result - " + month);
				}
			} catch (Exception e) {
				getLogger().error("parameter Error - " + e.toString());
				Calendar c = Calendar.getInstance();
				int nYear = c.get(Calendar.YEAR);
				int nMonth = c.get(Calendar.MONTH) + 1;
				year = String.format("%04d", nYear);
				month = String.format("%02d", nMonth);
			}
		} else {
			Calendar c = Calendar.getInstance();
			int nYear = c.get(Calendar.YEAR);
			int nMonth = c.get(Calendar.MONTH) + 1;
			year = String.format("%04d", nYear);
			month = String.format("%02d", nMonth);
		}

		getModelmap().addAttribute("year", year);
		getModelmap().addAttribute("month", month);

		return "/mobile/main";
	}
}
