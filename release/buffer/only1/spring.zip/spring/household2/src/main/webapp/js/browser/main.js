/*
 * 障害事項
 * 1.新規登録する後修正するとデータがなくなる現状。　- 2015/04/27	解決
 * 2.削除処理がまだ。-チョコチョコ障害があり - 2015/04/27解決
 * 3.カテゴリ処理がまだ。
 * 4.日付がない場合は年月が合わない現状　- 2015/04/27解決
 * 5.金額がなくても格納される現状　- 2015/04/27解決
 * 6.5月に4月のデータが格納される現状 - 2015/04/27解決
 * 7.内容がなくても格納される現状 - 2015/04/27解決
  *  8.カテゴリコードを作成完了 - テスト予定
  *  9 カテゴリvalidation??
 * */

var contentsUrl = "div.contents > table > tbody";
var categoryUrl = "div#categoryDialog > div:nth-child(2) > table > tbody";
var rowCount = 0;
var caterowCount = 0;
var webSocket = null;
var minLineCount = 20;
var updateList;
var updateCount;
var deleteList;
var deleteCount;
var cateupdateList;
var cateupdateCount;
var catedeleteList;
var catedeleteCount;

$(function(){
	for(i=1;i<=minLineCount;i++){
		tableadd("new"+i,"","","","","","","","");
		rowCount++;
	}
	$(contentsUrl+" > tr > td > input.datepicker").datepicker({
	    dateFormat:'yy-mm-dd',
	    changeMonth:false,
	    changeYear:false,
	    autoclose:true,
	    maxDate:getMaxDate(),
	    minDate:getMinDate(),
	    monthNames: [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ]
	});
	$(contentsUrl+" > tr > td > input.numberOnly").on('keydown', function(event) {
		if(!numOnly(event)){
			return false;
		}
	});
	dialogSetting();
	data = $("div.nowmonth > input[type=hidden]#yearD").val()+"-"+$("div.nowmonth > input[type=hidden]#monthD").val();
	sendAjax("search",data);
});
function newline(){
	rowCount++;
	tableadd("new"+rowCount,"","","","","","","","");
	$(contentsUrl+" > tr#linenew"+rowCount+" > td > input.datepicker").datepicker({
	    dateFormat:'yy-mm-dd',
	    changeMonth:false,
	    changeYear:false,
	    autoclose:true,
	    maxDate:getMaxDate(),
	    minDate:getMinDate(),
	    monthNames: [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ] 
	});
	$(contentsUrl+" > tr#linenew"+rowCount+" > td > input.numberOnly").on('keydown', function(event) {
		if(!numOnly(event)){
			return false;
		}
	});
}
function dialogSetting() {
    $("div#categoryDialog").dialog({
        autoOpen: false,
        height: '400',
        width: '400',
        top: '100',
        modal: true,
        resizable : false,
        position: { my: "center top", at: "center top", of: $("div.nowmonth") },
        close: function () {
            $("div#categoryDialog").dialog("close");
        }
    });
}
function categoryDialog(){
	loddingShow();
	sendAjax("categorySearch",null);
}
function checkin(idx){
	$(contentsUrl+" > tr#line"+idx+" > td > input[type=checkbox]").prop("checked",true);
}
function catecheckin(idx){
	$(categoryUrl+" > tr#cateline"+idx+" > td > input[type=checkbox]").prop("checked",true);
}
function categoryView(idx){
	type = $(contentsUrl+" > tr#line"+idx+" > td:nth-child(3) > select").val();
	$(contentsUrl+" > tr#line"+idx+" > td:nth-child(4) > select").css("display","none");
	$(contentsUrl+" > tr#line"+idx+" > td:nth-child(4) > select:nth-child("+type+")").css("display","block");
	if(type == 1){
		$(contentsUrl+" > tr#line"+idx+" > td:nth-child(6) > input[type=text]").css("color","#ff0000");
	}else{
		$(contentsUrl+" > tr#line"+idx+" > td:nth-child(6) > input[type=text]").css("color","#0000ff");
	}
}
function cateadd(idx,moneytype,contents){
	if(moneytype === null || moneytype ===""){
		moneytype = 1;
	}
	dom = $("div.template > table > tbody#templateCategory").html();
	dom = dom.replace(/##idx##/gi, idx);
	dom = dom.replace(/##contents##/gi, contents);
	$(categoryUrl).append(dom);
	$(categoryUrl+" > tr#cateline"+idx+" > td > select").val(moneytype);
}
function tableadd(idx, date, type, contents, money, other, category,categoryname,categorystate) {
    dom = $("div.template > table > tbody#template").html();
    dom = dom.replace(/##idx##/gi, idx);
    dom = dom.replace(/##date##/gi, date);
    dom = dom.replace(/##contents##/gi, contents);
    dom = dom.replace(/##money##/gi, money);
    dom = dom.replace(/##other##/gi, other);
    $(contentsUrl).append(dom);
    if(type == ""){
    	type = 1;
    }
    $(contentsUrl+ " > tr#line"+idx+" > td:nth-child(3) > select").val(type);
    categoryView(idx);
    if (category == 0) {
        category = "";
    }
    if (type == 1) {
    	if(categorystate == "1"){
    		$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(1)").append("<option value='"+category+"'>"+categoryname+"</option>");
    		$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(1)").prop("disabled","true");
    	}
    	$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(1)").val(category);
    } else if (type == 2) {
    	if(categorystate == "1"){
    		$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(2)").append("<option value='"+category+"'>"+categoryname+"</option>");
    		$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(2)").prop("disabled","true");
    	}
    	$(contentsUrl+ " > tr#line"+idx+" > td:nth-child(4) > select:nth-child(2)").val(category);
    }
}
function sendAjax(func,data){
	loddingShow();
	msg = JSON.stringify({
		"func" : func,
		"data" : data
	});
	$.ajax({
		type:"POST",
		url:"listSearch.html",
		dataType:"json",
		data: "message="+msg,
		success:function(response){
			if(response.func === "search"){
				data = response.data;
				//console.log(data);
				rowCount = 0;
				$(contentsUrl).children().remove();
				count = 0;
				if(data.length < minLineCount)count = minLineCount;
				else count = data.length;
				newlineidx = 1;
				for(;rowCount<count;rowCount++){
					if(rowCount < data.length){
						tableadd(	data[rowCount].idx,
									getDateTicks(data[rowCount].householddate),
									setNullCheck(data[rowCount].moneytype),
									setNullCheck(data[rowCount].contents),
									numberFormat(data[rowCount].money+""),
									setNullCheck(data[rowCount].other),
									setNullCheck(data[rowCount].category),
									setNullCheck(data[rowCount].categoryname),
									setNullCheck(data[rowCount].categorystate));
					}else{
						tableadd("new"+newlineidx,"","","","","","","","");
						newlineidx++;
					}
				}
				$(contentsUrl+" > tr > td > input.datepicker").datepicker({
				    dateFormat:'yy-mm-dd',
				    changeMonth:false,
				    changeYear:false,
				    autoclose:true,
				    maxDate:getMaxDate(),
				    minDate:getMinDate(),
				    monthNames: [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ]
				});
				$(contentsUrl+" > tr > td > input.numberOnly").on('keydown', function(event) {
					if(!numOnly(event)){
						return false;
					}
				});
				$("div.contents > table > thead > tr > th:nth-child(1) > input[type=checkbox]").prop("checked",false);
				totalCalculator();
				loddingHide();
			}else if(response.func === "insert"){
				data = response.data;
				if(data.result == "success"){
					idxStr = updateList[updateCount];
					$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(1) > input[type=checkbox]").prop("checked",false);
					$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(1) > input[type=checkbox]").val(data.idx);
					$(contentsUrl+ " > tr#line"+idxStr+" > td > input[type=text]").change(function(){checkin(data.idx)});
					$(contentsUrl+ " > tr#line"+idxStr).prop("id","line"+data.idx);
					updateCount++;
					if(updateCount<updateList.length){
						insertSend();
					}else{
						totalCalculator();
						loddingHide();
						setMessage("登録完了しました。");
					}
				}else{
					loddingHide();
					setMessage("サーバ側からエラーが発生しました。管理者にお問いください。");
				}
			}else if(response.func == "delete"){
				data = response.data;
				if(data.result == "success"){
					idxStr = deleteList[deleteCount];
					$(contentsUrl+" > tr#line"+idxStr).remove();
					deleteCount++;
					if(deleteCount<deleteList.length){
						deleteSend();
					}else{
						totalCalculator();
						if($(contentsUrl+" > tr").length == 0){
							newline();
						}
						loddingHide();
						setMessage("削除完了しました。");
					}
				}else{
					loddingHide();
					setMessage("サーバ側からエラーが発生しました。管理者にお問いください。");
				}
			}else if(response.func === "categorySearch"){
				$("div#categoryDialog > form > div:nth-child(2) > table > tbody").children().remove();
				data = response.data;
				count = data.length;
				caterowCount = 0;
				newCatgoryIndex = 1;
				for(i=0; i < count; i++){
					cateadd(data[i].idx,data[i].moneytype,data[i].categoryname);
					caterowCount++;
				}
				for(i=count;i < 10 ;i++){
					cateadd("new"+newCatgoryIndex,"","");
					caterowCount++;
					newCatgoryIndex++;
				}
				loddingHide();
				$("div#categoryDialog").dialog("open");
				$("div#categoryDialog > div:nth-child(2) > table > thead > tr > th > input[type=checkbox]").prop("checked",false);
			}else if(response.func === "categoryUpdate"){
				data = response.data;
				if(data.result == "success"){
					idxStr = cateupdateList[cateupdateCount];
					$(categoryUrl+ " > tr#cateline"+idxStr+" > td:nth-child(1) > input[type=checkbox]").prop("checked",false);
					cateupdateCount++;
					if(cateupdateCount<cateupdateList.length){
						cateupdateSend();
					}else{
						$("div#categoryDialog > form > input[name=year]").val($("div.nowmonth > input[type=hidden]#yearD").val());
						$("div#categoryDialog > form > input[name=month]").val($("div.nowmonth > input[type=hidden]#monthD").val());
						loddingHide();
						$("div#categoryDialog > form").submit();
					}
				}else{
					$("div#categoryDialog > form > input[name=year]").val($("div.nowmonth > input[type=hidden]#yearD").val());
					$("div#categoryDialog > form > input[name=month]").val($("div.nowmonth > input[type=hidden]#monthD").val());
					loddingHide();
					$("div#categoryDialog > form").submit();
				}
			}else if(response.func === "categoryDelete"){
				data = response.data;
				if(data.result == "success"){
					idxStr = catedeleteList[catedeleteCount];
					$(categoryUrl+" > tr#cateline"+idxStr).remove();
					catedeleteCount++;
					if(catedeleteCount<catedeleteList.length){
						catedeleteSend();
					}else{
						$("div#categoryDialog > form > input[name=year]").val($("div.nowmonth > input[type=hidden]#yearD").val());
						$("div#categoryDialog > form > input[name=month]").val($("div.nowmonth > input[type=hidden]#monthD").val());
						loddingHide();
						$("div#categoryDialog > form").submit();
					}
				}else{
					$("div#categoryDialog > form > input[name=year]").val($("div.nowmonth > input[type=hidden]#yearD").val());
					$("div#categoryDialog > form > input[name=month]").val($("div.nowmonth > input[type=hidden]#monthD").val());
					loddingHide();
					$("div#categoryDialog > form").submit();
				}
			}
		},
		error:function(xhr,status,error){
			
		}
	});
}
function totalCalculator(){
	incometotal = 0;
	expendtotal = 0;
	for(i=1;i<=rowCount;i++){
		if($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(3) > select").val() == 1){
			incometotal += Number(unNumberFormat($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(6) > input[type=text]").val()));
		}else if($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(3) > select").val() == 2){
			expendtotal += Number(unNumberFormat($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(6) > input[type=text]").val()));
		}
	}
	$("div.contents > table > tfoot > tr > td > label#income").html("￥"+numberFormat(incometotal+""));
	$("div.contents > table > tfoot > tr > td > label#expend").html("￥"+numberFormat(expendtotal+""));
	total = incometotal-expendtotal;
	if(total > 0){
		$("div.contents > table > tfoot > tr > td > label#total").css("color","#ff0000");
	}else if(total < 0){
		$("div.contents > table > tfoot > tr > td > label#total").css("color","#0000ff");
	}else{
		$("div.contents > table > tfoot > tr > td > label#total").css("color","#000000");
	}
	$("div.contents > table > tfoot > tr > td > label#total").html("￥"+numberFormat(total+""));
}
function AddDay(date){
	loddingShow();
	year = $("div.nowmonth > input[type=hidden]#yearD").val();
	month = $("div.nowmonth > input[type=hidden]#monthD").val();
	year = Number(year);
	month = Number(month) + date;
	if(month < 1){
		year--;
		month += 12;
	}else if(month > 12){
		year++;
		month -= 12;
	}
	if(month<10)month = "0"+month;
	setDate(year,month);
	data = year +"-"+month;
	sendAjax("search",data);
}
function setDate(year,month){
	$("div.nowmonth > b > span#year").html(year);
	$("div.nowmonth > b > span#month").html(month);
	
	$("div.nowmonth > input[type=hidden]#yearD").val(year);
	$("div.nowmonth > input[type=hidden]#monthD").val(month);
}
function getMinDate(){
	return new Date($("div.nowmonth > input[type=hidden]#yearD").val(),Number($("div.nowmonth > input[type=hidden]#monthD").val())-1, 1);
}
function getMaxDate(){
	return new Date($("div.nowmonth > input[type=hidden]#yearD").val(),Number($("div.nowmonth > input[type=hidden]#monthD").val()), 0);
}
//登録/修正ボタンイベント関数
function Apply(){
	loddingShow();
	updateCount = 0;
	updateList = new Array();
	for(i =1;i<=rowCount;i++){
		if($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").is(":checked")){
			updateList.push($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").val());
		}
	}
	if(updateCount<updateList.length){
		insertSend();
	}else{
		loddingHide();
	}
}
//登録/修正メッセージ転送関数
function insertSend(){
	if(updateCount<updateList.length){
		insertData = {idx:null,householddate:null,moneytype:null,category:null,contents:null,money:null,other:null};
		idxStr = updateList[updateCount];
		if(idxStr.indexOf("new") < 0){
			insertData.idx = idxStr;
		}
		insertData.householddate = setNull($(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(2) > input[type=text]").val());
		insertData.moneytype = $(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(3) > select").val();
		$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(4) > select:nth-child("+insertData.moneytype+")").prop("disabled","false");
		insertData.category = $(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(4) > select:nth-child("+insertData.moneytype+")").val();
		insertData.contents = setNull($(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(5) > input[type=text]").val());
		insertData.money = unNumberFormat($(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(6) > input[type=text]").val());
		insertData.other = setNull($(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(7) > input[type=text]").val());
		//validate中でメッセージ処理をしました。
		if(validate(insertData)){
			sendAjax("insert",JSON.stringify(insertData));
		}
	}
}
function validate(insertData){
	if(insertData.householddate == null || insertData.contents == null || insertData.money == "" || insertData.money == "NaN"){
		loddingHide();
		//alert("データ形式が不正確です。ご確認お願いします。");
		setMessage("データ形式が不正確です。ご確認お願いします。");
		if(insertData.contents == null){
			$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(5) > input[type=text]").focus();
		}else if(insertData.householddate  == null){
			$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(2) > input[type=text]").focus();
		}else{
			$(contentsUrl+ " > tr#line"+idxStr+" > td:nth-child(6) > input[type=text]").focus();
		}
		return false;
	}else{
		return true;
	}
}
//削除ボタンイベント関数
function Delete(){
	loddingShow();
	deleteCount = 0;
	deleteList = new Array();
	for(i =1;i<=rowCount;i++){
		if($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").is(":checked")){
			deleteList.push($(contentsUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").val());
		}
	}
	if(deleteCount<deleteList.length){
		deleteSend();
	}else{
		if($(contentsUrl+" > tr").length == 0){
			newline();
		}
		loddingHide();
	}
}
//削除メッセージ転送関数
function deleteSend(){
	if(deleteCount<deleteList.length){
		deleteData = {idx:null};
		idxStr = deleteList[deleteCount];
		if(idxStr.indexOf("new") < 0){
			deleteData.idx = idxStr;
			sendAjax("delete",JSON.stringify(deleteData));
		}else{
			$(contentsUrl+" > tr#line"+idxStr).remove();
			deleteCount++;
			if(deleteCount<deleteList.length){
				deleteSend();
			}else{
				if($(contentsUrl+" > tr").length == 0){
					newline();
				}
				loddingHide();
				setMessage("削除完了しました。");
			}
		}
	}
}
//全体チェック処理
function allCheck(obj){
	if(obj.checked) {
		$(contentsUrl+ " > tr > td:nth-child(1) > input[type=checkbox]").prop("checked",true);
    }else {
    	$(contentsUrl+ " > tr > td:nth-child(1) > input[type=checkbox]").prop("checked",false);
    }
}
function cateallCheck(obj){
	if(obj.checked){
		$(categoryUrl+" > tr > td > input[type=checkbox]").prop("checked",true);
	}else{
		$(categoryUrl+" > tr > td > input[type=checkbox]").prop("checked",false);
	}
}
function cateAddline(){
	caterowCount++;
	cateadd("new"+caterowCount,"","");
}
function cateApply(){
	loddingShow();
	cateupdateCount = 0;
	cateupdateList = new Array();
	for(i =1;i<=caterowCount;i++){
		if($(categoryUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").is(":checked")){
			cateupdateList.push($(categoryUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").val());
		}
	}
	if(cateupdateCount<cateupdateList.length){
		cateupdateSend();
	}else{
		loddingHide();
	}
}
function cateupdateSend(){
	if(cateupdateCount<cateupdateList.length){
		cateupdateDate = {idx:null,moneytype:null,categoryname:null};
		idxStr = cateupdateList[cateupdateCount];
		if(idxStr.indexOf("new") < 0){
			cateupdateDate.idx = idxStr;
		}
		cateupdateDate.moneytype = $(categoryUrl+ " > tr#cateline"+idxStr+" > td:nth-child(2) > select").val();
		cateupdateDate.categoryname = $(categoryUrl+ " > tr#cateline"+idxStr+" > td:nth-child(3) > input[type=text]").val();
		sendAjax("categoryUpdate",JSON.stringify(cateupdateDate));
	}
}
function cateDelete(){
	loddingShow();
	catedeleteCount = 0;
	catedeleteList = new Array();
	for(i =1;i<=caterowCount;i++){
		if($(categoryUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").is(":checked")){
			catedeleteList.push($(categoryUrl+ " > tr:nth-child("+i+") > td:nth-child(1) > input[type=checkbox]").val());
		}
	}
	if(catedeleteCount<catedeleteList.length){
		catedeleteSend();
	}else{
		if($(categoryUrl+" > tr").length == 0){
			cateAddline();
		}
		loddingHide();
	}
}
function catedeleteSend(){
	if(catedeleteCount<catedeleteList.length){
		catedeleteDate = {idx:null};
		idxStr = catedeleteList[catedeleteCount];
		if(idxStr.indexOf("new") < 0){
			catedeleteDate.idx = idxStr;
			sendAjax("categoryDelete",JSON.stringify(catedeleteDate));
		}else{
			$("div#categoryDialog > form > input[name=year]").val($("div.nowmonth > input[type=hidden]#yearD").val());
			$("div#categoryDialog > form > input[name=month]").val($("div.nowmonth > input[type=hidden]#monthD").val());
			loddingHide();
			$("div#categoryDialog > form").submit();
		}
	}
}