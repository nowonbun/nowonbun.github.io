$(document).ready(function () {
	$("div#header > h2").html("家計作成");
	$("div#year-button > select").val($("input#yearD").val());
	$("div#year-button > span").html($("div#year-button > select > option:checked").html());
	$("div#month-button > select").val(Number($("input#monthD").val()));
	$("div#month-button > span").html($("div#month-button > select > option:checked").html());
	$("div#day-button > select").val(Number($("input#dayD").val()));
	$("div#day-button > span").html($("div#day-button > select > option:checked").html());
    categoryView();
    $("div#popupCalcul > div > div > a").each(function (i, node) {
        new NoClickDelay(node);
     });
});
function categoryView() {
    if ($("#selectType").val() == "1") {
        $("#incomecategoryListDiv").show();
        $("#expendcategoryListDiv").hide();
    }
    else {
        $("#incomecategoryListDiv").hide();
        $("#expendcategoryListDiv").show();
    }
}
function Apply(){
	if(validate()){
		if($("#selectType").val() == "1"){
			$("#incomecategoryList").prop("disabled",false);
		}else{
			$("#expendcategoryList").prop("disabled",false);
		}
		$("div#main > form").submit();
	}
}
function validate(){
	if( 	$("input#contents").val() == null || $("input#contents").val() == "" || 
			$("input#money").val() == null || $("input#money").val() == ""){
		setMessage("データ形式が不正確です。ご確認お願いします。");
		$('#ApplyDialog').popup('close');
		$('#ModifyDialog').popup('close');
		$('#DeleteDialog').popup('close');
		return false;
	}else{
		return true;
	}
}
function setMessage(value){
	$("div#errorMsg > span").html(value);
	$("div#errorMsg > span").show();
	setTimeout("setMessageHide()",2000);
}
function setMessageHide(){
	$("div#errorMsg > span").hide();
}
function Modify(){
	if(validate()){
		if($("#selectType").val() == "1"){
			$("#incomecategoryList").prop("disabled",false);
		}else{
			$("#expendcategoryList").prop("disabled",false);
		}
		$("div#main > form").submit();
	}
}
function Delete(){
	$("div#main > form").prop("action","deleteform.html");
	$("div#main > form").submit();
}
function selectedEnable(obj){
	$("#"+obj).prop("disabled",true);
}