package kr.pe.nowonbun.household2.browser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.pe.nowonbun.household2.bean.Household_Category;
import kr.pe.nowonbun.household2.common.HDefine;
import kr.pe.nowonbun.household2.common.HWSParams;
import kr.pe.nowonbun.household2.common.abstractCommon.HAjaxController;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.dao.HouseholdDao;
import kr.pe.nowonbun.household2.entity.Category;
import kr.pe.nowonbun.household2.entity.Household;

@Controller
public class HBPostListSearch extends HAjaxController {

	@RequestMapping(value = "/browser/listSearch.html", method = RequestMethod.POST)
	@ResponseBody
	protected String index(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		return initialize(modelmap, session, req, res);
	}
	@Override
	public String run(){
		//TODO メッセージデータ？？
		String message = getParameter("message");
		HWSParams input = decode(message);
		if (input == null) {
			throw new NullPointerException("Function Type Null Exception");
		}
		getLogger().info("Browser Ajax Search ID -" + getUerInfoSession().getUserid());
		getLogger().info("Function Code - " + input.getFunc());
		if ("search".equals(input.getFunc())) {
			return processSearch(input);
		} else if ("insert".equals(input.getFunc())) {
			return processInsert(input);
		} else if ("delete".equals(input.getFunc())) {
			return processDelete(input);
		} else if ("categorySearch".equals(input.getFunc())) {
			return processCategorySearch(input);
		} else if ("categoryUpdate".equals(input.getFunc())) {
			return processCategoryUpdate(input);
		} else if ("categoryDelete".equals(input.getFunc())) {
			return processCategoryDelete(input);
		}
		throw new RuntimeException("message funcion name wrong!");
	}

	private Calendar getMonthFirstDay(Calendar nowMonth) {
		Calendar ret = (Calendar) nowMonth.clone();
		ret.set(Calendar.DATE, 1);
		return ret;
	}

	private Calendar getMonthLastDay(Calendar nowMonth) {
		Calendar ret = getMonthFirstDay(nowMonth);
		ret.add(Calendar.MONTH, 1);
		ret.add(Calendar.DATE, -1);
		return ret;
	}

	private Calendar transCalendar(String nowMonth) throws ParseException {
		Calendar temp = Calendar.getInstance();
		temp.setTime(HDefine.MONTH_FORMAT.parse(nowMonth));
		return temp;
	}

	private String processSearch(HWSParams param) {
		try {
			HouseholdDao householddao = FactoryDao.getDao(HouseholdDao.class);
			CategoryDao categorydao = FactoryDao.getDao(CategoryDao.class);

			Calendar nowMonth = transCalendar(param.getData().toString());
			Calendar nowMonthFirstDay = getMonthFirstDay(nowMonth);
			Calendar nowMonthLastDay = getMonthLastDay(nowMonth);

			getLogger().info("household Type - " + getUerInfoSession().getHouseholdtype());
			getLogger().info("startDate - " + nowMonthFirstDay.getTime());
			getLogger().info("endDate - " + nowMonthLastDay.getTime());

			List<Household> householdList = householddao.getDefaultList(getUerInfoSession().getHouseholdtype(), nowMonthFirstDay.getTime(), nowMonthLastDay.getTime());
			List<Category> categoryList = categorydao.getAllList(getUerInfoSession().getHouseholdtype());
			getLogger().info("Search count - " + householdList.size());

			List<Household_Category> householdResultList = new ArrayList<Household_Category>(householdList.size());
			householdList.stream().forEach(household -> {
				Household_Category entity = new Household_Category();
				householdResultList.add(entity);
				entity.setData(household);
				if (entity.getCategory() == null) {
					return;
				}
				Category category = categoryList.parallelStream().filter(item -> item.getIdx().intValue() == entity.getCategory().intValue()).findFirst().get();
				entity.setCategoryname(category.getCategoryname());
				entity.setCategorystate(category.getState());
			});
			setReturnFunc(param.getFunc());
			setReturnData(householdResultList);
			getLogger().info("Search OK! ");
			return encode(getReturnParams());
		} catch (NoSuchElementException e) {
			getLogger().error("household Category error!");
			throw e;
		} catch (Throwable e) {
			getLogger().error("household list Searching error!");
			throw new RuntimeException(e);
		}
	}

	private String processInsert(HWSParams input) {
		HouseholdDao householddao = FactoryDao.getDao(HouseholdDao.class);
		String jSondata = input.getData().toString();
		getLogger().info("insert message - " + jSondata);
		// JSON処理
		Household data = (Household) processMessage(jSondata, Household.class);

		Map<String, Object> ret = new HashMap<>();
		try {
			if (validate(data)) {
				Integer idx = data.getIdx();
				if (idx != null) {
					getLogger().info("MODIFY!!!");
					Household entity = householddao.getHouseHold(idx);
					if (!entity.getHouseholdtype().equals(getUerInfoSession().getHouseholdtype())) {
						throw new Exception("householdType Bind Error!");
					}

					// TODO:可笑しい？？
					householddao.insertBackupData(entity);
					entity.setHouseholddate(data.getHouseholddate());
					entity.setMoneytype(data.getMoneytype());
					entity.setCategory(data.getCategory());
					entity.setContents(data.getContents());
					entity.setMoney(data.getMoney());
					entity.setOther(data.getOther());
					entity.setCreater(getUerInfoSession().getUserid());
					entity.setCreatedate(new Date());
					householddao.updateData(entity);

					getLogger().info("MODIFY OK!");
					ret.put("result", "success");
					ret.put("idx", data.getIdx());
				} else {
					getLogger().info("Addcation!!!");
					data.setState("0");
					if (data.getCategory() == null) {
						data.setCategory(new Long(0));
					}
					data.setHouseholdtype(getUerInfoSession().getHouseholdtype());
					data.setCreater(getUerInfoSession().getUserid());
					data.setCreatedate(new Date());
					householddao.insertData(data);
					getLogger().info("data addcation idx - " + data.getIdx());
					getLogger().info("Insert OK!");
					ret.put("result", "success");
					ret.put("idx", data.getIdx());
				}
			} else {
				getLogger().error("Household data validate error!");
				getLogger().error("householdDate - " + data.getHouseholddate());
				getLogger().error("moneyType - " + data.getMoneytype());
				getLogger().error("contents - " + data.getContents());
				getLogger().error("money - " + data.getMoney());
				getLogger().error("other - " + data.getOther());
				getLogger().error("householdType - " + data.getHouseholdtype());
				getLogger().error("Category - " + data.getCategory());
				ret.put("result", "failed");
			}
		} catch (Throwable e) {
			getLogger().error("data update error - " + e);
			ret.put("result", "failed");
		}
		setReturnFunc(input.getFunc());
		setReturnData(ret);
		return encode(getReturnParams());
	}

	private String processDelete(HWSParams input) {
		HouseholdDao householddao = FactoryDao.getDao(HouseholdDao.class);
		String jSonData = input.getData().toString();
		getLogger().info("delete message - " + jSonData);
		Household data = (Household) processMessage(jSonData, Household.class);

		Map<String, Object> ret = new HashMap<>();

		try {
			data = householddao.getHouseHold(data.getIdx());
			if (!data.getHouseholdtype().equals(getUerInfoSession().getHouseholdtype())) {
				throw new Exception("householdType Bind Error!");
			}
			householddao.deleteData(data);
			getLogger().info("data delete idx - " + data.getIdx());
			ret.put("result", "success");
		} catch (Exception e) {
			getLogger().error("data delete error - " + e);
			ret.put("result", "failed");
		}
		setReturnFunc(input.getFunc());
		setReturnData(ret);
		return encode(getReturnParams());
	}

	private String processCategorySearch(HWSParams input) {
		try {
			CategoryDao categorydao = FactoryDao.getDao(CategoryDao.class);
			List<Category> categoryList = categorydao.getDefaultList(getUerInfoSession().getHouseholdtype());
			getLogger().info("CategorySearch count - " + categoryList.size());
			setReturnFunc(input.getFunc());
			setReturnData(categoryList);
			return encode(getReturnParams());
		} catch (Exception e) {
			getLogger().error("category Search Error - " + e);
			throw e;
		}
	}

	private String processCategoryUpdate(HWSParams input) {
		CategoryDao categorydao = FactoryDao.getDao(CategoryDao.class);
		String jSonData = input.getData().toString();
		getLogger().info("Category Update message - " + jSonData);

		Category data = (Category) processMessage(jSonData, Category.class);
		Map<String, Object> ret = new HashMap<String, Object>();
		try {
			Integer idx = data.getIdx();
			if (idx != null) {
				Category entity = categorydao.getCategory(idx);
				if (!entity.getHouseholdtype().equals(getUerInfoSession().getHouseholdtype())) {
					throw new Exception("householdType Bind Error!");
				}
				categorydao.updateBackupData(entity);
				getLogger().info("category modify idx - " + data.getIdx());
				data.setIdx(null);
			}
			data.setState("0");
			data.setCreatedate(new Date());
			data.setCreater(getUerInfoSession().getUserid());
			data.setHouseholdtype(getUerInfoSession().getHouseholdtype());
			categorydao.insertData(data);
			ret.put("result", "success");
		} catch (Exception e) {
			getLogger().error("data update error - " + e);
			ret.put("result", "failed");
		}
		setReturnFunc(input.getFunc());
		setReturnData(ret);
		return encode(getReturnParams());
	}

	private String processCategoryDelete(HWSParams input) {
		CategoryDao categorydao = FactoryDao.getDao(CategoryDao.class);
		String jSonData = input.getData().toString();
		getLogger().info("Category Delete message - " + jSonData);

		Category data = (Category) processMessage(jSonData, Category.class);

		Map<String, Object> ret = new HashMap<>();
		try {

			data = categorydao.getCategory(data.getIdx());
			if (!data.getHouseholdtype().equals(getUerInfoSession().getHouseholdtype())) {
				throw new Exception("householdType Bind Error!");
			}
			categorydao.deleteData(data);
			getLogger().info("data delete idx - " + data.getIdx());
			ret.put("result", "success");
		} catch (Exception e) {
			getLogger().error("data update error - " + e);
			ret.put("result", "failed");
		}
		setReturnFunc(input.getFunc());
		setReturnData(ret);
		return encode(getReturnParams());
	}

	protected boolean validate(Household household) {
		getLogger().info("validate Check - " + household.getIdx());
		if (household.getHouseholddate() == null) {
			getLogger().error("HouseholdDate null");
			return false;
		} else if (household.getMoneytype() == null || "".equals(household.getMoneytype())) {
			getLogger().error("MoneyType null");
			return false;
		} else if (household.getContents() == null || "".equals(household.getContents())) {
			getLogger().error("Contents null");
			return false;
		} else if (household.getMoney() == null) {
			getLogger().error("Money null");
			return false;
		} else if (household.getHouseholdtype() == null) {
			// return false;
		} else if (household.getCategory() == null) {
			getLogger().error("Category null");
			return false;
		}
		return true;
	}
}
