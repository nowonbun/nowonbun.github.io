var webSocket = null;
$(function(){
	selecteChange();
	initMenu();
});
function sendAjax(func,data){
	loddingShow();
	msg = JSON.stringify({
		"func" : func,
		"data" : data
	});
	$.ajax({
		type:"POST",
		url:"listMobileSearch.html",
		dataType:"json",
		data: "message="+msg,
		success:function(response){
			if(response.func === "search"){
				data = response.data;
				income = 0;
				expend = 0;
				tableDelete();
				for(i=0;i<data.length;i++){
					defaultListAdd(data[i]);
					if(data[i].moneytype == 1){
						income += data[i].money;
					}else if(data[i].moneytype == 2){
						expend += data[i].money;
					}
				}
				if (data.length == 0) {
				    dom = $("#templateNot").html();
				    $("#listData").append(dom);
				}
				totalCalcul(income,expend);
				loddingHide();
			}else if(response.func === "searchDay"){
				data = response.data;
				income = 0;
				expend = 0;
				dayTotle = 0;
				tableDelete();
				dayIndex = 0;
				dayBuffer = -1;
				for(i=0;i<data.length;i++){
					date = new Date(data[i].householddate).getDate();
					if(dayBuffer != date){
						if(dayBuffer != -1){
							//Total
							tableDaytotaladd(dayTotle,dayIndex);
							dayTotle = 0;
						}
						//新しいパート始まる。
						dayIndex++;
						tableDayLineAdd(date,dayIndex);
						dayBuffer = date;
					}
					dayListAdd(data[i],dayIndex);
					if(data[i].moneytype == 1){
						income += data[i].money;
						dayTotle += data[i].money;
					}else if(data[i].moneytype == 2){
						expend += data[i].money;
						dayTotle -= data[i].money;
					}
				}
				if (data.length == 0) {
				    dom = $("#templateNot").html();
				    $("#listData").append(dom);
				} else {
				    if (dayTotle != 0) {
				        tableDaytotaladd(dayTotle, dayIndex);
				        dayTotle = 0;
				    }
				}
				totalCalcul(income,expend);
				loddingHide();
			}else if(response.func === "searchCategory"){
				data = response.data;
				income = 0;
				expend = 0;
				dayTotle = 0;
				tableDelete();
				dayIndex = 0;
				categoryBuffer = -1;
				for(i=0;i<data.length;i++){
					category = data[i].category
					if(categoryBuffer != category){
						if(categoryBuffer != -1){
							//Total
							tableDaytotaladd(dayTotle,dayIndex);
							dayTotle = 0;
						}
						//新しいパート始まる。
						dayIndex++;
						tableCategoryLineAdd(category,dayIndex,data[i].categoryname);
						categoryBuffer = category;
					}
					dayListAdd(data[i],dayIndex);
					if(data[i].moneytype == 1){
						income += data[i].money;
						dayTotle += data[i].money;
					}else if(data[i].moneytype == 2){
						expend += data[i].money;
						dayTotle -= data[i].money;
					}
				}
				if (data.length == 0) {
				    dom = $("#templateNot").html();
				    $("#listData").append(dom);
				} else {
				    if (dayTotle != 0) {
				        tableDaytotaladd(dayTotle, dayIndex);
				        dayTotle = 0;
				    }
				}
				totalCalcul(income,expend);
				loddingHide();
			}
		},
		error:function(xhr,status,error){
			
		}
	});
}
function selecteChange(){
	$("div#year-button > select").val($("input[name=yearD]").val());
	$("div#year-button > span").html($("div#year-button > select > option:checked").html());
	$("div#month-button > select").val(Number($("input[name=monthD]").val()));
	$("div#month-button > span").html($("div#month-button > select > option:checked").html());
}
function initMenu(){
	dateCookie();
	menuCookie();
}
function dateCookie(){
	data = getCookie("date");
	if(data != null){
		date = data.split('-');
		if(date.length == 2){
			$("input[name=yearD]").val(date[0]);
			$("input[name=monthD]").val(date[1]);
		}
		selecteChange();
	}
}
function menuCookie(){
	type = getCookie("selecttype");
	if(type == "2"){
		$("div.navbar > ul > li:nth-child(2) > a").prop("class","categoryMenu ui-link ui-btn ui-btn-active");
		dayEvent();
	}else if(type == "3"){
		$("div.navbar > ul > li:nth-child(3) > a").prop("class","categoryMenu ui-link ui-btn ui-btn-active");
		categoryEvent();
	}else{
		$("div.navbar > ul > li:nth-child(1) > a").prop("class","categoryMenu ui-link ui-btn ui-btn-active");
		selectEvent();
	}
}
//全体グループ選択する時
function selectEvent(){
	loddingShow();
	$("input[name=yearD]").val($("div#year-button > select").val());
	$("input[name=monthD]").val($("div#month-button > select").val());
	data = $("input[name=yearD]").val()+"-"+$("input[name=monthD]").val();
	setCookie("date",data,1);
	setCookie("selecttype","1",1);
	sendAjax("search",data);
}
function dayEvent(){
	loddingShow();
	$("input[name=yearD]").val($("div#year-button > select").val());
	$("input[name=monthD]").val($("div#month-button > select").val());
	data = $("input[name=yearD]").val()+"-"+$("input[name=monthD]").val();
	setCookie("date",data,1);
	setCookie("selecttype","2",1);
	sendAjax("searchDay",data);
}
function categoryEvent(){
	loddingShow();
	$("input[name=yearD]").val($("div#year-button > select").val());
	$("input[name=monthD]").val($("div#month-button > select").val());
	data = $("input[name=yearD]").val()+"-"+$("input[name=monthD]").val();
	setCookie("date",data,1);
	setCookie("selecttype","3",1);
	sendAjax("searchCategory",data);
}
function totalCalcul(income,expend){
	$("div#mainTotal > table > tbody > tr > td > label#income ").html("￥"+numberFormat(income + ""));
	$("div#mainTotal > table > tbody > tr > td > label#expend ").html("￥"+numberFormat(expend + ""));
	total = income - expend;
	if(total < 0){
		total *= -1;
		$("div#mainTotal > table > tbody > tr > td > label#total").css("color","blue");
	}else if(total > 0){
		$("div#mainTotal > table > tbody > tr > td > label#total").css("color","red");
	}
	$("div#mainTotal > table > tbody > tr > td > label#total").html("￥"+numberFormat((total) + ""));
}
function tableDelete(){
	$("div#listForm > table > tbody").children().remove();
}
function dayListAdd(data,LineNumber){
	dom = $("#templateHidden").html();
	dom = dom.replace(/##idx##/gi, data.idx);
	dom = dom.replace(/##date##/gi,new Date(data.householddate).getDate() );
	dom = dom.replace(/##contents##/gi, data.contents);
	dom = dom.replace(/##LineNumber##/gi, LineNumber);
	if (data.moneytype == 1) {
		color = "<label style='color:red;margin-right:3px;'>";
	}else {
		color = "<label style='color:blue;margin-right:3px;'>";
	}
	dom = dom.replace(/##money##/gi, color + "￥" + numberFormat(data.money+"") + "</label>");
	$("#listData").append(dom);
}
function tableDayLineAdd(date, LineNumber) {
    dom = $("#templateLabel").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    dom = dom.replace(/##date##/gi, date);
    $("#listData").append(dom);
}
function tableCategoryLineAdd(categoryidx, LineNumber,categoryname) {
	if(categoryname == null){
		categoryname = "カテゴリなし";
	}
    dom = $("#templateLabel2").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    dom = dom.replace(/##CategoryName##/gi, categoryname);
    $("#listData").append(dom);
}
/*function getCategoryName(idx){
	ret = $("tbody#categorylist > tr#"+idx+" > td").html();
	if(ret == null){
		return "カテゴリなし";
	}
	return ret;
}*/
function tableDaytotaladd( money, LineNumber) {
    dom = $("#templateHidden2").html();
    dom = dom.replace(/##LineNumber##/gi, LineNumber);
    if(money > 0){
        color = "<label style='color:red;margin-right:3px;'>";
    }else if(money < 0){
        color = "<label style='color:blue;margin-right:3px;'>";
        money = money * -1;
    }else{
        color = "<label style='color:black;margin-right:3px;'>";
     }
    dom = dom.replace(/##money##/gi, color + "￥" + numberFormat(money+"") + "</label>");
    $("#listData").append(dom);
}
function defaultListAdd(data){
	dom = $("#template").html();
	dom = dom.replace(/##idx##/gi, data.idx);
	dom = dom.replace(/##date##/gi,new Date(data.householddate).getDate() );
	dom = dom.replace(/##contents##/gi, data.contents);
	if (data.moneytype == 1) {
		color = "<label style='color:red;margin-right:3px;'>";
	}else {
		color = "<label style='color:blue;margin-right:3px;'>";
	}
	dom = dom.replace(/##money##/gi, color + "￥" + numberFormat(data.money+"") + "</label>");
	$("#listData").append(dom);
}
function selectGroup(type){
	if(type == 1){
		selectEvent();
	}else if(type == 2){
		dayEvent();
	}else if(type == 3){
		categoryEvent();
	}
	return true;
}
function ShowDisplay(LineNumber) {
    var dispCheck = $("#disp" + LineNumber).val();
    if (dispCheck == "0") {
        $(".disp" + LineNumber).show();
        $("#plus" + LineNumber).hide();
        $("#minus" + LineNumber).show();
        $("#disp" + LineNumber).val("1");
    } else {
        $(".disp" + LineNumber).hide();
        $("#plus" + LineNumber).show();
        $("#minus" + LineNumber).hide();
        $("#disp" + LineNumber).val("0");
    }
}
function insertForm() {
    location.href = "insertform.html";
}
function modifyForm(idx,obj){
	obj.style.backgroundColor = "#CBECC7";
	location.href = "modifyform.html?idx="+idx;
}
function categoryForm(){
	location.href = "categorylist.html";
}