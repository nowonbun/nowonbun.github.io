package kr.pe.nowonbun.household2.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.entity.Household;

public class HouseholdDao extends HDao<Household> {

	public final static String DEFAULTLIST = "Defaultlist";
	public final static String DAYORDERLIST = "DayOrderlist";
	public final static String CATGORYLIST = "CategoryOrderlist";

	private final static String DEFAULT_QUERY = "SELECT * FROM household.household where state= ?  "
			+ "and householdtype= ? and householddate between ? and ? ";

	public List<Household> getDefaultList(Integer householdtype, Date householddatestart, Date householddateend) {
		String query = DEFAULT_QUERY + " order by householddate desc,idx asc ";
		List<Object> parameter = new ArrayList<>();
		parameter.add(householdtype);
		parameter.add(householddatestart);
		parameter.add(householddateend);
		return super.selectToListByNative(query, parameter);
	}
	public List<Household> getDayOrderList(Integer householdtype, Date householddatestart, Date householddateend) {
		String query = DEFAULT_QUERY + " order by householddate desc,idx asc ";
		List<Object> parameter = new ArrayList<>();
		parameter.add(householdtype);
		parameter.add(householddatestart);
		parameter.add(householddateend);
		return super.selectToListByNative(query, parameter);
	}
	public List<Household> getCategoryList(Integer householdtype, Date householddatestart, Date householddateend) {
		String query = DEFAULT_QUERY + " order by category desc,householddate desc,idx asc ";
		List<Object> parameter = new ArrayList<>();
		parameter.add(householdtype);
		parameter.add(householddatestart);
		parameter.add(householddateend);
		return super.selectToListByNative(query, parameter);
	}
	public Household getHouseHold(Integer idx){
		Household where = getTemplate();
		where.setIdx(idx);
		return super.selectToList(where).stream().findFirst().get();
	}
	public void insertBackupData(Household entity){
		try {
			Household backup = (Household)entity.clone();
			backup.setIdx(null);
			backup.setState("1");
			super.create(backup);
		} catch (Throwable e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public void updateData(Household entity){
		super.update(entity);
	}
	public void insertData(Household entity){
		super.create(entity);
	}
	public void deleteData(Household entity){
		entity.setState("1");
		super.update(entity);
	}
}
