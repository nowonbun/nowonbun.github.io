package kr.pe.nowonbun.household2.test;

import org.junit.Assert;
import org.junit.Test;

public class JUnitTest {
	@Test
	public void successMethod(){
		int a = 1;
		Assert.assertEquals(a, 1);
	}
	@Test
	public void failedMethod(){
		int a = 1;
		Assert.assertEquals(a, 2);
	}
}
