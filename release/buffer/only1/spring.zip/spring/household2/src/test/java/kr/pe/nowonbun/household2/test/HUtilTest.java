package kr.pe.nowonbun.household2.test;

import org.junit.Test;

import kr.pe.nowonbun.household2.common.HUtils;
import kr.pe.nowonbun.household2.dao.CategoryDao;

public class HUtilTest {
	@Test
	public void testClassName(){
		System.out.println(HUtils.getClassName(CategoryDao.class));
	}
}
