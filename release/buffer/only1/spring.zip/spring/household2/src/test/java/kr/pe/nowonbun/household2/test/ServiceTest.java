package kr.pe.nowonbun.household2.test;

import org.junit.Test;

import kr.pe.nowonbun.household2.common.HService;

public class ServiceTest{
	
	@Test
	public void test(){
		HService.getInstance().transaction(em ->{
			
			int a = 0;
			return a;
		});
	}
}
