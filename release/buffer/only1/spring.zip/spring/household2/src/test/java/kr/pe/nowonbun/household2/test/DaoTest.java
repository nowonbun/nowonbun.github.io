package kr.pe.nowonbun.household2.test;

import java.util.List;

import org.junit.Test;

import kr.pe.nowonbun.household2.common.abstractCommon.HDao;
import kr.pe.nowonbun.household2.dao.CategoryDao;
import kr.pe.nowonbun.household2.dao.FactoryDao;
import kr.pe.nowonbun.household2.entity.Category;

public class DaoTest {
	class CategoryTestClass extends HDao<Category>{
		
	}
	@Test
	public void selectToListTest1(){
//		CategoryTestClass cls = new CategoryTestClass();
//		Category test = new Category();
//		List<Category> value = cls.selectToList();
//		System.out.println(value.size());
	}
	@Test
	public void selectToListTest2(){
//		CategoryTestClass cls = new CategoryTestClass();
//		Category test = new Category();
//		test.setState("0");
//		List<Category> value = cls.selectToList(test);
//		System.out.println(value.size());
	}
	@Test
	public void selectToListTest3(){
//		CategoryTestClass cls = new CategoryTestClass();
//		Category test = new Category();
//		test.setState("0");
//		List<Category> value = cls.selectToList(test,"IDX");
//		System.out.println(value.size());
	}
	@Test
	public void testCategoryDao(){
		CategoryDao dao = FactoryDao.getDao(CategoryDao.class);
		List<Category> t = dao.getAllList(1);
		System.out.println(t.size());
	}
}
