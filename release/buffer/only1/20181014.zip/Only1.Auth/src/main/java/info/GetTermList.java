package info;

import java.util.List;
import javax.servlet.annotation.WebServlet;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import dao.CmcodeDao;
import model.master.Cmcode;

@WebServlet("/GetTermList")
public class GetTermList extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		List<Cmcode> list = FactoryDao.getDao(CmcodeDao.class).getTermCodeList();
		StringBuffer sb = new StringBuffer();
		createTerms(sb);
		for (Cmcode cm : list) {
			createSubTerms(sb, cm.getId().getCode(), cm.getValue());
		}
		getResponse().setContentType("text/html;charset=UTF-8");
		getPrinter().write(sb.toString());
	}

	private void createTerms(StringBuffer sb) {
		sb.append("<div class=\"form-check mb-3\">");
		sb.append("<input type=\"checkbox\" class=\"form-check-input total-term-check\" id=\"totalCheckbox\">");
		sb.append("<label class=\"form-check-label oneId-term-label\" for=\"totalCheckbox\">전체 약관 동의</label>");
		sb.append("</div>");
	}

	private void createSubTerms(StringBuffer sb, String code, String text) {
		sb.append("<div class=\"form-check mb-1\">");
		sb.append("<input type=\"checkbox\" class=\"form-check-input sub-term-check\" id=\"subCheckbox" + code + "\">");
		sb.append("<label class=\"form-check-label oneId-term-label\" for=\"subCheckbox" + code + "\">" + text + "</label>");
		sb.append("<button type=\"button\" class=\"btn btn-info btn-sm my-0 ml-3 waves-effect waves-light one-term-btn\" data-term=\"" + code + "\">내용 보기</button>");
		sb.append("</div>");
	}

	@Override
	protected void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

}
