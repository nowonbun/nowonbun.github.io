package model.master;

import java.io.Serializable;
import javax.persistence.*;

import model.transaction.MemberService;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "mst_service")
@NamedQuery(name = "Service.findAll", query = "SELECT s FROM Service s")
public class Service implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "service_id")
	private String serviceId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_dt")
	private Date endDt;

	@Column(name = "is_use")
	private boolean isUse;

	private String remark;

	@Column(name = "service_nm")
	private String serviceNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_dt")
	private Date startDt;

	@OneToMany(mappedBy = "service", fetch = FetchType.LAZY)
	private List<MemberService> memberServices;

	public Service() {
	}

	public String getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getServiceNm() {
		return this.serviceNm;
	}

	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public List<MemberService> getMemberServices() {
		return this.memberServices;
	}

	public void setMemberServices(List<MemberService> memberServices) {
		this.memberServices = memberServices;
	}

	public MemberService addMemberService(MemberService memberService) {
		getMemberServices().add(memberService);
		memberService.setService(this);

		return memberService;
	}

	public MemberService removeMemberService(MemberService memberService) {
		getMemberServices().remove(memberService);
		memberService.setService(null);

		return memberService;
	}
}