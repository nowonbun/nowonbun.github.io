package dao;

import java.util.Date;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.TransactionDao;
import model.transaction.UserAuth;

public class UserAuthDao extends TransactionDao<UserAuth> {

	protected UserAuthDao() {
		super(UserAuth.class);
	}

	public UserAuth getUserAuthById(String id) {
		return transaction((em) -> {
			try {
				String qy = "SELECT ua FROM UserAuth ua WHERE ua.authId = :id and ua.expDt > :date and ua.ix is null";
				Query query = em.createQuery(qy);
				query.setParameter("id", id);
				query.setParameter("date", new Date());
				return (UserAuth) query.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public int updateDelete(String id, String method) {
		return transaction((em) -> {
			try {
				String qy = "UPDATE UserAuth SET expDt = :date , ix = :ix, updateDt = :date, updateMethod = :method  WHERE authId = :id and expDt > :date and ix is null";
				Query query = em.createQuery(qy);
				query.setParameter("id", id);
				query.setParameter("date", new Date());
				query.setParameter("ix", "x");
				query.setParameter("method", method);
				int ret = query.executeUpdate();
				qy = "DELETE FROM UserAuth WHERE ix = :ix";
				query = em.createQuery(qy);
				query.setParameter("ix", "x");
				query.executeUpdate();
				return ret;
			} catch (NoResultException e) {
				return 0;
			}
		});
	}
}
