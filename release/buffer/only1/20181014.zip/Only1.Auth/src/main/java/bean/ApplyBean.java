package bean;

import java.util.List;

public class ApplyBean {
	private String id;
	private boolean idCheck;
	private String auth;
	private String pwd;
	private String comp;
	private String bizno;
	private boolean biznoCheck;
	private String owner;
	private String ownerp;
	private boolean ownerpCheck;
	private int mallcount;
	private List<MallBean> mall;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isIdCheck() {
		return idCheck;
	}

	public void setIdCheck(boolean idCheck) {
		this.idCheck = idCheck;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getComp() {
		return comp;
	}

	public void setComp(String comp) {
		this.comp = comp;
	}

	public String getBizno() {
		return bizno;
	}

	public void setBizno(String bizno) {
		this.bizno = bizno;
	}

	public boolean isBiznoCheck() {
		return biznoCheck;
	}

	public void setBiznoCheck(boolean biznoCheck) {
		this.biznoCheck = biznoCheck;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerp() {
		return ownerp;
	}

	public void setOwnerp(String ownerp) {
		this.ownerp = ownerp;
	}

	public boolean isOwnerpCheck() {
		return ownerpCheck;
	}

	public void setOwnerpCheck(boolean ownerpCheck) {
		this.ownerpCheck = ownerpCheck;
	}

	public int getMallcount() {
		return mallcount;
	}

	public void setMallcount(int mallcount) {
		this.mallcount = mallcount;
	}

	public List<MallBean> getMall() {
		return mall;
	}

	public void setMall(List<MallBean> mall) {
		this.mall = mall;
	}

}
