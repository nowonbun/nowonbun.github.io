package login;

import java.util.Calendar;
import java.util.Date;
import bean.DataBean;
import bean.LoginBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import dao.UserDao;
import model.transaction.AccessLog;
import model.transaction.User;
import model.transaction.UserAuth;

/**
 * writer - Soonyub Hwang
 * 
 * Finally updated data - 2018/10/09
 * 
 * Finally Code review - 2018/10/09 Soonyub Hwang
 * 
 * This is login class. For login, it will check id and password with database.
 * The password consists of md5. After the user was login, this will generate
 * the authentication key. and apply to session and cookie. Finally this will
 * return the authentication key.
 */
public class Login extends IServlet {
	private static final long serialVersionUID = 1L;
	private LoginBean login = null;

	public Login() {
		super();
	}

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			getLogger().error("[validate] The parameter was not setted.");
			super.setStatus(403);
			return false;
		}
		login = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			LoginBean ret = new LoginBean();
			ret.setId(JsonConverter.JsonString(obj, "id"));
			ret.setPw(JsonConverter.JsonString(obj, "pw"));
			ret.setMd5(JsonConverter.JsonString(obj, "md5"));
			return ret;
		});
		getLogger().error("[validate] The user tried to login this. - " + login.getId());
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		getLogger().error("[error] error message - " + e);
		// TODO: error log data insert?
		resParam.setCode(ResponseCodeMap.CODE001);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		String pw = login.getMd5();
		if (pw == null) {
			pw = Util.convertMD5(login.getPw());
		}
		User user = validateLogin(login.getId(), pw, reqParam.getServiceid());
		if (user == null) {
			getLogger().info("[doMain] The login has failed.");
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		String authId = Util.createCookieKey();
		getLogger().info("[doMain] The auth id was generated. - " + authId);
		resParam.setCode(ResponseCodeMap.CODE000);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE000));

		updateUserAuth(authId, user);
		updateAccessLog(authId, reqParam.getServiceid(), user, resParam.getMessage());

		super.setCookie(getCookieKey(), authId);
		getSession().setAttribute(SESSION_KEY, authId);
		getSession().setAttribute(USER_SESSION_KEY, user);
		getLogger().info("[doMain] The auth id was applied to cookie and session. - " + authId);

		DataBean data = new DataBean();
		data.setAuthId(authId);
		resParam.setData(JsonConverter.create(data));
	}

	private void updateUserAuth(String authId, User user) {
		UserAuth userAuth = new UserAuth();
		userAuth.setAuthId(authId);
		userAuth.setUser(user);

		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		// TODO: The expire data was hard coding.
		c.add(Calendar.DATE, 1);
		userAuth.setExpDt(c.getTime());

		userAuth.setLocation(getRequest().getRemoteHost());
		userAuth.setInsertDt(new Date());
		userAuth.setInsertMethod(getClass().getName());
		userAuth.setUpdateDt(new Date());
		userAuth.setUpdateMethod(getClass().getName());
		FactoryDao.getDao(UserAuthDao.class).update(userAuth);
		getLogger().info("[updateUserAuth] The data was updated to table of UserAuth.");
	}

	private void updateAccessLog(String authId, String serviceId, User userBean, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setUser(userBean.getIdx());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName());
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
		getLogger().info("[updateAccessLog] The data was updated to table of AccessLog.");
	}

	private User validateLogin(String id, String pw, String serviceId) {
		if (id == null || pw == null) {
			getLogger().error("[validateLogin] id or pw is null");
			return null;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(id);
		if (user == null) {
			getLogger().error("[validateLogin] The user was not exists in database. - " + id);
			return null;
		}
		if (!Util.StringEquals(user.getPassword().toUpperCase(), pw.toUpperCase())) {
			getLogger().error("[validateLogin] The password was not matched.");
			return null;
		}
		return user;
	}
}
