package model.master;

import java.io.Serializable;
import javax.persistence.*;
import model.master.key.TermPK;
import model.transaction.MemberTerm;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "mst_terms")
@NamedQuery(name = "Term.findAll", query = "SELECT t FROM Term t")
public class Term implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TermPK id;

	@Lob
	private String content;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_dt")
	private Date endDt;

	@Column(name = "is_use")
	private boolean isUse;

	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_dt")
	private Date startDt;

	@OneToMany(mappedBy = "term", fetch = FetchType.LAZY)
	private List<MemberTerm> memberTerms;

	public Term() {
	}

	public TermPK getId() {
		return this.id;
	}

	public void setId(TermPK id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public List<MemberTerm> getMemberTerms() {
		return this.memberTerms;
	}

	public void setMemberTerms(List<MemberTerm> memberTerms) {
		this.memberTerms = memberTerms;
	}

	public MemberTerm addMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().add(memberTerm);
		memberTerm.setTerm(this);

		return memberTerm;
	}

	public MemberTerm removeMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().remove(memberTerm);
		memberTerm.setTerm(null);

		return memberTerm;
	}

}