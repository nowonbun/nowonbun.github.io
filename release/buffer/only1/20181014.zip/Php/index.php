<?php
include_once $_SERVER ['DOCUMENT_ROOT'] . './AbstractClass.php';
class Index extends Only1Auth{
	public function run() {
		$authId = $_REQUEST["authId"];
		if(!parent::isLogin($authId)){
			parent::redirect(parent::getServiceUrl()."?service=63414DE4-EAB0-4A73-9AF6-000B393811EB&redirect=http://localhost/");
			return;
		}
		$_SESSION["authId"] = $authId;
		parent::redirect("main.php");
	}
}
$obj = new Index();
$obj->run();
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<a href="main.php">main</a>
</body>
</html>