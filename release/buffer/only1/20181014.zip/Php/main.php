<?php
include_once $_SERVER ['DOCUMENT_ROOT'] . './AbstractClass.php';
class Index extends Only1Auth{
	private $authId = "";
	public function run() {
		$this->authId = $_SESSION["authId"];
		if(!parent::isLogin($this->authId)){
			$this->authId = "";
			parent::redirect(parent::getServiceUrl()."?service=63414DE4-EAB0-4A73-9AF6-000B393811EB&redirect=http://localhost/");
			return;
		}
	}
	public function logoutUrl(){
		return parent::getServiceUrl(). "platformAPI?_method=doLogout&serviceid=63414DE4-EAB0-4A73-9AF6-000B393811EB";
	}
	public function platform(){
		return parent::getServiceUrl(). "platformAPI";
	}
	public function getAuthId(){
		return $this->authId;
	}
}
$obj = new Index();
$obj->run();
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<form action="<?=$obj->platform()?>" id="form">	
		<input type="text" name="_method" id="method">
		<input type="text" name="serviceid" id="serviceid" value="63414DE4-EAB0-4A73-9AF6-000B393811EB">
		<input type="text" name="params" id="params" value="">
	</form>
	<a href="<?=$obj->logoutUrl()?>">logout</a>
	<br />
	authid : <input type="text" id="authid" value="<?=$obj->getAuthId()?>" readonly>
	<fieldset>
		<legend>password:</legend>
		pw : <input type="text" id="pwd">
		<br />
		<button id="pwdsetting">password setting</button>
	</fieldset>
	<fieldset>
		<legend>user info:</legend>
		<button id="getInfo">get info</button> <br />
		id : <input type="text" id="i_id"> <br />
		comp : <input type="text" id="i_comp"> <br />
		bizno : <input type="text" id="i_bizno"> <br />
		owner : <input type="text" id="i_owner"> <br />
		owner-p : <input type="text" id="i_owner_p"> <br />
		<button id="saveInfo">save info</button> <br />
	</fieldset>
	<script type="text/javascript" src="//code.jquery.com/jquery-3.3.1.min.js"></script>
	<script>
		$(function(){
			$(document).on("click","#pwdsetting",function(){
				$("#method").val("doSetPassword");
				$("#params").val(JSON.stringify({
					authid : $("#authid").val(),
					pwd: $("#pwd").val()
				}));
				$.ajax({
					url : "<?=$obj->platform()?>",
					type : "POST",
					data : $("form").serialize(),
					dataType : "json",
					success : function(data, textStatus, jqXHR) {
						console.log(data);
					}
				});
			});
			$(document).on("click","#getInfo",function(){
				$("#method").val("doGetUserInfo");
				$("#params").val(JSON.stringify({
					authid : $("#authid").val(),
				}));
				$.ajax({
					url : "<?=$obj->platform()?>",
					type : "POST",
					data : $("form").serialize(),
					dataType : "json",
					success : function(data, textStatus, jqXHR) {
						var result = JSON.parse(data.result);
						var info = JSON.parse(result.data);
						$("#i_id").val(info.id);
						$("#i_comp").val(info.comp);
						$("#i_bizno").val(info.bizno);
						$("#i_owner").val(info.owner);
						$("#i_owner_p").val(info.ownerp);
						console.log(info);
					}
				});
			});
			$(document).on("click","#saveInfo",function(){
				$("#method").val("doSetUserInfo");
				$("#params").val(JSON.stringify({
					authid : $("#authid").val(),
					owner : $("#i_owner").val(),
					ownerp : $("#i_owner_p").val(),
					ownerpCheck : 'true'
				}));
				$.ajax({
					url : "<?=$obj->platform()?>",
					type : "POST",
					data : $("form").serialize(),
					dataType : "json",
					success : function(data, textStatus, jqXHR) {
						console.log(data);
					}
				});
			});
		});
	</script>
</body>
</html>