﻿/*History
1. 2018.09.04 작성시작 작성자: 황순엽
*/
create database platform;
use platform;

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: MASTER
테이블명: 공통코드
*/
CREATE TABLE mst_cmcode(
	group_cd VARCHAR(4) NOT NULL COMMENT '그룹코드',
	code VARCHAR(4) NOT NULL COMMENT '코드',
	value NVARCHAR(50) NOT NULL COMMENT '값',
	priority INT NOT NULL DEFAULT '1' COMMENT '우선순위',
	p_group_cd VARCHAR(4) NULL COMMENT '부모그룹',
	p_code VARCHAR(4) NULL COMMENT '부모코드',
	attribute_int INT NULL COMMENT '속성_숫자',
	attribute_str NVARCHAR(50) NULL COMMENT '속성_문자',
	is_use BOOLEAN NOT NULL DEFAULT '0' COMMENT '사용여부',
	description NVARCHAR(255) NULL COMMENT '설명',
	remark NVARCHAR(255) NULL COMMENT '비고',
	
	PRIMARY KEY (group_cd, code)	
) COMMENT='공통코드';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: MASTER
테이블명: 서비스 정보 테이블
*/
CREATE TABLE mst_service(
	service_id CHAR(36) NOT NULL DEFAULT uuid() COMMENT 'uuid',
	service_nm NVARCHAR(50) NOT NULL COMMENT '서비스명',
	is_use BOOLEAN NOT NULL COMMENT '사용여부',
	start_dt DATETIME NOT NULL DEFAULT now() COMMENT '서비스 시작일',
	end_dt DATETIME NULL COMMENT '서비스 종료일',
	remark NVARCHAR(255) NULL COMMENT '비고',
	
	PRIMARY KEY (service_id)	
) COMMENT='서비스 정보 테이블';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: MASTER
테이블명: 약관
*/
CREATE TABLE mst_terms(
	terms_type CHAR(2) NOT NULL COMMENT '약관형태코드',
	version INT NOT NULL COMMENT 'version',
	start_dt DATETIME NOT NULL DEFAULT now() COMMENT '약관시행일',
	end_dt DATETIME NOT NULL COMMENT '약관시행종료일',
	content NVARCHAR(20000) NULL COMMENT '약관내용',
	is_use BOOLEAN NOT NULL DEFAULT '0' COMMENT '사용여부',
	remark NVARCHAR(255) NULL COMMENT '비고',
	
	PRIMARY KEY (terms_type, version)	
) COMMENT='약관';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: MASTER
테이블명: 몰정보
*/
CREATE TABLE mst_mall(
	mall_id CHAR(3) NOT NULL COMMENT '몰ID',
	mall_nm NVARCHAR(50) NOT NULL COMMENT '몰명',
	class_cd CHAR(2) NOT NULL COMMENT '분류코드',
	acc_type CHAR(2) NOT NULL COMMENT '정산타입코드',
	group_cd VARCHAR(4) NOT NULL COMMENT 'cmcode.group_code',
	code VARCHAR(4) NOT NULL COMMENT 'cmcode.code',
	priority INT NOT NULL COMMENT '표시 우선순위',
	id1_is_use BOOLEAN NOT NULL COMMENT 'ID#1 사용여부',
	id1_name NVARCHAR(50) NOT NULL COMMENT 'ID#1 명칭',
	id2_is_use BOOLEAN NOT NULL COMMENT 'ID#2 사용여부',
	id2_name NVARCHAR(50) NULL COMMENT 'ID#2 명칭',
	id3_is_use BOOLEAN NOT NULL COMMENT 'ID#3 사용여부',
	id3_name NVARCHAR(50) NULL COMMENT 'ID#3 명칭',
	pw1_is_use BOOLEAN NOT NULL COMMENT 'PW#1 사용여부',
	pw1_name NVARCHAR(50) NOT NULL COMMENT 'PW#1 명칭',
	pw2_is_use BOOLEAN NOT NULL COMMENT 'PW#2 사용여부',
	pw2_name NVARCHAR(50) NULL COMMENT 'PW#2 명칭',
	option1_is_use BOOLEAN NOT NULL COMMENT '옵션#1 사용여부',
	option1_name NVARCHAR(50) NULL COMMENT '옵션#1 명칭',
	option2_is_use BOOLEAN NOT NULL COMMENT '옵션#2 사용여부',
	option2_name NVARCHAR(50) NULL COMMENT '옵션#2 명칭',
	login_uri NVARCHAR(255) NOT NULL COMMENT '로그인URI',
	remark NVARCHAR(255) NULL COMMENT '비고',
	
	PRIMARY KEY (mall_id),
	FOREIGN KEY (group_cd, code) REFERENCES mst_cmcode (group_cd, code)
) COMMENT='몰정보';


/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.04
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 회원정보 테이블
*/
CREATE TABLE tsn_member(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	company_nm NVARCHAR(100) NOT NULL COMMENT '회사명',
	group_cd VARCHAR(4) DEFAULT 'A011' NOT NULL COMMENT 'cmcode.group_code',
	code VARCHAR(4) DEFAULT '10' NOT NULL COMMENT 'cmcode.code',
	state_dt DATETIME NOT NULL COMMENT '상태변경일시',
	state_reason NVARCHAR(100) NULL COMMENT '상태변경사유',
	biz_no VARCHAR(10) NOT NULL COMMENT '사업자번호', 
	ceo_nm NVARCHAR(50) NOT NULL COMMENT '대표자명',
	ceo_phone varchar(15) NOT NULL COMMENT '대표자휴대폰번호',
	signup_dt DATETIME NOT NULL COMMENT '회원가입일',
	signup_route NVARCHAR(255) NOT NULL COMMENT '회원가입경로',
	remark NVARCHAR(255) NULL COMMENT '비고',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	UNIQUE KEY (biz_no),
	FOREIGN KEY (group_cd, code) REFERENCES mst_cmcode (group_cd, code)
) COMMENT='회원정보';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.04
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 회원정보 테이블
*/
CREATE TABLE tsn_user(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	member_id INT NOT NULL COMMENT 'member.idx',
	email VARCHAR(50)  NOT NULL COMMENT '이메일(로그인 ID)',
	password VARCHAR(100) NOT NULL COMMENT '로그인 패스워드',
	group_cd VARCHAR(4) DEFAULT 'A011' NOT NULL COMMENT 'cmcode.group_code',
	code VARCHAR(4) DEFAULT '10' NOT NULL COMMENT 'cmcode.code',
	state_dt DATETIME NOT NULL COMMENT '상태변경일시',
	state_reason NVARCHAR(100) NULL COMMENT '상태변경사유',
	name NVARCHAR(50) NULL COMMENT '이름',
	position NVARCHAR(50) NULL COMMENT '직책',
	role VARCHAR(4) NULL COMMENT '권한그룹',
	grade VARCHAR(4) NULL COMMENT '권한등급',
	pw_change_dt DATETIME NOT NULL DEFAULT now() COMMENT '패스워드 수정일',
	remark NVARCHAR(255) NULL COMMENT '비고',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	UNIQUE KEY (email),
	FOREIGN KEY (member_id) REFERENCES tsn_member (idx),
	FOREIGN KEY (group_cd, code) REFERENCES mst_cmcode (group_cd, code)
) COMMENT='사용자 정보 테이블';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 사용자인증
*/
CREATE TABLE tsn_user_auth(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	auth_id CHAR(36) NOT NULL DEFAULT uuid() COMMENT 'uuid',
	user_id INT NOT NULL COMMENT 'user.idx',
	exp_dt DATETIME NOT NULL DEFAULT now() COMMENT '만료일시',
	location VARCHAR(255) NOT NULL COMMENT 'remote IP',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	FOREIGN KEY (user_id) REFERENCES tsn_user (idx)
) COMMENT='사용자인증';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 회원별서비스등록
*/
CREATE TABLE tsn_member_service(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	member_id INT NOT NULL COMMENT 'member.idx',
	service_id CHAR(36) NOT NULL COMMENT 'service.service_id',
	remark NVARCHAR(255) NULL COMMENT '비고',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	FOREIGN KEY (member_id) REFERENCES tsn_member(idx),
	FOREIGN KEY (service_id) REFERENCES mst_service(service_id)
) COMMENT='회원별서비스등록';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 회원별동의약관
*/
CREATE TABLE tsn_member_terms(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	member_id INT NOT NULL COMMENT 'member.idx',
	terms_type CHAR(2) NOT NULL COMMENT 'term.terms_type',
	terms_version INT NOT NULL COMMENT 'term.terms_version',
	remark NVARCHAR(255) NULL COMMENT '비고',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	FOREIGN KEY (member_id) REFERENCES tsn_member(idx),
	FOREIGN KEY (terms_type,terms_version) REFERENCES mst_terms(terms_type,version)
	
) COMMENT='회원별동의약관';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 회원별계정정보
*/
CREATE TABLE tsn_member_mall(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	member_id INT NOT NULL COMMENT 'member.idx',
	mall_id CHAR(3) NOT NULL COMMENT 'mall.mall_id',
	id1_value NVARCHAR(50) NULL COMMENT 'ID#1 값',
	id2_value NVARCHAR(50) NULL COMMENT 'ID#2 값',
	id3_value NVARCHAR(50) NULL COMMENT 'ID#3 값',
	pw1_value NVARCHAR(50) NULL COMMENT 'PW#1 값',
	pw2_value NVARCHAR(50) NULL COMMENT 'PW#2 값',
	option1_value NVARCHAR(50) NULL COMMENT 'Option#1 값',
	option2_value NVARCHAR(50) NULL COMMENT 'Option#2 값',
	last_sc_dt DATETIME NULL COMMENT '최근 스크래핑 일시',
	last_sc_state CHAR(4) COMMENT '최근 스크래핑 상태',
	remark NVARCHAR(255) NULL COMMENT '비고',
	ix CHAR(1) NULL COMMENT '삭제지시자',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	update_dt DATETIME NOT NULL DEFAULT now() COMMENT '수정일시',
	update_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '수정메소드',
	
	PRIMARY KEY (idx),
	FOREIGN KEY (member_id) REFERENCES tsn_member(idx),
	FOREIGN KEY (mall_id) REFERENCES mst_mall(mall_id)
	
) COMMENT='회원별계정정보';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 접속로그
*/
CREATE TABLE tsn_access_log(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	service_id CHAR(36) NOT NULL COMMENT 'service.service_id',
	is_accepted boolean NOT NULL COMMENT '인증여부',
	access_msg NVARCHAR(255) NULL COMMENT '메시지',
	ip VARCHAR(40) NOT NULL COMMENT '리모트 ip (로컬+리얼)',
	user INT NULL COMMENT 'user.idx',
	auth_id VARCHAR(36) NULL COMMENT 'user_auth.auth_id',
	remark NVARCHAR(255) NULL COMMENT '비고',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	
	PRIMARY KEY (idx)
) COMMENT='접속로그';

/*
설계일시: 2018.09.04
설계자 : 장지오
최종 작성일시: 2018.09.06
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 에러로그
*/
CREATE TABLE tsn_error_log(
	idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
	error_cd VARCHAR(4) NULL COMMENT '에러코드',
	error_msg NVARCHAR(255) NULL COMMENT '에러메시지',
	ip VARCHAR(40) NOT NULL COMMENT '리모트 ip (로컬+리얼)',
	user INT NULL COMMENT 'user.idx',
	auth_id VARCHAR(36) NULL COMMENT 'user_auth.auth_id',
	remark NVARCHAR(255) NULL COMMENT '비고',
	insert_dt DATETIME NOT NULL DEFAULT now() COMMENT '등록일시',
	insert_method VARCHAR(255) NOT NULL DEFAULT 'unknown' COMMENT '등록메소드',
	
	PRIMARY KEY (idx)
) COMMENT='에러로그';

/*
설계일시: 2018.10.08
최종 작성일시: 2018.10.08
최종 작성자 : 황순엽
테이블 TYPE: TRANSACTION
테이블명: 체크 임시 테이블
*/
CREATE TABLE tsn_checking_temporary(
        idx INT NOT NULL AUTO_INCREMENT COMMENT 'idx',
        type VARCHAR(255) NOT NULL COMMENT 'Check Type',
        id VARCHAR(255) NOT NULL COMMENT 'EMAIL-ID',
        data VARCHAR(255) NOT NULL COMMENT '체크데이터',
        value VARCHAR(255) NOT NULL COMMENT '인증키',
        isCheck BOOLEAN NOT NULL DEFAULT FALSE COMMENT '확인여부',
        update_dt DATETIME NOT NULL DEFAULT now(),
        
        PRIMARY KEY(idx)
) COMMENT='체크 임시 테이블'
