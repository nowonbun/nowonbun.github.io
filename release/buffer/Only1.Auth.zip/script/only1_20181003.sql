DROP TRIGGER member_after_update;
delimiter //
CREATE TRIGGER member_after_update
AFTER UPDATE ON member
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF NEW.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'U';
	END IF;
	INSERT INTO member_h(
		issue_type,
		oidx,
		company_nm,
		state,
		state_dt,
		state_reason,
		biz_no,
		ceo_nm,
		ceo_phone,
		signup_dt,
		signup_route,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.company_nm,
		OLD.state,
		OLD.state_dt,
		OLD.state_reason,
		OLD.biz_no,
		OLD.ceo_nm,
		OLD.ceo_phone,
		OLD.signup_dt,
		OLD.signup_route,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method);
END;
//
delimiter ;