﻿delimiter //
CREATE TRIGGER mst_cmcode_after_insert
AFTER INSERT ON mst_cmcode
 FOR EACH ROW
BEGIN
	INSERT INTO mst_cmcode_h(
		issue_type,
		group_cd,
		code,
		value,
		priority,
		p_group_cd,
		p_code,
		attribute_int,
		attribute_str,
		is_use,
		description,
		remark
	) VALUES (
		'I',
		NEW.group_cd,
		NEW.code,
		NEW.value,
		NEW.priority,
		NEW.p_group_cd,
		NEW.p_code,
		NEW.attribute_int,
		NEW.attribute_str,
		NEW.is_use,
		NEW.description,
		NEW.remark
	);
END;
//

CREATE TRIGGER mst_cmcode_after_update
AFTER UPDATE ON mst_cmcode
 FOR EACH ROW
BEGIN
	INSERT INTO mst_cmcode_h(
		issue_type,
		group_cd,
		code,
		value,
		priority,
		p_group_cd,
		p_code,
		attribute_int,
		attribute_str,
		is_use,
		description,
		remark
	) VALUES (
		'U',
		OLD.group_cd,
		OLD.code,
		OLD.value,
		OLD.priority,
		OLD.p_group_cd,
		OLD.p_code,
		OLD.attribute_int,
		OLD.attribute_str,
		OLD.is_use,
		OLD.description,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_cmcode_before_delete
BEFORE DELETE ON mst_cmcode
 FOR EACH ROW
BEGIN
	INSERT INTO mst_cmcode_h(
		issue_type,
		group_cd,
		code,
		value,
		priority,
		p_group_cd,
		p_code,
		attribute_int,
		attribute_str,
		is_use,
		description,
		remark
	) VALUES (
		'D',
		OLD.group_cd,
		OLD.code,
		OLD.value,
		OLD.priority,
		OLD.p_group_cd,
		OLD.p_code,
		OLD.attribute_int,
		OLD.attribute_str,
		OLD.is_use,
		OLD.description,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_service_after_insert
AFTER INSERT ON mst_service
 FOR EACH ROW
BEGIN
	INSERT INTO mst_service_h(
		issue_type,
		service_id,
		service_nm,
		is_use,
		start_dt,
		end_dt,
		remark
	) VALUES (
		'I',
		NEW.service_id,
		NEW.service_nm,
		NEW.is_use,
		NEW.start_dt,
		NEW.end_dt,
		NEW.remark
	);
END;
//

CREATE TRIGGER mst_service_after_update
AFTER UPDATE ON mst_service
 FOR EACH ROW
BEGIN
	INSERT INTO service_h(
		issue_type,
		service_id,
		service_nm,
		is_use,
		start_dt,
		end_dt,
		remark
	) VALUES (
		'U',
		OLD.service_id,
		OLD.service_nm,
		OLD.is_use,
		OLD.start_dt,
		OLD.end_dt,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_service_before_delete
BEFORE DELETE ON mst_service
 FOR EACH ROW
BEGIN
	INSERT INTO mst_service_h(
		issue_type,
		service_id,
		service_nm,
		is_use,
		start_dt,
		end_dt,
		remark
	) VALUES (
		'D',
		OLD.service_id,
		OLD.service_nm,
		OLD.is_use,
		OLD.start_dt,
		OLD.end_dt,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_terms_after_insert
AFTER INSERT ON mst_terms
 FOR EACH ROW
BEGIN
	INSERT INTO mst_terms_h(
		issue_type,
		terms_type,
		version,
		start_dt,
		end_dt,
		content,
		is_use,
		remark
	) VALUES (
		'I',
		NEW.terms_type,
		NEW.version,
		NEW.start_dt,
		NEW.end_dt,
		NEW.content,
		NEW.is_use,
		NEW.remark
	);
END;
//

CREATE TRIGGER mst_terms_after_update
AFTER UPDATE ON mst_terms
 FOR EACH ROW
BEGIN
	INSERT INTO mst_terms_h(
		issue_type,
		terms_type,
		version,
		start_dt,
		end_dt,
		content,
		is_use,
		remark
	) VALUES (
		'U',
		OLD.terms_type,
		OLD.version,
		OLD.start_dt,
		OLD.end_dt,
		OLD.content,
		OLD.is_use,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_terms_before_delete
BEFORE DELETE ON mst_terms
 FOR EACH ROW
BEGIN
	INSERT INTO mst_terms_h(
		issue_type,
		terms_type,
		version,
		start_dt,
		end_dt,
		content,
		is_use,
		remark
	) VALUES (
		'D',
		OLD.terms_type,
		OLD.version,
		OLD.start_dt,
		OLD.end_dt,
		OLD.content,
		OLD.is_use,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_mall_after_insert
AFTER INSERT ON mst_mall
 FOR EACH ROW
BEGIN
	INSERT INTO mst_mall_h(
		issue_type,
		mall_id,
		mall_nm,
		class_cd,
		acc_type,
		group_cd,
		code,
		priority,
		id1_is_use,
		id1_name,
		id2_is_use,
		id2_name,
		id3_is_use,
		id3_name,
		pw1_is_use,
		pw1_name,
		pw2_is_use,
		pw2_name,
		option1_is_use,
		option1_name,
		option2_is_use,
		option2_name,
		login_uri,
		remark
	) VALUES (
		'I',
		NEW.mall_id,
		NEW.mall_nm,
		NEW.class_cd,
		NEW.acc_type,
		NEW.group_cd,
		NEW.code,
		NEW.priority,
		NEW.id1_is_use,
		NEW.id1_name,
		NEW.id2_is_use,
		NEW.id2_name,
		NEW.id3_is_use,
		NEW.id3_name,
		NEW.pw1_is_use,
		NEW.pw1_name,
		NEW.pw2_is_use,
		NEW.pw2_name,
		NEW.option1_is_use,
		NEW.option1_name,
		NEW.option2_is_use,
		NEW.option2_name,
		NEW.login_uri,
		NEW.remark
	);
END;
//

CREATE TRIGGER mst_mall_after_update
AFTER UPDATE ON mst_mall
 FOR EACH ROW
BEGIN
	INSERT INTO mst_mall_h(
		issue_type,
		mall_id,
		mall_nm,
		class_cd,
		acc_type,
		group_cd,
		code,
		priority,
		id1_is_use,
		id1_name,
		id2_is_use,
		id2_name,
		id3_is_use,
		id3_name,
		pw1_is_use,
		pw1_name,
		pw2_is_use,
		pw2_name,
		option1_is_use,
		option1_name,
		option2_is_use,
		option2_name,
		login_uri,
		remark
	) VALUES (
		'U',
		OLD.mall_id,
		OLD.mall_nm,
		OLD.class_cd,
		OLD.acc_type,
		OLD.group_cd,
		OLD.code,
		OLD.priority,
		OLD.id1_is_use,
		OLD.id1_name,
		OLD.id2_is_use,
		OLD.id2_name,
		OLD.id3_is_use,
		OLD.id3_name,
		OLD.pw1_is_use,
		OLD.pw1_name,
		OLD.pw2_is_use,
		OLD.pw2_name,
		OLD.option1_is_use,
		OLD.option1_name,
		OLD.option2_is_use,
		OLD.option2_name,
		OLD.login_uri,
		OLD.remark
	);
END;
//

CREATE TRIGGER mst_mall_before_delete
BEFORE DELETE ON mst_mall
 FOR EACH ROW
BEGIN
	INSERT INTO mst_mall_h(
		issue_type,
		mall_id,
		mall_nm,
		class_cd,
		acc_type,
		group_cd,
		code,
		priority,
		id1_is_use,
		id1_name,
		id2_is_use,
		id2_name,
		id3_is_use,
		id3_name,
		pw1_is_use,
		pw1_name,
		pw2_is_use,
		pw2_name,
		option1_is_use,
		option1_name,
		option2_is_use,
		option2_name,
		login_uri,
		remark
	) VALUES (
		'D',
		OLD.mall_id,
		OLD.mall_nm,
		OLD.class_cd,
		OLD.acc_type,
		OLD.group_cd,
		OLD.code,
		OLD.priority,
		OLD.id1_is_use,
		OLD.id1_name,
		OLD.id2_is_use,
		OLD.id2_name,
		OLD.id3_is_use,
		OLD.id3_name,
		OLD.pw1_is_use,
		OLD.pw1_name,
		OLD.pw2_is_use,
		OLD.pw2_name,
		OLD.option1_is_use,
		OLD.option1_name,
		OLD.option2_is_use,
		OLD.option2_name,
		OLD.login_uri,
		OLD.remark
	);
END;
//

CREATE TRIGGER tsn_member_after_insert
AFTER INSERT ON tsn_member
 FOR EACH ROW
BEGIN
	INSERT INTO tsn_member_h(
		issue_type,
		oidx,
		company_nm,
		group_cd,
		code,
		state_dt,
		state_reason,
		biz_no,
		ceo_nm,
		ceo_phone,
		signup_dt,
		signup_route,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.company_nm,
		NEW.group_cd,
		NEW.code,
		NEW.state_dt,
		NEW.state_reason,
		NEW.biz_no,
		NEW.ceo_nm,
		NEW.ceo_phone,
		NEW.signup_dt,
		NEW.signup_route,
		NEW.remark,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_member_after_update
AFTER UPDATE ON tsn_member
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO tsn_member_h(
			issue_type,
			oidx,
			company_nm,
			group_cd,
			code,
			state_dt,
			state_reason,
			biz_no,
			ceo_nm,
			ceo_phone,
			signup_dt,
			signup_route,
			remark,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD.idx,
			OLD.company_nm,
			OLD.group_cd,
			OLD.code,
			OLD.state_dt,
			OLD.state_reason,
			OLD.biz_no,
			OLD.ceo_nm,
			OLD.ceo_phone,
			OLD.signup_dt,
			OLD.signup_route,
			OLD.remark,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
END;
//

CREATE TRIGGER tsn_member_before_delete
BEFORE DELETE ON tsn_member
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_member_h(
		issue_type,
		oidx,
		company_nm,
		group_cd,
		code,
		state_dt,
		state_reason,
		biz_no,
		ceo_nm,
		ceo_phone,
		signup_dt,
		signup_route,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.company_nm,
		OLD.group_cd,
		OLD.code,
		OLD.state_dt,
		OLD.state_reason,
		OLD.biz_no,
		OLD.ceo_nm,
		OLD.ceo_phone,
		OLD.signup_dt,
		OLD.signup_route,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method
	);
END;
//

CREATE TRIGGER tsn_user_after_insert
AFTER INSERT ON tsn_user
 FOR EACH ROW
BEGIN
	INSERT INTO tsn_user_h(
		issue_type,
		oidx,
		member_id,
		email,
		password,
		group_cd,
		code,
		state_dt,
		state_reason,
		name,
		position,
		role,
		grade,
		pw_change_dt,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.member_id,
		NEW.email,
		NEW.password,
		NEW.group_cd,
		NEW.code,
		NEW.state_dt,
		NEW.state_reason,
		NEW.name,
		NEW.position,
		NEW.role,
		NEW.grade,
		NEW.pw_change_dt,
		NEW.remark,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_user_after_update
AFTER UPDATE ON tsn_user
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO tsn_user_h(
			issue_type,
			oidx,
			member_id,
			email,
			password,
			group_cd,
			code,
			state_dt,
			state_reason,
			name,
			position,
			role,
			grade,
			pw_change_dt,
			remark,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD.idx,
			OLD.member_id,
			OLD.email,
			OLD.password,
			OLD.group_cd,
			OLD.code,
			OLD.state_dt,
			OLD.state_reason,
			OLD.name,
			OLD.position,
			OLD.role,
			OLD.grade,
			OLD.pw_change_dt,
			OLD.remark,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
END;
//

CREATE TRIGGER tsn_user_before_delete
BEFORE DELETE ON tsn_user
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_user_h(
		issue_type,
		oidx,
		member_id,
		email,
		password,
		group_cd,
		code,
		state_dt,
		state_reason,
		name,
		position,
		role,
		grade,
		pw_change_dt,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.member_id,
		OLD.email,
		OLD.password,
		OLD.group_cd,
		OLD.code,
		OLD.state_dt,
		OLD.state_reason,
		OLD.name,
		OLD.position,
		OLD.role,
		OLD.grade,
		OLD.pw_change_dt,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method
	);
END;
//

CREATE TRIGGER tsn_user_auth_after_insert
AFTER INSERT ON tsn_user_auth
 FOR EACH ROW
BEGIN
	INSERT INTO tsn_user_auth_h(
		issue_type,
		oidx,
		auth_id,
		user_id,
		exp_dt,
		location,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.auth_id,
		NEW.user_id,
		NEW.exp_dt,
		NEW.location,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_user_auth_after_update
AFTER UPDATE ON tsn_user_auth
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO user_auth_h(
			issue_type,
			oidx,
			auth_id,
			user_id,
			exp_dt,
			location,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD.idx,
			OLD.auth_id,
			OLD.user_id,
			OLD.exp_dt,
			OLD.location,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
	
END;
//

CREATE TRIGGER tsn_user_auth_before_delete
BEFORE DELETE ON tsn_user_auth
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_user_auth_h(
		issue_type,
		oidx,
		auth_id,
		user_id,
		exp_dt,
		location,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.auth_id,
		OLD.user_id,
		OLD.exp_dt,
		OLD.location,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method
	);
END;
//

CREATE TRIGGER tsn_member_service_after_insert
AFTER INSERT ON tsn_member_service
 FOR EACH ROW
BEGIN
	INSERT INTO tsn_member_service_h(
		issue_type,
		oidx,
		member_id,
		service_id,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.member_id,
		NEW.service_id,
		NEW.remark,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_member_service_after_update
AFTER UPDATE ON tsn_member_service
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO tsn_member_service_h(
			issue_type,
			oidx,
			member_id,
			service_id,
			remark,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD.idx,
			OLD.member_id,
			OLD.service_id,
			OLD.remark,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
	
END;
//

CREATE TRIGGER tsn_member_service_before_delete
BEFORE DELETE ON tsn_member_service
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_member_service_h(
		issue_type,
		oidx,
		member_id,
		service_id,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.member_id,
		OLD.service_id,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method
	);
END;
//

CREATE TRIGGER tsn_member_terms_before_insert
AFTER INSERT ON tsn_member_terms
 FOR EACH ROW
BEGIN
	INSERT INTO member_terms_h(
		issue_type,
		oidx,
		member_id,
		terms_type,
		terms_version,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.member_id,
		NEW.terms_type,
		NEW.terms_version,
		NEW.remark,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_member_terms_after_update
AFTER UPDATE ON tsn_member_terms
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO member_terms_h(
			issue_type,
			oidx,
			member_id,
			terms_type,
			terms_version,
			remark,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD,idx,
			OLD.member_id,
			OLD.terms_type,
			OLD.terms_version,
			OLD.remark,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
	
END;
//

CREATE TRIGGER tsn_member_terms_before_delete
BEFORE DELETE ON tsn_member_terms
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_member_terms_h(
		issue_type,
		oidx,
		member_id,
		terms_type,
		terms_version,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.member_id,
		OLD.terms_type,
		OLD.terms_version,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method);
END;
//

CREATE TRIGGER tsn_member_mall_before_insert
AFTER INSERT ON tsn_member_mall
 FOR EACH ROW
BEGIN
	INSERT INTO tsn_member_mall_h(
		issue_type,
		oidx,
		member_id,
		mall_id,
		id1_value,
		id2_value,
		id3_value,
		pw1_value,
		pw2_value,
		option1_value,
		option2_value,
		last_sc_dt,
		last_sc_state,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		'I',
		NEW.idx,
		NEW.member_id,
		NEW.mall_id,
		NEW.id1_value,
		NEW.id2_value,
		NEW.id3_value,
		NEW.pw1_value,
		NEW.pw2_value,
		NEW.option1_value,
		NEW.option2_value,
		NEW.last_sc_dt,
		NEW.last_sc_state,
		NEW.remark,
		NEW.ix,
		NEW.insert_dt,
		NEW.insert_method,
		NEW.update_dt,
		NEW.update_method
	);
END;
//

CREATE TRIGGER tsn_member_mall_after_update
AFTER UPDATE ON tsn_member_mall
 FOR EACH ROW
BEGIN
	IF NEW.ix != 'X'
	THEN
		INSERT INTO tsn_member_mall_h(
			issue_type,
			oidx,
			member_id,
			mall_id,
			id1_value,
			id2_value,
			id3_value,
			pw1_value,
			pw2_value,
			option1_value,
			option2_value,
			last_sc_dt,
			last_sc_state,
			remark,
			ix,
			insert_dt,
			insert_method,
			update_dt,
			update_method
		) VALUES (
			'U',
			OLD,idx,
			OLD.member_id,
			OLD.mall_id,
			OLD.id1_value,
			OLD.id2_value,
			OLD.id3_value,
			OLD.pw1_value,
			OLD.pw2_value,
			OLD.option1_value,
			OLD.option2_value,
			OLD.last_sc_dt,
			OLD.last_sc_state,
			OLD.remark,
			OLD.ix,
			OLD.insert_dt,
			OLD.insert_method,
			OLD.update_dt,
			OLD.update_method
		);
	END IF;
	
END;
//

CREATE TRIGGER tsn_member_mall_before_delete
BEFORE DELETE ON tsn_member_mall
 FOR EACH ROW
BEGIN
	DECLARE var_issue CHAR(1);
	IF OLD.ix = 'X'
	THEN
		SET var_issue = 'X';
	ELSE
		SET var_issue = 'D';
	END IF;
	INSERT INTO tsn_member_mall_h(
		issue_type,
		oidx,
		member_id,
		mall_id,
		id1_value,
		id2_value,
		id3_value,
		pw1_value,
		pw2_value,
		option1_value,
		option2_value,
		last_sc_dt,
		last_sc_state,
		remark,
		ix,
		insert_dt,
		insert_method,
		update_dt,
		update_method
	) VALUES (
		var_issue,
		OLD.idx,
		OLD.member_id,
		OLD.mall_id,
		OLD.id1_value,
		OLD.id2_value,
		OLD.id3_value,
		OLD.pw1_value,
		OLD.pw2_value,
		OLD.option1_value,
		OLD.option2_value,
		OLD.last_sc_dt,
		OLD.last_sc_state,
		OLD.remark,
		OLD.ix,
		OLD.insert_dt,
		OLD.insert_method,
		OLD.update_dt,
		OLD.update_method
	);
END;
//
delimiter ;
