import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailTest {
	public static void main(String... args) {
		Properties props = new Properties();
		/*props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.host", "smtps.hiworks.com");*/
		props.put("mail.smtp.host", "smtps.hiworks.com");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		props.put("mail.smtp.ssl.enable", "true");
		props.put("mail.smtp.ssl.trust", "smtps.hiworks.com");
		/*props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.quitwait", "false");*/

		Authenticator auth = new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("nowonbun@onlyoneloan.co.kr", "Ghkdtnsduq1");
			}
		};

		Session session = Session.getDefaultInstance(props, auth);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress("nowonbun@onlyoneloan.co.kr"));
			message.setSubject("test");

			message.setRecipient(Message.RecipientType.TO, new InternetAddress("nowonbun@naver.com"));

			/*Multipart mp = new MimeMultipart();
			MimeBodyPart mbp1 = new MimeBodyPart();*/
			/*mbp1.setText("content");
			mp.addBodyPart(mbp1);*/

			//message.setContent(mp);
			message.setText("hello world");

			Transport.send(message);
		} catch (Throwable e) {
			System.out.println(e.toString());
		}
	}
}
