import java.util.List;

import common.FactoryDao;
import dao.CmcodeDao;
import dao.UserDao;
import model.master.Cmcode;
import model.transaction.User;

public class DaoTest {

	public static void main(String... args) {
		FactoryDao.initializeMaster();
		/*List<Cmcode> list = FactoryDao.getDao(CmcodeDao.class).getCmcodeAll();
		for (Cmcode entity : list) {
			System.out.println(entity.getId().getGroupCd() + "  " + entity.getId().getCode());
		}
		List<User> a = FactoryDao.getDao(UserDao.class).findAll();
		User user = FactoryDao.getDao(UserDao.class).getUser("nowonbun@test.com");
		System.out.println(user.getEmail());
		for (User b : a) {
			System.out.println(b);
		}*/
		//System.out.println(System.getProperty("user.dir"));
	}
}
