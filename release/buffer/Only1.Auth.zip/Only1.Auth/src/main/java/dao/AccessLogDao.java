package dao;

import common.TransactionDao;
import model.AccessLog;

public class AccessLogDao extends TransactionDao<AccessLog> {

	protected AccessLogDao() {
		super(AccessLog.class);
	}
}
