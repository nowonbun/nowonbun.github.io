package dao;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.TransactionDao;
import model.Member;

public class MemberDao extends TransactionDao<Member> {

	protected MemberDao() {
		super(Member.class);
	}

	public Member getMemberByBizNo(String bizNo) {
		return transaction((em) -> {
			try {
				String qy = "SELECT m FROM Member m WHERE m.bizNo = :bizNo";
				Query query = em.createQuery(qy);
				query.setParameter("bizNo", bizNo);
				return (Member) query.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		});
	}
}
