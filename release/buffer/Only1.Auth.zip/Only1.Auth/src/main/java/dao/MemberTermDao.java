package dao;

import common.TransactionDao;
import model.MemberTerm;

public class MemberTermDao extends TransactionDao<MemberTerm> {

	protected MemberTermDao() {
		super(MemberTerm.class);
	}
}
