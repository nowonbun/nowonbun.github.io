package dao;

import java.util.List;
import java.util.NoSuchElementException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.MasterDao;
import model.Term;
import model.key.TermPK;

public class TermDao extends MasterDao<Term> {

	protected TermDao() {
		super(Term.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<Term> getDataList() {
		return transaction((em) -> {
			try {
				Query query = em.createNamedQuery("Term.findAll", Term.class);
				return (List<Term>) query.getResultList();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public Term getTerm(TermPK pk) {
		return getTerm(pk.getTermsType(), pk.getVersion());
	}

	public Term getTerm(String termsType, int version) {
		try {
			return getData().stream().filter(x -> x.getId().getTermsType().equals(termsType) && x.getId().getVersion() == version).findFirst().get();
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	public List<Term> getTermAll() {
		return getData();
	}
}
