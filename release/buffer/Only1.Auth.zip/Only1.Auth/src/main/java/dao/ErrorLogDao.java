package dao;

import common.TransactionDao;
import model.transaction.ErrorLog;

public class ErrorLogDao extends TransactionDao<ErrorLog> {

	protected ErrorLogDao() {
		super(ErrorLog.class);
	}
}
