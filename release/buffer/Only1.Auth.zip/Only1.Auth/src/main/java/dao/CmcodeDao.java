package dao;

import java.util.List;
import java.util.NoSuchElementException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.MasterDao;
import model.master.Cmcode;
import model.master.key.CmcodePK;

public class CmcodeDao extends MasterDao<Cmcode> {

	protected CmcodeDao() {
		super(Cmcode.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<Cmcode> getDataList() {
		return transaction((em) -> {
			try {
				Query query = em.createNamedQuery("Cmcode.findAll", Cmcode.class);
				return (List<Cmcode>) query.getResultList();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public Cmcode getCmcode(CmcodePK pk) {
		return getCmcode(pk.getGroupCd(), pk.getCode());
	}

	public Cmcode getCmcode(String groupCd, String code) {
		try {
			return getData().stream().filter(x -> x.getId().getGroupCd().equals(groupCd) && x.getId().getCode().equals(code)).findFirst().get();
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	public List<Cmcode> getCmcodeAll() {
		return getData();
	}
}
