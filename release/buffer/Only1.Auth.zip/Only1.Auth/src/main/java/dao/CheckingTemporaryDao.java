package dao;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.TransactionDao;
import model.CheckingTemporary;

public class CheckingTemporaryDao extends TransactionDao<CheckingTemporary> {

	protected CheckingTemporaryDao() {
		super(CheckingTemporary.class);
	}
	
	public CheckingTemporary getCheckingTemporary(String type, String id) {
		return transaction((em) -> {
			try {
				String qy = "SELECT ct FROM CheckingTemporary ct WHERE ct.target_type=:target_type and ct.id=:id and ct.isCheck=:isCheck";
				Query query = em.createQuery(qy);
				query.setParameter("isCheck", false);
				query.setParameter("target_type", type);
				query.setParameter("id", id);
				return (CheckingTemporary)query.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public int disabledAllType(String type, String id) {
		return transaction((em) -> {
			try {
				String qy = "UPDATE CheckingTemporary SET isCheck=:isCheck WHERE target_type=:target_type and id=:id";
				Query query = em.createQuery(qy);
				query.setParameter("isCheck", true);
				query.setParameter("target_type", type);
				query.setParameter("id", id);
				return query.executeUpdate();

			} catch (NoResultException e) {
				return 0;
			}
		});
	}

}
