package bean;

import java.util.List;

import common.ObjectBean;

public class UserBean extends ObjectBean {
	private String id;
	private String comp;
	private String bizno;
	private String owner;
	private String ownerp;
	private int mallcount;
	private List<MallBean> mall;

	public String getId() {
		return id;
	}

	public void setUid(String id) {
		this.id = id;
	}

	public String getComp() {
		return comp;
	}

	public void setComp(String comp) {
		this.comp = comp;
	}

	public String getBizno() {
		return bizno;
	}

	public void setBizno(String bizno) {
		this.bizno = bizno;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerp() {
		return ownerp;
	}

	public void setOwnerp(String ownerp) {
		this.ownerp = ownerp;
	}

	public int getMallcount() {
		return mallcount;
	}

	public void setMallcount(int mallcount) {
		this.mallcount = mallcount;
	}

	public List<MallBean> getMall() {
		return mall;
	}

	public void setMall(List<MallBean> mall) {
		this.mall = mall;
	}

	public void setId(String id) {
		this.id = id;
	}

}
