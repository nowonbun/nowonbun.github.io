package bean;

import common.ObjectBean;

public class UserBean extends ObjectBean{
	private String uid;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}
}
