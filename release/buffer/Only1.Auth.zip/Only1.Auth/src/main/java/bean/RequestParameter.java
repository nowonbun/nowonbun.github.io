package bean;

public class RequestParameter {
	private String _method;
	private String serviceid;
	private String params;

	public String getMethod() {
		return _method;
	}

	public void setMethod(String _method) {
		this._method = _method;
	}

	public String getServiceid() {
		return serviceid;
	}

	public void setServiceid(String serviceid) {
		this.serviceid = serviceid;
	}

	public String getParams() {
		return params;
	}

	public void setParams(String params) {
		this.params = params;
	}
}
