package common;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import bean.RequestParameter;
import bean.ResponseParameter;
import bean.ResultBean;
import login.ApplyUser;
import login.CheckBizNo;
import login.CheckMailAddress;
import login.GetUserInfo;
import login.Login;
import login.LoginState;
import login.Logout;
import login.SearchUserId;
import login.SendTemporaryPw;
import login.SetPassword;
import login.SetService;
import login.SetUserInfo;

@WebServlet("/platformAPI")
public class Servlet extends IServlet {

	private static final long serialVersionUID = 1L;
	private String method;
	private String serviceid;
	private static Map<String, IServlet> binderFlyweight = null;

	@Override
	public void init() throws ServletException {
		super.init();
		if (binderFlyweight == null) {
			binderFlyweight = new HashMap<>();
			binderFlyweight.put("doLogin", new Login());
			binderFlyweight.put("doLoginState", new LoginState());
			binderFlyweight.put("doLogout", new Logout());
			binderFlyweight.put("doSearchUserId", new SearchUserId());
			binderFlyweight.put("doSendTemporaryPw", new SendTemporaryPw());
			binderFlyweight.put("doCheckMailAddress", new CheckMailAddress());
			binderFlyweight.put("doCheckBizNo", new CheckBizNo());
			binderFlyweight.put("doApplyUser", new ApplyUser());
			binderFlyweight.put("doSetUserInfo", new SetUserInfo());
			binderFlyweight.put("doSetPassword", new SetPassword());
			binderFlyweight.put("doGetUserInfo", new GetUserInfo());
			binderFlyweight.put("doSetService", new SetService());
		}
	}

	@Override
	public boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		this.method = getRequest().getParameter("_method");
		if (Util.StringIsEmptyOrNull(this.method)) {
			setStatus(403);
			return false;
		}
		this.serviceid = getRequest().getParameter("serviceid");
		if (Util.StringIsEmptyOrNull(this.serviceid)) {
			setStatus(403);
			return false;
		}
		reqParam.setMethod(this.method);
		reqParam.setServiceid(this.serviceid);
		reqParam.setParams(getRequest().getParameter("params"));
		if (binderFlyweight.containsKey(this.method)) {
			return binderFlyweight.get(this.method).validate(reqParam, resParam);
		}
		setStatus(403);
		return false;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (!validate(reqParam, resParam)) {
			return;
		}
		IServlet worker = binderFlyweight.get(this.method);
		worker.doWork(getRequest(), getResponse(), reqParam, resParam);
		ResultBean result = new ResultBean();
		result.setResult(JsonConverter.create(resParam));
		String json = JsonConverter.create(result);

		getResponse().setContentType("text/html;charset=UTF-8");
		getResponse().setHeader("Access-Control-Allow-Origin", "*");
		getPrinter().write(json);

	}
}
