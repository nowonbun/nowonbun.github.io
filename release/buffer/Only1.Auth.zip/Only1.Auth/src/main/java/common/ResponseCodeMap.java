package common;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class ResponseCodeMap {
	public static String CODE000 = "000";
	public static String CODE001 = "001";
	public static String CODE002 = "002";
	public static String CODE101 = "101";
	public static String CODE201 = "201";
	public static String CODE202 = "202";
	public static String CODE300 = "300";
	public static String CODE301 = "301";
	public static String CODE400 = "400";
	public static String CODE401 = "401";
	public static String CODE500 = "500";
	public static String CODE501 = "501";
	public static String CODE502 = "502";
	public static String CODE503 = "503";
	public static String CODE504 = "504";
	public static String CODE505 = "505";
	public static String CODE506 = "506";
	public static String CODE507 = "507";
	private static Map<String, String> singletonmap = null;

	public static String getCodeMessage(String code) {
		init();
		return singletonmap.get(code);
	}

	private static void init() {
		if (singletonmap == null) {
			singletonmap = new HashMap<>();
			Field[] fields = ResponseCodeMap.class.getDeclaredFields();
			for (Field field : fields) {
				if (field.getType() != String.class) {
					continue;
				}
				try {
					singletonmap.put((String) field.get(null), PropertyMap.getInstance().getProperty("codemessage", field.getName()));
				} catch (Throwable e) {
					e.printStackTrace();
				}
			}
		}
	}

	private ResponseCodeMap() {

	}
}
