package login;

import java.util.Date;

import javax.servlet.http.Cookie;

import bean.DataBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import model.transaction.AccessLog;
import model.transaction.User;
import model.transaction.UserAuth;

public class LoginState extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		String authId = (String) getSession().getAttribute(SESSION_KEY);
		User userBean = (User) getSession().getAttribute(USER_SESSION_KEY);
		if (authId != null && userBean != null) {
			UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
			if (userAuth != null && userAuth.getUser().getIdx() == userBean.getIdx()) {
				setLoginOk(authId, userAuth.getUser(), reqParam, resParam);
				return;
			}
		}
		Cookie cookie = getCookie(getCookieKey());
		if (cookie != null) {
			authId = cookie.getValue();
			UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
			if (userAuth != null) {
				setLoginOk(authId, userAuth.getUser(), reqParam, resParam);
				return;
			}
		}

		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}
		try {
			authId = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "authid");
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		if (authId == null) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		UserAuth userAuth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(authId);
		if (userAuth == null) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		userBean = userAuth.getUser();
		setLoginOk(authId, userBean, reqParam, resParam);
	}

	private void setLoginOk(String authId, User userBean, RequestParameter reqParam, ResponseParameter resParam) {
		resParam.setCode(ResponseCodeMap.CODE000);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE000));
		DataBean data = new DataBean();
		data.setAuthId(authId);
		resParam.setData(JsonConverter.create(data));

		updateAccessLog(authId, reqParam.getServiceid(), userBean, resParam.getMessage());
		super.setCookie(getCookieKey(), authId);
		getSession().setAttribute(SESSION_KEY, authId);
		getSession().setAttribute(USER_SESSION_KEY, userBean);
	}

	private void updateAccessLog(String authId, String serviceId, User userBean, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setUser(userBean.getIdx());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName());
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
	}
}