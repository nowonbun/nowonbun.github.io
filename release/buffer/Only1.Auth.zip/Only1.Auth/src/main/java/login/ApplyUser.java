package login;

import java.util.ArrayList;
import java.util.Date;
import javax.json.JsonArray;
import bean.ApplyBean;
import bean.ApplyMallBean;
import bean.LoginBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.CheckingTemporaryDao;
import dao.MallDao;
import dao.MemberDao;
import dao.ServiceDao;
import model.CheckingTemporary;
import model.Member;
import model.MemberMall;
import model.MemberService;
import model.User;

public class ApplyUser extends IServlet {

	private static final long serialVersionUID = 1L;

	public static String TemporaryMailCheckCode = "MAIL";
	private static Login loginServlet = null;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		ApplyBean apply = null;
		try {
			apply = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				ApplyBean bean = new ApplyBean();
				bean.setId(JsonConverter.JsonString(obj, "id"));
				bean.setIdCheck("true".equals(JsonConverter.JsonString(obj, "idCheck")));
				bean.setAuth(JsonConverter.JsonString(obj, "auth"));
				bean.setPwd(JsonConverter.JsonString(obj, "pwd"));
				bean.setComp(JsonConverter.JsonString(obj, "comp"));
				bean.setBizno(JsonConverter.JsonString(obj, "bizno"));
				bean.setBiznoCheck("true".equals(JsonConverter.JsonString(obj, "biznoCheck")));
				bean.setOwner(JsonConverter.JsonString(obj, "owner"));
				bean.setOwnerp(JsonConverter.JsonString(obj, "ownerp"));
				bean.setOwnerpCheck("true".equals(JsonConverter.JsonString(obj, "ownerpCheck")));
				bean.setMallcount(JsonConverter.JsonInteger(obj, "mallcount"));
				bean.setMall(new ArrayList<>());
				JsonArray array = obj.getJsonArray("mall");
				for (int i = 0; i < bean.getMallcount(); i++) {
					bean.getMall().add(JsonConverter.parseObject(array.get(i).toString(), (subobj) -> {
						ApplyMallBean sub = new ApplyMallBean();
						sub.setCode(JsonConverter.JsonString(subobj, "code"));
						sub.setId1(JsonConverter.JsonString(subobj, "id1"));
						sub.setId2(JsonConverter.JsonString(subobj, "id2"));
						sub.setId3(JsonConverter.JsonString(subobj, "id3"));
						sub.setPw1(JsonConverter.JsonString(subobj, "pw1"));
						sub.setPw2(JsonConverter.JsonString(subobj, "pw2"));
						sub.setOp1(JsonConverter.JsonString(subobj, "op1"));
						sub.setOp2(JsonConverter.JsonString(subobj, "op2"));
						return sub;
					}));
				}
				return bean;
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}

		if (!apply.isIdCheck()) {
			resParam.setCode(ResponseCodeMap.CODE501);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE501));
			return;
		}
		CheckingTemporary temp = FactoryDao.getDao(CheckingTemporaryDao.class).getCheckingTemporary(CheckMailAddress.TemporaryMailCheckCode, apply.getId());
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(CheckMailAddress.TemporaryMailCheckCode, apply.getId());
		if (!Util.StringEquals(temp.getValue(), apply.getAuth())) {
			resParam.setCode(ResponseCodeMap.CODE504);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE504));
			return;
		}
		if (!apply.isOwnerpCheck()) {
			resParam.setCode(ResponseCodeMap.CODE502);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE502));
			return;
		}
		if (!apply.isBiznoCheck()) {
			resParam.setCode(ResponseCodeMap.CODE503);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE503));
			return;
		}
		temp = FactoryDao.getDao(CheckingTemporaryDao.class).getCheckingTemporary(CheckBizNo.TemporaryBIZNOCheckCode, apply.getId());
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(CheckBizNo.TemporaryBIZNOCheckCode, apply.getId());
		if (!Util.StringEquals(temp.getValue(), apply.getBizno())) {
			resParam.setCode(ResponseCodeMap.CODE504);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE504));
			return;
		}
		try {
			Member member = new Member();
			member.setCompanyNm(apply.getComp());
			member.setState("10");
			member.setStateDt(new Date());
			member.setBizNo(apply.getBizno());
			member.setCeoNm(apply.getOwner());
			member.setCeoPhone(apply.getOwnerp());
			member.setSignupDt(new Date());
			member.setSignupRoute("");
			member.setInsertDt(new Date());
			member.setInsertMethod(getClass().getName());
			member.setUpdateDt(new Date());
			member.setUpdateMethod(getClass().getName());

			member.setUsers(new User());
			member.getUser().setEmail(apply.getId());
			member.getUser().setPassword(Util.convertMD5(apply.getPwd()));
			member.getUser().setState("10");
			member.getUser().setStateDt(new Date());
			member.getUser().setInsertDt(new Date());
			member.getUser().setInsertMethod(getClass().getName());
			member.getUser().setUpdateDt(new Date());
			member.getUser().setUpdateMethod(getClass().getName());
			member.getUser().setPwChangeDt(new Date());
			member.getUser().setMemberBean(member);

			member.setMemberMalls(new ArrayList<>());
			for (ApplyMallBean bean : apply.getMall()) {
				MemberMall mall = new MemberMall();
				mall.setMall(FactoryDao.getDao(MallDao.class).getTerm(bean.getCode()));
				mall.setId1Value(bean.getId1());
				mall.setId2Value(bean.getId2());
				mall.setId3Value(bean.getId3());
				mall.setPw1Value(bean.getPw1());
				mall.setPw2Value(bean.getPw2());
				mall.setOption1Value(bean.getOp1());
				mall.setOption2Value(bean.getOp2());
				mall.setInsertDt(new Date());
				mall.setInsertMethod(getClass().getName());
				mall.setUpdateDt(new Date());
				mall.setUpdateMethod(getClass().getName());
				member.addMemberMall(mall);
			}

			member.setMemberServices(new ArrayList<>());
			MemberService service = new MemberService();
			service.setService(FactoryDao.getDao(ServiceDao.class).getService(reqParam.getServiceid()));
			service.setInsertDt(new Date());
			service.setInsertMethod(getClass().getName());
			service.setUpdateDt(new Date());
			service.setUpdateMethod(getClass().getName());
			member.addMemberService(service);

			FactoryDao.getDao(MemberDao.class).create(member);
			LoginBean login = new LoginBean();
			login.setId(member.getUser().getEmail());
			login.setMd5(member.getUser().getPassword());
			reqParam.setParams(JsonConverter.create(login));
			if (loginServlet == null) {
				loginServlet = new Login();
			}
			loginServlet.doWork(getRequest(), getResponse(), reqParam, resParam);

			resParam.setCode(ResponseCodeMap.CODE500);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE500));
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
	}

}
