package login;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import bean.DataBean;
import bean.LoginBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import dao.UserDao;
import model.transaction.AccessLog;
import model.transaction.MemberService;
import model.transaction.User;
import model.transaction.UserAuth;

public class Login extends IServlet {
	private static final long serialVersionUID = 1L;
	private LoginBean login = null;

	public Login() {
		super();
	}

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null) {
			super.setStatus(403);
			return false;
		}
		login = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			LoginBean ret = new LoginBean();
			ret.setId(JsonConverter.JsonString(obj, "id"));
			ret.setPw(JsonConverter.JsonString(obj, "pw"));
			ret.setMd5(JsonConverter.JsonString(obj, "md5"));
			return ret;
		});
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		resParam.setCode(ResponseCodeMap.CODE001);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {

		String pw = login.getMd5();
		if (pw == null) {
			pw = Util.convertMD5(login.getPw());
		}
		User user = validateLogin(login.getId(), pw, reqParam.getServiceid());
		if (user == null) {
			resParam.setCode(ResponseCodeMap.CODE001);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE001));
			return;
		}

		String authId = Util.createCookieKey();
		resParam.setCode(ResponseCodeMap.CODE000);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE000));

		updateUserAuth(authId, user);
		updateAccessLog(authId, reqParam.getServiceid(), user, resParam.getMessage());

		super.setCookie(getCookieKey(), authId);
		getSession().setAttribute(SESSION_KEY, authId);
		getSession().setAttribute(USER_SESSION_KEY, user);

		DataBean data = new DataBean();
		data.setAuthId(authId);
		resParam.setData(JsonConverter.create(data));
	}

	private void updateUserAuth(String authId, User user) {
		UserAuth userAuth = new UserAuth();
		userAuth.setAuthId(authId);
		userAuth.setUser(user);

		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(Calendar.DATE, 1);
		userAuth.setExpDt(c.getTime());

		userAuth.setLocation(getRequest().getRemoteHost());
		userAuth.setInsertDt(new Date());
		userAuth.setInsertMethod(getClass().getName());
		userAuth.setUpdateDt(new Date());
		userAuth.setUpdateMethod(getClass().getName());
		FactoryDao.getDao(UserAuthDao.class).update(userAuth);
	}

	private void updateAccessLog(String authId, String serviceId, User userBean, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setUser(userBean.getIdx());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName());
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
	}

	private User validateLogin(String id, String pw, String serviceId) {
		if (id == null || pw == null) {
			return null;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(id);
		if (user == null) {
			return null;
		}
		if (!Util.StringEquals(user.getPassword().toUpperCase(), pw.toUpperCase())) {
			return null;
		}
		if (!checkService(user.getMember().getMemberServices(), serviceId)) {
			return null;
		}
		return user;
	}

	private boolean checkService(List<MemberService> list, String serviceId) {
		for (MemberService service : list) {
			if (Util.StringEquals(service.getService().getServiceId().toUpperCase(), serviceId.toUpperCase())) {
				return true;
			}
		}
		return false;
	}
}
