package login;

import java.util.Date;

import javax.servlet.http.Cookie;

import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.AccessLogDao;
import dao.UserAuthDao;
import model.transaction.AccessLog;

public class Logout extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {

	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {

		resParam.setCode(ResponseCodeMap.CODE002);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE002));

		String authId = (String) getSession().getAttribute(SESSION_KEY);
		if (authId != null) {
			getSession().removeAttribute(SESSION_KEY);
			getSession().removeAttribute(USER_SESSION_KEY);
			if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
				updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
			}
		}
		Cookie cookie = getCookie(getCookieKey());
		if (cookie != null) {
			authId = cookie.getValue();
			deleteCookie(getCookieKey());
			if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
				updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
			}
		}
		if (reqParam.getParams() != null && !Util.StringIsEmptyOrNull(reqParam.getParams())) {
			try {
				authId = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
					return JsonConverter.JsonString(obj, "authid");
				});
				if (FactoryDao.getDao(UserAuthDao.class).updateDelete(authId, getClass().getName()) > 0) {
					updateAccessLog(authId, reqParam.getServiceid(), resParam.getMessage());
				}
			} catch (Throwable e) {

			}
		}
		redirect("./?service=" + reqParam.getServiceid());
	}

	private void updateAccessLog(String authId, String serviceId, String message) {
		AccessLog logBean = new AccessLog();
		logBean.setServiceId(serviceId);
		logBean.setIsAccepted(true);
		logBean.setAccessMsg(message);
		logBean.setIp(getRequest().getRemoteHost());
		logBean.setAuthId(authId);
		logBean.setInsertDt(new Date());
		logBean.setInsertMethod(getClass().getName() + ".doMain");
		FactoryDao.getDao(AccessLogDao.class).update(logBean);
	}

}
