package login;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.MailSender;
import common.ResponseCodeMap;
import common.Util;
import dao.UserDao;
import model.User;

public class SendTemporaryPw extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		String tpid = null;
		try {
			tpid = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "tpid");
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(tpid);
		if (user == null) {
			resParam.setCode(ResponseCodeMap.CODE300);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE300));
			return;
		}
		String email = user.getEmail();
		String temp = getTemporaryPassword();
		user.setPassword(Util.convertMD5(temp));
		FactoryDao.getDao(UserDao.class).update(user);
		MailSender.Send(email, "임시 패스워드 발급", getMailTemplate().replace("##password##", temp));

		String prefix = email.substring(0, email.indexOf("@"));
		String suffix = email.substring(email.indexOf("@"), email.length());
		if (prefix.length() > 3) {
			prefix = prefix.substring(0, 3) + "*******";
		}
		resParam.setCode(ResponseCodeMap.CODE300);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE300));
		resParam.setData(prefix + suffix);
	}

	private String getTemporaryPassword() {
		return Util.createCookieKey().substring(0, 8);
	}

	private String getMailTemplate() {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		URL url = cl.getResource("Password.html");
		File file = new File(url.getFile());
		byte[] buffer = new byte[(int) file.length()];
		try (InputStream stream = url.openStream()) {
			stream.read(buffer, 0, buffer.length);
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
		return new String(buffer);
	}
}