package login;

import bean.ApplyBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.UserAuthDao;
import dao.UserDao;
import model.transaction.User;
import model.transaction.UserAuth;

public class SetPassword extends IServlet {
	private static final long serialVersionUID = 1L;
	private ApplyBean apply = null;

	@Override
	protected boolean validate(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return false;
		}
		apply = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
			ApplyBean bean = new ApplyBean();
			bean.setAuth(JsonConverter.JsonString(obj, "authid"));
			bean.setPwd(JsonConverter.JsonString(obj, "pwd"));
			return bean;
		});
		return true;
	}

	@Override
	public void error(RequestParameter reqParam, ResponseParameter resParam, Throwable e) {
		resParam.setCode(ResponseCodeMap.CODE201);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		UserAuth auth = FactoryDao.getDao(UserAuthDao.class).getUserAuthById(apply.getAuth());
		if (auth == null) {
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return;
		}
		User user = auth.getUser();
		user.setPassword(Util.convertMD5(apply.getPwd()));
		FactoryDao.getDao(UserDao.class).update(user);
		resParam.setCode(ResponseCodeMap.CODE506);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE506));
	}
}
