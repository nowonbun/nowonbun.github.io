package login;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;

import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.MailSender;
import common.ResponseCodeMap;
import common.Util;
import dao.CheckingTemporaryDao;
import dao.UserDao;
import model.CheckingTemporary;
import model.User;

public class CheckMailAddress extends IServlet {

	private static final long serialVersionUID = 1L;

	public static String TemporaryMailCheckCode = "MAIL";

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		String mailaddress = null;
		try {
			mailaddress = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				return JsonConverter.JsonString(obj, "mailaddress");
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(mailaddress);
		if (user != null) {
			resParam.setCode(ResponseCodeMap.CODE301);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE301));
			return;
		}
		String temp = getTemporaryAuth();
		MailSender.Send(mailaddress, "메일 인증 정보", getMailTemplate().replace("##TemporaryAuthCode##", temp));
		getTemporary(mailaddress, temp);

		resParam.setCode(ResponseCodeMap.CODE300);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE300));
	}

	private String getTemporaryAuth() {
		return Util.createCookieKey();
	}

	private CheckingTemporary getTemporary(String id, String code) {
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(TemporaryMailCheckCode, id);
		CheckingTemporary ret = new CheckingTemporary();
		ret.setType(TemporaryMailCheckCode);
		ret.setId(id);
		ret.setData(id);
		ret.setValue(code);
		ret.setIsCheck(false);
		ret.setUpdateDt(new Date());
		FactoryDao.getDao(CheckingTemporaryDao.class).update(ret);
		return ret;
	}

	private String getMailTemplate() {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		URL url = cl.getResource("CheckMail.html");
		File file = new File(url.getFile());
		byte[] buffer = new byte[(int) file.length()];
		try (InputStream stream = url.openStream()) {
			stream.read(buffer, 0, buffer.length);
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
		return new String(buffer);
	}
}