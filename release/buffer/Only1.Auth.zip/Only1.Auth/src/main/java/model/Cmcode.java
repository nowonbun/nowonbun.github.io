package model;

import java.io.Serializable;
import javax.persistence.*;
import model.key.CmcodePK;
import java.util.Date;

@Entity
@NamedQuery(name = "Cmcode.findAll", query = "SELECT c FROM Cmcode c")
public class Cmcode implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CmcodePK id;

	@Column(name = "attribute_int")
	private int attributeInt;

	@Column(name = "attribute_str")
	private String attributeStr;

	private String description;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	@Column(name = "is_use")
	private boolean isUse;

	private String ix;

	@Column(name = "p_code")
	private String pCode;

	@Column(name = "p_group_cd")
	private String pGroupCd;

	private int priority;

	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	private String value;

	public Cmcode() {
	}

	public CmcodePK getId() {
		return this.id;
	}

	public void setId(CmcodePK id) {
		this.id = id;
	}

	public int getAttributeInt() {
		return this.attributeInt;
	}

	public void setAttributeInt(int attributeInt) {
		this.attributeInt = attributeInt;
	}

	public String getAttributeStr() {
		return this.attributeStr;
	}

	public void setAttributeStr(String attributeStr) {
		this.attributeStr = attributeStr;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getPCode() {
		return this.pCode;
	}

	public void setPCode(String pCode) {
		this.pCode = pCode;
	}

	public String getPGroupCd() {
		return this.pGroupCd;
	}

	public void setPGroupCd(String pGroupCd) {
		this.pGroupCd = pGroupCd;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}