package model.master.key;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class CmcodePK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name="group_cd")
	private String groupCd;

	private String code;

	public CmcodePK() {
	}
	public String getGroupCd() {
		return this.groupCd;
	}
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	public String getCode() {
		return this.code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CmcodePK)) {
			return false;
		}
		CmcodePK castOther = (CmcodePK)other;
		return 
			this.groupCd.equals(castOther.groupCd)
			&& this.code.equals(castOther.code);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.groupCd.hashCode();
		hash = hash * prime + this.code.hashCode();
		
		return hash;
	}
}