package model.master;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;
import model.master.key.CmcodePK;
import model.transaction.Member;
import model.transaction.User;

@Entity
@Table(name = "mst_cmcode")
@NamedQuery(name = "Cmcode.findAll", query = "SELECT c FROM Cmcode c")
public class Cmcode implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CmcodePK id;

	@Column(name = "attribute_int")
	private int attributeInt;

	@Column(name = "attribute_str")
	private String attributeStr;

	private String description;

	@Column(name = "is_use")
	private boolean isUse;

	@Column(name = "p_code")
	private String pCode;

	@Column(name = "p_group_cd")
	private String pGroupCd;

	private int priority;

	private String remark;

	private String value;

	@OneToMany(mappedBy = "cmcode")
	private List<Mall> malls;

	@OneToMany(mappedBy = "cmcode")
	private List<Member> members;

	@OneToMany(mappedBy = "cmcode")
	private List<User> users;

	public Cmcode() {
	}

	public CmcodePK getId() {
		return this.id;
	}

	public void setId(CmcodePK id) {
		this.id = id;
	}

	public int getAttributeInt() {
		return this.attributeInt;
	}

	public void setAttributeInt(int attributeInt) {
		this.attributeInt = attributeInt;
	}

	public String getAttributeStr() {
		return this.attributeStr;
	}

	public void setAttributeStr(String attributeStr) {
		this.attributeStr = attributeStr;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getPCode() {
		return this.pCode;
	}

	public void setPCode(String pCode) {
		this.pCode = pCode;
	}

	public String getPGroupCd() {
		return this.pGroupCd;
	}

	public void setPGroupCd(String pGroupCd) {
		this.pGroupCd = pGroupCd;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<Mall> getMalls() {
		return this.malls;
	}

	public void setMalls(List<Mall> malls) {
		this.malls = malls;
	}

	public Mall addMall(Mall mall) {
		getMalls().add(mall);
		mall.setCmcode(this);

		return mall;
	}

	public Mall removeMstMall(Mall mall) {
		getMalls().remove(mall);
		mall.setCmcode(null);

		return mall;
	}

	public List<Member> getMembers() {
		return this.members;
	}

	public void setMembers(List<Member> members) {
		this.members = members;
	}

	public Member addMember(Member member) {
		getMembers().add(member);
		member.setCmcode(this);

		return member;
	}

	public Member removeMember(Member member) {
		getMembers().remove(member);
		member.setCmcode(null);

		return member;
	}

	public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public User addUser(User user) {
		getUsers().add(user);
		user.setCmcode(this);

		return user;
	}

	public User removeUser(User user) {
		getUsers().remove(user);
		user.setCmcode(null);

		return user;
	}
}