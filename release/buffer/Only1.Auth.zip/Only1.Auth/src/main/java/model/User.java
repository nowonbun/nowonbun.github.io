package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@NamedQuery(name = "User.findAll", query = "SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;

	private String email;

	private String grade;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	private String ix;

	private String name;

	private String password;

	private String position;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "pw_change_dt")
	private Date pwChangeDt;

	private String remark;

	private String role;

	private String state;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "state_dt")
	private Date stateDt;

	@Column(name = "state_reason")
	private String stateReason;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	@OneToOne(cascade = CascadeType.ALL, targetEntity = Member.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "member")
	private Member memberBean;

	@OneToMany(mappedBy = "userBean", cascade = CascadeType.ALL, targetEntity = UserAuth.class, fetch = FetchType.LAZY)
	private List<UserAuth> userAuths;

	public User() {
	}

	public int getIdx() {
		return this.idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGrade() {
		return this.grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public Date getPwChangeDt() {
		return this.pwChangeDt;
	}

	public void setPwChangeDt(Date pwChangeDt) {
		this.pwChangeDt = pwChangeDt;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getStateDt() {
		return this.stateDt;
	}

	public void setStateDt(Date stateDt) {
		this.stateDt = stateDt;
	}

	public String getStateReason() {
		return this.stateReason;
	}

	public void setStateReason(String stateReason) {
		this.stateReason = stateReason;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public Member getMemberBean() {
		return this.memberBean;
	}

	public void setMemberBean(Member memberBean) {
		this.memberBean = memberBean;
	}

	public List<UserAuth> getUserAuths() {
		return this.userAuths;
	}

	public void setUserAuths(List<UserAuth> userAuths) {
		this.userAuths = userAuths;
	}

	public UserAuth addUserAuth(UserAuth userAuth) {
		getUserAuths().add(userAuth);
		userAuth.setUserBean(this);

		return userAuth;
	}

	public UserAuth removeUserAuth(UserAuth userAuth) {
		getUserAuths().remove(userAuth);
		userAuth.setUserBean(null);

		return userAuth;
	}

}