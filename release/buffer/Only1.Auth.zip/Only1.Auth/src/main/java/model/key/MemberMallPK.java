package model.key;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class MemberMallPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false)
	private int member;

	@Column(name="mall_id", insertable=false, updatable=false)
	private String mallId;

	public MemberMallPK() {
	}
	public int getMember() {
		return this.member;
	}
	public void setMember(int member) {
		this.member = member;
	}
	public String getMallId() {
		return this.mallId;
	}
	public void setMallId(String mallId) {
		this.mallId = mallId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MemberMallPK)) {
			return false;
		}
		MemberMallPK castOther = (MemberMallPK)other;
		return 
			(this.member == castOther.member)
			&& this.mallId.equals(castOther.mallId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.member;
		hash = hash * prime + this.mallId.hashCode();
		
		return hash;
	}
}