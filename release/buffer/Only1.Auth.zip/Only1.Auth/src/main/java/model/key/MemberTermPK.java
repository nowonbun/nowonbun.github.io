package model.key;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the member_terms database table.
 * 
 */
@Embeddable
public class MemberTermPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false)
	private int member;

	@Column(name="terms_type", insertable=false, updatable=false)
	private String termsType;

	@Column(name="terms_version", insertable=false, updatable=false)
	private int termsVersion;

	public MemberTermPK() {
	}
	public int getMember() {
		return this.member;
	}
	public void setMember(int member) {
		this.member = member;
	}
	public String getTermsType() {
		return this.termsType;
	}
	public void setTermsType(String termsType) {
		this.termsType = termsType;
	}
	public int getTermsVersion() {
		return this.termsVersion;
	}
	public void setTermsVersion(int termsVersion) {
		this.termsVersion = termsVersion;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MemberTermPK)) {
			return false;
		}
		MemberTermPK castOther = (MemberTermPK)other;
		return 
			(this.member == castOther.member)
			&& this.termsType.equals(castOther.termsType)
			&& (this.termsVersion == castOther.termsVersion);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.member;
		hash = hash * prime + this.termsType.hashCode();
		hash = hash * prime + this.termsVersion;
		
		return hash;
	}
}