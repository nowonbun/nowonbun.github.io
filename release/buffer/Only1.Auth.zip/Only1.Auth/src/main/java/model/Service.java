package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@NamedQuery(name = "Service.findAll", query = "SELECT s FROM Service s")
public class Service implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "service_id")
	private String serviceId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_dt")
	private Date endDt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	@Column(name = "is_use")
	private boolean isUse;

	private String ix;

	private String remark;

	@Column(name = "service_nm")
	private String serviceNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_dt")
	private Date startDt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	private String redirect_url;

	@OneToMany(mappedBy = "service", fetch = FetchType.LAZY)
	private List<MemberService> memberServices;

	public Service() {
	}

	public String getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getServiceNm() {
		return this.serviceNm;
	}

	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public List<MemberService> getMemberServices() {
		return this.memberServices;
	}

	public void setMemberServices(List<MemberService> memberServices) {
		this.memberServices = memberServices;
	}

	public MemberService addMemberService(MemberService memberService) {
		getMemberServices().add(memberService);
		memberService.setService(this);

		return memberService;
	}

	public MemberService removeMemberService(MemberService memberService) {
		getMemberServices().remove(memberService);
		memberService.setService(null);

		return memberService;
	}

	public String getRedirect_url() {
		return redirect_url;
	}

	public void setRedirect_url(String redirect_url) {
		this.redirect_url = redirect_url;
	}

}