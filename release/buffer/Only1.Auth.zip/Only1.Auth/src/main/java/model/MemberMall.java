package model;

import java.io.Serializable;
import javax.persistence.*;
import model.key.MemberMallPK;
import java.util.Date;

@Entity
@Table(name = "member_mall")
@NamedQuery(name = "MemberMall.findAll", query = "SELECT m FROM MemberMall m")
public class MemberMall implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MemberMallPK id;

	@Column(name = "id1_value")
	private String id1Value;

	@Column(name = "id2_value")
	private String id2Value;

	@Column(name = "id3_value")
	private String id3Value;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	private String ix;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_sc_dt")
	private Date lastScDt;

	@Column(name = "last_sc_state")
	private String lastScState;

	@Column(name = "option1_value")
	private String option1Value;

	@Column(name = "option2_value")
	private String option2Value;

	@Column(name = "pw1_value")
	private String pw1Value;

	@Column(name = "pw2_value")
	private String pw2Value;

	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "member")
	private Member memberBean;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mall_id")
	private Mall mall;

	public MemberMall() {
	}

	public MemberMallPK getId() {
		return this.id;
	}

	public void setId(MemberMallPK id) {
		this.id = id;
	}

	public String getId1Value() {
		return this.id1Value;
	}

	public void setId1Value(String id1Value) {
		this.id1Value = id1Value;
	}

	public String getId2Value() {
		return this.id2Value;
	}

	public void setId2Value(String id2Value) {
		this.id2Value = id2Value;
	}

	public String getId3Value() {
		return this.id3Value;
	}

	public void setId3Value(String id3Value) {
		this.id3Value = id3Value;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public Date getLastScDt() {
		return this.lastScDt;
	}

	public void setLastScDt(Date lastScDt) {
		this.lastScDt = lastScDt;
	}

	public String getLastScState() {
		return this.lastScState;
	}

	public void setLastScState(String lastScState) {
		this.lastScState = lastScState;
	}

	public String getOption1Value() {
		return this.option1Value;
	}

	public void setOption1Value(String option1Value) {
		this.option1Value = option1Value;
	}

	public String getOption2Value() {
		return this.option2Value;
	}

	public void setOption2Value(String option2Value) {
		this.option2Value = option2Value;
	}

	public String getPw1Value() {
		return this.pw1Value;
	}

	public void setPw1Value(String pw1Value) {
		this.pw1Value = pw1Value;
	}

	public String getPw2Value() {
		return this.pw2Value;
	}

	public void setPw2Value(String pw2Value) {
		this.pw2Value = pw2Value;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public Member getMemberBean() {
		return this.memberBean;
	}

	public void setMemberBean(Member memberBean) {
		this.memberBean = memberBean;
	}

	public Mall getMall() {
		return this.mall;
	}

	public void setMall(Mall mall) {
		this.mall = mall;
	}


}