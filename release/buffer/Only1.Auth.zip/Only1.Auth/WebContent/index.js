var _ = (function(obj) {
	$(obj.onLoad);
	$(obj.eventAttach);
	return obj;
})({
	mailregex : /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i,
	passwordregex : /^.*(?=^.{8,15}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/,
	numregex : /^[0-9]*$/,
	onLoad : function() {
		var service = _.getParam("service");
		if (service === undefined || service === null || $.trim(service) === "") {
			$("#serviceErrorMessage").modal();
			return;
		}
		$("#serviceid").val(service);
		$("#method").val("doLoginState");
		_.ajax(function(data) {
			var node = JSON.parse(data.result);
			if (node.code === "000") {
				var subNode = JSON.parse(node.data);
				location.href = subNode.redirectUrl + "?authId=" + subNode.authId;
				return;
			}
			$("#pid").prop("disabled", false);
			$("#pwd").prop("disabled", false);
			$("#loginBtn").removeClass("disabled");
		});
		$.ajax({
			url : "GetMallSelection",
			type : "GET",
			success : function(data, textStatus, jqXHR) {
				$("#selectarea").html(data);
				$('.mall-select').material_select();
			}
		});

	},
	eventAttach : function() {
		$(document).on("click", "#loginBtn", function() {
			if ($.trim($("#pid").val()) === "") {
				toastr.warning("ID(메일주소)를 입력해 주십시오.");
				return;
			}
			if ($.trim($("#pwd").val()) === "") {
				toastr.warning("패스워드를 입력해 주십시오.");
				return;
			}
			$("#method").val("doLogin");
			$("#params").val(JSON.stringify({
				id : $("#pid").val(),
				pw : $("#pwd").val()
			}));
			_.ajax(function(data) {
				var node = JSON.parse(data.result);
				if (node.code === "000") {
					var subNode = JSON.parse(node.data);
					location.href = subNode.redirectUrl + "?authId=" + subNode.authId;
					return;
				}
				toastr.error(node.message);
				$("#pwd").val("");
			});
		});

		$(document).on("click", "#searchBizNo", function() {
			if ($.trim($("#bizNo").val()) === "") {
				toastr.warning("사업자 번호를 입력해 주십시오.");
				return;
			}
			$("#method").val("doSearchUserId");
			$("#params").val(JSON.stringify({
				bizNo : $("#bizNo").val()
			}));
			_.ajax(function(data) {
				var node = JSON.parse(data.result);
				if (node.code === "101") {
					$("#resultId").text(node.data);
					$("#searchID").modal("hide");
					$('body').removeClass('modal-open');
					$('.modal-backdrop').remove();
					$("#searchResultID").modal("show");
					return;
				}
				toastr.warning(node.message);
			});
		});
		$(document).on("click", "#searchIdBtn", function() {
			$("#searchID").modal("show");
		});
		$(document).on("click", "#tpPwBtn", function() {
			$("#temporaryPW").modal("show");
		});

		$(document).on("click", "#tpPwOk", function() {
			if ($.trim($("#tpid").val()) === "") {
				toastr.warning("ID(메일주소)를 입력해 주십시오.");
				return;
			}
			$("#method").val("doSendTemporaryPw");
			$("#params").val(JSON.stringify({
				tpid : $("#tpid").val()
			}));
			_.ajax(function(data) {
				var node = JSON.parse(data.result);
				if (node.code === "300") {
					$("#temporaryPW").modal("hide");
					$('body').removeClass('modal-open');
					$('.modal-backdrop').remove();
					$("#temporaryPWResult").modal("show");
					return;
				}
				toastr.warning(node.message);
			});
		});

		$(document).on("click", "#applicationFormBtn", function() {
			$("#applicationForm").modal("show");
		});
		$(document).on("click", "#addMall", function() {
			var code = $(".mall-select select").val();
			if (code == null || code == undefined) {
				return;
			}
			var option = $(".mall-select select>option[value=" + code + "]");
			var num = $(".mall-row").length;
			var row = $("<div></div>").addClass("row justify-content-md-center mall-row");
			var col1 = $("<div></div>").addClass("col-3 mall-node-name").append($("<label>").text(option.data("text-name")));
			var col2 = $("<div></div>").addClass("col-6");
			row = row.append(col1);
			function createSubCol(is, id, clazz, name, iptype) {
				if (option.data(is)) {
					col2 = col2.append(_.createTextBox(id, clazz, name, iptype));
				}
			}
			row = row.append(col2);
			var col3 = $("<div></div>").addClass("col-2").append($("<button>").addClass("btn btn-danger btn-sm my-0 ml-3 waves-effect waves-light one-app-btn mall-delete-btn").text("삭제"));
			row = row.append(col3);
			col2 = col2.append($("<input type=hidden>").prop("id", "code" + num).addClass("code").val(option.val()));
			createSubCol("id1use", "id1" + num, "id1", option.data("id1nm"), "text");
			createSubCol("id2use", "id2" + num, "id2", option.data("id2nm"), "text");
			createSubCol("id3use", "id3" + num, "id3", option.data("id3nm"), "text");
			createSubCol("pw1use", "pw1" + num, "pw1", option.data("pw1nm"), "password");
			createSubCol("pw2use", "pw2" + num, "pw2", option.data("pw2nm"), "password");
			createSubCol("op1use", "op1" + num, "op1", option.data("op1nm"), "text");
			createSubCol("op2use", "op2" + num, "op2", option.data("op2nm"), "text");
			$(".mall-child").append(row);
		});
		$(document).on("click", "#applyUser", function() {
			var data = {};
			if ($.trim($("#cid").val()) === "") {
				toastr.warning("ID(메일주소)를 입력해 주십시오.");
				return;
			}
			data.id = $.trim($("#cid").val());

			if ($.trim($("#cidCheck").val()) === "") {
				toastr.warning("인증 요청해 주십시오.");
				return;
			}
			data.idCheck = $.trim($("#cidCheck").val());

			if ($.trim($("#cauth").val()) === "") {
				toastr.warning("인증번호를 입력해 주십시오.");
				return;
			}
			data.auth = $.trim($("#cauth").val());

			if ($.trim($("#cpwd").val()) === "") {
				toastr.warning("패스워드를 입력해 주십시오.");
				return;
			}
			data.pwd = $.trim($("#cpwd").val());

			if (!_.passwordregex.test($("#cpwd").val())) {
				toastr.warning("영문자,숫자,득수문자 조합 8-20자리로 입력해 주십시오.");
				return;
			}

			if (!checkPassword()) {
				toastr.warning("패스워드가 일치하지 않습니다.");
				return;
			}

			if ($.trim($("#ccomp").val()) === "") {
				toastr.warning("회사명을 입력해 주십시오.");
				return;
			}
			data.comp = $.trim($("#ccomp").val());

			if ($.trim($("#cbizno").val()) === "") {
				toastr.warning("사업자등록번호을 입력해 주십시오.");
				return;
			}
			data.bizno = $.trim($("#cbizno").val());

			if ($.trim($("#cbiznoCheck").val()) === "") {
				toastr.warning("중복확인을 해 주십시오.");
				return;
			}
			data.biznoCheck = $.trim($("#cbiznoCheck").val());

			if ($.trim($("#cowner").val()) === "") {
				toastr.warning("대표자명을 입력해 주십시오.");
				return;
			}
			data.owner = $.trim($("#cowner").val());

			if ($.trim($("#cownerp").val()) === "") {
				toastr.warning("휴대폰번호를 입력해 주십시오.");
				return;
			}
			data.ownerp = $.trim($("#cownerp").val());

			if ($.trim($("#cownerpCheck").val()) === "") {
				// toastr.warning("본인인증을 해 주십시오.");
				// return;
			}
			data.ownerpCheck = "true";// $.trim($("#cownerpCheck").val());

			data.mallcount = $(".mall-row").length;
			data.mall = [];
			var mallcheck = true;
			function checkmall($this) {
				if ($this.length === 0) {
					return null;
				}
				if (mallcheck && $.trim($this.val()) === "") {
					var mallnm = $this.parent().parent().parent().parent().parent().find(".mall-node-name").find("label").text();
					var colnm = $this.parent().parent().parent().find(".oneId-app-label").text();
					toastr.warning(mallnm + " " + colnm + "을(를) 입력해 주십시오.");
					mallcheck = false
					return null;
				}
				return $.trim($this.val());
			}
			$(".mall-row").each(function() {
				var mallinfo = {};
				mallinfo.code = $(this).find(".code").val();
				mallinfo.id1 = checkmall($(this).find(".id1"));
				mallinfo.id2 = checkmall($(this).find(".id2"));
				mallinfo.id3 = checkmall($(this).find(".id3"));
				mallinfo.pw1 = checkmall($(this).find(".pw1"));
				mallinfo.pw2 = checkmall($(this).find(".pw2"));
				mallinfo.op1 = checkmall($(this).find(".op1"));
				mallinfo.op2 = checkmall($(this).find(".op2"));
				data.mall.push(mallinfo);
			});

			if (!mallcheck) {
				return;
			}
			$("#method").val("doApplyUser");
			$("#params").val(JSON.stringify(data));
			_.loader.show();
			_.ajax(function(data) {
				_.loader.hide();
				var node = JSON.parse(data.result);
				if (node.code === "500") {
					var subNode = JSON.parse(node.data);
					location.href = subNode.redirectUrl + "?authId=" + subNode.authId;
					return;
				}
				toastr.warning(node.message);
			});
		});
		function checkPassword() {
			if ($("#cpwd").val() !== $("#cpwd1").val()) {
				$("#cpwd1").addClass("text-box-error");
				return false;
			}
			$("#cpwd1").removeClass("text-box-error");
			return true;
		}
		$(document).on("keyup", "#cpwd", function() {
			checkPassword();
		});
		$(document).on("keyup", "#cpwd1", function() {
			checkPassword();
		});

		$(document).on("click", ".mall-delete-btn", function() {
			$(this).parent().parent().remove();
		});
		$("#searchID").on('hidden.bs.modal', function() {
			$("#bizNo").val("");
		});
		$("#temporaryPW").on('hidden.bs.modal', function() {
			$("#tpid").val("");
		});
		$("#applicationForm").on('hidden.bs.modal', function() {
			$("#cid").val("");
			$("#cidCheck").val(0);
			$("#cauth").val("");
			$("#cpwd").val("");
			$("#cpwd1").val("");
			$("#ccomp").val("");
			$("#cbizno").val("");
			$("#cbiznoCheck").val(0);
			$("#cowner").val("");
			$("#cownerpCheck").val(0);
			$(".mall-select").material_select("destroy");
			$(".mall-select").val("");
			$(".mall-select").material_select();
			$(".mall-child").html("");
			$("#cid").prop("readonly", false);
			$("#mailCheckBtn").prop("disabled", false);
			$("#cidCheck").val(false);
			$("#duplicateCheckBtn").prop("disabled", false);
			$("#cbiznoCheckLabel").show();
			$("#cbiznoCheck").val(false);
			$("#cbizno").prop("readonly", false);
		});
		$(document).on("click", "#mailCheckBtn", function() {
			if ($.trim($("#cid").val()) === "") {
				toastr.warning("ID(메일주소)를 입력해 주십시오.");
				return;
			}
			if (!_.mailregex.test($("#cid").val())) {
				toastr.warning("이메일 형식으로 입력해 주십시오.");
				return;
			}
			$("#method").val("doCheckMailAddress");
			$("#params").val(JSON.stringify({
				mailaddress : $("#cid").val()
			}));
			_.ajax(function(data) {
				var node = JSON.parse(data.result);
				if (node.code === "300") {
					$("#mailCheckBtn").prop("disabled", true);
					$("#cidCheck").val(true);
					$("#cid").prop("readonly", true);
					toastr.info(node.message);
					return;
				}
				toastr.warning(node.message);
			});
		});
		$(document).on("click", "#duplicateCheckBtn", function() {
			if ($.trim($("#cid").val()) === "") {
				toastr.warning("ID(메일주소)를 입력해 주십시오.");
				return;
			}
			if ($.trim($("#cidCheck").val()) === "") {
				toastr.warning("인증 요청해 주십시오.");
				return;
			}
			if ($.trim($("#cbizno").val()) === "") {
				toastr.warning("사업자 등록번호를 입력해 주십시오.");
				return;
			}
			if (!_.numregex.test($("#cbizno").val())) {
				toastr.warning("입력 형식을 확인해 주십시오.");
				return;
			}
			$("#method").val("doCheckBizNo");
			$("#params").val(JSON.stringify({
				id : $("#cid").val(),
				bizno : $("#cbizno").val()
			}));
			_.ajax(function(data) {
				var node = JSON.parse(data.result);
				if (node.code === "400") {
					$("#duplicateCheckBtn").prop("disabled", true);
					$("#cbiznoCheckLabel").hide();
					$("#cbiznoCheck").val(true);
					$("#cbizno").prop("readonly", true);
					toastr.info(node.message);
					return;
				}
				toastr.warning(node.message);
			});
		});
		$(document).on("keydown", function(e) {
			if (e.keyCode === 13) {
				$("#loginBtn").trigger("click");
			}
		});
	},
	getParam : function(name) {
		var url = window.location.href;
		name = name.replace(/[\[\]]/g, "\\$&");
		var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"), results = regex.exec(url);
		if (!results) {
			return null;
		}
		if (!results[2]) {
			return '';
		}
		return decodeURIComponent(results[2].replace(/\+/g, " "));
	},
	ajax : function(cb) {
		$.ajax({
			url : "platformAPI",
			type : "POST",
			data : $("form").serialize(),
			dataType : "json",
			success : function(data, textStatus, jqXHR) {
				cb(data);
			}
		});
	},
	createTextBox : function(id, clazz, name, iptype) {
		var ret = $("<div></div>").addClass("form-group row oneId-app-row");
		ret.append($("<label></label>").addClass("col-5 col-form-label oneId-app-label").attr("for", id).text(name));
		ret.append($("<div></div>").addClass("col-7").append($("<div></div>").addClass("md-form mt-0 mall-form").append($("<input type=" + iptype + ">").addClass(clazz).addClass("form-control oneId-app-form-control mall-input").prop("id", id).attr("placeholder", name))));
		return ret;
	},
	loader : {
		show : function() {
			$(".loader-loc").show();
		},
		hide : function() {
			$(".loader-loc").hide();
		}
	}
});