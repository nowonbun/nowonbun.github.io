package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "error_log")
@NamedQuery(name = "ErrorLog.findAll", query = "SELECT e FROM ErrorLog e")
public class ErrorLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;

	@Column(name = "auth_id")
	private String authId;

	@Column(name = "error_cd")
	private String errorCd;

	@Column(name = "error_msg")
	private String errorMsg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	private String ip;

	private String remark;

	private int user;

	public ErrorLog() {
	}

	public int getIdx() {
		return this.idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getAuthId() {
		return this.authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}

	public String getErrorCd() {
		return this.errorCd;
	}

	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getUser() {
		return this.user;
	}

	public void setUser(int user) {
		this.user = user;
	}

}