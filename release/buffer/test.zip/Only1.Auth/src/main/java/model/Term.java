package model;

import java.io.Serializable;
import javax.persistence.*;

import model.key.TermPK;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "terms")
@NamedQuery(name = "Term.findAll", query = "SELECT t FROM Term t")
public class Term implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TermPK id;

	@Lob
	private String content;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_dt")
	private Date endDt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	@Column(name = "is_use")
	private boolean isUse;

	private String ix;

	private String remark;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_dt")
	private Date startDt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	@OneToMany(mappedBy = "term", fetch = FetchType.LAZY)
	private List<MemberTerm> memberTerms;

	public Term() {
	}

	public TermPK getId() {
		return this.id;
	}

	public void setId(TermPK id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public boolean getIsUse() {
		return this.isUse;
	}

	public void setIsUse(boolean isUse) {
		this.isUse = isUse;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public List<MemberTerm> getMemberTerms() {
		return this.memberTerms;
	}

	public void setMemberTerms(List<MemberTerm> memberTerms) {
		this.memberTerms = memberTerms;
	}

	public MemberTerm addMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().add(memberTerm);
		memberTerm.setTerm(this);

		return memberTerm;
	}

	public MemberTerm removeMemberTerm(MemberTerm memberTerm) {
		getMemberTerms().remove(memberTerm);
		memberTerm.setTerm(null);

		return memberTerm;
	}

}