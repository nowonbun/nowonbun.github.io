package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@NamedQuery(name = "Mall.findAll", query = "SELECT m FROM Mall m WHERE m.ix is null")
public class Mall implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "mall_id")
	private String mallId;

	@Column(name = "acc_type")
	private String accType;

	@Column(name = "class_cd")
	private String classCd;

	@Column(name = "id1_is_use")
	private boolean id1IsUse;

	@Column(name = "id1_name")
	private String id1Name;

	@Column(name = "id2_is_use")
	private boolean id2IsUse;

	@Column(name = "id2_name")
	private String id2Name;

	@Column(name = "id3_is_use")
	private boolean id3IsUse;

	@Column(name = "id3_name")
	private String id3Name;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "insert_dt")
	private Date insertDt;

	@Column(name = "insert_method")
	private String insertMethod;

	private String ix;

	@Column(name = "login_uri")
	private String loginUri;

	@Column(name = "mall_nm")
	private String mallNm;

	@Column(name = "option1_is_use")
	private boolean option1IsUse;

	@Column(name = "option1_name")
	private String option1Name;

	@Column(name = "option2_is_use")
	private boolean option2IsUse;

	@Column(name = "option2_name")
	private String option2Name;

	private int priority;

	@Column(name = "pw1_is_use")
	private boolean pw1IsUse;

	@Column(name = "pw1_name")
	private String pw1Name;

	@Column(name = "pw2_is_use")
	private boolean pw2IsUse;

	@Column(name = "pw2_name")
	private String pw2Name;

	private String remark;

	private String state;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_dt")
	private Date updateDt;

	@Column(name = "update_method")
	private String updateMethod;

	@OneToMany(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(name = "mall_id")
	private List<MemberMall> memberMalls;

	public Mall() {
	}

	public String getMallId() {
		return this.mallId;
	}

	public void setMallId(String mallId) {
		this.mallId = mallId;
	}

	public String getAccType() {
		return this.accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getClassCd() {
		return this.classCd;
	}

	public void setClassCd(String classCd) {
		this.classCd = classCd;
	}

	public boolean getId1IsUse() {
		return this.id1IsUse;
	}

	public void setId1IsUse(boolean id1IsUse) {
		this.id1IsUse = id1IsUse;
	}

	public String getId1Name() {
		return this.id1Name;
	}

	public void setId1Name(String id1Name) {
		this.id1Name = id1Name;
	}

	public boolean getId2IsUse() {
		return this.id2IsUse;
	}

	public void setId2IsUse(boolean id2IsUse) {
		this.id2IsUse = id2IsUse;
	}

	public String getId2Name() {
		return this.id2Name;
	}

	public void setId2Name(String id2Name) {
		this.id2Name = id2Name;
	}

	public boolean getId3IsUse() {
		return this.id3IsUse;
	}

	public void setId3IsUse(boolean id3IsUse) {
		this.id3IsUse = id3IsUse;
	}

	public String getId3Name() {
		return this.id3Name;
	}

	public void setId3Name(String id3Name) {
		this.id3Name = id3Name;
	}

	public Date getInsertDt() {
		return this.insertDt;
	}

	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}

	public String getInsertMethod() {
		return this.insertMethod;
	}

	public void setInsertMethod(String insertMethod) {
		this.insertMethod = insertMethod;
	}

	public String getIx() {
		return this.ix;
	}

	public void setIx(String ix) {
		this.ix = ix;
	}

	public String getLoginUri() {
		return this.loginUri;
	}

	public void setLoginUri(String loginUri) {
		this.loginUri = loginUri;
	}

	public String getMallNm() {
		return this.mallNm;
	}

	public void setMallNm(String mallNm) {
		this.mallNm = mallNm;
	}

	public boolean getOption1IsUse() {
		return this.option1IsUse;
	}

	public void setOption1IsUse(boolean option1IsUse) {
		this.option1IsUse = option1IsUse;
	}

	public String getOption1Name() {
		return this.option1Name;
	}

	public void setOption1Name(String option1Name) {
		this.option1Name = option1Name;
	}

	public boolean getOption2IsUse() {
		return this.option2IsUse;
	}

	public void setOption2IsUse(boolean option2IsUse) {
		this.option2IsUse = option2IsUse;
	}

	public String getOption2Name() {
		return this.option2Name;
	}

	public void setOption2Name(String option2Name) {
		this.option2Name = option2Name;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public boolean getPw1IsUse() {
		return this.pw1IsUse;
	}

	public void setPw1IsUse(boolean pw1IsUse) {
		this.pw1IsUse = pw1IsUse;
	}

	public String getPw1Name() {
		return this.pw1Name;
	}

	public void setPw1Name(String pw1Name) {
		this.pw1Name = pw1Name;
	}

	public boolean getPw2IsUse() {
		return this.pw2IsUse;
	}

	public void setPw2IsUse(boolean pw2IsUse) {
		this.pw2IsUse = pw2IsUse;
	}

	public String getPw2Name() {
		return this.pw2Name;
	}

	public void setPw2Name(String pw2Name) {
		this.pw2Name = pw2Name;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateMethod() {
		return this.updateMethod;
	}

	public void setUpdateMethod(String updateMethod) {
		this.updateMethod = updateMethod;
	}

	public List<MemberMall> getMemberMalls() {
		return this.memberMalls;
	}

	public void setMemberMalls(List<MemberMall> memberMalls) {
		this.memberMalls = memberMalls;
	}
}