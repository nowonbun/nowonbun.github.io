package model.key;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the member_service database table.
 * 
 */
@Embeddable
public class MemberServicePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(insertable=false, updatable=false)
	private int member;

	@Column(name="service", insertable=false, updatable=false)
	private String serviceId;

	public MemberServicePK() {
	}
	public int getMember() {
		return this.member;
	}
	public void setMember(int member) {
		this.member = member;
	}
	public String getServiceId() {
		return this.serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MemberServicePK)) {
			return false;
		}
		MemberServicePK castOther = (MemberServicePK)other;
		return 
			(this.member == castOther.member)
			&& this.serviceId.equals(castOther.serviceId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.member;
		hash = hash * prime + this.serviceId.hashCode();
		
		return hash;
	}
}