package dao;

import java.util.List;
import java.util.NoSuchElementException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import common.MasterDao;
import model.Mall;

public class MallDao extends MasterDao<Mall> {

	protected MallDao() {
		super(Mall.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<Mall> getDataList() {
		return transaction((em) -> {
			try {
				Query query = em.createNamedQuery("Mall.findAll", Mall.class);
				return (List<Mall>) query.getResultList();
			} catch (NoResultException e) {
				return null;
			}
		});
	}

	public Mall getTerm(String mallId) {
		try {
			return getData().stream().filter(x -> x.getMallId().equals(mallId)).findFirst().get();
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	public List<Mall> getMallAll() {
		return getData();
	}
}
