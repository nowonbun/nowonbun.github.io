package dao;

import common.TransactionDao;
import model.MemberService;

public class MemberServiceDao extends TransactionDao<MemberService> {

	protected MemberServiceDao() {
		super(MemberService.class);
	}
}
