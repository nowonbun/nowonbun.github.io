package dao;

import common.TransactionDao;
import model.MemberMall;

public class MemberMallDao extends TransactionDao<MemberMall> {

	protected MemberMallDao() {
		super(MemberMall.class);
	}
}
