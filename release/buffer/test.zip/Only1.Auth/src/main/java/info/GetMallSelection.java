package info;

import java.util.List;

import javax.servlet.annotation.WebServlet;

import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import dao.MallDao;
import model.Mall;

@WebServlet("/GetMallSelection")
public class GetMallSelection extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		List<Mall> list = FactoryDao.getDao(MallDao.class).getMallAll();
		StringBuffer sb = new StringBuffer();
		sb.append("<select class=\"mall-select\">");
		sb.append("<option value=\"\" disabled selected>쇼핑몰 선택</option>");
		for (Mall item : list) {
			sb.append("<option value=\"");
			sb.append(item.getMallId());
			sb.append("\" ");
			sb.append(" data-text-name=\"" + item.getMallNm() + "\" ");
			if (item.getId1IsUse()) {
				sb.append(" data-id1use=\"true\" ");
				sb.append(" data-id1Nm=\"");
				sb.append(item.getId1Name());
				sb.append("\" ");
			} else {
				sb.append(" data-id1use=\"false\" ");
			}
			if (item.getId2IsUse()) {
				sb.append(" data-id2use=\"true\" ");
				sb.append(" data-id2Nm=\"");
				sb.append(item.getId2Name());
				sb.append("\" ");
			} else {
				sb.append(" data-id2use=\"false\" ");
			}
			if (item.getId3IsUse()) {
				sb.append(" data-id3use=\"true\" ");
				sb.append(" data-id3Nm=\"");
				sb.append(item.getId3Name());
				sb.append("\" ");
			} else {
				sb.append(" data-id3use=\"false\" ");
			}
			if (item.getPw1IsUse()) {
				sb.append(" data-pw1use=\"true\" ");
				sb.append(" data-pw1Nm=\"");
				sb.append(item.getPw1Name());
				sb.append("\" ");
			} else {
				sb.append(" data-pw1use=\"false\" ");
			}
			if (item.getPw2IsUse()) {
				sb.append(" data-pw2use=\"true\" ");
				sb.append(" data-pw2Nm=\"");
				sb.append(item.getPw2Name());
				sb.append("\" ");
			} else {
				sb.append(" data-pw2use=\"false\" ");
			}
			if (item.getOption1IsUse()) {
				sb.append(" data-op1use=\"true\" ");
				sb.append(" data-op1Nm=\"");
				sb.append(item.getOption1Name());
				sb.append("\" ");
			} else {
				sb.append(" data-op1use=\"false\" ");
			}
			if (item.getOption2IsUse()) {
				sb.append(" data-op2use=\"true\" ");
				sb.append(" data-op2Nm=\"");
				sb.append(item.getOption2Name());
				sb.append("\" ");
			} else {
				sb.append(" data-op2use=\"false\" ");
			}
			sb.append(">");
			sb.append(item.getMallNm());
			sb.append("</option>");
		}
		sb.append("</select>");
		getResponse().setContentType("text/html;charset=UTF-8");
		getPrinter().write(sb.toString());
	}

}
