package info;

import javax.servlet.annotation.WebServlet;

import bean.RequestParameter;
import bean.ResponseParameter;
import bean.UserBean;
import common.IServlet;
import login.Login;

@WebServlet("/getuserinfo")
@Deprecated
public class GetUserInfo extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		String authId = getRequest().getParameter(Login.AUTH_ID);
		if (authId == null) {
			setStatus(400);
			return;
		}
		// TODO: select from DB
		UserBean bean = new UserBean();
		bean.setUid("test");

		getPrinter().write(bean.toJson());
	}

}