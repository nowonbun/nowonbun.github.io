package login;

import bean.ApplyBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.UserDao;
import model.User;

public class SetPassword extends IServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		ApplyBean apply = null;
		try {
			apply = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				ApplyBean bean = new ApplyBean();
				bean.setId(JsonConverter.JsonString(obj, "id"));
				bean.setPwd(JsonConverter.JsonString(obj, "pwd"));
				return bean;
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(apply.getId());
		if (user == null) {
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return;
		}
		user.setPassword(Util.convertMD5(apply.getPwd()));
		FactoryDao.getDao(UserDao.class).update(user);
		resParam.setCode(ResponseCodeMap.CODE506);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE506));
	}
}
