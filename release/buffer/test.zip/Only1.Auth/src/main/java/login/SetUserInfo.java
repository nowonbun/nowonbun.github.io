package login;

import java.util.ArrayList;
import java.util.Date;
import javax.json.JsonArray;
import bean.ApplyBean;
import bean.ApplyMallBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.MallDao;
import dao.UserDao;
import model.Member;
import model.MemberMall;
import model.User;

public class SetUserInfo extends IServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		ApplyBean apply = null;
		try {
			apply = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				ApplyBean bean = new ApplyBean();
				bean.setId(JsonConverter.JsonString(obj, "id"));
				bean.setOwner(JsonConverter.JsonString(obj, "owner"));
				bean.setOwnerp(JsonConverter.JsonString(obj, "ownerp"));
				bean.setOwnerpCheck("true".equals(JsonConverter.JsonString(obj, "ownerpCheck")));
				bean.setMallcount(JsonConverter.JsonInteger(obj, "mallcount"));
				bean.setMall(new ArrayList<>());
				JsonArray array = obj.getJsonArray("mall");
				for (int i = 0; i < bean.getMallcount(); i++) {
					bean.getMall().add(JsonConverter.parseObject(array.get(i).toString(), (subobj) -> {
						ApplyMallBean sub = new ApplyMallBean();
						sub.setCode(JsonConverter.JsonString(subobj, "code"));
						sub.setId1(JsonConverter.JsonString(subobj, "id1"));
						sub.setId2(JsonConverter.JsonString(subobj, "id2"));
						sub.setId3(JsonConverter.JsonString(subobj, "id3"));
						sub.setPw1(JsonConverter.JsonString(subobj, "pw1"));
						sub.setPw2(JsonConverter.JsonString(subobj, "pw2"));
						sub.setOp1(JsonConverter.JsonString(subobj, "op1"));
						sub.setOp2(JsonConverter.JsonString(subobj, "op2"));
						return sub;
					}));
				}
				return bean;
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		if (apply.getId() == null) {
			resParam.setCode(ResponseCodeMap.CODE202);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE202));
			return;
		}

		if (!apply.isOwnerpCheck()) {
			resParam.setCode(ResponseCodeMap.CODE502);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE502));
			return;
		}
		User user = FactoryDao.getDao(UserDao.class).getUser(apply.getId());
		if (user == null) {
			resParam.setCode(ResponseCodeMap.CODE502);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE502));
			return;
		}
		try {
			Member member = user.getMemberBean();
			if (apply.getOwner() != null) {
				member.setCeoNm(apply.getOwner());
			}
			if (apply.getOwnerp() != null) {
				member.setCeoPhone(apply.getOwnerp());
			}
			member.setUpdateDt(new Date());
			member.setUpdateMethod(getClass().getName());

			member.getMemberMalls().clear();
			for (ApplyMallBean bean : apply.getMall()) {
				MemberMall mall = new MemberMall();
				mall.setMall(FactoryDao.getDao(MallDao.class).getTerm(bean.getCode()));
				mall.setId1Value(bean.getId1());
				mall.setId2Value(bean.getId2());
				mall.setId3Value(bean.getId3());
				mall.setPw1Value(bean.getPw1());
				mall.setPw2Value(bean.getPw2());
				mall.setOption1Value(bean.getOp1());
				mall.setOption2Value(bean.getOp2());
				mall.setInsertDt(new Date());
				mall.setInsertMethod(getClass().getName());
				mall.setUpdateDt(new Date());
				mall.setUpdateMethod(getClass().getName());
				member.addMemberMall(mall);
			}

			FactoryDao.getDao(UserDao.class).update(user);

			resParam.setCode(ResponseCodeMap.CODE505);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE505));
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
	}
}
