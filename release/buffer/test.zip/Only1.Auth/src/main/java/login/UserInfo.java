package login;

public class UserInfo {

}
