package login;

import java.util.Date;

import bean.CheckBizNoBean;
import bean.RequestParameter;
import bean.ResponseParameter;
import common.FactoryDao;
import common.IServlet;
import common.JsonConverter;
import common.ResponseCodeMap;
import common.Util;
import dao.CheckingTemporaryDao;
import dao.MemberDao;
import model.CheckingTemporary;
import model.Member;

public class CheckBizNo extends IServlet {

	private static final long serialVersionUID = 1L;

	public static String TemporaryBIZNOCheckCode = "BIZNO";

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		if (reqParam.getParams() == null || Util.StringIsEmptyOrNull(reqParam.getParams())) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		CheckBizNoBean bean = null;
		try {
			bean = JsonConverter.parseObject(reqParam.getParams(), (obj) -> {
				CheckBizNoBean ret = new CheckBizNoBean();
				ret.setBizNo(JsonConverter.JsonString(obj, "bizno"));
				ret.setId(JsonConverter.JsonString(obj, "id"));
				return ret;
			});
		} catch (Throwable e) {
			resParam.setCode(ResponseCodeMap.CODE201);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE201));
			return;
		}
		Member member = FactoryDao.getDao(MemberDao.class).getMemberByBizNo(bean.getBizNo());
		if (member == null) {
			getTemporary(bean.getId(), bean.getBizNo());
			resParam.setCode(ResponseCodeMap.CODE400);
			resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE400));
			return;
		}

		resParam.setCode(ResponseCodeMap.CODE401);
		resParam.setMessage(ResponseCodeMap.getCodeMessage(ResponseCodeMap.CODE401));
	}

	private CheckingTemporary getTemporary(String id, String bizno) {
		FactoryDao.getDao(CheckingTemporaryDao.class).disabledAllType(TemporaryBIZNOCheckCode, id);
		CheckingTemporary ret = new CheckingTemporary();
		ret.setType(TemporaryBIZNOCheckCode);
		ret.setId(id);
		ret.setData(id);
		ret.setValue(bizno);
		ret.setIsCheck(false);
		ret.setUpdateDt(new Date());
		FactoryDao.getDao(CheckingTemporaryDao.class).update(ret);
		return ret;
	}
}