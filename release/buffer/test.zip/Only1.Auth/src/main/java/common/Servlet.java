package common;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.annotation.WebServlet;
import bean.RequestParameter;
import bean.ResponseParameter;
import bean.ResultBean;
import login.ApplyUser;
import login.CheckBizNo;
import login.CheckMailAddress;
import login.Login;
import login.LoginState;
import login.Logout;
import login.SearchUserId;
import login.SendTemporaryPw;
import login.SetPassword;
import login.SetUserInfo;

@WebServlet("/platformAPI")
public class Servlet extends IServlet {

	private static final long serialVersionUID = 1L;
	private String method;
	private String serviceid;
	private static Map<String, IServlet> binderFlyweight = null;

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		initBinder();
		IServlet worker = null;
		if ((worker = validate()) == null) {
			setStatus(403);
			return;
		}
		reqParam.setMethod(this.method);
		reqParam.setServiceid(this.serviceid);
		reqParam.setParams(getRequest().getParameter("params"));

		worker.doWork(getRequest(), getResponse(), reqParam, resParam);
		ResultBean result = new ResultBean();
		result.setResult(JsonConverter.create(resParam));
		String json = JsonConverter.create(result);

		getResponse().setContentType("text/html;charset=UTF-8");
		getPrinter().write(json);

	}

	private void initBinder() {
		if (binderFlyweight == null) {
			binderFlyweight = new HashMap<>();
			binderFlyweight.put("doLogin", new Login());
			binderFlyweight.put("doLoginState", new LoginState());
			binderFlyweight.put("doLogout", new Logout());
			binderFlyweight.put("doSearchUserId", new SearchUserId());
			binderFlyweight.put("doSendTemporaryPw", new SendTemporaryPw());
			binderFlyweight.put("doCheckMailAddress", new CheckMailAddress());
			binderFlyweight.put("doCheckBizNo", new CheckBizNo());
			binderFlyweight.put("doApplyUser", new ApplyUser());
			binderFlyweight.put("doSetUserInfo", new SetUserInfo());
			binderFlyweight.put("doSetPassword", new SetPassword());
		}
	}

	private IServlet validate() {
		this.method = getRequest().getParameter("_method");
		if (Util.StringIsEmptyOrNull(this.method)) {
			return null;
		}
		this.serviceid = getRequest().getParameter("serviceid");
		if (Util.StringIsEmptyOrNull(this.serviceid)) {
			return null;
		}
		if (binderFlyweight.containsKey(this.method)) {
			return binderFlyweight.get(this.method);
		}
		return null;
	}
}
