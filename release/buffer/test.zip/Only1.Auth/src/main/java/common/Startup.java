package common;

import javax.servlet.annotation.WebServlet;

import bean.RequestParameter;
import bean.ResponseParameter;

@WebServlet("/Startup")
public class Startup extends IServlet {

	private static final long serialVersionUID = 1L;

	public void init() {
		FactoryDao.initializeMaster();
	}

	@Override
	protected void doMain(RequestParameter reqParam, ResponseParameter resParam) {
		FactoryDao.resetMaster();
	}

}
