import java.util.List;

import common.FactoryDao;
import dao.CmcodeDao;
import dao.UserDao;
import model.Cmcode;
import model.User;

public class DaoTest {

	public static void main(String... args) {
		List<Cmcode> list = FactoryDao.getDao(CmcodeDao.class).getCmcodeAll();
		for (Cmcode entity : list) {
			System.out.println(entity.getId().getGroupCd() + "  " + entity.getId().getCode());
		}
		List<User> a = FactoryDao.getDao(UserDao.class).findAll();
		User user = FactoryDao.getDao(UserDao.class).getUser("nowonbun@test.com");
		System.out.println(user.getEmail());
		for (User b : a) {
			System.out.println(b);
		}
	}
}
