<?php
include_once $_SERVER ['DOCUMENT_ROOT'] . './AbstractClass.php';
class Index extends Only1Auth{
	public function run() {
		$authId = $_SESSION["authId"];
		if(!parent::isLogin($authId)){
			parent::redirect(parent::getServiceUrl()."?serviceid=63414DE4-EAB0-4A73-9AF6-000B393811EB");
			return;
		}
	}
	public function logoutUrl(){
		return parent::getServiceUrl(). "platformAPI?_method=doLogout&serviceid=63414DE4-EAB0-4A73-9AF6-000B393811EB";
	}
	public function platform(){
		return parent::getServiceUrl(). "platformAPI";
	}
}
$obj = new Index();
$obj->run();
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<form action="<?=$obj->platform()?>" id="form">	
		<input type="text" name="_method" id="method" value="doSetPassword">
		<input type="text" name="serviceid" id="serviceid" value="63414DE4-EAB0-4A73-9AF6-000B393811EB">
		<input type="text" name="params" id="params" value="">
	</form>
	<a href="<?=$obj->logoutUrl()?>">logout</a>
	
	<fieldset>
		<legend>password:</legend>
		id : <input type="text" id="id">
		<br />
		pw : <input type="text" id="pwd">
		<br />
		<button id="pwdsetting">password setting</button>
	</fieldset>
	
	<script type="text/javascript" src="//code.jquery.com/jquery-3.3.1.min.js"></script>
	<script>
		$(function(){
			$(document).on("click","#pwdsetting",function(){
				$("#params").val(JSON.stringify({
					id : $("#id").val(),
					pwd: $("#pwd").val()
				}));
				$.ajax({
					url : "<?=$obj->platform()?>",
					type : "POST",
					data : $("form").serialize(),
					dataType : "jsonp",
					success : function(data, textStatus, jqXHR) {
						console.log(data);
					}
				});
			});
		});
	</script>
</body>
</html>